# Blackstock v11 – Production Checklist

## Portable Release Gates

- [ ] `Build/Core-Tests.sh` vollständig grün
- [ ] `Build/Release-Audit.sh` vollständig grün
- [ ] gesamter Swift-Quellbaum parsebar
- [ ] keine `try!`, `fatalError` oder erzwungenen Casts in `Sources/`
- [ ] Version `11.1.0`, Build `1110` aus `Build/version.env`
- [ ] `RELEASE_NOTES_v11.md`, README, Architektur und Installation vorhanden
- [ ] v10→v11 Migration erhält IDs und erstellt Pre-v11-Snapshot
- [ ] Revenue ohne Scope erscheint als nicht verfügbar, nicht als `0 €`
- [ ] Sport bleibt unabhängig von geladenen Trends als Filter verfügbar
- [ ] Rights `unknown/restricted/expired` blockieren Auto-Publishing
- [ ] lizenzierte Quelle ohne Edit/Publish/Commercial-Recht blockiert Auto-Publishing
- [ ] RemixTimeline validiert Reihenfolge, Dauer und Segmentüberschneidungen
- [ ] YouTube Upload ist resumable und idempotent
- [ ] Projektlöschung löscht keine importierten Originalmedien

## macOS Release Gates

Diese Punkte müssen auf einem echten macOS/Xcode-Runner geprüft werden:

- [ ] nativer arm64 Build
- [ ] nativer x86_64 Build
- [ ] Universal Binary enthält beide Architekturen
- [ ] App-Bundle startet
- [ ] SwiftUI/AppKit/AVFoundation Smoke Test
- [ ] `codesign --verify --deep --strict`
- [ ] Developer-ID-Signatur korrekt
- [ ] DMG erstellt
- [ ] Notarisierung erfolgreich und Staple vorhanden
- [ ] OAuth Login gegen echten Test-Account
- [ ] mindestens zwei Kanäle unter einem Google-Login geprüft
- [ ] echte tägliche YouTube Analytics geprüft
- [ ] Revenue-Flow mit und ohne monetären Scope geprüft
- [ ] resumable Upload einschließlich künstlichem Verbindungsabbruch geprüft
- [ ] Review-Modus und Auto-Publish jeweils Ende-zu-Ende geprüft
- [ ] FFmpeg Live-Playout gegen Testbroadcast geprüft, sofern Live releast wird

## Release-Regel

Kein „vollständig getestet“-Claim ohne abgeschlossenen macOS-Link-/Launch-/Codesign-Test. Keine Demo-/Seed-Daten in echten verbundenen Accounts. Keine Fake-Live-, Fake-Revenue- oder Fake-Analytics-Zustände.
