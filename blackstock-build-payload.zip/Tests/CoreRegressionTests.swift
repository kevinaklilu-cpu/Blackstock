import Foundation

@main
struct CoreRegressionTests {
  static func main() throws {
    try migrationVonV52()
    try qualityGateSemantik()
    try lokaleQualitaet()
    print("BLACKSTOCK_CORE_TESTS_OK")
  }

  static func migrationVonV52() throws {
    let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
    let fixture = root.appendingPathComponent("Tests/Fixtures/v5_2-state.json")
    let data = try Data(contentsOf: fixture)
    let decoder = JSONDecoder()
    decoder.dateDecodingStrategy = .iso8601
    let state = try decoder.decode(AppZustand.self, from: data)
    guard state.kanaele.count == 3 else {
      throw Fehler("v5.2 Kanäle gingen bei Migration verloren")
    }
    guard state.chancen.count == 3 else {
      throw Fehler("v5.2 Chancen gingen bei Migration verloren")
    }
    guard state.produktionen.count == 3 else {
      throw Fehler("v5.2 Produktionen gingen bei Migration verloren")
    }
    guard state.videos.count == 2 else { throw Fehler("v5.2 Videos gingen bei Migration verloren") }
    guard state.provider.count == 5 else {
      throw Fehler("v5.2 Provider gingen bei Migration verloren")
    }
    guard state.medien.isEmpty && state.batchAuftraege.isEmpty && state.automationsregeln.isEmpty
    else {
      throw Fehler("Neue v6-Felder wurden nicht sauber mit Defaults migriert")
    }
  }

  static func qualityGateSemantik() throws {
    var q = Qualitaetsprofil(
      story: 95, hook: 95, visuals: 0, schnitt: 0, stimme: 0, audio: 0,
      thumbnail: 0, titel: 95, originalitaet: 95, fakten: 0, rechte: 0, policy: 0, technisch: 0)
    guard !q.offeneGates.isEmpty else {
      throw Fehler("Ungeprüfte Gates dürfen nicht als bestanden gelten")
    }
    guard q.fehlgeschlageneGates.isEmpty else {
      throw Fehler("Ungeprüfte Gates dürfen nicht als Fehler gelten")
    }
    q.visuals = 60
    guard q.fehlgeschlageneGates.contains(where: { $0.hasPrefix("Bildwelt") }) else {
      throw Fehler("Ein tatsächlich schlechter geprüfter Wert muss als Fehler markiert werden")
    }
  }

  static func lokaleQualitaet() throws {
    let q = Qualitaetsprofil(
      story: 0, hook: 0, visuals: 0, schnitt: 0, stimme: 0, audio: 0,
      thumbnail: 0, titel: 0, originalitaet: 0, fakten: 0, rechte: 0, policy: 0, technisch: 0)
    let p = Produktion(
      kanalID: UUID(), chanceID: nil, arbeitstitel: "Warum dieses Format besser funktioniert",
      format: .short, status: .skript, erstelltAm: Date(), geplantFuer: nil,
      zielDauerSekunden: 45,
      skript: String(
        repeating: "Eine konkrete Aussage mit Erklärung, Beispiel und Nutzen. ", count: 25),
      hook: "Das verändert deinen Workflow stärker als du denkst.",
      thumbnailIdee: "Besserer Workflow", voiceDirection: "Natürlich",
      storyboardNotizen: "", qualitaet: q, konfidenz: 0.95,
      erwarteteViews24h: 1_000, erwarteteAbonnenten: 10, erwarteterUmsatz: 0)
    let result = QualityEngineService.shared.bewerten(
      produktion: p, medien: [], andereProduktionen: [])
    guard result.story != nil, result.hook != nil, result.titel != nil else {
      throw Fehler("Lokale Vorprüfung muss vorhandene Redaktionsteile bewerten")
    }
    guard result.rechte == nil else {
      throw Fehler("Ohne Medien darf die Rechteprüfung nicht erfunden werden")
    }
  }

  struct Fehler: Error, CustomStringConvertible {
    let description: String
    init(_ description: String) { self.description = description }
  }
}
