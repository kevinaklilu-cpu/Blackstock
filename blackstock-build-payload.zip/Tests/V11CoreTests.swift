import Foundation

@main
struct V11CoreTests {
  struct Failure: Error, CustomStringConvertible {
    let description: String
    init(_ description: String) { self.description = description }
  }

  static func main() throws {
    try taxonomyIsStable()
    try analyticsArePeriodCorrect()
    try incompleteRevenueIsUnavailable()
    try rightsBlockUnsafeSources()
    try remixIsValidAndNonOverlapping()
    try readyCheckUsesActionableFacts()
    try legacyStateDecodesWithoutV11()
    print("BLACKSTOCK_V11_CORE_TESTS_OK")
  }

  static func taxonomyIsStable() throws {
    guard TopicTaxonomy.stableCategories.contains(.sport) else { throw Failure("Sport fehlt aus stabiler Taxonomie") }
    guard TopicTaxonomy.stableCategories.contains(.football) else { throw Failure("Fußball fehlt aus stabiler Taxonomie") }
  }

  static func analyticsArePeriodCorrect() throws {
    var calendar = Calendar(identifier: .gregorian)
    calendar.timeZone = TimeZone(secondsFromGMT: 0)!
    let formatter = ISO8601DateFormatter()
    let channel = UUID()
    let start = formatter.date(from: "2026-09-10T00:00:00Z")!
    let end = formatter.date(from: "2026-09-12T00:00:00Z")!
    let points = [
      AnalyticsDailyPoint(channelID: channel, date: end, views: 30, watchTimeMinutes: 60, subscribersGained: 3, subscribersLost: 1, estimatedRevenue: 3),
      AnalyticsDailyPoint(channelID: channel, date: start, views: 10, watchTimeMinutes: 20, subscribersGained: 1, subscribersLost: 0, estimatedRevenue: 1),
    ]
    let normalized = AnalyticsNormalizer.normalized(points: points, channelIDs: [channel], from: start, through: end, revenueComplete: true, calendar: calendar)
    guard normalized.count == 3 else { throw Failure("Fehlende Analytics-Tage wurden nicht normalisiert") }
    guard normalized.map(\.date) == normalized.map(\.date).sorted() else { throw Failure("Tageswerte sind nicht sortiert") }
    guard normalized[1].views == 0 else { throw Failure("Fehlender Tag muss bei Views 0 sein") }
  }

  static func incompleteRevenueIsUnavailable() throws {
    let channel = UUID()
    let date = Date()
    let points = [AnalyticsDailyPoint(channelID: channel, date: date, views: 20, watchTimeMinutes: 10, subscribersGained: 1, subscribersLost: 0, estimatedRevenue: 4)]
    let normalized = AnalyticsNormalizer.normalized(points: points, channelIDs: [channel], from: date, through: date, revenueComplete: false)
    guard normalized.first?.estimatedRevenue == nil else { throw Failure("Unvollständiger Revenue-Zugriff darf nicht als Teilumsatz erscheinen") }
    guard AnalyticsNormalizer.summary(normalized).estimatedRevenue == nil else { throw Failure("Revenue Summary muss nil bleiben") }
  }

  static func rightsBlockUnsafeSources() throws {
    let unsafe = SourceAsset(provider: .directHTTPS, remoteURL: "https://example.com/a.mp4", title: "A", duration: 30, rightsStatus: .unknown, allowedUses: [])
    guard !unsafe.canAutoPublish, RightsService.blockingReason(unsafe) != nil else { throw Failure("Unbekannte Rechte müssen blockieren") }
    let incomplete = SourceAsset(provider: .directHTTPS, remoteURL: "https://example.com/b.mp4", title: "B", duration: 30, licenseType: nil, rightsStatus: .licensed, allowedUses: [.edit, .publish])
    guard !incomplete.canAutoPublish else { throw Failure("Lizenz ohne Lizenztyp darf nicht automatisch veröffentlichen") }
    let owned = SourceAsset(provider: .directHTTPS, remoteURL: "https://example.com/c.mp4", title: "C", duration: 70, licenseType: "User-owned media", rightsStatus: .owned, allowedUses: [.edit, .publish], channelOwnership: true)
    guard owned.canAutoPublish else { throw Failure("Eigenes Material muss nutzbar sein") }
  }

  static func remixIsValidAndNonOverlapping() throws {
    let a = SourceAsset(provider: .directHTTPS, remoteURL: "https://example.com/a.mp4", title: "A", duration: 80, licenseType: "User-owned media", rightsStatus: .owned, allowedUses: [.edit, .publish], channelOwnership: true, transcript: "Jetzt ist entscheidend warum dieses Ergebnis wichtig ist.")
    let b = SourceAsset(provider: .directHTTPS, remoteURL: "https://example.com/b.mp4", title: "B", duration: 90, licenseType: "User-owned media", rightsStatus: .owned, allowedUses: [.edit, .publish], channelOwnership: true, transcript: "Ein überraschendes Ergebnis zeigt das Problem und die Lösung.")
    let timeline = try RemixPlannerService().plan(sources: [a, b], mode: .remix, requestedFormat: .short)
    guard timeline.isValid, timeline.format == .short else { throw Failure("Short-Remix ungültig") }
    guard timeline.segments.allSatisfy({ $0.cropMode == .smartReframe }) else { throw Failure("Shorts müssen Smart Reframe verwenden") }
    for source in [a.id, b.id] {
      let ranges = timeline.segments.filter { $0.sourceAssetID == source }.map { ($0.startTime, $0.endTime) }
      for i in ranges.indices { for j in ranges.indices where i < j {
        guard max(ranges[i].0, ranges[j].0) >= min(ranges[i].1, ranges[j].1) else { throw Failure("Remix enthält überlappende Duplikatsegmente") }
      }}
    }
  }

  static func readyCheckUsesActionableFacts() throws {
    let channelID = UUID()
    let source = SourceAsset(provider: .directHTTPS, remoteURL: "https://example.com/a.mp4", title: "A", duration: 30, licenseType: "User-owned media", rightsStatus: .owned, allowedUses: [.edit, .publish], channelOwnership: true)
    let timeline = RemixTimeline(format: .short, duration: 20, segments: [RemixSegment(sourceAssetID: source.id, startTime: 0, endTime: 20, cropMode: .smartReframe, order: 0)])
    let q = Qualitaetsprofil(story: 0, hook: 0, visuals: 0, schnitt: 0, stimme: 0, audio: 0, thumbnail: 0, titel: 0, originalitaet: 0, fakten: 0, rechte: 0, policy: 0, technisch: 0)
    var p = Produktion(kanalID: channelID, chanceID: nil, arbeitstitel: "Titel", format: .short, status: .bereit, erstelltAm: Date(), geplantFuer: nil, zielDauerSekunden: 20, skript: "", hook: "", thumbnailIdee: "", voiceDirection: "", storyboardNotizen: "", qualitaet: q, konfidenz: 0, erwarteteViews24h: 0, erwarteteAbonnenten: 0, erwarteterUmsatz: 0)
    p.beschreibung = "Beschreibung"
    let state = ProductionV11State(productionID: p.id, mode: .short, phase: .ready, sourceAssetIDs: [source.id], timeline: timeline)
    let check = ReadyCheckEngine.evaluate(production: p, v11: state, sources: [source], targetChannelExists: true, renderedFileExists: true, thumbnailFileExists: false)
    guard check.canPublish else { throw Failure("Short darf ohne erzwungenes Thumbnail bei sonst vollständigem Ready Check veröffentlichbar sein: \(check.issues)") }
  }

  static func legacyStateDecodesWithoutV11() throws {
    let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
    let data = try Data(contentsOf: root.appendingPathComponent("Tests/Fixtures/v5_2-state.json"))
    let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
    let state = try decoder.decode(AppZustand.self, from: data)
    guard state.v11 == nil else { throw Failure("Legacy-Fixture darf nicht fälschlich bereits v11 sein") }
  }
}
