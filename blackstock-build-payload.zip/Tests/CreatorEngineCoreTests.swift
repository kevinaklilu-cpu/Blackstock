import Foundation

@main
struct CreatorEngineCoreTests {
  static func main() throws {
    try presetKatalog()
    try providerMigration()
    try localCreator()
    try topicAlignment()
    print("BLACKSTOCK_CREATOR_ENGINE_TESTS_OK")
  }

  static func presetKatalog() throws {
    for typ in [ProviderVerbindung.Typ.research, .voice, .image, .video, .music] {
      let presets = EnginePresetService.presets(fuer: typ)
      guard !presets.isEmpty else { throw Fehler("Kein Engine-Preset für \(typ.rawValue)") }
      let standard = EnginePresetService.standardPreset(fuer: typ)
      guard !standard.id.isEmpty else { throw Fehler("Standard-Preset ohne ID") }
    }
    guard EnginePresetService.standardPreset(fuer: .research).id == "local-creator" else {
      throw Fehler("Zero-Setup Creator muss den immer verfügbaren lokalen Creator verwenden")
    }
    guard EnginePresetService.standardPreset(fuer: .research).brauchtAPIKey == false else {
      throw Fehler("Zero-Setup Creator darf keinen API-Key verlangen")
    }
    guard EnginePresetService.presets(fuer: .research).contains(where: { $0.id == "local-creator" })
    else {
      throw Fehler("Lokaler Creator-Fallback fehlt")
    }
    guard EnginePresetService.standardPreset(fuer: .voice).brauchtAPIKey == false else {
      throw Fehler("Zero-Setup Voice darf keinen Key verlangen")
    }
    guard EnginePresetService.standardPreset(fuer: .image).id == "local-thumbnail" else {
      throw Fehler("Zero-Setup Thumbnail muss den robusten lokalen Renderer verwenden")
    }
    guard EnginePresetService.standardPreset(fuer: .image).brauchtAPIKey == false else {
      throw Fehler("Zero-Setup Thumbnail darf keinen Key verlangen")
    }
    guard EnginePresetService.presets(fuer: .image).contains(where: { $0.id == "local-thumbnail" })
    else {
      throw Fehler("Lokaler Thumbnail-Fallback fehlt")
    }
    guard EnginePresetService.standardPreset(fuer: .video).brauchtAPIKey == false else {
      throw Fehler("Zero-Setup Visual darf keinen Key verlangen")
    }
  }

  static func providerMigration() throws {
    let legacy = ProviderVerbindung(
      typ: .video, name: "Legacy Video", verbunden: true, detail: "alt",
      basisURL: nil, modell: nil, apiKeyVorhanden: nil, optionen: nil)
    let migrated = EnginePresetService.normalisieren([legacy])
    guard migrated.count == 5 else {
      throw Fehler("Provider-Migration muss alle fünf Engine-Typen ergänzen")
    }
    guard migrated.first(where: { $0.typ == .video })?.optionen?["preset"] == "local-visual" else {
      throw Fehler("Leere Legacy-Video-Engine wurde nicht auf sicheren lokalen Fallback migriert")
    }

    let oldAppleImage = ProviderVerbindung(
      typ: .image, name: "Apple Image Playground", verbunden: true, detail: "legacy",
      basisURL: "apple://image-playground", modell: "system-image", apiKeyVorhanden: true,
      optionen: ["preset": "apple-image", "adapter": "apple-image"])
    let migratedImage = EnginePresetService.normalisieren([oldAppleImage])
      .first(where: { $0.typ == .image })
    guard migratedImage?.optionen?["preset"] == "local-thumbnail" else {
      throw Fehler(
        "Eingestellte Apple-Image-Creator-Konfiguration muss auf lokalen Renderer migrieren")
    }

    let custom = ProviderVerbindung(
      typ: .video, name: "Eigene Engine", verbunden: true, detail: "custom",
      basisURL: "https://example.invalid/v1", modell: "my-model", apiKeyVorhanden: true,
      optionen: ["adapter": "custom"])
    let preserved = EnginePresetService.normalisieren([custom])
      .first(where: { $0.typ == .video })
    guard preserved?.basisURL == custom.basisURL, preserved?.modell == custom.modell else {
      throw Fehler("Eigene Provider-Konfiguration darf beim Upgrade nicht überschrieben werden")
    }
  }

  static func localCreator() throws {
    let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
    let fixture = root.appendingPathComponent("Tests/Fixtures/v5_2-state.json")
    let data = try Data(contentsOf: fixture)
    let decoder = JSONDecoder()
    decoder.dateDecodingStrategy = .iso8601
    let state = try decoder.decode(AppZustand.self, from: data)
    guard let chance = state.chancen.first, let kanal = state.kanaele.first else {
      throw Fehler("Fixture enthält keine Chance oder keinen Kanal")
    }
    let short = LocalCreatorService.produktionsPaket(
      chance: chance, kanal: kanal, format: .short, modus: .studio)
    guard !short.titel.isEmpty, !short.hook.isEmpty, short.szenen.count >= 6 else {
      throw Fehler("Lokaler Short-Entwurf ist unvollständig")
    }
    guard short.tags.count <= 12 else { throw Fehler("Zu viele Tags") }
    let long = LocalCreatorService.produktionsPaket(
      chance: chance, kanal: kanal, format: .longform, modus: .master)
    guard long.szenen.count >= 10, long.skript.count > short.skript.count else {
      throw Fehler("Longform-Entwurf ist nicht ausreichend strukturiert")
    }
  }

  static func topicAlignment() throws {
    let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
    let fixture = root.appendingPathComponent("Tests/Fixtures/v5_2-state.json")
    let data = try Data(contentsOf: fixture)
    let decoder = JSONDecoder()
    decoder.dateDecodingStrategy = .iso8601
    let state = try decoder.decode(AppZustand.self, from: data)
    guard let baseChance = state.chancen.first, let kanal = state.kanaele.first else {
      throw Fehler("Fixture enthält keine Chance oder keinen Kanal")
    }
    let themen = [
      ("Gaming", "Neue Gameplay-Mechanik verändert das Matchmaking"),
      ("Politik", "Bundestagsdebatte über ein neues Digitalgesetz"),
      ("Business", "Neues Startup-Modell für Creator-Software"),
      ("Wissenschaft", "Neue Studie zur Batterieforschung"),
      ("Gesundheit", "Fitness-Training und Regeneration im Alltag"),
      ("Auto", "Elektroauto-Laden im Alltag"),
    ]
    for (thema, titel) in themen {
      var chance = baseChance
      chance.thema = thema
      chance.titel = titel
      chance.begruendung = "Testsignal für \(thema)"
      let paket = LocalCreatorService.produktionsPaket(
        chance: chance, kanal: kanal, format: .short, modus: .studio)
      let combined = "\(paket.titel) \(paket.hook) \(paket.beschreibung) \(paket.skript)"
        .lowercased()
      let anchor = thema.lowercased()
      guard
        combined.contains(anchor)
          || combined.contains(
            titel.lowercased().split(separator: " ").first.map(String.init) ?? "")
      else {
        throw Fehler("Lokaler Creator driftet beim Thema \(thema) ab")
      }
      guard paket.beschreibung.count >= 100, paket.szenen.count >= 6 else {
        throw Fehler("Themenspezifischer Output für \(thema) ist unvollständig")
      }
    }
  }

  struct Fehler: Error, CustomStringConvertible {
    let description: String
    init(_ description: String) { self.description = description }
  }
}
