import Foundation

@main
struct V11ReleaseTests {
  struct Failure: Error, CustomStringConvertible {
    let description: String
    init(_ description: String) { self.description = description }
  }

  static func main() throws {
    try multipleChannelsRemainIndependent()
    try interruptedJobsBecomeRecoverable()
    try uploadRecordsAreIdempotentPerProduction()
    try rightsPolicyIsConservative()
    try timelineValidationRejectsCorruption()
    try plannerHonorsExplicitFormatModes()
    try metadataIsDerivedFromUsedSources()
    print("BLACKSTOCK_V11_RELEASE_TESTS_OK")
  }

  static func multipleChannelsRemainIndependent() throws {
    let account = UUID()
    let localA = UUID(), localB = UUID()
    var state = V11State()
    state.channelConnections = [
      YouTubeChannelConnection(googleAccountID: account, localChannelID: localA, youtubeChannelID: "UC_A", name: "A", handle: "@a"),
      YouTubeChannelConnection(googleAccountID: account, localChannelID: localB, youtubeChannelID: "UC_B", name: "B", handle: "@b"),
    ]
    state.upsertProfile(ChannelContentProfile(channelID: localA, topics: [.gaming], revenueAccess: .available))
    state.upsertProfile(ChannelContentProfile(channelID: localB, topics: [.sport], revenueAccess: .notAuthorized))
    guard state.channelConnections.count == 2 else { throw Failure("Ein Google-Account muss mehrere Kanäle behalten") }
    guard state.profile(for: localA)?.topics == [.gaming] else { throw Failure("Profil A wurde vermischt") }
    guard state.profile(for: localB)?.revenueAccess == .notAuthorized else { throw Failure("Revenue-Status darf nicht accountweit überschrieben werden") }
  }

  static func interruptedJobsBecomeRecoverable() throws {
    let productionID = UUID()
    var state = V11State()
    state.productionStates = [ProductionV11State(productionID: productionID, mode: .remix, phase: .rendering)]
    state.markInterruptedInFlightJobs()
    guard let recovered = state.productionState(for: productionID), recovered.interrupted else {
      throw Failure("Laufende Produktion wurde nach Neustart nicht als unterbrochen markiert")
    }
    guard recovered.phase == .rendering, recovered.lastError?.contains("fortgesetzt") == true else {
      throw Failure("Checkpoint/Recovery-Information fehlt")
    }
  }

  static func uploadRecordsAreIdempotentPerProduction() throws {
    let production = UUID(), channel = UUID()
    var state = V11State()
    let first = UploadRecord(productionID: production, channelID: channel, filePath: "/tmp/a.mp4", fileSize: 100)
    state.upsertUploadRecord(first)
    var second = first
    second.youtubeVideoID = "youtube-123"
    second.state = .complete
    state.upsertUploadRecord(second)
    guard state.uploadRecords.count == 1 else { throw Failure("Upload-State wurde dupliziert") }
    guard state.uploadRecords.first?.youtubeVideoID == "youtube-123" else { throw Failure("Commit der YouTube-ID ging verloren") }
  }

  static func rightsPolicyIsConservative() throws {
    let publicDomain = SourceAsset(
      provider: .licensedProvider, remoteURL: "https://example.com/public.mp4", title: "PD", duration: 20,
      rightsStatus: .publicDomain, allowedUses: [])
    guard publicDomain.canAutoPublish else { throw Failure("Public-Domain-Material darf ohne künstlichen Lizenztyp nutzbar sein") }

    let nonCommercial = SourceAsset(
      provider: .licensedProvider, remoteURL: "https://example.com/licensed.mp4", title: "Licensed", duration: 20,
      licenseType: "Editorial", rightsStatus: .licensed, allowedUses: [.edit, .publish])
    guard !nonCommercial.canAutoPublish else { throw Failure("Lizenzierte Quelle ohne Commercial-Recht darf nicht automatisch veröffentlicht werden") }

    let missingAttribution = SourceAsset(
      provider: .licensedProvider, remoteURL: "https://example.com/cc.mp4", title: "CC", duration: 20,
      licenseType: "CC compatible", rightsStatus: .creativeCommonsCompatible,
      allowedUses: [.edit, .publish, .commercial, .attributionRequired])
    guard !missingAttribution.canAutoPublish else { throw Failure("Attribution-Pflicht ohne Attribution muss blockieren") }

    let expired = SourceAsset(
      provider: .licensedProvider, remoteURL: "https://example.com/expired.mp4", title: "Expired", duration: 20,
      licenseType: "Commercial", rightsStatus: .licensed, allowedUses: [.edit, .publish, .commercial],
      expiresAt: Date().addingTimeInterval(-1))
    guard !expired.canAutoPublish else { throw Failure("Abgelaufene Rechte dürfen nicht automatisch genutzt werden") }
  }

  static func timelineValidationRejectsCorruption() throws {
    let source = UUID()
    let valid = RemixTimeline(
      format: .short, duration: 10,
      segments: [RemixSegment(sourceAssetID: source, startTime: 0, endTime: 10, cropMode: .smartReframe, order: 0)])
    guard valid.isValid else { throw Failure("Gültige Timeline wurde abgelehnt") }

    let wrongDuration = RemixTimeline(format: .short, duration: 20, segments: valid.segments)
    guard !wrongDuration.isValid else { throw Failure("Manipulierte Timeline-Dauer wurde akzeptiert") }

    let overlapping = RemixTimeline(
      format: .longform, duration: 20,
      segments: [
        RemixSegment(sourceAssetID: source, startTime: 0, endTime: 12, cropMode: .fill, order: 0),
        RemixSegment(sourceAssetID: source, startTime: 10, endTime: 18, cropMode: .fill, order: 1),
      ])
    guard !overlapping.isValid else { throw Failure("Überlappende Segmente derselben Quelle wurden akzeptiert") }
  }

  static func plannerHonorsExplicitFormatModes() throws {
    let source = SourceAsset(
      provider: .directHTTPS, remoteURL: "https://example.com/owned.mp4", title: "Owned", duration: 140,
      licenseType: "User-owned", rightsStatus: .owned, allowedUses: [.edit, .publish, .commercial], channelOwnership: true,
      transcript: "Jetzt ist wichtig warum dieses neue Ergebnis entscheidend ist. Ein zweiter Satz erklärt den Kontext.")
    let planner = RemixPlannerService()
    let short = try planner.plan(sources: [source], mode: .short, requestedFormat: .longform)
    guard short.format == .short, short.duration <= 55.01 else { throw Failure("Short-Modus erzwingt kein korrektes Short-Format/Dauer") }
    let long = try planner.plan(sources: [source], mode: .longform, requestedFormat: .short)
    guard long.format == .longform else { throw Failure("Longform-Modus darf nicht vom Defaultformat auf Short zurückfallen") }
  }

  static func metadataIsDerivedFromUsedSources() throws {
    let source = SourceAsset(
      provider: .directHTTPS, remoteURL: "https://example.com/source.mp4", title: "Konkrete Quelle", duration: 30,
      creator: "Redaktion", sourcePage: "https://example.com/source", licenseType: "Owned", rightsStatus: .owned,
      allowedUses: [.edit, .publish, .commercial], channelOwnership: true,
      transcript: "Die tatsächlich verwendete Sequenz behandelt einen konkreten Test und dessen Ergebnis.", topicTags: ["Technologie"])
    let timeline = RemixTimeline(
      format: .longform, duration: 20,
      segments: [RemixSegment(sourceAssetID: source.id, startTime: 0, endTime: 20, cropMode: .fill, order: 0)])
    let profile = ChannelContentProfile(channelID: UUID(), topics: [.technologyAI])
    let metadata = FinalMetadataService().make(
      trendTitle: "Neuer Technik-Test", profile: profile, sources: [source], timeline: timeline, fallbackTitle: "Fallback")
    guard metadata.description.contains("Konkrete Quelle") else { throw Failure("Beschreibung nennt die tatsächlich verwendete Quelle nicht") }
    guard metadata.chapters.first?.hasPrefix("00:00") == true else { throw Failure("Longform-Kapitel beginnen nicht bei 00:00") }
    guard !metadata.title.isEmpty, metadata.title.count <= 96 else { throw Failure("Titelvalidierung fehlerhaft") }
  }
}
