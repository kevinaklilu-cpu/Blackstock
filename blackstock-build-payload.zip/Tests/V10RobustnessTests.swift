import Foundation

@main
struct V10RobustnessTests {
  static func main() throws {
    try zeroSetupDefaults()
    try topicPackageIntegrity()
    try premiumPresetsHaveSafeLocalCounterparts()
    print("BLACKSTOCK_V10_ROBUSTNESS_TESTS_OK")
  }

  static func zeroSetupDefaults() throws {
    let required: [(ProviderVerbindung.Typ, String)] = [
      (.research, "local-creator"),
      (.image, "local-thumbnail"),
      (.voice, "local-voice"),
      (.video, "local-visual"),
      (.music, "local-music"),
    ]
    for (typ, id) in required {
      let preset = EnginePresetService.standardPreset(fuer: typ)
      guard preset.id == id else { throw Fehler("Falscher Zero-Setup-Default für \(typ.rawValue)") }
      guard !preset.brauchtAPIKey else {
        throw Fehler("Zero-Setup-Default verlangt API-Key: \(preset.name)")
      }
      guard !preset.modell.isEmpty, !preset.basisURL.isEmpty else {
        throw Fehler("Preset ist technisch unvollständig: \(preset.name)")
      }
    }
  }

  static func topicPackageIntegrity() throws {
    let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
    let data = try Data(contentsOf: root.appendingPathComponent("Tests/Fixtures/v5_2-state.json"))
    let decoder = JSONDecoder()
    decoder.dateDecodingStrategy = .iso8601
    let state = try decoder.decode(AppZustand.self, from: data)
    guard let base = state.chancen.first, let kanal = state.kanaele.first else {
      throw Fehler("Fixture unvollständig")
    }
    let topics = [
      ("Gaming", "Neues Strategiespiel verändert Multiplayer-Taktiken"),
      ("Politik", "Digitalgesetz verändert Regeln für Plattformen"),
      ("Tech & KI", "Neue KI-Hardware beschleunigt lokale Modelle"),
      ("Finanzen", "ETF-Kosten sinken bei neuen Anbietern"),
      ("Wissenschaft", "Batterieforschung erhöht Energiedichte"),
      ("Auto", "Neue Schnellladetechnik verändert Elektroauto-Reisen"),
    ]
    for (thema, titel) in topics {
      var chance = base
      chance.thema = thema
      chance.titel = titel
      chance.begruendung = "Aktuelles Signal zu \(thema) mit klarer Nachfrage."
      let raw = LocalCreatorService.produktionsPaket(
        chance: chance, kanal: kanal, format: .short, modus: .studio)
      let paket = CreatorPackagePolisherService.normalisieren(
        raw, chance: chance, kanal: kanal, format: .short)
      guard !paket.titel.isEmpty, !paket.hook.isEmpty, !paket.skript.isEmpty else {
        throw Fehler("Redaktion unvollständig für \(thema)")
      }
      guard paket.beschreibung.count >= 100 else {
        throw Fehler("Beschreibung zu kurz für \(thema)")
      }
      guard paket.szenen.count >= 6,
        paket.szenen.allSatisfy({
          !$0.narration.isEmpty && !$0.visualDirection.isEmpty && $0.dauerSekunden >= 1.5
        })
      else {
        throw Fehler("Szenenpaket unvollständig für \(thema)")
      }
      let combined = "\(paket.titel) \(paket.hook) \(paket.beschreibung) \(paket.skript)"
        .lowercased()
      let anchors = Set(
        titel.lowercased().split(separator: " ").filter { $0.count >= 5 }.map(String.init))
      guard anchors.contains(where: { combined.contains($0) }) else {
        throw Fehler("Paket driftet vom Thema ab: \(thema)")
      }
      guard paket.thumbnailText.count <= 42, paket.thumbnailText.split(separator: " ").count <= 4
      else {
        throw Fehler("Thumbnail-Text nicht kompakt für \(thema)")
      }
    }
  }

  static func premiumPresetsHaveSafeLocalCounterparts() throws {
    for typ in [ProviderVerbindung.Typ.research, .image, .voice, .video] {
      let presets = EnginePresetService.presets(fuer: typ)
      if presets.contains(where: { $0.premium }) {
        guard presets.contains(where: { !$0.premium && !$0.brauchtAPIKey }) else {
          throw Fehler("Premium-Typ ohne lokalen Fallback: \(typ.rawValue)")
        }
      }
    }
  }

  struct Fehler: Error, CustomStringConvertible {
    let description: String
    init(_ description: String) { self.description = description }
  }
}
