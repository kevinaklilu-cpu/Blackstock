import Foundation

@main
struct MediaCenterCoreTests {
  static func main() throws {
    try navigationMigration()
    try packageAlignment()
    print("BLACKSTOCK_MEDIA_CENTER_TESTS_OK")
  }

  static func navigationMigration() throws {
    let raw = Data("\"kalender\"".utf8)
    let ziel = try JSONDecoder().decode(Navigationsziel.self, from: raw)
    guard ziel == .kalender else { throw Fehler("Kalender-Navigation kann nicht dekodiert werden") }

    // Legacy destinations remain decodable so existing user state is not broken.
    for value in ["automatik", "einnahmen", "qualitaet"] {
      _ = try JSONDecoder().decode(Navigationsziel.self, from: Data("\"\(value)\"".utf8))
    }
  }

  static func packageAlignment() throws {
    let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
    let fixture = root.appendingPathComponent("Tests/Fixtures/v5_2-state.json")
    let data = try Data(contentsOf: fixture)
    let decoder = JSONDecoder()
    decoder.dateDecodingStrategy = .iso8601
    let state = try decoder.decode(AppZustand.self, from: data)
    guard var chance = state.chancen.first, let kanal = state.kanaele.first else {
      throw Fehler("Fixture enthält keine Chance oder keinen Kanal")
    }

    chance.thema = "Gaming News"
    chance.titel = "Neues Open-World-Spiel verändert das Matchmaking"
    let generic = ProduktionsPaket(
      titel: "Alles was du wissen musst",
      hook: "Kurz erklärt.",
      skript: "Das ist ein allgemeiner Entwurf ohne klaren Themenanker.",
      beschreibung: "Willkommen auf diesem Kanal. Like und abonnieren.",
      tags: ["Video", "News"],
      thumbnailText: "Das musst du jetzt unbedingt komplett wissen",
      szenen: [
        ProduktionsSzene(titel: "", narration: "", visualDirection: "", dauerSekunden: 0.4)
      ])

    let result = CreatorPackagePolisherService.normalisieren(
      generic, chance: chance, kanal: kanal, format: .short)
    let combined = "\(result.titel) \(result.hook) \(result.skript) \(result.beschreibung)"
      .lowercased()
    guard
      combined.contains("gaming") || combined.contains("matchmaking")
        || combined.contains("open-world")
    else {
      throw Fehler("Creator-Paket bleibt nach Normalisierung thematisch generisch")
    }
    guard result.beschreibung.count >= 90,
      !result.beschreibung.lowercased().contains("like und abonnieren")
    else {
      throw Fehler("Beschreibung wurde nicht professionell an das Thema angepasst")
    }
    guard result.thumbnailText.count <= 42, result.thumbnailText.split(separator: " ").count <= 4
    else {
      throw Fehler("Thumbnail-Text überschreitet das kompakte Blackstock-Limit")
    }
    guard let scene = result.szenen.first,
      !scene.narration.isEmpty,
      !scene.visualDirection.isEmpty,
      scene.dauerSekunden >= 1.5
    else {
      throw Fehler("Szenen-Fallback ist unvollständig")
    }
    guard !result.tags.isEmpty, result.tags.count <= 18 else {
      throw Fehler("Tag-Normalisierung ist ungültig")
    }
  }

  struct Fehler: Error, CustomStringConvertible {
    let description: String
    init(_ description: String) { self.description = description }
  }
}
