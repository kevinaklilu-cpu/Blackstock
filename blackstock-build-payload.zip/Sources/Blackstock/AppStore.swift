import AppKit
import Foundation
import SwiftUI

struct CreatorSystemCheck: Identifiable, Hashable {
  let id: String
  let titel: String
  let detail: String
  let bereit: Bool
  let kritisch: Bool
}

struct CreatorSystemReport: Hashable {
  let geprueftAm: Date
  let checks: [CreatorSystemCheck]

  var bereit: Bool { checks.filter(\.kritisch).allSatisfy(\.bereit) }
  var bestandeneChecks: Int { checks.filter(\.bereit).count }
  var gesamtChecks: Int { checks.count }
}

@MainActor
final class AppStore: ObservableObject {
  @Published var onboardingAbgeschlossen: Bool
  @Published var demoModus: Bool
  @Published var googleVerbunden: Bool
  @Published var googleZugaenge: [GoogleZugang]
  @Published var ausgewaehltesZiel: Navigationsziel
  @Published var kanalPlaene: [KanalPlan]
  @Published var kanaele: [Kanal]
  @Published var chancen: [Chance]
  @Published var produktionen: [Produktion]
  @Published var videos: [VideoLeistung]
  @Published var provider: [ProviderVerbindung]
  @Published var adsenseProfil: AdSenseProfil
  @Published var medien: [MedienAsset]
  @Published var batchAuftraege: [BatchAuftrag]
  @Published var automationsregeln: [Automationsregel]
  @Published var v11State: V11State
  @Published var ausgewaehlteProduktionID: UUID?
  @Published var ausgewaehlterKanalID: UUID?
  @Published var meldung: String?
  @Published var istBeschaeftigt = false
  @Published var apiEinrichtungsHinweis: APIEinrichtungsHinweis?

  let youtube = YouTubeService()
  private let persistence = PersistenceService.shared

  init() {
    Self.standardwerteRegistrieren()
    let zustand = persistence.laden() ?? SeedData.leererZustand()
    onboardingAbgeschlossen = zustand.onboardingAbgeschlossen
    demoModus = zustand.demoModus
    googleZugaenge = zustand.googleZugaenge
    googleVerbunden = !zustand.googleZugaenge.isEmpty
    ausgewaehltesZiel = Self.normalisiertesNavigationsziel(zustand.ausgewaehltesZiel)
    kanalPlaene = zustand.kanalPlaene
    kanaele = zustand.kanaele
    chancen = zustand.chancen
    produktionen = zustand.produktionen
    videos = zustand.videos
    provider = EnginePresetService.normalisieren(
      zustand.provider.isEmpty ? SeedData.standardProvider : zustand.provider)
    adsenseProfil = zustand.adsenseProfil
    medien = zustand.medien
    batchAuftraege = zustand.batchAuftraege
    automationsregeln = zustand.automationsregeln
    var migriert = zustand.v11 ?? V11State()
    migriert.normalizeLegacy(kanaele: zustand.kanaele, produktionen: zustand.produktionen)
    migriert.markInterruptedInFlightJobs()
    v11State = migriert
    for index in produktionen.indices
    where produktionen[index].format == .livestream && produktionen[index].status == .live {
      produktionen[index].status = .blockiert
      produktionen[index].letzterFehler =
        "Das Live-Playout war beim letzten App-Lauf aktiv. Der lokale Encoder läuft nach einem Neustart nicht weiter und muss erneut gestartet werden."
      produktionen[index].naechsterSchritt = "Live Playout erneut starten"
    }
    if let gespeichert = youtube.gespeicherterAPIEinrichtungsHinweis() {
      apiEinrichtungsHinweis = gespeichert
    } else if googleZugaenge.contains(where: { $0.status == .apiEinrichtung }) {
      apiEinrichtungsHinweis = youtube.standardDataAPIHinweis()
    }
    automatischProviderSchluesselImportieren()
  }

  private static func normalisiertesNavigationsziel(_ ziel: Navigationsziel) -> Navigationsziel {
    switch ziel {
    case .factory, .automatik, .qualitaet: return .produktionen
    case .kalender: return .veroeffentlicht
    case .einnahmen: return .wachstum
    case .bibliothek: return .einstellungen
    default: return ziel
    }
  }

  private static func standardwerteRegistrieren() {
    UserDefaults.standard.register(defaults: [
      "minQuality": 92.0,
      "automationIntervalMinutes": 240,
      "automatikStufe": "Produktion automatisch",
      "minConfidence": 0.90,
      "dailyProductionLimit": 12,
      "automationCloudVisuals": false,
      "blackstock.appearance": BlackstockAppearance.system.rawValue,
      "blackstock.existingMediaFirst": true,
      "blackstock.aiFallback": false,
      "blackstock.reviewBeforePublish": true,
      "blackstock.remoteCacheLimitGB": 20.0,
    ])
  }

  var zustand: AppZustand {
    AppZustand(
      onboardingAbgeschlossen: onboardingAbgeschlossen,
      demoModus: demoModus,
      googleVerbunden: googleVerbunden,
      googleZugaenge: googleZugaenge,
      ausgewaehltesZiel: ausgewaehltesZiel,
      kanalPlaene: kanalPlaene,
      kanaele: kanaele,
      chancen: chancen,
      produktionen: produktionen,
      videos: videos,
      provider: provider,
      adsenseProfil: adsenseProfil,
      medien: medien,
      batchAuftraege: batchAuftraege,
      automationsregeln: automationsregeln,
      v11: v11State
    )
  }

  var liveKanaele: [Kanal] { kanaele.filter { !$0.istDemo && $0.youtubeChannelID != nil } }
  var aktiveProduktionen: [Produktion] {
    produktionen.filter { ![.live, .blockiert].contains($0.status) }
  }
  var blockierteProduktionen: [Produktion] {
    produktionen.filter { $0.status == .blockiert || $0.qualitaet.harteSperre }
  }
  var gesamtUmsatz28Tage: Double { kanaele.reduce(0) { $0 + $1.umsatz28Tage } }
  var gesamtViews28Tage: Int { kanaele.reduce(0) { $0 + $1.views28Tage } }
  var gesamtAbonnenten: Int { kanaele.reduce(0) { $0 + $1.abonnenten } }
  var globaleQualitaetsGrenze: Double {
    let stored = UserDefaults.standard.double(forKey: "minQuality")
    return max(80, min(99, stored > 0 ? stored : 92))
  }

  func istFreigabeBereit(_ p: Produktion) -> Bool {
    p.qualitaet.offeneGates.isEmpty && p.qualitaet.fehlgeschlageneGates.isEmpty
      && p.qualitaet.gesamt >= globaleQualitaetsGrenze
  }

  func speichern() {
    if !persistence.speichern(zustand) {
      meldung =
        "Blackstock konnte den lokalen Projektstand nicht speichern. Prüfe freien Speicherplatz und Zugriffsrechte."
    }
  }

  func onboardingAbschliessen(demo: Bool) {
    if demo {
      let d = SeedData.demoZustand()
      demoModus = true
      googleVerbunden = d.googleVerbunden
      googleZugaenge = d.googleZugaenge
      kanalPlaene = d.kanalPlaene
      kanaele = d.kanaele
      chancen = d.chancen
      produktionen = d.produktionen
      videos = d.videos
      provider = d.provider
      adsenseProfil = d.adsenseProfil
      medien = d.medien
      batchAuftraege = d.batchAuftraege
      automationsregeln = d.automationsregeln
    } else {
      demoModus = false
    }
    onboardingAbgeschlossen = true
    speichern()
  }

  func demoDatenNeuLaden() { onboardingAbschliessen(demo: true) }

  func demoEntfernen() {
    demoModus = false
    kanaele.removeAll { $0.istDemo }
    chancen.removeAll { $0.istDemo }
    produktionen.removeAll { $0.istDemo }
    videos.removeAll { $0.istDemo }
    adsenseProfil = AdSenseProfil()
    googleZugaenge.removeAll { $0.datenherkunft == .beispiel }
    speichern()
  }

  func kanalName(fuer id: UUID) -> String {
    kanaele.first(where: { $0.id == id })?.name ?? "Nicht zugeordnet"
  }
  func kanal(fuer id: UUID) -> Kanal? { kanaele.first(where: { $0.id == id }) }

  // MARK: - Google / YouTube Start

  @discardableResult
  func googleZugangHinzufuegen() async -> GoogleZugang? {
    istBeschaeftigt = true
    defer { istBeschaeftigt = false }
    do {
      let ergebnis = try await youtube.googleZugangHinzufuegen()
      googleVerbunden = true
      apiEinrichtungsHinweis = ergebnis.einrichtungsHinweis ?? youtube.letzterAPIEinrichtungsHinweis
      upsertGoogleZugang(ergebnis.zugang)
      let gefundeneKanaele = ergebnis.kanaele.isEmpty ? ergebnis.kanal.map { [$0] } ?? [] : ergebnis.kanaele
      for var kanal in gefundeneKanaele {
        kanal.verbindungsID = ergebnis.zugang.id
        importiereKanal(kanal, verbindungsID: ergebnis.zugang.id)
      }
      demoModus = false
      speichern()
      return ergebnis.zugang
    } catch let fehler as YouTubeService.YouTubeFehler {
      if let hinweis = fehler.einrichtungsHinweis { apiEinrichtungsHinweis = hinweis }
      meldung = fehler.localizedDescription
      return nil
    } catch {
      meldung = "Google konnte nicht verbunden werden. \(error.localizedDescription)"
      return nil
    }
  }

  func googleKontoVerbinden() async -> Bool {
    let zugang = await googleZugangHinzufuegen()
    return zugang?.youtubeChannelID != nil
  }

  private func upsertGoogleZugang(_ zugang: GoogleZugang) {
    if let channelID = zugang.youtubeChannelID,
      let idx = googleZugaenge.firstIndex(where: { $0.youtubeChannelID == channelID })
    {
      let alteID = googleZugaenge[idx].id
      if alteID != zugang.id { youtube.verbindungTrennen(alteID) }
      googleZugaenge[idx] = zugang
      return
    }
    if let idx = googleZugaenge.firstIndex(where: {
      $0.email.caseInsensitiveCompare(zugang.email) == .orderedSame
    }) {
      let alteID = googleZugaenge[idx].id
      if alteID != zugang.id { youtube.verbindungTrennen(alteID) }
      googleZugaenge[idx] = zugang
      return
    }
    if zugang.youtubeChannelID == nil,
      let idx = googleZugaenge.firstIndex(where: {
        $0.email == zugang.email && $0.youtubeChannelID == nil
      })
    {
      let alteID = googleZugaenge[idx].id
      if alteID != zugang.id { youtube.verbindungTrennen(alteID) }
      googleZugaenge[idx] = zugang
      return
    }
    googleZugaenge.insert(zugang, at: 0)
  }

  private func importiereKanal(_ apiKanal: Kanal, verbindungsID: UUID, planID: UUID? = nil) {
    var kanal = apiKanal
    kanal.verbindungsID = verbindungsID
    kanal.datenherkunft = .live
    kanal.analyticsStand = Date()
    // YPP approval is not inferred from revenue. The exact status stays unknown unless
    // YouTube exposes a trustworthy signal for it.
    kanal.status = .verbunden
    kanal.monetarisierungFortschritt = 0

    let localID: UUID
    if let idx = kanaele.firstIndex(where: {
      $0.youtubeChannelID == kanal.youtubeChannelID && $0.youtubeChannelID != nil
    }) {
      kanal.id = kanaele[idx].id
      kanal.autopilotAktiv = kanaele[idx].autopilotAktiv
      kanal.branding = kanaele[idx].branding
      kanaele[idx] = kanal
      localID = kanal.id
    } else if let planID, let pidx = kanalPlaene.firstIndex(where: { $0.id == planID }) {
      localID = kanal.id
      kanaele.insert(kanal, at: 0)
      kanalPlaene[pidx].status = .verbunden
      kanalPlaene[pidx].verbundenerKanalID = localID
    } else {
      localID = kanal.id
      kanaele.insert(kanal, at: 0)
    }

    if let zidx = googleZugaenge.firstIndex(where: { $0.id == verbindungsID }) {
      googleZugaenge[zidx].status = .verbunden
      if googleZugaenge[zidx].youtubeChannelID == nil {
        googleZugaenge[zidx].youtubeChannelID = kanal.youtubeChannelID
        googleZugaenge[zidx].youtubeChannelName = kanal.name
      }
      googleZugaenge[zidx].letzteSynchronisierung = Date()
    }

    if let youtubeID = kanal.youtubeChannelID {
      let connection = YouTubeChannelConnection(
        googleAccountID: verbindungsID,
        localChannelID: localID,
        youtubeChannelID: youtubeID,
        name: kanal.name,
        handle: kanal.handle,
        active: true,
        connectedAt: Date(),
        lastSyncAt: Date())
      if let cidx = v11State.channelConnections.firstIndex(where: {
        $0.googleAccountID == verbindungsID && $0.youtubeChannelID == youtubeID
      }) {
        var preserved = connection
        preserved.id = v11State.channelConnections[cidx].id
        preserved.connectedAt = v11State.channelConnections[cidx].connectedAt
        v11State.channelConnections[cidx] = preserved
      } else {
        v11State.channelConnections.append(connection)
      }
    }
    if v11State.profile(for: localID) == nil {
      let inferred = TopicTaxonomy.infer(from: kanal.thema).map { [$0] } ?? []
      var profile = ChannelContentProfile(channelID: localID)
      profile.language = UserDefaults.standard.string(forKey: "blackstock.language") ?? "Deutsch"
      profile.region = UserDefaults.standard.string(forKey: "blackstock.region") ?? "DE"
      profile.topics = inferred
      profile.customTopics = kanal.thema.isEmpty ? [] : [kanal.thema]
      profile.reviewBeforePublish = UserDefaults.standard.object(forKey: "blackstock.reviewBeforePublish") == nil
        ? true : UserDefaults.standard.bool(forKey: "blackstock.reviewBeforePublish")
      profile.defaultPrivacy = ChannelPrivacy(
        rawValue: UserDefaults.standard.string(forKey: "blackstock.defaultPrivacy") ?? "") ?? .privateVideo
      profile.revenueAccess = .unknown
      profile.analyticsAuthorized = true
      profile.uploadAuthorized = youtube.featureAutorisiert(.upload, verbindungID: verbindungsID)
      profile.liveAuthorized = youtube.featureAutorisiert(.liveManagement, verbindungID: verbindungsID)
      v11State.upsertProfile(profile)
    }
    adsenseProfil.verknuepfteKanalIDs = Array(Set(adsenseProfil.verknuepfteKanalIDs + [localID]))
  }

  func bestehendenYouTubeKanalVerbinden() async {
    let zugang = await googleZugangHinzufuegen()
    if let zugang {
      meldung =
        zugang.youtubeChannelID == nil
        ? "Google ist verbunden. Für dieses Profil wurde noch kein YouTube-Kanal gefunden."
        : "YouTube-Kanal wurde verbunden."
    }
  }

  func googleZugangEntfernen(_ id: UUID) {
    youtube.verbindungTrennen(id)
    googleZugaenge.removeAll { $0.id == id }
    for index in kanaele.indices where kanaele[index].verbindungsID == id {
      kanaele[index].verbindungsID = nil
      kanaele[index].status = .entwurf
      kanaele[index].datenherkunft = .nichtVerfuegbar
    }
    googleVerbunden = !googleZugaenge.isEmpty
    speichern()
  }

  // MARK: - Kanalplanung

  @discardableResult
  func kanalPlanAnlegen(thema: String) -> KanalPlan {
    let sauber = thema.trimmingCharacters(in: .whitespacesAndNewlines)
    let basis = sauber.isEmpty ? "Media" : sauber
    let slug = basis.lowercased()
      .replacingOccurrences(of: "ä", with: "ae")
      .replacingOccurrences(of: "ö", with: "oe")
      .replacingOccurrences(of: "ü", with: "ue")
      .replacingOccurrences(of: "ß", with: "ss")
      .filter { $0.isLetter || $0.isNumber }
    let plan = KanalPlan(
      thema: basis,
      name: "Blackstock \(basis)",
      handleVorschlag: "@blackstock\(slug)",
      status: .vorbereitet,
      zielgruppe: "Wird anhand der ersten echten Performance-Daten kalibriert.",
      positionierung:
        "Schnelle, hochwertige und verifizierte \(basis)-Inhalte mit klarer Blackstock-Handschrift.",
      contentDNA:
        "Originale Recherche, klare Story, starke Hook, wiederkehrende Serien statt austauschbarer Masseninhalte.",
      visualDNA:
        "Editorial, hochwertig, mobile-first, klare Motive, kontrollierte Motion und hohe Lesbarkeit.",
      voiceDNA:
        "Natürlich, präzise, souverän; Energie passend zum Thema, niemals künstlich überdreht.",
      startFormate: ["Discovery Short", "Erklär-Short", "Deep Dive"],
      empfohleneUploadsProWoche: 5,
      marktScore: 0,
      erwarteteAboChance: 0,
      vertrauen: 0.65
    )
    kanalPlaene.insert(plan, at: 0)
    speichern()
    return plan
  }

  func kanalPlanYoutubeStarten(_ id: UUID) {
    guard let idx = kanalPlaene.firstIndex(where: { $0.id == id }) else { return }
    kanalPlaene[idx].status = .youtubeErstellung
    youtube.oeffneKanalErstellung(vorgeschlagenerName: kanalPlaene[idx].name)
    speichern()
  }

  func kanalPlanAlsErstelltMarkieren(_ id: UUID) {
    guard let idx = kanalPlaene.firstIndex(where: { $0.id == id }) else { return }
    kanalPlaene[idx].status = .bereitZumVerbinden
    speichern()
  }

  func kanalPlanVerbinden(_ id: UUID) async {
    istBeschaeftigt = true
    defer { istBeschaeftigt = false }
    do {
      if let bestehend = googleZugaenge.first(where: { $0.status == .kanalFehlt }) {
        if var kanal = try await youtube.kanalLaden(verbindungID: bestehend.id) {
          kanal.verbindungsID = bestehend.id
          importiereKanal(kanal, verbindungsID: bestehend.id, planID: id)
          googleVerbunden = true
          speichern()
          meldung = "Der neue YouTube-Kanal wurde automatisch erkannt und Blackstock zugeordnet."
          return
        }
      }

      let ergebnis = try await youtube.googleZugangHinzufuegen()
      upsertGoogleZugang(ergebnis.zugang)
      guard var kanal = ergebnis.kanal else {
        googleVerbunden = true
        speichern()
        meldung =
          "Google ist verbunden, aber YouTube meldet noch keinen Kanal. Schließe die Kanalerstellung bei YouTube ab und wähle anschließend „Jetzt erkennen“."
        return
      }
      kanal.verbindungsID = ergebnis.zugang.id
      importiereKanal(kanal, verbindungsID: ergebnis.zugang.id, planID: id)
      googleVerbunden = true
      speichern()
      meldung = "Der neue YouTube-Kanal wurde Blackstock zugeordnet."
    } catch let fehler as YouTubeService.YouTubeFehler {
      if let hinweis = fehler.einrichtungsHinweis { apiEinrichtungsHinweis = hinweis }
      meldung = fehler.localizedDescription
    } catch {
      meldung = "Der Kanal konnte noch nicht verbunden werden. \(error.localizedDescription)"
    }
  }

  // MARK: - Chancen

  func chanceBeobachten(_ id: UUID) {
    guard let idx = chancen.firstIndex(where: { $0.id == id }) else { return }
    chancen[idx].beobachtet.toggle()
    speichern()
  }

  @discardableResult
  func chancenAktualisieren(zusaetzlicheMarktThemen: [String] = []) async -> Bool {
    guard let verbindungsID = liveKanaele.first?.verbindungsID ?? googleZugaenge.first?.id else {
      meldung =
        "Für aktuelle YouTube-Trends reicht ein Google-Zugang. Ein eigener YouTube-Kanal muss noch nicht existieren."
      return false
    }
    istBeschaeftigt = true
    defer { istBeschaeftigt = false }
    do {
      youtube.aktiveVerbindungSetzen(verbindungsID)
      let planThemen = kanalPlaene.filter { $0.status != .verbunden }.map(\.thema)
      let marktThemen = Array(Set(planThemen + zusaetzlicheMarktThemen))
      var neue = try await youtube.trendChancen(fuer: liveKanaele, zusaetzlicheThemen: marktThemen)
      for index in neue.indices {
        neue[index].datenherkunft = .live
        neue[index].nachfrageScore = max(neue[index].trendScore, 0)
        neue[index].momentum = max(0, neue[index].trendScore - 50)
        neue[index].contentGapScore = max(25, 100 - neue[index].trendScore * 0.42)
        neue[index].wettbewerbScore = min(100, 45 + neue[index].trendScore * 0.45)
        neue[index].phase = neue[index].trendScore >= 85 ? .beschleunigend : .entstehend
      }
      // Live-Chancen behalten über Refreshes eine stabile Identität. Das schützt
      // Beobachtungsstatus, Verlauf und bereits angelegte Produktionen.
      let vorherigeLive = chancen.filter { !$0.istDemo }
      var vorherigeNachQuelle: [String: Chance] = [:]
      for alt in vorherigeLive { vorherigeNachQuelle[chanceStabilerSchluessel(alt)] = alt }
      let jetzt = Date()
      for index in neue.indices {
        let key = chanceStabilerSchluessel(neue[index])
        if let alt = vorherigeNachQuelle[key] {
          neue[index].id = alt.id
          neue[index].beobachtet = alt.beobachtet
          var verlauf = alt.trendVerlauf
          if verlauf.last.map({ jetzt.timeIntervalSince($0.zeit) > 60 }) ?? true {
            verlauf.append(TrendPunkt(zeit: jetzt, wert: neue[index].trendScore))
          }
          neue[index].trendVerlauf = Array(verlauf.suffix(96))
          if neue[index].quellenSchluessel == nil {
            neue[index].quellenSchluessel = alt.quellenSchluessel
          }
        } else {
          neue[index].trendVerlauf = [TrendPunkt(zeit: jetzt, wert: neue[index].trendScore)]
        }
      }
      chancen.removeAll { !$0.istDemo }
      chancen.insert(contentsOf: neue, at: 0)
      speichern()
      meldung =
        neue.isEmpty
        ? "Keine ausreichend starken Signale gefunden."
        : "\(neue.count) Chancen wurden mit aktuellen YouTube-Signalen bewertet."
      return true
    } catch let fehler as YouTubeService.YouTubeFehler {
      if let hinweis = fehler.einrichtungsHinweis {
        apiEinrichtungsHinweis = hinweis
        if let idx = googleZugaenge.firstIndex(where: { $0.id == verbindungsID }) {
          googleZugaenge[idx].status = .apiEinrichtung
        }
        speichern()
      }
      meldung = fehler.localizedDescription
      return false
    } catch {
      meldung = "Trends konnten nicht aktualisiert werden. \(error.localizedDescription)"
      return false
    }
  }

  private func chanceStabilerSchluessel(_ chance: Chance) -> String {
    if let quelle = chance.quellenSchluessel, !quelle.isEmpty { return quelle }
    let titel = chance.titel.lowercased()
      .folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
      .split { !$0.isLetter && !$0.isNumber }
      .joined(separator: " ")
    return "fallback:\(chance.thema.lowercased())|\(titel)"
  }

  // MARK: - Produktion

  @discardableResult
  func produktionAusChance(
    _ chance: Chance,
    format: VideoFormat? = nil,
    modus: Produktionsmodus = .studio,
    publikationsmodus: Publikationsmodus = .review
  ) -> UUID? {
    guard let kanalID = chance.empfohlenerKanalID ?? liveKanaele.first?.id ?? kanaele.first?.id
    else {
      meldung =
        "Ordne die Chance zuerst einem Kanal zu oder richte im Kanalbereich deinen ersten Kanal ein."
      return nil
    }
    let q = Qualitaetsprofil(
      story: 0, hook: 0, visuals: 0, schnitt: 0, stimme: 0, audio: 0,
      thumbnail: 0, titel: 0, originalitaet: 0, fakten: 0,
      rechte: 0, policy: 0, technisch: 0
    )
    let gewaehlt = format ?? chance.empfohleneFormate.first ?? .short
    let dauer: Int =
      switch gewaehlt {
      case .short: 45
      case .longform: 420
      case .serie: 240
      case .livestream: 1_800
      }
    let neueProduktion = Produktion(
      kanalID: kanalID,
      chanceID: chance.id,
      arbeitstitel: chance.titel,
      format: gewaehlt,
      status: .idee,
      erstelltAm: Date(),
      geplantFuer: nil,
      zielDauerSekunden: dauer,
      skript: "", hook: "", thumbnailIdee: "",
      voiceDirection: "Natürlich, präzise und markentypisch.", storyboardNotizen: "",
      qualitaet: q,
      konfidenz: chance.konfidenz,
      erwarteteViews24h: Int(25_000 + chance.trendScore * 1_800),
      erwarteteAbonnenten: Int(max(25, chance.abonnentenPotenzial * 8)),
      erwarteterUmsatz: max(0, chance.umsatzPotenzial * 0.45),
      istDemo: chance.istDemo,
      datenherkunft: chance.istDemo ? .beispiel : .lokal,
      naechsterSchritt: "Produktionspaket erstellen",
      modus: modus,
      publikationsmodus: publikationsmodus,
      chanceSnapshot: chance,
      chanceQuellenSchluessel: chance.quellenSchluessel
    )
    produktionen.insert(neueProduktion, at: 0)
    ausgewaehlteProduktionID = neueProduktion.id
    ausgewaehltesZiel = .produktionen
    speichern()
    return neueProduktion.id
  }

  func chanceDirektProduzieren(
    _ chance: Chance,
    format: VideoFormat? = nil,
    modus: Produktionsmodus = .studio,
    publikationsmodus: Publikationsmodus = .review
  ) async {
    guard
      let id = produktionAusChance(
        chance, format: format, modus: modus, publikationsmodus: publikationsmodus)
    else { return }

    let erfolgreich = await produktionAutomatischFertigstellen(id)
    if erfolgreich {
      ausgewaehlteProduktionID = id
      ausgewaehltesZiel = .produktionen
      meldung = "Blackstock hat das Projekt vollständig bis zum Master-Render produziert."
    } else if let projekt = produktionen.first(where: { $0.id == id }) {
      ausgewaehlteProduktionID = id
      ausgewaehltesZiel = .produktionen
      meldung =
        projekt.letzterFehler
        ?? "Die automatische Produktion wurde angehalten. Öffne das Studio für den konkret markierten Schritt."
    }
  }

  var researchEngineBereit: Bool { providerBereit(.research) }

  var voiceEngineBereit: Bool { providerBereit(.voice) }

  var imageEngineBereit: Bool { providerBereit(.image) }

  var videoEngineBereit: Bool { providerBereit(.video) }

  var lokaleCreatorFallbacksBereit: Bool { true }

  func creatorSystemPruefen() -> CreatorSystemReport {
    var checks: [CreatorSystemCheck] = []

    let ordner = ["Voiceovers", "Thumbnails", "LocalVisuals", "AutoMusic", "Renders"]
    var arbeitsbereichBereit = true
    for name in ordner {
      do {
        let url = try persistence.arbeitsordner(name)
        let probe = url.appendingPathComponent(".blackstock-write-test")
        try Data("ok".utf8).write(to: probe, options: .atomic)
        try? FileManager.default.removeItem(at: probe)
      } catch {
        arbeitsbereichBereit = false
        break
      }
    }
    checks.append(
      CreatorSystemCheck(
        id: "storage", titel: "Arbeitsbereich",
        detail: arbeitsbereichBereit
          ? "Voice, Bilder, Visuals, Musik und Render sind beschreibbar"
          : "Lokaler Arbeitsbereich ist nicht beschreibbar",
        bereit: arbeitsbereichBereit, kritisch: true))

    for (typ, id, titel, fallback) in [
      (ProviderVerbindung.Typ.research, "research", "Redaktion", "Blackstock Local Creator"),
      (.image, "image", "Thumbnail & Bilder", "Blackstock Thumbnail"),
      (.voice, "voice", "Voice", "macOS Natural Voice"),
      (.video, "video", "Video & Visuals", "Blackstock Local Visual"),
      (.music, "music", "Musik", "Blackstock Auto Music"),
    ] {
      let aktiv = provider.first(where: { $0.typ == typ })
      let preset = aktiv.flatMap { EnginePresetService.aktiviertesPreset(fuer: $0) }
      let activeReady = providerBereit(typ)
      let localFallbackReady = EnginePresetService.presets(fuer: typ).contains {
        !$0.premium && !$0.brauchtAPIKey
      }
      let ready = activeReady || localFallbackReady
      let detail: String
      if activeReady {
        detail =
          preset?.premium == true
          ? "\(preset?.name ?? titel) verbunden" : "\(preset?.name ?? fallback) lokal bereit"
      } else if localFallbackReady {
        detail = "Aktive Premium-Engine nicht verbunden · automatischer Fallback: \(fallback)"
      } else {
        detail = "Keine funktionsfähige Engine oder lokaler Fallback vorhanden"
      }
      checks.append(
        CreatorSystemCheck(id: id, titel: titel, detail: detail, bereit: ready, kritisch: true))
    }

    let youtubeBereit = googleZugaenge.contains { $0.status == .verbunden }
    checks.append(
      CreatorSystemCheck(
        id: "youtube", titel: "YouTube",
        detail: youtubeBereit
          ? "Upload und Kanal-Synchronisierung verbunden"
          : "Optional: Für Upload einmal Google/YouTube verbinden",
        bereit: youtubeBereit, kritisch: false))

    return CreatorSystemReport(geprueftAm: Date(), checks: checks)
  }

  @discardableResult
  func creatorSystemSelbsttest() -> CreatorSystemReport {
    creatorEnginesAufStandardFallsUnvollstaendig()
    produktionsEinstellungenNormalisieren()
    let report = creatorSystemPruefen()
    meldung =
      report.bereit
      ? "Blackstock Selbsttest bestanden: \(report.bestandeneChecks)/\(report.gesamtChecks) Bereiche bereit."
      : "Blackstock Selbsttest hat einen kritischen lokalen Fehler gefunden. Prüfe den Systemstatus in Einstellungen."
    return report
  }

  func produktionsStandardsWiederherstellen() {
    let defaults = UserDefaults.standard
    defaults.set(92.0, forKey: "minQuality")
    defaults.set(0.90, forKey: "minConfidence")
    defaults.set(12, forKey: "dailyProductionLimit")
    defaults.set(240, forKey: "automationIntervalMinutes")
    defaults.set("Produktion automatisch", forKey: "automatikStufe")
    defaults.set(false, forKey: "automationCloudVisuals")
    meldung = "Produktionsparameter wurden auf die sicheren lokalen Blackstock-Fallbacks zurückgesetzt."
  }

  private func produktionsEinstellungenNormalisieren() {
    let defaults = UserDefaults.standard
    let quality = defaults.double(forKey: "minQuality")
    defaults.set(max(80, min(99, quality > 0 ? quality : 92)), forKey: "minQuality")
    let confidence = defaults.double(forKey: "minConfidence")
    defaults.set(max(0.75, min(0.99, confidence > 0 ? confidence : 0.90)), forKey: "minConfidence")
    let daily = defaults.integer(forKey: "dailyProductionLimit")
    defaults.set(max(1, min(200, daily > 0 ? daily : 12)), forKey: "dailyProductionLimit")
    let interval = defaults.integer(forKey: "automationIntervalMinutes")
    let normalizedInterval = max(180, min(720, interval > 0 ? interval : 240))
    defaults.set((normalizedInterval / 30) * 30, forKey: "automationIntervalMinutes")
    let allowed = [
      "Aus", "Assistiert", "Produktion automatisch", "Smart Autopilot", "Vollautomatik",
    ]
    let mode = defaults.string(forKey: "automatikStufe") ?? "Produktion automatisch"
    if !allowed.contains(mode) { defaults.set("Produktion automatisch", forKey: "automatikStufe") }
  }

  private func creatorEnginesAufStandardFallsUnvollstaendig() {
    for typ in [ProviderVerbindung.Typ.research, .image, .voice, .video, .music] {
      guard provider.first(where: { $0.typ == typ }) == nil else { continue }
      let preset = EnginePresetService.standardPreset(fuer: typ)
      let neu = ProviderVerbindung(
        typ: typ, name: preset.name, verbunden: !preset.brauchtAPIKey, detail: preset.detail,
        basisURL: preset.basisURL, modell: preset.modell, apiKeyVorhanden: !preset.brauchtAPIKey,
        optionen: preset.optionen.merging(["preset": preset.id]) { _, neu in neu })
      provider.append(neu)
    }
    provider = EnginePresetService.normalisieren(provider)
    speichern()
  }

  func providerBereit(_ typ: ProviderVerbindung.Typ) -> Bool {
    guard let p = provider.first(where: { $0.typ == typ }) else { return false }
    if let preset = EnginePresetService.aktiviertesPreset(fuer: p), !preset.brauchtAPIKey {
      if preset.optionen["adapter"] == "apple-foundation" {
        return AppleIntelligenceCreatorService.verfuegbar
      }
      return true
    }
    return p.verbunden && !(p.basisURL ?? "").isEmpty && !(p.modell ?? "").isEmpty
      && KeychainService.shared.lesen("provider.api.\(p.id.uuidString)") != nil
  }

  var automationSchedulerAktiv: Bool {
    let stufe = UserDefaults.standard.string(forKey: "automatikStufe") ?? "Assistiert"
    return !["Aus", "Assistiert"].contains(stufe) && automationsregeln.contains(where: \.aktiv)
      && !googleZugaenge.isEmpty
  }

  var automationIntervallMinuten: Int {
    let stored = UserDefaults.standard.integer(forKey: "automationIntervalMinutes")
    return max(180, min(720, stored > 0 ? stored : 180))
  }

  func automationSchedulerTick() async {
    guard automationSchedulerAktiv, !istBeschaeftigt else { return }
    let aktualisiert = await chancenAktualisieren()
    guard aktualisiert, !istBeschaeftigt else { return }
    await aktiveAutomationenAusfuehren()
  }

  func produktionsPaketErzeugen(_ id: UUID) async {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    let p = produktionen[index]
    let chance: Chance? = {
      if let chanceID = p.chanceID, let live = chancen.first(where: { $0.id == chanceID }) {
        return live
      }
      if let key = p.chanceQuellenSchluessel,
        let live = chancen.first(where: { $0.quellenSchluessel == key })
      {
        return live
      }
      return p.chanceSnapshot
    }()
    guard let chance else {
      meldung =
        "Für dieses Projekt fehlt die ursprüngliche Chance. Lege Hook und Skript direkt im Studio an."
      return
    }
    guard let kanal = kanal(fuer: p.kanalID) else {
      meldung = "Zielkanal wurde nicht gefunden."
      return
    }

    istBeschaeftigt = true
    produktionen[index].status = .recherche
    produktionen[index].naechsterSchritt = "Redaktionelles Produktionspaket wird erstellt"
    produktionen[index].letzterFehler = nil
    speichern()
    defer { istBeschaeftigt = false }

    let paket: ProduktionsPaket
    var creatorQuelle = "Blackstock Local Creator"
    let engine = provider.first(where: { $0.typ == .research })
    let preset = engine.flatMap { EnginePresetService.aktiviertesPreset(fuer: $0) }

    if AppleIntelligenceCreatorService.verfuegbar,
      ["apple-foundation", "local"].contains(preset?.optionen["adapter"] ?? "local")
    {
      if let applePaket = try? await AppleIntelligenceCreatorService.produktionsPaket(
        chance: chance, kanal: kanal, format: p.format, modus: p.modus ?? .studio)
      {
        paket = applePaket
        creatorQuelle = "Apple Intelligence · on-device"
      } else {
        paket = LocalCreatorService.produktionsPaket(
          chance: chance, kanal: kanal, format: p.format, modus: p.modus ?? .studio)
      }
    } else if let engine,
      preset?.premium == true,
      let apiKey = KeychainService.shared.lesen("provider.api.\(engine.id.uuidString)")
    {
      do {
        paket = try await CreatorAIService.shared.produktionsPaket(
          chance: chance, kanal: kanal, format: p.format, modus: p.modus ?? .studio,
          provider: engine, apiKey: apiKey)
        creatorQuelle = engine.name
      } catch {
        // Ein temporärer Cloud-/Quota-/Formatfehler darf die komplette Factory nicht stoppen.
        paket = LocalCreatorService.produktionsPaket(
          chance: chance, kanal: kanal, format: p.format, modus: p.modus ?? .studio)
        creatorQuelle = "\(engine.name) fehlgeschlagen → Blackstock Local Creator"
      }
    } else {
      paket = LocalCreatorService.produktionsPaket(
        chance: chance, kanal: kanal, format: p.format, modus: p.modus ?? .studio)
    }

    let finalPaket = CreatorPackagePolisherService.normalisieren(
      paket, chance: chance, kanal: kanal, format: p.format)
    guard let aktuell = produktionen.firstIndex(where: { $0.id == id }) else { return }
    produktionen[aktuell].paket = finalPaket
    produktionen[aktuell].arbeitstitel = finalPaket.titel
    produktionen[aktuell].hook = finalPaket.hook
    produktionen[aktuell].skript = finalPaket.skript
    produktionen[aktuell].beschreibung = finalPaket.beschreibung
    produktionen[aktuell].tags = finalPaket.tags
    produktionen[aktuell].thumbnailIdee = finalPaket.thumbnailText
    produktionen[aktuell].storyboardNotizen = finalPaket.szenen.map {
      "\($0.titel): \($0.visualDirection)"
    }.joined(separator: "\n")
    produktionen[aktuell].status = .storyboard
    produktionen[aktuell].naechsterSchritt =
      "Redaktion fertig · Medien werden automatisch erzeugt oder zugeordnet"
    produktionen[aktuell].letzterFehler = nil
    produktionen[aktuell].aktualisiertAm = Date()
    qualitaetsVorpruefung(id, speichernDanach: false)
    speichern()
    meldung = "Produktionspaket mit \(creatorQuelle) erstellt und auf Themenbezug vorgeprüft."
  }

  func finaleDateiSetzen(_ id: UUID, url: URL, technikScore: Double, audioScore: Double? = nil) {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    produktionen[index].lokaleDatei = url.path
    produktionen[index].qualitaet.technisch = technikScore
    if let audioScore, audioScore > 0 { produktionen[index].qualitaet.audio = audioScore }
    produktionen[index].letztePruefung = Date()
    produktionen[index].aktualisiertAm = Date()
    produktionen[index].letzterFehler = nil
    qualitaetsVorpruefung(id, speichernDanach: false)
    produktionen[index].status = istFreigabeBereit(produktionen[index]) ? .bereit : .qualitaet
    produktionen[index].naechsterSchritt =
      istFreigabeBereit(produktionen[index])
      ? "Bereit zur Veröffentlichung" : freigabeHinweis(produktionen[index])
    speichern()
  }

  func thumbnailSetzen(_ id: UUID, url: URL, score: Double) {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    produktionen[index].thumbnailDatei = url.path
    produktionen[index].qualitaet.thumbnail = score
    produktionen[index].letzterFehler = nil
    produktionen[index].letztePruefung = Date()
    produktionen[index].aktualisiertAm = Date()
    produktionen[index].naechsterSchritt = freigabeHinweis(produktionen[index])
    speichern()
  }

  func produktionsStatusAendern(_ id: UUID, zu status: Produktionsstatus) {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    produktionen[index].status = status
    speichern()
  }

  func freigabeHinweis(_ p: Produktion) -> String {
    if !p.qualitaet.fehlgeschlageneGates.isEmpty {
      return "Nachbessern: " + p.qualitaet.fehlgeschlageneGates.joined(separator: ", ")
    }
    if !p.qualitaet.offeneGates.isEmpty {
      return "Noch prüfen: " + p.qualitaet.offeneGates.joined(separator: ", ")
    }
    if p.qualitaet.gesamt < globaleQualitaetsGrenze {
      return "Gesamtqualität auf mindestens \(Int(globaleQualitaetsGrenze)) erhöhen"
    }
    return "Bereit"
  }

  func qualitaetsVorpruefung(_ id: UUID, speichernDanach: Bool = true) {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    let p = produktionen[index]
    let bewertung = QualityEngineService.shared.bewerten(
      produktion: p,
      medien: medienFuerProduktion(id),
      andereProduktionen: produktionen
    )
    if let value = bewertung.story { produktionen[index].qualitaet.story = value }
    if let value = bewertung.hook { produktionen[index].qualitaet.hook = value }
    if let value = bewertung.titel { produktionen[index].qualitaet.titel = value }
    if let value = bewertung.originalitaet { produktionen[index].qualitaet.originalitaet = value }
    if let value = bewertung.rechte { produktionen[index].qualitaet.rechte = value }
    produktionen[index].qualitaetsHinweise = bewertung.hinweise
    produktionen[index].letztePruefung = Date()
    produktionen[index].aktualisiertAm = Date()
    produktionen[index].naechsterSchritt = freigabeHinweis(produktionen[index])
    if speichernDanach { speichern() }
  }

  func manuelleRedaktionsfreigabe(_ id: UUID) {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    guard !produktionen[index].skript.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
      meldung = "Vor der redaktionellen Freigabe braucht das Projekt ein fertiges Skript."
      return
    }
    produktionen[index].qualitaet.fakten = 100
    produktionen[index].qualitaet.policy = 100
    if produktionen[index].qualitaet.rechte <= 0 {
      let assets = medienFuerProduktion(id)
      let finaleDateiVorhanden =
        produktionen[index].lokaleDatei.map { FileManager.default.fileExists(atPath: $0) } ?? false
      if !assets.isEmpty {
        // Ein finaler Render darf ungeklärte Quellmedien niemals "heilen".
        produktionen[index].qualitaet.rechte =
          assets.contains(where: { !$0.herkunft.autoPublishingErlaubt }) ? 40 : 100
      } else if finaleDateiVorhanden {
        // Bei extern fertig importierten Videos ist dies eine explizite Nutzer-Attestierung.
        produktionen[index].qualitaet.rechte = 100
      }
    }
    produktionen[index].letztePruefung = Date()
    produktionen[index].aktualisiertAm = Date()
    produktionen[index].naechsterSchritt = freigabeHinweis(produktionen[index])
    if istFreigabeBereit(produktionen[index]) { produktionen[index].status = .bereit }
    speichern()
    meldung =
      produktionen[index].qualitaet.rechte >= 90
      ? "Redaktionelle Freigabe gespeichert. Fakten, Richtlinien und die dokumentierte Rechtebasis wurden bestätigt."
      : "Fakten und Richtlinien sind bestätigt. Veröffentlichung bleibt blockiert, weil mindestens ein verwendetes Asset keine geklärte Rechteherkunft hat."
  }

  func livestreamVorbereiten(_ id: UUID) async {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    guard produktionen[index].format == .livestream else {
      meldung = "Dieses Projekt ist kein Livestream."
      return
    }
    guard let verbindungsID = kanal(fuer: produktionen[index].kanalID)?.verbindungsID else {
      meldung = "Für diesen Kanal ist kein Google-/YouTube-Zugang verbunden."
      return
    }
    let start = produktionen[index].geplantFuer ?? Date().addingTimeInterval(3600)
    if produktionen[index].geplantFuer == nil { produktionen[index].geplantFuer = start }
    youtube.aktiveVerbindungSetzen(verbindungsID)
    istBeschaeftigt = true
    produktionen[index].naechsterSchritt = "YouTube-Livestream wird vorbereitet"
    produktionen[index].letzterFehler = nil
    speichern()
    defer { istBeschaeftigt = false }
    do {
      let setup = try await youtube.livestreamEinrichten(
        titel: produktionen[index].arbeitstitel,
        beschreibung: produktionen[index].beschreibung ?? produktionen[index].paket?.beschreibung
          ?? "",
        start: start,
        privatStatus: (produktionen[index].publikationsmodus ?? .review) == .nachGate
          ? "unlisted" : "private")
      guard let aktuell = produktionen.firstIndex(where: { $0.id == id }) else { return }
      let keySaved = KeychainService.shared.speichern(
        setup.streamName, schluessel: "youtube.live.streamName.\(id.uuidString)")
      guard keySaved else {
        throw YouTubeService.YouTubeFehler.apiFehler(
          "Der YouTube-Stream-Key konnte nicht sicher im macOS-Schlüsselbund gespeichert werden.")
      }
      produktionen[aktuell].liveBroadcastID = setup.broadcastID
      produktionen[aktuell].liveStreamID = setup.streamID
      produktionen[aktuell].liveIngestionAddress = setup.ingestionAddress
      produktionen[aktuell].status = .geplant
      produktionen[aktuell].naechsterSchritt = "Encoder mit dem sicheren RTMP-Ziel verbinden"
      produktionen[aktuell].aktualisiertAm = Date()
      speichern()
      meldung = "YouTube-Livestream wurde geplant und mit einem RTMP-Stream verbunden."
    } catch let fehler as YouTubeService.YouTubeFehler {
      if let hinweis = fehler.einrichtungsHinweis { apiEinrichtungsHinweis = hinweis }
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].letzterFehler = fehler.localizedDescription
        produktionen[aktuell].aktualisiertAm = Date()
      }
      speichern()
      meldung = fehler.localizedDescription
    } catch {
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].letzterFehler = error.localizedDescription
        produktionen[aktuell].aktualisiertAm = Date()
      }
      speichern()
      meldung = error.localizedDescription
    }
  }

  func livestreamRTMPZiel(_ id: UUID) -> String? {
    guard let p = produktionen.first(where: { $0.id == id }),
      let address = p.liveIngestionAddress,
      let streamName = KeychainService.shared.lesen("youtube.live.streamName.\(id.uuidString)"),
      !address.isEmpty, !streamName.isEmpty
    else { return nil }
    return address.hasSuffix("/") ? address + streamName : address + "/" + streamName
  }

  func livestreamRTMPKopieren(_ id: UUID) {
    guard let ziel = livestreamRTMPZiel(id) else {
      meldung = "Für dieses Projekt gibt es noch kein RTMP-Ziel."
      return
    }
    NSPasteboard.general.clearContents()
    NSPasteboard.general.setString(ziel, forType: .string)
    meldung =
      "RTMP-Ziel wurde in die Zwischenablage kopiert. Behandle den Stream-Key wie ein Passwort."
  }

  func planungSetzen(_ id: UUID, datum: Date?) {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    produktionen[index].geplantFuer = datum
    produktionen[index].aktualisiertAm = Date()
    speichern()
  }

  func produktionHochladen(_ id: UUID) async {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    let p = produktionen[index]
    let v11 = v11State.productionState(for: id)
    if v11?.timeline != nil || !(v11?.sourceAssetIDs.isEmpty ?? true) {
      let check = bereitCheck(for: id)
      guard check.canPublish else {
        meldung = check.issues.first?.message ?? "Diese Produktion ist noch nicht bereit zum Veröffentlichen."
        return
      }
    } else {
      // Migrierte v10-Projekte bleiben veröffentlichbar, wenn ihr bisheriger
      // belastbarer Freigabezustand vollständig vorhanden ist.
      guard istFreigabeBereit(p) else {
        meldung = "Noch nicht veröffentlichungsbereit. " + freigabeHinweis(p)
        return
      }
    }
    guard let pfad = p.lokaleDatei else {
      meldung = "Wähle oder rendere zuerst die finale Videodatei."
      return
    }
    guard FileManager.default.fileExists(atPath: pfad) else {
      meldung = "Die finale Videodatei existiert nicht mehr. Rendere die Produktion erneut."
      return
    }
    if let v11, !v11.sourceAssetIDs.isEmpty {
      let used = v11State.sourceAssets.filter { v11.sourceAssetIDs.contains($0.id) }
      guard used.count == v11.sourceAssetIDs.count, used.allSatisfy({ $0.canAutoPublish }) else {
        meldung = "Auto-Publishing blockiert: Mindestens eine verwendete Quelle besitzt keine eindeutig erlaubte Veröffentlichungsnutzung."
        return
      }
    } else if let assetIDs = p.assetIDs {
      let unklar = medien.filter { assetIDs.contains($0.id) && !$0.herkunft.autoPublishingErlaubt }
      guard unklar.isEmpty else {
        meldung = "Auto-Publishing blockiert: Bei mindestens einem verwendeten Asset ist die Rechteherkunft unklar."
        return
      }
    }

    guard let verbindungsID = kanal(fuer: p.kanalID)?.verbindungsID else {
      meldung = "Für diesen Kanal ist kein Google-Zugang verbunden."
      return
    }
    youtube.aktiveVerbindungSetzen(verbindungsID)
    let attrs = try? FileManager.default.attributesOfItem(atPath: pfad)
    let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
    var record = v11State.uploadRecords.first(where: { $0.productionID == id })
      ?? UploadRecord(productionID: id, channelID: p.kanalID, filePath: pfad, fileSize: size)
    if record.filePath != pfad || record.fileSize != size {
      // Neuer Render => alte resumable Session ist nicht mehr gültig.
      record = UploadRecord(productionID: id, channelID: p.kanalID, filePath: pfad, fileSize: size)
    }

    istBeschaeftigt = true
    produktionen[index].uploadFortschritt = size > 0 ? Double(record.confirmedBytes) / Double(size) : 0
    produktionen[index].letzterFehler = nil
    produktionen[index].aktualisiertAm = Date()
    v11State.upsertUploadRecord(record)
    speichern()
    defer { istBeschaeftigt = false }

    do {
      let profile = channelProfile(for: p.kanalID)
      let reviewRequired = v11?.reviewBeforePublishOverride ?? ((p.publikationsmodus ?? .review) == .review)
      let reviewApproved = !reviewRequired || v11?.phase == .ready || v11?.phase == .uploading || v11?.phase == .published
      guard reviewApproved else {
        meldung = "Vor dem Upload muss das Review freigegeben werden."
        return
      }
      let privacyStatus = p.geplantFuer != nil ? "private" : profile.defaultPrivacy.apiValue
      let existingVideoID = p.youtubeVideoID ?? record.youtubeVideoID
      let videoID: String
      if let existingVideoID, !existingVideoID.isEmpty {
        // Idempotency: Eine bereits von YouTube bestätigte ID wird niemals erneut hochgeladen.
        videoID = existingVideoID
      } else {
        record.state = record.sessionURL == nil ? .notStarted : .uploading
        record.updatedAt = Date()
        v11State.upsertUploadRecord(record)
        speichern()
        videoID = try await youtube.videoHochladen(
          datei: URL(fileURLWithPath: pfad),
          titel: p.arbeitstitel,
          beschreibung: p.beschreibung ?? p.paket?.beschreibung ?? "Erstellt und geprüft mit Blackstock.",
          tags: p.tags ?? p.paket?.tags ?? [kanalName(fuer: p.kanalID), p.format.rawValue, "Blackstock"],
          privacyStatus: privacyStatus,
          geplantFuer: p.geplantFuer,
          bestehendeSessionURL: record.sessionURL,
          bestaetigteBytes: record.confirmedBytes
        ) { [weak self] status in
          guard let self else { return }
          guard var current = self.v11State.uploadRecords.first(where: { $0.productionID == id }) else { return }
          current.sessionURL = status.sessionURL
          current.confirmedBytes = status.confirmedBytes
          current.fileSize = status.totalBytes
          current.state = status.confirmedBytes >= status.totalBytes ? .uploaded : .uploading
          current.lastError = nil
          current.updatedAt = Date()
          self.v11State.upsertUploadRecord(current)
          if let i = self.produktionen.firstIndex(where: { $0.id == id }) {
            self.produktionen[i].uploadFortschritt = status.totalBytes > 0
              ? Double(status.confirmedBytes) / Double(status.totalBytes) : 0
          }
          self.speichern()
        }

        // Kritischer Commit-Punkt: die YouTube-ID sofort persistieren, BEVOR
        // optionale Folgeaktionen wie Thumbnail-Upload ausgeführt werden.
        guard let currentIndex = produktionen.firstIndex(where: { $0.id == id }) else { return }
        produktionen[currentIndex].youtubeVideoID = videoID
        produktionen[currentIndex].uploadFortschritt = 1
        record = v11State.uploadRecords.first(where: { $0.productionID == id }) ?? record
        record.youtubeVideoID = videoID
        record.confirmedBytes = size
        record.state = .thumbnailPending
        record.lastError = nil
        record.updatedAt = Date()
        v11State.upsertUploadRecord(record)
        speichern()
      }

      if let thumbnailPfad = p.thumbnailDatei, FileManager.default.fileExists(atPath: thumbnailPfad) {
        try await youtube.thumbnailHochladen(videoID: videoID, datei: URL(fileURLWithPath: thumbnailPfad))
      }

      guard let aktuell = produktionen.firstIndex(where: { $0.id == id }) else { return }
      produktionen[aktuell].youtubeVideoID = videoID
      produktionen[aktuell].uploadFortschritt = 1
      produktionen[aktuell].letzterFehler = nil
      produktionen[aktuell].aktualisiertAm = Date()
      if p.geplantFuer != nil {
        produktionen[aktuell].status = .geplant
        v11PhaseSetzen(id, phase: .scheduled, detail: "Upload abgeschlossen und geplant")
      } else if privacyStatus == "public" {
        produktionen[aktuell].status = .live
        v11PhaseSetzen(id, phase: .published, detail: "Auf YouTube veröffentlicht")
      } else {
        produktionen[aktuell].status = .bereit
        v11PhaseSetzen(
          id, phase: .ready,
          detail: privacyStatus == "unlisted" ? "Nicht gelistet hochgeladen" : "Privat hochgeladen")
      }
      record = v11State.uploadRecords.first(where: { $0.productionID == id }) ?? record
      record.youtubeVideoID = videoID
      record.state = .complete
      record.lastError = nil
      record.updatedAt = Date()
      v11State.upsertUploadRecord(record)
      speichern()
      meldung = privacyStatus == "public" && p.geplantFuer == nil
        ? "Upload abgeschlossen und veröffentlicht · YouTube-ID \(videoID)."
        : "Upload abgeschlossen · YouTube-ID \(videoID) · Sichtbarkeit: \(p.geplantFuer != nil ? "geplant" : profile.defaultPrivacy.rawValue)."
    } catch let fehler as YouTubeService.YouTubeFehler {
      if let hinweis = fehler.einrichtungsHinweis { apiEinrichtungsHinweis = hinweis }
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].letzterFehler = fehler.localizedDescription
        produktionen[aktuell].aktualisiertAm = Date()
      }
      if var failed = v11State.uploadRecords.first(where: { $0.productionID == id }) {
        failed.state = .failed
        failed.lastError = fehler.localizedDescription
        failed.updatedAt = Date()
        v11State.upsertUploadRecord(failed)
      }
      speichern()
      meldung = fehler.localizedDescription
    } catch is CancellationError {
      meldung = "Upload pausiert. Blackstock setzt ihn bei einem erneuten Versuch an der bestätigten Stelle fort."
      speichern()
    } catch {
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].letzterFehler = error.localizedDescription
        produktionen[aktuell].aktualisiertAm = Date()
      }
      if var failed = v11State.uploadRecords.first(where: { $0.productionID == id }) {
        failed.state = .failed
        failed.lastError = error.localizedDescription
        failed.updatedAt = Date()
        v11State.upsertUploadRecord(failed)
      }
      speichern()
      meldung = "Upload fehlgeschlagen. \(error.localizedDescription)"
    }
  }

  // MARK: - Creator Engines, Medien & Batch

  func providerKonfigurieren(
    _ id: UUID, basisURL: String, modell: String, apiKey: String?, optionen: [String: String]? = nil
  ) {
    guard let index = provider.firstIndex(where: { $0.id == id }) else { return }
    provider[index].basisURL = basisURL.trimmingCharacters(in: .whitespacesAndNewlines)
    provider[index].modell = modell.trimmingCharacters(in: .whitespacesAndNewlines)
    if let optionen { provider[index].optionen = optionen }
    if let apiKey, !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
      speichereProviderSchluessel(apiKey, fuer: provider[index])
    } else {
      provider[index].apiKeyVorhanden =
        KeychainService.shared.lesen("provider.api.\(id.uuidString)") != nil
    }
    let preset = EnginePresetService.aktiviertesPreset(fuer: provider[index])
    provider[index].verbunden =
      preset?.brauchtAPIKey == false
      || (!(provider[index].basisURL ?? "").isEmpty && !(provider[index].modell ?? "").isEmpty
        && (provider[index].apiKeyVorhanden ?? false))
    provider[index].detail =
      provider[index].verbunden ? (preset?.detail ?? "Creator Engine bereit") : "API-Key verbinden"
    speichern()
  }

  func providerAPIKeyVorhanden(_ id: UUID) -> Bool {
    KeychainService.shared.lesen("provider.api.\(id.uuidString)") != nil
  }

  func providerPresetID(_ typ: ProviderVerbindung.Typ) -> String {
    guard let p = provider.first(where: { $0.typ == typ }) else {
      return EnginePresetService.standardPreset(fuer: typ).id
    }
    return EnginePresetService.aktiviertesPreset(fuer: p)?.id ?? "custom"
  }

  func creatorEnginesAufStandard() {
    for typ in [
      ProviderVerbindung.Typ.research, .image, .voice, .video, .music,
    ] {
      providerPresetAnwenden(typ, presetID: EnginePresetService.standardPreset(fuer: typ).id)
    }
    speichern()
    meldung = "Creator Engines wurden auf die vorkonfigurierten Blackstock-Standards zurückgesetzt."
  }

  func providerPresetAnwenden(_ typ: ProviderVerbindung.Typ, presetID: String) {
    guard let preset = EnginePresetService.preset(id: presetID), preset.typ == typ,
      let index = provider.firstIndex(where: { $0.typ == typ })
    else { return }
    provider[index] = EnginePresetService.anwenden(preset, auf: provider[index])
    if preset.brauchtAPIKey {
      let presetKey =
        KeychainService.shared.lesen("provider.preset.\(preset.id)")
        ?? preset.umgebungsvariable.flatMap {
          KeychainService.shared.lesen("provider.shared.\($0)")
        }
      if let presetKey {
        _ = KeychainService.shared.speichern(
          presetKey, schluessel: "provider.api.\(provider[index].id.uuidString)")
        provider[index].apiKeyVorhanden = true
        provider[index].verbunden = true
      } else {
        _ = KeychainService.shared.loeschen("provider.api.\(provider[index].id.uuidString)")
        provider[index].apiKeyVorhanden = false
        provider[index].verbunden = false
      }
    } else {
      provider[index].apiKeyVorhanden = true
      provider[index].verbunden = true
    }
    provider[index].detail = preset.detail
    speichern()
  }

  func providerSchluesselAusZwischenablage(_ typ: ProviderVerbindung.Typ) {
    guard let index = provider.firstIndex(where: { $0.typ == typ }) else { return }
    guard
      let raw = NSPasteboard.general.string(forType: .string)?.trimmingCharacters(
        in: .whitespacesAndNewlines),
      raw.count >= 12
    else {
      meldung = "In der Zwischenablage wurde kein plausibler API-Key gefunden."
      return
    }
    speichereProviderSchluessel(raw, fuer: provider[index])
    let preset = EnginePresetService.aktiviertesPreset(fuer: provider[index])
    provider[index].verbunden = true
    provider[index].detail = preset?.detail ?? "Creator Engine bereit"
    speichern()
    meldung = "\(provider[index].name) wurde sicher im macOS-Schlüsselbund verbunden."
  }

  func providerVerbindungOeffnen(_ typ: ProviderVerbindung.Typ) {
    guard let p = provider.first(where: { $0.typ == typ }),
      let preset = EnginePresetService.aktiviertesPreset(fuer: p),
      let raw = preset.verbindungsURL, let url = URL(string: raw)
    else { return }
    NSWorkspace.shared.open(url)
  }

  private func speichereProviderSchluessel(_ key: String, fuer p: ProviderVerbindung) {
    guard let index = provider.firstIndex(where: { $0.id == p.id }) else { return }
    let clean = key.trimmingCharacters(in: .whitespacesAndNewlines)
    let ok = KeychainService.shared.speichern(clean, schluessel: "provider.api.\(p.id.uuidString)")
    provider[index].apiKeyVorhanden = ok
    if let preset = EnginePresetService.aktiviertesPreset(fuer: p) {
      _ = KeychainService.shared.speichern(clean, schluessel: "provider.preset.\(preset.id)")
      if let env = preset.umgebungsvariable {
        _ = KeychainService.shared.speichern(clean, schluessel: "provider.shared.\(env)")
      }
    }
    if !ok {
      meldung = "Der API-Key konnte nicht sicher im macOS-Schlüsselbund gespeichert werden."
    }
  }

  private func automatischProviderSchluesselImportieren() {
    for index in provider.indices {
      guard let preset = EnginePresetService.aktiviertesPreset(fuer: provider[index]) else {
        continue
      }
      if !preset.brauchtAPIKey {
        provider[index].apiKeyVorhanden = true
        provider[index].verbunden = true
        continue
      }
      if KeychainService.shared.lesen("provider.api.\(provider[index].id.uuidString)") != nil {
        provider[index].apiKeyVorhanden = true
        provider[index].verbunden = true
        continue
      }
      let existing =
        KeychainService.shared.lesen("provider.preset.\(preset.id)")
        ?? preset.umgebungsvariable.flatMap {
          KeychainService.shared.lesen("provider.shared.\($0)")
        }
        ?? preset.umgebungsvariable.flatMap { ProcessInfo.processInfo.environment[$0] }
      if let existing, !existing.isEmpty {
        _ = KeychainService.shared.speichern(
          existing, schluessel: "provider.api.\(provider[index].id.uuidString)")
        _ = KeychainService.shared.speichern(existing, schluessel: "provider.preset.\(preset.id)")
        if let env = preset.umgebungsvariable {
          _ = KeychainService.shared.speichern(existing, schluessel: "provider.shared.\(env)")
        }
        provider[index].apiKeyVorhanden = true
        provider[index].verbunden = true
      } else {
        provider[index].apiKeyVorhanden = false
        provider[index].verbunden = false
      }
    }
  }

  func medienImportieren(_ urls: [URL], herkunft: MedienHerkunft) {
    let videoExtensions: Set<String> = ["mp4", "mov", "m4v", "mkv", "webm"]
    let audioExtensions: Set<String> = ["mp3", "wav", "m4a", "aac", "aiff", "flac"]
    let imageExtensions: Set<String> = ["png", "jpg", "jpeg", "heic", "webp", "tif", "tiff"]
    var ignoriert = 0
    for url in urls {
      guard FileManager.default.fileExists(atPath: url.path) else {
        ignoriert += 1
        continue
      }
      let ext = url.pathExtension.lowercased()
      let typ: MedienTyp
      if videoExtensions.contains(ext) {
        typ = .video
      } else if audioExtensions.contains(ext) {
        typ = .audio
      } else if imageExtensions.contains(ext) {
        typ = .bild
      } else {
        ignoriert += 1
        continue
      }
      if !medien.contains(where: { $0.lokalerPfad == url.path }) {
        medien.insert(
          MedienAsset(
            name: url.lastPathComponent, lokalerPfad: url.path, typ: typ, herkunft: herkunft), at: 0
        )
      }
    }
    speichern()
    if ignoriert > 0 {
      meldung = "\(ignoriert) nicht unterstützte oder fehlende Datei(en) wurden übersprungen."
    }
  }

  func medienEntfernen(_ assetID: UUID) {
    medien.removeAll { $0.id == assetID }
    for index in produktionen.indices {
      produktionen[index].assetIDs?.removeAll { $0 == assetID }
      if produktionen[index].qualitaet.rechte > 0 {
        produktionen[index].qualitaet.rechte = 0
        qualitaetsVorpruefung(produktionen[index].id, speichernDanach: false)
      }
    }
    speichern()
  }

  func medienNeuVerknuepfen(_ assetID: UUID, mit url: URL) {
    guard FileManager.default.fileExists(atPath: url.path),
      let index = medien.firstIndex(where: { $0.id == assetID })
    else { return }
    medien[index].lokalerPfad = url.path
    medien[index].name = url.lastPathComponent
    speichern()
  }

  func fehlendeMedien() -> [MedienAsset] {
    medien.filter { !FileManager.default.fileExists(atPath: $0.lokalerPfad) }
  }

  func asset(_ assetID: UUID, zuProduktion produktionID: UUID) {
    guard medien.contains(where: { $0.id == assetID }),
      let index = produktionen.firstIndex(where: { $0.id == produktionID })
    else { return }
    var ids = produktionen[index].assetIDs ?? []
    if !ids.contains(assetID) { ids.append(assetID) }
    produktionen[index].assetIDs = ids
    produktionen[index].status = .visuals
    produktionen[index].naechsterSchritt = "Rohschnitt aus ausgewählten Medien rendern"
    produktionen[index].aktualisiertAm = Date()
    qualitaetsVorpruefung(produktionID, speichernDanach: false)
    speichern()
  }

  func assetEntfernen(_ assetID: UUID, ausProduktion produktionID: UUID) {
    guard let index = produktionen.firstIndex(where: { $0.id == produktionID }) else { return }
    produktionen[index].assetIDs?.removeAll { $0 == assetID }
    produktionen[index].qualitaet.rechte = 0
    produktionen[index].aktualisiertAm = Date()
    qualitaetsVorpruefung(produktionID, speichernDanach: false)
    speichern()
  }

  func medienFuerProduktion(_ id: UUID) -> [MedienAsset] {
    guard let p = produktionen.first(where: { $0.id == id }) else { return [] }
    let ids = Set(p.assetIDs ?? [])
    return medien.filter { ids.contains($0.id) }
  }

  func lokalenRohschnittRendern(_ id: UUID, ziel: URL) async {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    let clips = medienFuerProduktion(id).filter { $0.typ == .video }.map {
      URL(fileURLWithPath: $0.lokalerPfad)
    }
    guard !clips.isEmpty else {
      meldung =
        "Füge dem Projekt zuerst mindestens einen echten Video-Clip aus der Bibliothek hinzu."
      return
    }
    istBeschaeftigt = true
    produktionen[index].status = .schnitt
    produktionen[index].naechsterSchritt = "Lokaler Rohschnitt wird gerendert"
    speichern()
    defer { istBeschaeftigt = false }
    do {
      let url = try await VideoEditingService.shared.rohSchnitt(
        clips: clips, format: produktionen[index].format, ziel: ziel)
      let check = await MediaQualityService.shared.videoPruefen(
        url: url, erwartetesFormat: produktionen[index].format)
      finaleDateiSetzen(id, url: url, technikScore: check.videoScore, audioScore: check.audioScore)
      meldung = "Rohschnitt gerendert und technisch geprüft: \(Int(check.score))/100."
    } catch {
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].status = .visuals
        produktionen[aktuell].letzterFehler = error.localizedDescription
        produktionen[aktuell].naechsterSchritt = "Renderfehler beheben und erneut versuchen"
        produktionen[aktuell].aktualisiertAm = Date()
      }
      speichern()
      meldung = error.localizedDescription
    }
  }

  @discardableResult
  func autoMedienZuordnen(_ produktionID: UUID, maxClips: Int = 8) -> Int {
    guard let index = produktionen.firstIndex(where: { $0.id == produktionID }) else { return 0 }
    let p = produktionen[index]
    let text = ([p.arbeitstitel, p.chanceSnapshot?.thema ?? "", p.hook] + (p.tags ?? []))
      .joined(separator: " ")
      .lowercased()
    let tokens = Set(
      text.split { !$0.isLetter && !$0.isNumber }.map(String.init).filter { $0.count >= 4 })
    let existing = Set(p.assetIDs ?? [])

    let candidates = medien.filter {
      $0.typ == .video && $0.herkunft.autoPublishingErlaubt
        && FileManager.default.fileExists(atPath: $0.lokalerPfad) && !existing.contains($0.id)
    }.map { asset -> (MedienAsset, Int) in
      let haystack = "\(asset.name) \(asset.rechteNotiz)".lowercased()
      let score =
        tokens.reduce(0) { $0 + (haystack.contains($1) ? 1 : 0) }
        + (asset.herkunft == .eigen ? 2 : 1)
      return (asset, score)
    }
    .filter { $0.1 >= 2 }
    .sorted { $0.1 > $1.1 }

    var ids = produktionen[index].assetIDs ?? []
    for (asset, _) in candidates.prefix(max(1, min(16, maxClips))) where !ids.contains(asset.id) {
      ids.append(asset.id)
    }
    produktionen[index].assetIDs = ids
    if !ids.isEmpty {
      produktionen[index].status = .visuals
      produktionen[index].aktualisiertAm = Date()
      qualitaetsVorpruefung(produktionID, speichernDanach: false)
      speichern()
    }
    return ids.filter { !existing.contains($0) }.count
  }

  func generativeClipsErzeugen(_ id: UUID, maxClips: Int? = nil) async {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    guard let paket = produktionen[index].paket, !paket.szenen.isEmpty else {
      meldung = "Für Visuals wird zuerst ein Szenenplan benötigt."
      return
    }
    guard let engine = provider.first(where: { $0.typ == .video }) else {
      await lokalenVisualTrackErzeugen(id)
      return
    }

    if EnginePresetService.aktiviertesPreset(fuer: engine)?.brauchtAPIKey == false {
      await lokalenVisualTrackErzeugen(id)
      return
    }
    guard videoEngineBereit,
      let apiKey = KeychainService.shared.lesen("provider.api.\(engine.id.uuidString)")
    else {
      await lokalenVisualTrackErzeugen(id)
      return
    }

    let modus = produktionen[index].modus ?? .studio
    let defaultLimit: Int = {
      switch modus {
      case .fast: return produktionen[index].format == .short ? 4 : 3
      case .studio: return produktionen[index].format == .short ? 6 : 5
      case .master: return produktionen[index].format == .short ? 8 : 6
      }
    }()
    let limit = max(1, min(maxClips ?? defaultLimit, paket.szenen.count))
    let szenen = Array(paket.szenen.prefix(limit))
    let kanal = kanal(fuer: produktionen[index].kanalID)
    let visualDNA = kanal?.branding?.thumbnailStil ?? "hochwertig, editorial, realistisch"

    istBeschaeftigt = true
    produktionen[index].status = .visuals
    produktionen[index].naechsterSchritt = "Premium-Szenen werden erzeugt"
    produktionen[index].letzterFehler = nil
    produktionen[index].aktualisiertAm = Date()
    speichern()
    defer { istBeschaeftigt = false }

    do {
      let folder = try persistence.arbeitsordner("GeneratedVideo")
      var ids = produktionen[index].assetIDs ?? []
      for (offset, szene) in szenen.enumerated() {
        let prompt = """
          Professional YouTube B-roll for the following scene. Create a coherent, cinematic shot that can be edited into a premium creator video.
          Scene: \(szene.titel)
          Visual direction: \(szene.visualDirection)
          Channel visual DNA: \(visualDNA)
          Do not render subtitles, UI text or watermarks inside the generated shot. Avoid imitating copyrighted characters or protected brand artwork. Prefer believable lighting, natural motion and documentary/editorial framing.
          """
        let target = folder.appendingPathComponent("\(id.uuidString)-scene-\(offset + 1).mp4")
        _ = try await CloudVideoService.shared.generieren(
          prompt: prompt, format: produktionen[index].format, provider: engine, apiKey: apiKey,
          ziel: target, sekunden: 8)
        let asset = MedienAsset(
          name: "AI Szene \(offset + 1) · \(szene.titel)", lokalerPfad: target.path,
          typ: .video, herkunft: .generiert,
          rechteNotiz:
            "Generiert über \(engine.name) / \(engine.modell ?? "Video Engine"). Nutzung gemäß Providerbedingungen prüfen."
        )
        medien.insert(asset, at: 0)
        ids.append(asset.id)
        if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
          produktionen[aktuell].assetIDs = ids.reduce(into: [UUID]()) { result, value in
            if !result.contains(value) { result.append(value) }
          }
          produktionen[aktuell].naechsterSchritt = "Premium-Visuals \(offset + 1)/\(szenen.count)"
          produktionen[aktuell].aktualisiertAm = Date()
          speichern()
        }
      }
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].status = .visuals
        produktionen[aktuell].naechsterSchritt =
          "Generierte Clips erstellt · visuelle Qualität prüfen"
        produktionen[aktuell].aktualisiertAm = Date()
        qualitaetsVorpruefung(id, speichernDanach: false)
      }
      speichern()
      meldung = "Premium-Visuals wurden erzeugt und mit Herkunft dokumentiert."
    } catch {
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].letzterFehler = error.localizedDescription
        produktionen[aktuell].naechsterSchritt =
          "Premium-Video fehlgeschlagen · lokaler Visual-Fallback ist verfügbar"
        produktionen[aktuell].aktualisiertAm = Date()
      }
      speichern()
      meldung =
        "Premium-Video fehlgeschlagen. Blackstock wechselt automatisch auf den lokalen Visual-Renderer."
      await lokalenVisualTrackErzeugen(id)
    }
  }

  private func szenenbilderAutomatischErzeugen(_ id: UUID) async -> [URL] {
    guard let index = produktionen.firstIndex(where: { $0.id == id }),
      let paket = produktionen[index].paket,
      !paket.szenen.isEmpty,
      let kanal = kanal(fuer: produktionen[index].kanalID)
    else { return [] }

    let existingIDs = Set(produktionen[index].assetIDs ?? [])
    let existing = medien.filter {
      existingIDs.contains($0.id) && $0.typ == .bild && $0.herkunft == .generiert
        && $0.rechteNotiz.contains("Blackstock Szenenbild")
        && FileManager.default.fileExists(atPath: $0.lokalerPfad)
    }
    if !existing.isEmpty {
      return existing.sorted {
        $0.lokalerPfad.localizedStandardCompare($1.lokalerPfad) == .orderedAscending
      }.map { URL(fileURLWithPath: $0.lokalerPfad) }
    }

    let maxImages: Int = {
      let available = paket.szenen.count
      switch produktionen[index].modus ?? .studio {
      case .fast: return min(available, produktionen[index].format == .short ? 3 : 4)
      case .studio: return min(available, produktionen[index].format == .short ? 8 : 10)
      case .master: return min(available, produktionen[index].format == .short ? 10 : 14)
      }
    }()

    guard let folder = try? persistence.arbeitsordner("SceneImages") else { return [] }
    let imageEngine = provider.first(where: { $0.typ == .image })
    let imagePreset = imageEngine.flatMap { EnginePresetService.aktiviertesPreset(fuer: $0) }
    let cloudKey: String? = {
      guard let imageEngine, imagePreset?.premium == true else { return nil }
      return KeychainService.shared.lesen("provider.api.\(imageEngine.id.uuidString)")
    }()

    var urls: [URL] = []
    var ids = produktionen[index].assetIDs ?? []
    for (offset, scene) in paket.szenen.prefix(maxImages).enumerated() {
      let target = folder.appendingPathComponent("\(id.uuidString)-scene-\(offset + 1).png")
      let prompt = """
        Editorial YouTube scene image for this exact topic: \(produktionen[index].arbeitstitel).
        Scene: \(scene.titel).
        Narration meaning: \(scene.narration).
        Visual direction: \(scene.visualDirection).
        Channel: \(kanal.thema). Create one clear subject and composition that directly supports this scene. No text, no logos, no watermarks, no imitation of copyrighted characters or protected brand artwork.
        """
      do {
        let url: URL
        let sourceNote: String
        if let imageEngine, let cloudKey, imagePreset?.premium == true {
          do {
            url = try await CloudImageService.shared.generieren(
              prompt: prompt, provider: imageEngine, apiKey: cloudKey, ziel: target)
            sourceNote = "Premium-Bildengine \(imageEngine.name)"
          } catch {
            url = try await LocalSceneImageService.shared.generieren(
              scene: scene, produktion: produktionen[index], kanal: kanal,
              branding: kanal.branding ?? KanalBranding(), index: offset, ziel: target)
            sourceNote = "Blackstock Local Scene Visual"
          }
        } else {
          url = try await LocalSceneImageService.shared.generieren(
            scene: scene, produktion: produktionen[index], kanal: kanal,
            branding: kanal.branding ?? KanalBranding(), index: offset, ziel: target)
          sourceNote = "Blackstock Local Scene Visual"
        }
        let asset = MedienAsset(
          name: "Szenenbild \(offset + 1) · \(scene.titel)", lokalerPfad: url.path,
          typ: .bild, herkunft: .generiert,
          rechteNotiz: "Blackstock Szenenbild · \(sourceNote).")
        medien.insert(asset, at: 0)
        ids.append(asset.id)
        urls.append(url)
      } catch {
        // Eine einzelne Bildszene darf den Video-Render niemals stoppen.
        continue
      }
    }
    if let aktuell = produktionen.firstIndex(where: { $0.id == id }), !urls.isEmpty {
      produktionen[aktuell].assetIDs = ids.reduce(into: [UUID]()) { result, value in
        if !result.contains(value) { result.append(value) }
      }
      produktionen[aktuell].aktualisiertAm = Date()
      speichern()
    }
    return urls
  }

  func lokalenVisualTrackErzeugen(_ id: UUID) async {
    guard let index = produktionen.firstIndex(where: { $0.id == id }),
      let kanal = kanal(fuer: produktionen[index].kanalID)
    else { return }
    let sceneImages = await szenenbilderAutomatischErzeugen(id)
    guard let refreshedIndex = produktionen.firstIndex(where: { $0.id == id }) else { return }
    istBeschaeftigt = true
    produktionen[refreshedIndex].status = .visuals
    produktionen[refreshedIndex].naechsterSchritt = "Lokaler Visual-Track wird gerendert"
    produktionen[refreshedIndex].letzterFehler = nil
    speichern()
    defer { istBeschaeftigt = false }
    do {
      let folder = try persistence.arbeitsordner("LocalVisuals")
      let target = folder.appendingPathComponent("\(id.uuidString)-local-visual.mp4")
      let url = try await LocalVisualService.shared.rendern(
        produktion: produktionen[refreshedIndex], kanal: kanal,
        branding: kanal.branding ?? KanalBranding(), szenenbilder: sceneImages, ziel: target)
      let asset = MedienAsset(
        name: "Blackstock Local Visual · \(produktionen[refreshedIndex].arbeitstitel)",
        lokalerPfad: url.path, typ: .video, herkunft: .generiert,
        rechteNotiz: "Lokal von Blackstock aus eigenem Kanal-Branding und Projektdaten erzeugt.")
      medien.insert(asset, at: 0)
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        var ids = produktionen[aktuell].assetIDs ?? []
        ids.append(asset.id)
        produktionen[aktuell].assetIDs = ids.reduce(into: [UUID]()) { result, value in
          if !result.contains(value) { result.append(value) }
        }
        produktionen[aktuell].status = .visuals
        produktionen[aktuell].naechsterSchritt = "Lokaler Visual-Track bereit · Master rendern"
        produktionen[aktuell].aktualisiertAm = Date()
        qualitaetsVorpruefung(id, speichernDanach: false)
      }
      speichern()
      meldung = "Lokaler Visual-Track wurde erzeugt. Premium-Video kann ihn später ersetzen."
    } catch {
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].letzterFehler = error.localizedDescription
        produktionen[aktuell].aktualisiertAm = Date()
      }
      speichern()
      meldung = error.localizedDescription
    }
  }

  func voiceoverErzeugen(_ id: UUID) async {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    let text = produktionen[index].skript.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !text.isEmpty else {
      meldung = "Erzeuge oder schreibe zuerst ein Skript."
      return
    }
    guard let engine = provider.first(where: { $0.typ == .voice }), voiceEngineBereit,
      let apiKey = KeychainService.shared.lesen("provider.api.\(engine.id.uuidString)")
    else {
      await lokalesVoiceoverErzeugen(id)
      return
    }

    istBeschaeftigt = true
    produktionen[index].status = .stimme
    produktionen[index].naechsterSchritt = "Premium-Voiceover wird erzeugt"
    produktionen[index].letzterFehler = nil
    speichern()
    defer { istBeschaeftigt = false }
    do {
      let folder = try persistence.arbeitsordner("Voiceovers")
      let target = folder.appendingPathComponent("\(id.uuidString)-premium.m4a")
      let result = try await CloudVoiceService.shared.generieren(
        text: text, provider: engine, apiKey: apiKey, ziel: target)
      guard let aktuell = produktionen.firstIndex(where: { $0.id == id }) else { return }
      produktionen[aktuell].voiceoverDatei = result.path
      produktionen[aktuell].qualitaet.stimme = max(produktionen[aktuell].qualitaet.stimme, 92)
      produktionen[aktuell].status = .visuals
      produktionen[aktuell].naechsterSchritt = "Medien prüfen und Master-Render erstellen"
      produktionen[aktuell].aktualisiertAm = Date()
      qualitaetsVorpruefung(id, speichernDanach: false)
      speichern()
      meldung = "Premium-Voiceover wurde erzeugt und dem Projekt zugeordnet."
    } catch {
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].letzterFehler = error.localizedDescription
        produktionen[aktuell].status = .skript
        produktionen[aktuell].aktualisiertAm = Date()
      }
      speichern()
      meldung =
        "Premium-Voice fehlgeschlagen. Blackstock nutzt automatisch die lokale macOS-Stimme."
      await lokalesVoiceoverErzeugen(id)
    }
  }

  func lokalesVoiceoverErzeugen(_ id: UUID, voiceIdentifier: String? = nil) async {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    let text = produktionen[index].skript.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !text.isEmpty else {
      meldung = "Erzeuge oder schreibe zuerst ein Skript."
      return
    }
    istBeschaeftigt = true
    produktionen[index].status = .stimme
    produktionen[index].naechsterSchritt = "Voiceover wird lokal erzeugt"
    produktionen[index].letzterFehler = nil
    speichern()
    defer { istBeschaeftigt = false }
    do {
      let folder = try persistence.arbeitsordner("Voiceovers")
      let target = folder.appendingPathComponent("\(id.uuidString).caf")
      let result = try await VoiceoverService.shared.generieren(
        text: text, voiceIdentifier: voiceIdentifier, ziel: target)
      guard let aktuell = produktionen.firstIndex(where: { $0.id == id }) else { return }
      produktionen[aktuell].voiceoverDatei = result.path
      produktionen[aktuell].qualitaet.stimme = max(produktionen[aktuell].qualitaet.stimme, 86)
      produktionen[aktuell].status = .visuals
      produktionen[aktuell].naechsterSchritt = "Medien prüfen und Master-Render erstellen"
      produktionen[aktuell].aktualisiertAm = Date()
      qualitaetsVorpruefung(id, speichernDanach: false)
      speichern()
      meldung =
        "Lokales macOS-Voiceover wurde erzeugt. Für Premium-Stimmen kannst du zusätzlich eine externe Voice-Engine konfigurieren."
    } catch {
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].letzterFehler = error.localizedDescription
        produktionen[aktuell].status = .skript
        produktionen[aktuell].aktualisiertAm = Date()
      }
      speichern()
      meldung = error.localizedDescription
    }
  }

  func voiceoverDateiSetzen(_ id: UUID, url: URL) {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    guard FileManager.default.fileExists(atPath: url.path) else {
      meldung = "Die ausgewählte Voiceover-Datei existiert nicht."
      return
    }
    produktionen[index].voiceoverDatei = url.path
    produktionen[index].qualitaet.stimme = max(produktionen[index].qualitaet.stimme, 84)
    produktionen[index].aktualisiertAm = Date()
    speichern()
  }

  func musikAutomatischErzeugen(_ id: UUID) async {
    guard let index = produktionen.firstIndex(where: { $0.id == id }),
      let kanal = kanal(fuer: produktionen[index].kanalID)
    else { return }
    if let assetID = produktionen[index].musikAssetID,
      let asset = medien.first(where: { $0.id == assetID }),
      FileManager.default.fileExists(atPath: asset.lokalerPfad)
    {
      return
    }
    do {
      let folder = try persistence.arbeitsordner("AutoMusic")
      let target = folder.appendingPathComponent("\(id.uuidString)-bed.wav")
      let url = try await LocalMusicService.shared.generieren(
        produktion: produktionen[index], kanal: kanal, ziel: target)
      let asset = MedienAsset(
        name: "Blackstock Auto Music · \(produktionen[index].arbeitstitel)",
        lokalerPfad: url.path, typ: .audio, herkunft: .generiert,
        rechteNotiz:
          "Algorithmisch lokal von Blackstock erzeugt; keine externe Musikquelle verwendet.")
      medien.insert(asset, at: 0)
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].musikAssetID = asset.id
        produktionen[aktuell].aktualisiertAm = Date()
      }
      speichern()
    } catch {
      // Musik ist ein Qualitäts-Upgrade, darf aber die komplette Videoproduktion nie blockieren.
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].qualitaetsHinweise =
          (produktionen[aktuell].qualitaetsHinweise ?? [])
          + ["Auto-Musik konnte nicht erzeugt werden; Master wird ohne Musik fortgesetzt."]
      }
      speichern()
    }
  }

  func musikSetzen(_ id: UUID, assetID: UUID?) {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    if let assetID {
      guard let asset = medien.first(where: { $0.id == assetID && $0.typ == .audio }) else {
        meldung = "Das gewählte Audio-Asset wurde nicht gefunden."
        return
      }
      guard asset.herkunft.autoPublishingErlaubt else {
        meldung =
          "Musik mit unklarer Rechteherkunft darf nicht für Auto-Publishing verwendet werden."
        return
      }
    }
    produktionen[index].musikAssetID = assetID
    produktionen[index].aktualisiertAm = Date()
    speichern()
  }

  func captionsSetzen(_ id: UUID, aktiv: Bool) {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    produktionen[index].captionsAktiv = aktiv
    produktionen[index].aktualisiertAm = Date()
    speichern()
  }

  func watermarkSetzen(_ id: UUID, aktiv: Bool) {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    produktionen[index].watermarkAktiv = aktiv
    produktionen[index].aktualisiertAm = Date()
    speichern()
  }

  func thumbnailAutomatischGenerieren(_ id: UUID) {
    guard let index = produktionen.firstIndex(where: { $0.id == id }),
      let kanal = kanal(fuer: produktionen[index].kanalID)
    else { return }
    do {
      let folder = try persistence.arbeitsordner("Thumbnails")
      let target = folder.appendingPathComponent("\(id.uuidString).png")
      let bgAsset = medienFuerProduktion(id).first(where: {
        $0.typ == .bild && FileManager.default.fileExists(atPath: $0.lokalerPfad)
      })
      let bgURL = bgAsset.map { URL(fileURLWithPath: $0.lokalerPfad) }
      let url = try ThumbnailService.shared.generieren(
        produktion: produktionen[index], kanal: kanal, branding: kanal.branding ?? KanalBranding(),
        hintergrund: bgURL, ziel: target)
      let check = MediaQualityService.shared.thumbnailPruefen(url: url)
      thumbnailSetzen(id, url: url, score: check.score)
      meldung = "Thumbnail automatisch erstellt und geprüft: \(Int(check.score))/100."
    } catch {
      do {
        let folder = try persistence.arbeitsordner("Thumbnails")
        let target = folder.appendingPathComponent("\(id.uuidString)-safe.png")
        let url = try ThumbnailService.shared.generierenNotfall(
          produktion: produktionen[index], kanal: kanal,
          branding: kanal.branding ?? KanalBranding(),
          ziel: target)
        let check = MediaQualityService.shared.thumbnailPruefen(url: url)
        thumbnailSetzen(id, url: url, score: max(70, check.score))
        meldung = "Thumbnail wurde mit dem sicheren Blackstock-Fallback erzeugt."
      } catch {
        if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
          produktionen[aktuell].letzterFehler = error.localizedDescription
          produktionen[aktuell].aktualisiertAm = Date()
        }
        speichern()
        meldung = error.localizedDescription
      }
    }
  }

  func thumbnailMitAktiverEngineGenerieren(_ id: UUID) async {
    guard let index = produktionen.firstIndex(where: { $0.id == id }),
      let kanal = kanal(fuer: produktionen[index].kanalID)
    else { return }

    let engine = provider.first(where: { $0.typ == .image })
    let preset = engine.flatMap { EnginePresetService.aktiviertesPreset(fuer: $0) }
    let adapter = preset?.optionen["adapter"] ?? "local"

    do {
      let folder = try persistence.arbeitsordner("Thumbnails")
      let background = folder.appendingPathComponent("\(id.uuidString)-generated-bg.png")
      let final = folder.appendingPathComponent("\(id.uuidString).png")
      let prompt = """
        YouTube thumbnail background for exactly this topic: \(produktionen[index].arbeitstitel).
        Visual direction: \(produktionen[index].thumbnailIdee).
        Channel topic: \(kanal.thema).
        One clear focal subject, strong readable composition, no text, no logos, no watermarks, no copyrighted character imitation.
        """

      var bgURL: URL?
      if let engine, preset?.premium == true, preset?.brauchtAPIKey == true, imageEngineBereit,
        let apiKey = KeychainService.shared.lesen("provider.api.\(engine.id.uuidString)")
      {
        bgURL = try? await CloudImageService.shared.generieren(
          prompt: prompt, provider: engine, apiKey: apiKey, ziel: background)
      } else if adapter == "local" {
        bgURL = medienFuerProduktion(id).first(where: {
          $0.typ == .bild && FileManager.default.fileExists(atPath: $0.lokalerPfad)
        }).map { URL(fileURLWithPath: $0.lokalerPfad) }
      }

      let url = try ThumbnailService.shared.generieren(
        produktion: produktionen[index], kanal: kanal, branding: kanal.branding ?? KanalBranding(),
        hintergrund: bgURL, ziel: final)
      let check = MediaQualityService.shared.thumbnailPruefen(url: url)
      thumbnailSetzen(id, url: url, score: check.score)
      if bgURL != nil {
        meldung =
          "Thumbnail automatisch mit generiertem Themenbild und Blackstock-Branding erstellt: \(Int(check.score))/100."
      } else {
        meldung = "Thumbnail automatisch lokal erstellt und geprüft: \(Int(check.score))/100."
      }
    } catch {
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].letzterFehler = error.localizedDescription
        produktionen[aktuell].aktualisiertAm = Date()
      }
      speichern()
      // Zweiter, bewusst sehr robuster Fallback ohne generatives Hintergrundbild.
      thumbnailAutomatischGenerieren(id)
    }
  }

  func masterRendern(_ id: UUID, ziel: URL) async {
    guard produktionen.contains(where: { $0.id == id }) else { return }
    var clips = medienFuerProduktion(id).filter {
      $0.typ == .video && FileManager.default.fileExists(atPath: $0.lokalerPfad)
    }.map { URL(fileURLWithPath: $0.lokalerPfad) }
    if clips.isEmpty {
      await generativeClipsErzeugen(id)
      clips = medienFuerProduktion(id).filter {
        $0.typ == .video && FileManager.default.fileExists(atPath: $0.lokalerPfad)
      }.map { URL(fileURLWithPath: $0.lokalerPfad) }
    }
    guard !clips.isEmpty else {
      meldung =
        "Blackstock konnte keine Visual-Spur erzeugen. Der gespeicherte Projektfehler enthält die Ursache."
      return
    }
    if produktionen.first(where: { $0.id == id })?.musikAssetID == nil {
      await musikAutomatischErzeugen(id)
    }
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    let voice = produktionen[index].voiceoverDatei.map { URL(fileURLWithPath: $0) }
    let music: URL? = {
      guard let assetID = produktionen[index].musikAssetID,
        let asset = medien.first(where: { $0.id == assetID && $0.typ == .audio }),
        FileManager.default.fileExists(atPath: asset.lokalerPfad)
      else { return nil }
      return URL(fileURLWithPath: asset.lokalerPfad)
    }()
    let watermark: URL? = {
      guard produktionen[index].watermarkAktiv ?? true,
        let pfad = kanal(fuer: produktionen[index].kanalID)?.branding?.logoPfad,
        FileManager.default.fileExists(atPath: pfad)
      else { return nil }
      return URL(fileURLWithPath: pfad)
    }()

    istBeschaeftigt = true
    produktionen[index].status = .schnitt
    produktionen[index].naechsterSchritt = "Master-Render mit Audio, Captions und Branding läuft"
    produktionen[index].letzterFehler = nil
    produktionen[index].aktualisiertAm = Date()
    speichern()
    defer { istBeschaeftigt = false }

    do {
      let output = try await MasterVideoService.shared.rendern(
        clips: clips,
        optionen: .init(
          format: produktionen[index].format,
          voiceover: voice,
          musik: music,
          szenen: produktionen[index].paket?.szenen ?? [],
          captions: produktionen[index].captionsAktiv ?? true,
          watermark: watermark),
        ziel: ziel)
      let check = await MediaQualityService.shared.videoPruefen(
        url: output, erwartetesFormat: produktionen[index].format)
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].masterRenderDatum = Date()
        produktionen[aktuell].qualitaet.schnitt = max(produktionen[aktuell].qualitaet.schnitt, 91)
      }
      finaleDateiSetzen(
        id, url: output, technikScore: check.videoScore, audioScore: check.audioScore)
      meldung =
        "Master-Render fertig: Voice, Musik, Captions und Branding wurden verarbeitet · Technik \(Int(check.videoScore))/100."
    } catch {
      if let aktuell = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[aktuell].status = .visuals
        produktionen[aktuell].letzterFehler = error.localizedDescription
        produktionen[aktuell].naechsterSchritt = "Master-Render korrigieren und erneut starten"
        produktionen[aktuell].aktualisiertAm = Date()
      }
      speichern()
      meldung = error.localizedDescription
    }
  }

  @discardableResult
  func batchErstellen(
    name: String,
    kanalID: UUID?,
    anzahl: Int,
    format: VideoFormat,
    modus: Produktionsmodus,
    publikationsmodus: Publikationsmodus
  ) -> BatchAuftrag {
    let limit = max(1, min(100, anzahl))
    let verwendeteIDs = Set(produktionen.compactMap(\.chanceID))
    let verwendeteQuellen = Set(
      produktionen.compactMap { $0.chanceQuellenSchluessel ?? $0.chanceSnapshot?.quellenSchluessel }
    )
    let kandidaten =
      chancen
      .filter { chance in
        let quelleVerwendet =
          chance.quellenSchluessel.map { verwendeteQuellen.contains($0) } ?? false
        return !verwendeteIDs.contains(chance.id) && !quelleVerwendet
      }
      .sorted { ($0.trendScore * $0.konfidenz) > ($1.trendScore * $1.konfidenz) }
    var ids: [UUID] = []
    for chance in kandidaten.prefix(limit) {
      var angepasst = chance
      if let kanalID { angepasst.empfohlenerKanalID = kanalID }
      if let id = produktionAusChance(
        angepasst, format: format, modus: modus, publikationsmodus: publikationsmodus)
      {
        ids.append(id)
      }
    }
    let batch = BatchAuftrag(
      name: name, kanalID: kanalID, anzahl: ids.count, format: format, modus: modus,
      publikationsmodus: publikationsmodus, status: ids.isEmpty ? .geplant : .laeuft,
      produktionIDs: ids)
    batchAuftraege.insert(batch, at: 0)
    ausgewaehltesZiel = .factory
    speichern()
    return batch
  }

  func batchProduktionspaketeErzeugen(_ batchID: UUID) async {
    guard let batchIndex = batchAuftraege.firstIndex(where: { $0.id == batchID }) else { return }
    batchAuftraege[batchIndex].status = .laeuft
    speichern()
    let ids = batchAuftraege[batchIndex].produktionIDs
    for id in ids {
      await produktionsPaketErzeugen(id)
    }
    let erfolgreich = ids.filter { id in produktionen.first(where: { $0.id == id })?.paket != nil }
      .count
    if let aktuell = batchAuftraege.firstIndex(where: { $0.id == batchID }) {
      batchAuftraege[aktuell].status = erfolgreich > 0 ? .review : .pausiert
    }
    speichern()
    meldung =
      erfolgreich > 0
      ? "Batch-Redaktion abgeschlossen: \(erfolgreich) von \(ids.count) Projekten haben ein Produktionspaket. Offene Projekte zeigen ihren Fehler direkt im Studio."
      : "Kein Produktionspaket konnte erstellt werden. Der Batch wurde pausiert; prüfe Creator Engine und Projektfehler."
  }

  func produktionAutomatischFertigstellen(
    _ id: UUID, generativeVisualsErlaubt: Bool = true
  ) async -> Bool {
    guard let initialIndex = produktionen.firstIndex(where: { $0.id == id }) else { return false }
    produktionen[initialIndex].letzterFehler = nil
    produktionen[initialIndex].naechsterSchritt = "Produktionspipeline wird vorbereitet"
    produktionen[initialIndex].aktualisiertAm = Date()
    speichern()

    if produktionen.first(where: { $0.id == id })?.paket == nil {
      await produktionsPaketErzeugen(id)
    }
    guard produktionen.first(where: { $0.id == id })?.paket != nil else {
      produktionsFehlerSetzen(
        id, text: "Redaktion und Szenen konnten nicht vollständig erzeugt werden.",
        status: .recherche)
      return false
    }

    _ = autoMedienZuordnen(id)

    if produktionen.first(where: { $0.id == id })?.voiceoverDatei == nil {
      await voiceoverErzeugen(id)
    }
    guard let voicePath = produktionen.first(where: { $0.id == id })?.voiceoverDatei,
      FileManager.default.fileExists(atPath: voicePath)
    else {
      produktionsFehlerSetzen(
        id, text: "Voice konnte weder über die aktive Engine noch lokal erzeugt werden.",
        status: .stimme)
      return false
    }

    if produktionen.first(where: { $0.id == id })?.thumbnailDatei == nil {
      await thumbnailMitAktiverEngineGenerieren(id)
    }
    if produktionen.first(where: { $0.id == id })?.thumbnailDatei == nil {
      thumbnailAutomatischGenerieren(id)
    }
    guard let thumbnailPath = produktionen.first(where: { $0.id == id })?.thumbnailDatei,
      FileManager.default.fileExists(atPath: thumbnailPath)
    else {
      produktionsFehlerSetzen(
        id, text: "Thumbnail konnte auch mit dem sicheren lokalen Renderer nicht erzeugt werden.",
        status: .visuals)
      return false
    }

    if produktionen.first(where: { $0.id == id })?.musikAssetID == nil {
      await musikAutomatischErzeugen(id)
    }

    var clips = gueltigeVideoClips(fuer: id)
    if clips.isEmpty {
      if generativeVisualsErlaubt {
        await generativeClipsErzeugen(id)
      } else {
        await lokalenVisualTrackErzeugen(id)
      }
      clips = gueltigeVideoClips(fuer: id)
    }
    if clips.isEmpty {
      // Harte Garantie: selbst wenn ein Provider-Adapter seinen eigenen Fallback nicht erreicht,
      // wird der lokale Visual-Renderer genau hier nochmals explizit aufgerufen.
      await lokalenVisualTrackErzeugen(id)
      clips = gueltigeVideoClips(fuer: id)
    }
    guard !clips.isEmpty else {
      produktionsFehlerSetzen(
        id,
        text:
          "Visuals konnten weder über Premium noch über Blackstock Local Visual erzeugt werden.",
        status: .visuals)
      return false
    }

    do {
      let folder = try persistence.arbeitsordner("Renders")
      let target = folder.appendingPathComponent("\(id.uuidString)-master.mp4")
      await masterRendern(id, ziel: target)
      guard let path = produktionen.first(where: { $0.id == id })?.lokaleDatei,
        FileManager.default.fileExists(atPath: path)
      else {
        produktionsFehlerSetzen(
          id, text: "Master-Render wurde nicht als gültige Datei abgeschlossen.", status: .schnitt)
        return false
      }
      if let index = produktionen.firstIndex(where: { $0.id == id }) {
        produktionen[index].letzterFehler = nil
        produktionen[index].aktualisiertAm = Date()
        speichern()
      }
      return true
    } catch {
      produktionsFehlerSetzen(id, text: error.localizedDescription, status: .schnitt)
      return false
    }
  }

  private func gueltigeVideoClips(fuer id: UUID) -> [MedienAsset] {
    medienFuerProduktion(id).filter {
      $0.typ == .video && FileManager.default.fileExists(atPath: $0.lokalerPfad)
    }
  }

  private func produktionsFehlerSetzen(_ id: UUID, text: String, status: Produktionsstatus) {
    guard let index = produktionen.firstIndex(where: { $0.id == id }) else { return }
    produktionen[index].status = status
    produktionen[index].letzterFehler = text
    produktionen[index].naechsterSchritt = text
    produktionen[index].aktualisiertAm = Date()
    speichern()
    meldung = text
  }

  func batchVollProduzieren(_ batchID: UUID) async {
    guard let batchIndex = batchAuftraege.firstIndex(where: { $0.id == batchID }) else { return }
    let ids = batchAuftraege[batchIndex].produktionIDs
    guard !ids.isEmpty else {
      meldung = "Dieser Batch enthält keine Projekte."
      return
    }
    batchAuftraege[batchIndex].status = .laeuft
    speichern()

    var fertig = 0
    for id in ids {
      if await produktionAutomatischFertigstellen(id) { fertig += 1 }
    }
    if let aktuell = batchAuftraege.firstIndex(where: { $0.id == batchID }) {
      batchAuftraege[aktuell].status = fertig > 0 ? .review : .pausiert
    }
    speichern()
    meldung =
      fertig == ids.count
      ? "Batch-Produktion abgeschlossen: Alle \(fertig) Master-Render sind in der Review-Queue."
      : "Batch-Produktion: \(fertig) von \(ids.count) Master-Render fertig. Offene Projekte zeigen ihren Fehler im Studio."
  }

  func batchFreigabeBestaetigen(_ batchID: UUID) {
    guard let batch = batchAuftraege.first(where: { $0.id == batchID }) else { return }
    let ids = batch.produktionIDs
    var bestaetigt = 0
    for id in ids {
      guard let p = produktionen.first(where: { $0.id == id }), p.lokaleDatei != nil else {
        continue
      }
      manuelleRedaktionsfreigabe(id)
      bestaetigt += 1
    }
    speichern()
    meldung =
      "Redaktionelle Sammelfreigabe für \(bestaetigt) gerenderte Projekte gespeichert. Subjektive Qualitätswerte wie Bildwelt bleiben weiterhin individuell prüfbar."
  }

  func batchBereiteProjekteHochladen(_ batchID: UUID) async {
    guard let batch = batchAuftraege.first(where: { $0.id == batchID }) else { return }
    let ready = batch.produktionIDs.filter { id in
      guard let p = produktionen.first(where: { $0.id == id }) else { return false }
      return istFreigabeBereit(p) && p.lokaleDatei != nil
    }
    guard !ready.isEmpty else {
      meldung = "Kein Projekt im Batch hat alle Quality Gates bestanden."
      return
    }
    var uploaded = 0
    for id in ready {
      await produktionHochladen(id)
      if let p = produktionen.first(where: { $0.id == id }), p.youtubeVideoID != nil {
        uploaded += 1
      }
    }
    meldung =
      "Batch-Upload abgeschlossen: \(uploaded) von \(ready.count) freigegebenen Projekten hochgeladen."
  }

  @discardableResult
  func batchAusThemenErstellen(
    name: String, kanalID: UUID?, themen: [String], anzahl: Int, format: VideoFormat,
    modus: Produktionsmodus, publikationsmodus: Publikationsmodus
  ) -> BatchAuftrag {
    let clean = themen.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter {
      !$0.isEmpty
    }
    guard !clean.isEmpty else {
      return batchErstellen(
        name: name, kanalID: kanalID, anzahl: anzahl, format: format, modus: modus,
        publikationsmodus: publikationsmodus)
    }
    let limit = max(1, min(100, anzahl))
    var ids: [UUID] = []
    for offset in 0..<limit {
      let base = clean[offset % clean.count]
      let variation = offset / clean.count
      let angle: String = {
        switch variation % 6 {
        case 1: return "Erklärung & Kontext"
        case 2: return "Fehler & Missverständnisse"
        case 3: return "Praxis & Beispiele"
        case 4: return "Vergleich & Gegenposition"
        case 5: return "Zukunft & nächste Entwicklung"
        default: return "Kernstory"
        }
      }()
      let titel = variation == 0 ? base : "\(base) · \(angle)"
      let chance = Chance(
        titel: titel, thema: base, empfohlenerKanalID: kanalID,
        trendScore: 78, qualitaetsPotenzial: 92, abonnentenPotenzial: 72,
        viralitaetsWahrscheinlichkeit: 0.45, konfidenz: 0.82, risiko: .niedrig,
        quellenAnzahl: 0, primaerquellen: 0, widersprueche: 0, trendHalbwertszeitStunden: 168,
        empfohleneFormate: [format],
        begruendung:
          "Manuell angelegtes Factory-Thema. Fakten und Quellen werden vor Veröffentlichung geprüft.",
        entdecktAm: Date(), momentum: 0, nachfrageScore: 0, wettbewerbScore: 0,
        contentGapScore: 70, umsatzPotenzial: 60, evergreenScore: 78, phase: .evergreen,
        trendVerlauf: [], datenherkunft: .manuell, beobachtet: false,
        quellenSchluessel: "manual:\(base.lowercased()):\(offset)")
      if let id = produktionAusChance(
        chance, format: format, modus: modus, publikationsmodus: publikationsmodus)
      {
        ids.append(id)
      }
    }
    let batch = BatchAuftrag(
      name: name, kanalID: kanalID, anzahl: ids.count, format: format, modus: modus,
      publikationsmodus: publikationsmodus, status: ids.isEmpty ? .geplant : .laeuft,
      produktionIDs: ids)
    batchAuftraege.insert(batch, at: 0)
    ausgewaehltesZiel = .factory
    speichern()
    return batch
  }

  @discardableResult
  func produktionDuplizieren(_ id: UUID) -> UUID? {
    guard let original = produktionen.first(where: { $0.id == id }) else { return nil }
    var kopie = original
    kopie.id = UUID()
    kopie.arbeitstitel = original.arbeitstitel + " · Kopie"
    kopie.status = original.paket == nil ? .idee : .storyboard
    kopie.erstelltAm = Date()
    kopie.geplantFuer = nil
    kopie.youtubeVideoID = nil
    kopie.uploadFortschritt = nil
    kopie.lokaleDatei = nil
    kopie.thumbnailDatei = nil
    kopie.voiceoverDatei = nil
    kopie.masterRenderDatum = nil
    kopie.musikAssetID = nil
    let reusableAssetIDs = (original.assetIDs ?? []).filter { assetID in
      guard let asset = medien.first(where: { $0.id == assetID }) else { return false }
      return asset.herkunft != .generiert
        && FileManager.default.fileExists(atPath: asset.lokalerPfad)
    }
    kopie.assetIDs = reusableAssetIDs
    kopie.liveBroadcastID = nil
    kopie.liveStreamID = nil
    kopie.liveIngestionAddress = nil
    kopie.blockGrund = nil
    kopie.letzterFehler = nil
    kopie.aktualisiertAm = Date()
    kopie.letztePruefung = nil
    kopie.naechsterSchritt = "Medien prüfen und neuen Master erzeugen"

    // Redaktionelle Vorarbeit darf übernommen werden; technische/Output-Gates müssen
    // für die neue Produktion erneut gemessen werden.
    kopie.qualitaet.visuals = 0
    kopie.qualitaet.schnitt = 0
    kopie.qualitaet.stimme = 0
    kopie.qualitaet.audio = 0
    kopie.qualitaet.thumbnail = 0
    kopie.qualitaet.rechte = 0
    kopie.qualitaet.policy = 0
    kopie.qualitaet.technisch = 0

    produktionen.insert(kopie, at: 0)
    ausgewaehlteProduktionID = kopie.id
    speichern()
    meldung = "Projekt wurde dupliziert. Outputs und technische Quality Gates werden neu erzeugt."
    return kopie.id
  }

  func produktionLoeschen(_ id: UUID, erzeugteDateienLoeschen: Bool = true) {
    guard let p = produktionen.first(where: { $0.id == id }) else { return }
    if erzeugteDateienLoeschen {
      [p.lokaleDatei, p.thumbnailDatei, p.voiceoverDatei].compactMap { $0 }.forEach(
        loescheBlackstockArbeitsdatei)
      let assigned = Set((p.assetIDs ?? []) + [p.musikAssetID].compactMap { $0 })
      let generated = medien.filter { assigned.contains($0.id) && $0.herkunft == .generiert }
      for asset in generated {
        let usedElsewhere = produktionen.contains { other in
          guard other.id != id else { return false }
          return (other.assetIDs ?? []).contains(asset.id) || other.musikAssetID == asset.id
        }
        guard !usedElsewhere else { continue }
        loescheBlackstockArbeitsdatei(asset.lokalerPfad)
        medien.removeAll { $0.id == asset.id }
      }
    }
    _ = KeychainService.shared.loeschen("youtube.live.streamName.\(id.uuidString)")
    produktionen.removeAll { $0.id == id }
    for i in batchAuftraege.indices { batchAuftraege[i].produktionIDs.removeAll { $0 == id } }
    if ausgewaehlteProduktionID == id { ausgewaehlteProduktionID = produktionen.first?.id }
    speichern()
    meldung = "Projekt wurde entfernt. Eigene importierte Originalmedien bleiben unangetastet."
  }

  func batchLoeschen(_ id: UUID, projekteLoeschen: Bool) {
    guard let batch = batchAuftraege.first(where: { $0.id == id }) else { return }
    if projekteLoeschen {
      for pid in batch.produktionIDs { produktionLoeschen(pid, erzeugteDateienLoeschen: true) }
    }
    batchAuftraege.removeAll { $0.id == id }
    speichern()
  }

  func videoEintragLoeschen(_ id: UUID) {
    videos.removeAll { $0.id == id }
    speichern()
    meldung =
      "Der lokale Video-Eintrag wurde entfernt. Das YouTube-Video selbst wurde nicht gelöscht."
  }

  private func loescheBlackstockArbeitsdatei(_ path: String) {
    let url = URL(fileURLWithPath: path).standardizedFileURL
    guard
      let supportRoot = FileManager.default.urls(
        for: .applicationSupportDirectory, in: .userDomainMask
      ).first
    else { return }
    let appSupport = supportRoot.appendingPathComponent("Blackstock", isDirectory: true)
      .standardizedFileURL.path
    guard url.path.hasPrefix(appSupport + "/") else { return }
    try? FileManager.default.removeItem(at: url)
  }

  func automationSpeichern(_ regel: Automationsregel) {
    if let index = automationsregeln.firstIndex(where: { $0.id == regel.id }) {
      automationsregeln[index] = regel
    } else {
      automationsregeln.insert(regel, at: 0)
    }
    speichern()
  }

  func automationLoeschen(_ id: UUID) {
    automationsregeln.removeAll { $0.id == id }
    speichern()
  }

  func brandAssetsGenerieren(_ kanalID: UUID) {
    guard let index = kanaele.firstIndex(where: { $0.id == kanalID }) else { return }
    var branding = kanaele[index].branding ?? KanalBranding()
    do {
      let ergebnis = try BrandAssetService.shared.generieren(
        kanal: kanaele[index], branding: branding)
      branding.logoPfad = ergebnis.logo.path
      branding.bannerPfad = ergebnis.banner.path
      kanaele[index].branding = branding
      speichern()
      meldung = "Logo und Kanalbanner wurden lokal erzeugt und im Brand Kit gespeichert."
    } catch {
      meldung = error.localizedDescription
    }
  }

  func aktiveAutomationenAusfuehren() async {
    let automatikStufe = UserDefaults.standard.string(forKey: "automatikStufe") ?? "Assistiert"
    guard automatikStufe != "Aus" else {
      meldung = "Automationen sind global ausgeschaltet."
      return
    }

    let regeln = automationsregeln.filter(\.aktiv)
    guard !regeln.isEmpty else {
      meldung = "Aktiviere zuerst mindestens eine Automationsregel."
      return
    }

    let storedConfidence = UserDefaults.standard.double(forKey: "minConfidence")
    let globalMinConfidence = max(0.75, min(0.99, storedConfidence > 0 ? storedConfidence : 0.92))
    let storedDailyLimit = UserDefaults.standard.integer(forKey: "dailyProductionLimit")
    let dailyLimit = max(1, min(200, storedDailyLimit > 0 ? storedDailyLimit : 12))
    let calendar = Calendar.current
    let heuteBereits = produktionen.filter {
      calendar.isDateInToday($0.erstelltAm) && $0.chanceID != nil
    }.count
    var verbleibend = max(0, dailyLimit - heuteBereits)
    guard verbleibend > 0 else {
      meldung = "Das globale Tageslimit von \(dailyLimit) Produktionen ist für heute erreicht."
      return
    }

    var neueIDs: [UUID] = []
    for regel in regeln where verbleibend > 0 {
      let bereitsIDs = Set(produktionen.compactMap(\.chanceID))
      let bereitsQuellen = Set(
        produktionen.compactMap {
          $0.chanceQuellenSchluessel ?? $0.chanceSnapshot?.quellenSchluessel
        })
      let minConfidence = max(regel.minKonfidenz, globalMinConfidence)
      let ruleLimit = min(verbleibend, max(1, min(100, regel.maxProTag)))
      let kandidaten =
        chancen
        .filter { chance in
          let quelleSchonVerwendet =
            chance.quellenSchluessel.map { bereitsQuellen.contains($0) } ?? false
          return !bereitsIDs.contains(chance.id) && !quelleSchonVerwendet
            && chance.trendScore >= regel.minTrendScore && chance.konfidenz >= minConfidence
        }
        .sorted { ($0.trendScore * $0.konfidenz) > ($1.trendScore * $1.konfidenz) }
        .prefix(ruleLimit)
      for chance in kandidaten {
        var c = chance
        if let kanalID = regel.kanalID { c.empfohlenerKanalID = kanalID }
        if let id = produktionAusChance(
          c, format: regel.format, modus: regel.modus, publikationsmodus: regel.publikationsmodus)
        {
          neueIDs.append(id)
          verbleibend -= 1
          if verbleibend <= 0 { break }
        }
      }
    }

    let cloudVisualsErlaubt = UserDefaults.standard.bool(forKey: "automationCloudVisuals")
    if researchEngineBereit && automatikStufe != "Assistiert" {
      if ["Produktion automatisch", "Smart Autopilot", "Vollautomatik"].contains(automatikStufe) {
        for id in neueIDs {
          _ = await produktionAutomatischFertigstellen(
            id, generativeVisualsErlaubt: cloudVisualsErlaubt)
        }
      } else {
        for id in neueIDs { await produktionsPaketErzeugen(id) }
      }
    }

    if ["Smart Autopilot", "Vollautomatik"].contains(automatikStufe) {
      let uploadIDs =
        produktionen
        .filter {
          ($0.publikationsmodus ?? .review) == .nachGate && $0.youtubeVideoID == nil
            && $0.lokaleDatei != nil && istFreigabeBereit($0)
        }
        .map(\.id)
      for id in uploadIDs where !istBeschaeftigt {
        await produktionHochladen(id)
      }
    }
    ausgewaehltesZiel = .produktionen
    speichern()
    if neueIDs.isEmpty {
      meldung = "Keine neuen Chancen erfüllten die aktiven Regeln und globalen Grenzen."
    } else {
      let vorbereitet = researchEngineBereit && automatikStufe != "Assistiert"
      meldung =
        "\(neueIDs.count) neue Projekte wurden angelegt\(vorbereitet ? " und redaktionell vorbereitet" : ""). Verbleibendes Tageskontingent: \(verbleibend)."
    }
  }

  // MARK: - Live-Daten

  func liveDatenAktualisieren() async {
    guard !googleZugaenge.isEmpty else {
      meldung = "Verbinde zuerst einen Google-/YouTube-Zugang."
      return
    }
    istBeschaeftigt = true
    defer { istBeschaeftigt = false }

    var aktualisierteKanaele = 0
    var aktualisierteVideos = 0
    var fehler: [String] = []
    let end = Date()
    let start = Calendar(identifier: .gregorian).date(byAdding: .day, value: -364, to: end) ?? end

    for zugang in googleZugaenge {
      do {
        let remoteKanaele = try await youtube.kanaeleLaden(verbindungID: zugang.id)
        if let setup = youtube.letzterAPIEinrichtungsHinweis { apiEinrichtungsHinweis = setup }
        if remoteKanaele.isEmpty {
          if let zidx = googleZugaenge.firstIndex(where: { $0.id == zugang.id }) {
            googleZugaenge[zidx].status = .kanalFehlt
            googleZugaenge[zidx].letzteSynchronisierung = Date()
          }
          continue
        }

        for remote in remoteKanaele {
          importiereKanal(remote, verbindungsID: zugang.id)
          guard let youtubeID = remote.youtubeChannelID,
            let local = kanaele.first(where: {
              $0.youtubeChannelID == youtubeID && $0.verbindungsID == zugang.id
            })
          else { continue }
          aktualisierteKanaele += 1

          do {
            let daily = try await youtube.dailyAnalytics(
              verbindungID: zugang.id,
              youtubeChannelID: youtubeID,
              localChannelID: local.id,
              startDate: start,
              endDate: end)
            analyticsDailyUpsert(daily.points, for: local.id)
            var profile = channelProfile(for: local.id)
            profile.analyticsAuthorized = true
            profile.revenueAccess = daily.revenueAccess
            profile.uploadAuthorized = youtube.featureAutorisiert(.upload, verbindungID: zugang.id)
            profile.liveAuthorized = youtube.featureAutorisiert(.liveManagement, verbindungID: zugang.id)
            v11State.upsertProfile(profile)
          } catch {
            var profile = channelProfile(for: local.id)
            profile.analyticsAuthorized = false
            v11State.upsertProfile(profile)
            fehler.append("\(remote.name) Analytics: \(error.localizedDescription)")
          }

          do {
            let incoming = try await youtube.videosLaden(verbindungID: zugang.id, kanal: local)
            let ids = Set(incoming.compactMap(\.youtubeVideoID))
            videos.removeAll { existing in
              existing.kanalID == local.id && (existing.youtubeVideoID.map(ids.contains) ?? false)
            }
            videos.insert(contentsOf: incoming.map { input in
              var value = input
              value.kanalID = local.id
              value.datenherkunft = .live
              value.aktualisiertAm = Date()
              return value
            }, at: 0)
            aktualisierteVideos += incoming.count
          } catch {
            fehler.append("\(remote.name) Videos: \(error.localizedDescription)")
          }
        }

        if let zidx = googleZugaenge.firstIndex(where: { $0.id == zugang.id }) {
          googleZugaenge[zidx].status = .verbunden
          // Der Account ist nicht mehr identisch mit einem einzelnen Kanal; diese
          // Legacy-Felder bleiben nur als primäre Anzeige erhalten.
          if let first = remoteKanaele.first {
            googleZugaenge[zidx].youtubeChannelID = first.youtubeChannelID
            googleZugaenge[zidx].youtubeChannelName = first.name
          }
          googleZugaenge[zidx].letzteSynchronisierung = Date()
        }
      } catch let serviceFehler as YouTubeService.YouTubeFehler {
        if let hinweis = serviceFehler.einrichtungsHinweis {
          apiEinrichtungsHinweis = hinweis
          if let zidx = googleZugaenge.firstIndex(where: { $0.id == zugang.id }) {
            googleZugaenge[zidx].status = .apiEinrichtung
          }
        } else if let zidx = googleZugaenge.firstIndex(where: { $0.id == zugang.id }) {
          googleZugaenge[zidx].status = .erneuern
        }
        fehler.append("\(zugang.email): \(serviceFehler.localizedDescription)")
      } catch {
        if let zidx = googleZugaenge.firstIndex(where: { $0.id == zugang.id }) {
          googleZugaenge[zidx].status = .fehler
        }
        fehler.append("\(zugang.email): \(error.localizedDescription)")
      }
    }

    googleVerbunden = !googleZugaenge.isEmpty
    v11State.analyticsDaily.sort { $0.date < $1.date }
    speichern()
    if fehler.isEmpty {
      if youtube.letzterAPIEinrichtungsHinweis == nil { apiEinrichtungsHinweis = nil }
      meldung = "\(aktualisierteKanaele) Kanal/Kanäle und \(aktualisierteVideos) Videos wurden aktualisiert."
    } else if apiEinrichtungsHinweis != nil && aktualisierteKanaele == 0 {
      meldung = nil
    } else if aktualisierteKanaele > 0 {
      meldung = "Teilweise aktualisiert. \(fehler.count) Abruf/Abrufe benötigen Aufmerksamkeit."
    } else {
      meldung = fehler.first ?? "Aktualisierung fehlgeschlagen."
    }
  }

  func apiEinrichtungOeffnen() {
    guard let hinweis = apiEinrichtungsHinweis else { return }
    youtube.oeffneAPIEinrichtung(hinweis)
  }

  func apiEinrichtungErneutPruefen() async {
    await liveDatenAktualisieren()
  }

  // MARK: - AdSense & Auszahlungen

  func adsenseEinrichtungOeffnen() {
    adsenseProfil.status = .einrichtung
    adsenseProfil.datenherkunft = .manuell
    adsenseProfil.aktualisiertAm = Date()
    speichern()
    let studio =
      liveKanaele.first?.youtubeChannelID.map {
        "https://studio.youtube.com/channel/\($0)/monetization"
      } ?? "https://studio.youtube.com/"
    if let url = URL(string: studio) { NSWorkspace.shared.open(url) }
  }

  func adsenseStatusSetzen(_ status: AdSenseStatus) {
    adsenseProfil.status = status
    adsenseProfil.datenherkunft = .manuell
    adsenseProfil.aktualisiertAm = Date()
    speichern()
  }

  func adsenseVerifizierungSetzen(
    _ keyPath: WritableKeyPath<AdSenseProfil, Verifizierungsstatus>, _ status: Verifizierungsstatus
  ) {
    adsenseProfil[keyPath: keyPath] = status
    adsenseProfil.datenherkunft = .manuell
    adsenseProfil.aktualisiertAm = Date()
    speichern()
  }
}
