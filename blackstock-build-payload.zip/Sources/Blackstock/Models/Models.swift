import Foundation

// MARK: - Navigation

enum Navigationsziel: String, CaseIterable, Identifiable, Codable, Hashable {
  case command, chancen, factory, produktionen, veroeffentlicht, kalender, wachstum, konten,
    bibliothek,
    automatik, einnahmen, qualitaet, einstellungen
  var id: String { rawValue }

  var titel: String {
    switch self {
    case .command: "Übersicht"
    case .chancen: "Trends"
    case .factory: "Erstellen"
    case .produktionen: "Produktionen"
    case .veroeffentlicht: "Inhalte"
    case .kalender: "Kalender"
    case .wachstum: "Analytics"
    case .konten: "Kanäle"
    case .bibliothek: "Mediathek"
    case .automatik: "Automationen"
    case .einnahmen: "Einnahmen"
    case .qualitaet: "Qualität"
    case .einstellungen: "Einstellungen"
    }
  }

  var symbol: String {
    switch self {
    case .command: "house.fill"
    case .chancen: "chart.line.uptrend.xyaxis"
    case .factory: "bolt.fill"
    case .produktionen: "slider.horizontal.3"
    case .veroeffentlicht: "play.rectangle.fill"
    case .kalender: "calendar"
    case .wachstum: "chart.bar.xaxis"
    case .konten: "person.crop.rectangle.stack"
    case .bibliothek: "square.stack.3d.up.fill"
    case .automatik: "arrow.triangle.2.circlepath"
    case .einnahmen: "dollarsign.circle"
    case .qualitaet: "checkmark.shield"
    case .einstellungen: "gearshape"
    }
  }
}

// MARK: - Datenvertrauen

enum Datenherkunft: String, Codable, Hashable {
  case live = "Live"
  case lokal = "Lokal berechnet"
  case simulation = "Simulation"
  case beispiel = "Beispiel"
  case manuell = "Manuell bestätigt"
  case nichtVerfuegbar = "Nicht verfügbar"
}

enum Vertrauensstatus: String, Codable, Hashable {
  case verifiziert = "Bestätigt"
  case wahrscheinlich = "Wahrscheinlich"
  case unsicher = "Unsicher"
  case umstritten = "Umstritten"
  case veraltet = "Neu prüfen"
}

enum Risiko: String, Codable, Hashable {
  case niedrig = "Niedrig"
  case mittel = "Mittel"
  case hoch = "Hoch"
  case kritisch = "Kritisch"
}

struct TrendPunkt: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var zeit: Date
  var wert: Double
}

enum TrendPhase: String, Codable, CaseIterable, Identifiable, Hashable {
  case entstehend = "Entstehend"
  case beschleunigend = "Beschleunigend"
  case hoehepunkt = "Höhepunkt"
  case abkuehlend = "Abkühlend"
  case evergreen = "Evergreen"
  var id: String { rawValue }
}

// MARK: - Google- und YouTube-Zugänge

enum Verbindungsstatus: String, Codable, Hashable {
  case bereit = "Bereit"
  case kanalFehlt = "Noch kein YouTube-Kanal"
  case apiEinrichtung = "YouTube-API aktivieren"
  case verbunden = "Verbunden"
  case erneuern = "Neu anmelden"
  case fehler = "Fehler"
}

struct APIEinrichtungsHinweis: Identifiable, Hashable {
  var id = UUID()
  var titel: String
  var text: String
  var dienst: String
  var projektID: String?
  var aktivierungsURL: URL?
}

struct GoogleZugang: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var email: String
  var anzeigename: String
  var status: Verbindungsstatus
  var youtubeChannelID: String?
  var youtubeChannelName: String?
  var verbundenAm: Date = Date()
  var letzteSynchronisierung: Date? = nil
  var datenherkunft: Datenherkunft = .live
}

struct OAuthKonfigurationsstatus: Codable, Hashable {
  enum Zustand: String, Codable, Hashable {
    case eingebaut = "In Blackstock eingebaut"
    case importiert = "Lokal eingerichtet"
    case fehlt = "Entwicklerfreigabe fehlt"
    case ungueltig = "Konfiguration ungültig"
  }
  var zustand: Zustand = .fehlt
  var detail: String = ""
}

// MARK: - Kanal-Einrichtung

enum KanalPlanStatus: String, Codable, CaseIterable, Hashable {
  case vorgeschlagen = "Planung"
  case vorbereitet = "Vorbereitet"
  case youtubeErstellung = "YouTube-Schritt offen"
  case bereitZumVerbinden = "Bereit zum Verbinden"
  case verbunden = "Verbunden"

  var fortschritt: Double {
    switch self {
    case .vorgeschlagen: 0.12
    case .vorbereitet: 0.35
    case .youtubeErstellung: 0.58
    case .bereitZumVerbinden: 0.78
    case .verbunden: 1.0
    }
  }
}

struct KanalPlan: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var thema: String
  var name: String
  var handleVorschlag: String
  var status: KanalPlanStatus
  var zielgruppe: String
  var positionierung: String
  var contentDNA: String
  var visualDNA: String
  var voiceDNA: String
  var startFormate: [String]
  var empfohleneUploadsProWoche: Int
  var marktScore: Double
  var erwarteteAboChance: Double
  var vertrauen: Double
  var angelegtAm: Date = Date()
  var verbundenerKanalID: UUID?
}

// MARK: - Kanal & Monetarisierung

enum KanalStatus: String, Codable, CaseIterable, Hashable {
  case entwurf = "Einrichtung"
  case verbunden = "Verbunden"
  case wachstum = "Wachstum"
  case monetarisiert = "Monetarisiert"
  case pausiert = "Pausiert"
}

enum YPPStatus: String, Codable, Hashable {
  case nichtBerechtigt = "Noch nicht berechtigt"
  case fortschritt = "Auf dem Weg zum YPP"
  case antragMoeglich = "Antrag möglich"
  case pruefung = "In Prüfung"
  case aktiv = "Monetarisiert"
  case eingeschraenkt = "Eingeschränkt"
}

struct Kanal: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var youtubeChannelID: String?
  var verbindungsID: UUID? = nil
  var name: String
  var thema: String
  var handle: String
  var status: KanalStatus
  var abonnenten: Int
  var views28Tage: Int
  var abonnenten28Tage: Int
  var umsatz28Tage: Double
  var qualitaetsScore: Double
  var vertrauensScore: Double
  var monetarisierungFortschritt: Double
  var letzterUpload: Date?
  var naechsterUpload: Date?
  var autopilotAktiv: Bool
  var istDemo: Bool = false
  var yppStatus: YPPStatus = .nichtBerechtigt
  var gueltigeShortsViews90Tage: Int = 0
  var wiedergabeStunden12Monate: Double = 0
  var analyticsStand: Date? = nil
  var datenherkunft: Datenherkunft = .nichtVerfuegbar
  var branding: KanalBranding? = nil
}

enum AdSenseStatus: String, Codable, Hashable {
  case nichtEingerichtet = "Nicht eingerichtet"
  case einrichtung = "Einrichtung läuft"
  case aktiv = "Aktiv"
  case aktionErforderlich = "Aktion erforderlich"
  case pausiert = "Pausiert"
}

enum Verifizierungsstatus: String, Codable, Hashable {
  case offen = "Offen"
  case inPruefung = "In Prüfung"
  case bestaetigt = "Bestätigt"
  case nichtErforderlich = "Nicht erforderlich"
}

struct AdSenseProfil: Codable, Hashable {
  var status: AdSenseStatus = .nichtEingerichtet
  var zahlungsempfaenger: String = ""
  var identitaet: Verifizierungsstatus = .offen
  var adresse: Verifizierungsstatus = .offen
  var steuerinformationen: Verifizierungsstatus = .offen
  var zahlungsmethode: Verifizierungsstatus = .offen
  var auszahlungssperre: Bool = false
  var offenerBetrag: Double? = nil
  var letzteAuszahlung: Double? = nil
  var letzteAuszahlungAm: Date? = nil
  var naechsteAuszahlungFruehestens: Date? = nil
  var verknuepfteKanalIDs: [UUID] = []
  var datenherkunft: Datenherkunft = .nichtVerfuegbar
  var aktualisiertAm: Date? = nil
}

// MARK: - Chancen

struct Chance: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var titel: String
  var thema: String
  var empfohlenerKanalID: UUID?
  var trendScore: Double
  var qualitaetsPotenzial: Double
  var abonnentenPotenzial: Double
  var viralitaetsWahrscheinlichkeit: Double
  var konfidenz: Double
  var risiko: Risiko
  var quellenAnzahl: Int
  var primaerquellen: Int
  var widersprueche: Int
  var trendHalbwertszeitStunden: Double
  var empfohleneFormate: [VideoFormat]
  var begruendung: String
  var entdecktAm: Date
  var istDemo: Bool = false
  var momentum: Double = 0
  var nachfrageScore: Double = 0
  var wettbewerbScore: Double = 0
  var contentGapScore: Double = 0
  var umsatzPotenzial: Double = 0
  var evergreenScore: Double = 0
  var phase: TrendPhase = .entstehend
  var trendVerlauf: [TrendPunkt] = []
  var datenherkunft: Datenherkunft = .nichtVerfuegbar
  var beobachtet: Bool = false
  /// Stabiler Ursprungsschlüssel (z. B. youtube:<videoId>) für Refresh, Deduplizierung und Produktionsverknüpfung.
  var quellenSchluessel: String? = nil
}

// MARK: - Produktion

enum Produktionsstatus: String, Codable, CaseIterable, Identifiable, Hashable {
  case idee = "Idee"
  case recherche = "Recherche"
  case skript = "Skript"
  case storyboard = "Szenenplan"
  case visuals = "Bildwelt"
  case stimme = "Stimme"
  case schnitt = "Schnitt"
  case qualitaet = "Prüfung"
  case bereit = "Freigegeben"
  case geplant = "Geplant"
  case live = "Live"
  case blockiert = "Blockiert"

  var id: String { rawValue }
  var fortschritt: Double {
    switch self {
    case .idee: 0.05
    case .recherche: 0.14
    case .skript: 0.27
    case .storyboard: 0.39
    case .visuals: 0.55
    case .stimme: 0.67
    case .schnitt: 0.80
    case .qualitaet: 0.91
    case .bereit: 0.96
    case .geplant: 0.99
    case .live: 1.0
    case .blockiert: 0.91
    }
  }
}

enum VideoFormat: String, Codable, CaseIterable, Hashable {
  case short = "Short"
  case longform = "Langvideo"
  case serie = "Serienfolge"
  case livestream = "Livestream"
}

enum Produktionsmodus: String, Codable, CaseIterable, Identifiable, Hashable {
  case fast = "Fast"
  case studio = "Studio"
  case master = "Master"
  var id: String { rawValue }

  var beschreibung: String {
    switch self {
    case .fast: "Schneller Trend-Output mit reduzierten Varianten."
    case .studio: "Mehrere Qualitätsprüfungen und hochwertige Standardproduktion."
    case .master: "Maximale Qualitätspriorität mit strengeren Gates und Variantenvergleich."
    }
  }
}

enum Publikationsmodus: String, Codable, CaseIterable, Identifiable, Hashable {
  case review = "Vor Upload prüfen"
  case nachGate = "Nach Quality Gate veröffentlichen"
  case nurRender = "Nur rendern"
  var id: String { rawValue }
}

struct ProduktionsSzene: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var titel: String
  var narration: String
  var visualDirection: String
  var dauerSekunden: Double
}

struct ProduktionsPaket: Codable, Hashable {
  var titel: String
  var hook: String
  var skript: String
  var beschreibung: String
  var tags: [String]
  var thumbnailText: String
  var szenen: [ProduktionsSzene]
}

enum MedienHerkunft: String, Codable, CaseIterable, Identifiable, Hashable {
  case eigen = "Eigenes Material"
  case lizenziert = "Lizenziert"
  case publicDomain = "Public Domain"
  case generiert = "Generiert"
  case unklar = "Unklar"
  var id: String { rawValue }
  var autoPublishingErlaubt: Bool { self != .unklar }
}

enum MedienTyp: String, Codable, Hashable {
  case video = "Video"
  case bild = "Bild"
  case audio = "Audio"
}

struct MedienAsset: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var name: String
  var lokalerPfad: String
  var typ: MedienTyp
  var herkunft: MedienHerkunft
  var hinzugefuegtAm: Date = Date()
  var rechteNotiz: String = ""
}

enum BatchStatus: String, Codable, Hashable {
  case geplant = "Geplant"
  case laeuft = "Läuft"
  case review = "Review"
  case fertig = "Fertig"
  case pausiert = "Pausiert"
}

struct BatchAuftrag: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var name: String
  var kanalID: UUID?
  var anzahl: Int
  var format: VideoFormat
  var modus: Produktionsmodus
  var publikationsmodus: Publikationsmodus
  var status: BatchStatus = .geplant
  var erstelltAm: Date = Date()
  var produktionIDs: [UUID] = []
}

struct Automationsregel: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var name: String
  var aktiv: Bool
  var kanalID: UUID?
  var minTrendScore: Double
  var minKonfidenz: Double
  var modus: Produktionsmodus
  var publikationsmodus: Publikationsmodus
  var format: VideoFormat
  var maxProTag: Int
}

struct KanalBranding: Codable, Hashable {
  var akzentHex: String = "#FF1B20"
  var logoStil: String = "Play + B"
  var thumbnailStil: String = "Editorial Contrast"
  var captionStil: String = "Dynamic Bold"
  var introStil: String = "Minimal"
  var outroText: String = ""
  var standardVoice: String = "Natürlich"
  var logoPfad: String? = nil
  var bannerPfad: String? = nil
}

struct Qualitaetsprofil: Codable, Hashable {
  var story: Double
  var hook: Double
  var visuals: Double
  var schnitt: Double
  var stimme: Double
  var audio: Double
  var thumbnail: Double
  var titel: Double
  var originalitaet: Double
  var fakten: Double
  var rechte: Double
  var policy: Double
  var technisch: Double

  private var alleWerte: [(String, Double)] {
    [
      ("Story", story), ("Hook", hook), ("Bildwelt", visuals), ("Schnitt", schnitt),
      ("Stimme", stimme), ("Audio", audio), ("Thumbnail", thumbnail), ("Titel", titel),
      ("Originalität", originalitaet), ("Fakten", fakten), ("Rechte", rechte),
      ("Richtlinien", policy), ("Technik", technisch),
    ]
  }

  private var freigabeGrenzen: [(String, Double, Double)] {
    [
      ("Story", story, 90), ("Hook", hook, 88), ("Bildwelt", visuals, 84), ("Schnitt", schnitt, 86),
      ("Stimme", stimme, 82), ("Audio", audio, 85), ("Thumbnail", thumbnail, 82),
      ("Titel", titel, 85), ("Originalität", originalitaet, 88), ("Fakten", fakten, 88),
      ("Rechte", rechte, 90), ("Richtlinien", policy, 92), ("Technik", technisch, 90),
    ]
  }

  var gesamt: Double {
    let bewertet = alleWerte.map(\.1).filter { $0 > 0 }
    guard !bewertet.isEmpty else { return 0 }
    return bewertet.reduce(0, +) / Double(bewertet.count)
  }

  var offeneGates: [String] {
    freigabeGrenzen.filter { $0.1 <= 0 }.map(\.0)
  }

  var fehlgeschlageneGates: [String] {
    freigabeGrenzen.filter { $0.1 > 0 && $0.1 < $0.2 }.map { "\($0.0) \(Int($0.1))/\(Int($0.2))" }
  }

  var harteSperre: Bool { !fehlgeschlageneGates.isEmpty }

  var freigabeBereit: Bool {
    offeneGates.isEmpty && fehlgeschlageneGates.isEmpty && gesamt >= 90
  }

  var bewerteteBereiche: Int { alleWerte.filter { $0.1 > 0 }.count }
  var gesamtBereiche: Int { alleWerte.count }
}

struct Produktion: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var kanalID: UUID
  var chanceID: UUID?
  var arbeitstitel: String
  var format: VideoFormat
  var status: Produktionsstatus
  var erstelltAm: Date
  var geplantFuer: Date?
  var zielDauerSekunden: Int
  var skript: String
  var hook: String
  var thumbnailIdee: String
  var voiceDirection: String
  var storyboardNotizen: String
  var qualitaet: Qualitaetsprofil
  var konfidenz: Double
  var erwarteteViews24h: Int
  var erwarteteAbonnenten: Int
  var erwarteterUmsatz: Double
  var lokaleDatei: String?
  var blockGrund: String?
  var istDemo: Bool = false
  var datenherkunft: Datenherkunft = .lokal
  var letztePruefung: Date? = nil
  var naechsterSchritt: String = ""
  var modus: Produktionsmodus? = .studio
  var publikationsmodus: Publikationsmodus? = .review
  var paket: ProduktionsPaket? = nil
  var assetIDs: [UUID]? = nil
  var beschreibung: String? = nil
  var tags: [String]? = nil
  var youtubeVideoID: String? = nil
  var uploadFortschritt: Double? = nil
  var thumbnailDatei: String? = nil
  var voiceoverDatei: String? = nil
  var musikAssetID: UUID? = nil
  var captionsAktiv: Bool? = true
  var watermarkAktiv: Bool? = true
  var masterRenderDatum: Date? = nil
  var liveBroadcastID: String? = nil
  var liveStreamID: String? = nil
  var liveIngestionAddress: String? = nil
  var qualitaetsHinweise: [String]? = nil
  var letzterFehler: String? = nil
  var aktualisiertAm: Date? = nil
  /// Snapshot schützt das Projekt davor, dass ein späterer Trend-Refresh seine redaktionelle Ausgangsbasis entfernt.
  var chanceSnapshot: Chance? = nil
  var chanceQuellenSchluessel: String? = nil
}

// MARK: - Veröffentlichte Videos

struct VideoLeistung: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var youtubeVideoID: String?
  var kanalID: UUID
  var titel: String
  var format: VideoFormat
  var veroeffentlichtAm: Date
  var views: Int
  var views24h: Int
  var watchtimeMinuten: Int
  var durchschnittlicheWiedergabeProzent: Double
  var abonnentenGewonnen: Int
  var abonnentenVerloren: Int
  var likes: Int
  var kommentare: Int
  var shares: Int
  var umsatz: Double
  /// nil/false bedeutet: monetäre Analytics waren für diese Zeile nicht verfügbar.
  var umsatzVerfuegbar: Bool? = nil
  var rpm: Double
  var thumbnailCTR: Double?
  var qualitaetsScore: Double
  var forecastFehlerProzent: Double?
  var istDemo: Bool = false
  var datenherkunft: Datenherkunft = .nichtVerfuegbar
  var aktualisiertAm: Date? = nil
}

// MARK: - System

struct SystemAktion: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var titel: String
  var beschreibung: String
  var risiko: Risiko
  var symbol: String
  var ziel: Navigationsziel
}

struct ProviderVerbindung: Identifiable, Codable, Hashable {
  enum Typ: String, Codable, Hashable {
    case research = "Recherche & Text"
    case voice = "Stimme"
    case image = "Bilder & Thumbnails"
    case video = "Video & Visuals"
    case music = "Musik & Sound"
  }
  var id: UUID = UUID()
  var typ: Typ
  var name: String
  var verbunden: Bool
  var detail: String
  var basisURL: String? = nil
  var modell: String? = nil
  var apiKeyVorhanden: Bool? = nil
  var optionen: [String: String]? = nil
}

struct AppZustand: Codable {
  var onboardingAbgeschlossen: Bool
  var demoModus: Bool
  var googleVerbunden: Bool
  var googleZugaenge: [GoogleZugang]
  var ausgewaehltesZiel: Navigationsziel
  var kanalPlaene: [KanalPlan]
  var kanaele: [Kanal]
  var chancen: [Chance]
  var produktionen: [Produktion]
  var videos: [VideoLeistung]
  var provider: [ProviderVerbindung]
  var adsenseProfil: AdSenseProfil
  var medien: [MedienAsset]
  var batchAuftraege: [BatchAuftrag]
  var automationsregeln: [Automationsregel]
  var v11: V11State?

  enum CodingKeys: String, CodingKey {
    case onboardingAbgeschlossen, demoModus, googleVerbunden, googleZugaenge, ausgewaehltesZiel,
      kanalPlaene, kanaele, chancen, produktionen, videos, provider, adsenseProfil, medien,
      batchAuftraege, automationsregeln, v11
  }

  init(
    onboardingAbgeschlossen: Bool, demoModus: Bool, googleVerbunden: Bool = false,
    googleZugaenge: [GoogleZugang] = [], ausgewaehltesZiel: Navigationsziel,
    kanalPlaene: [KanalPlan] = [], kanaele: [Kanal], chancen: [Chance], produktionen: [Produktion],
    videos: [VideoLeistung], provider: [ProviderVerbindung],
    adsenseProfil: AdSenseProfil = AdSenseProfil(), medien: [MedienAsset] = [],
    batchAuftraege: [BatchAuftrag] = [], automationsregeln: [Automationsregel] = [],
    v11: V11State? = nil
  ) {
    self.onboardingAbgeschlossen = onboardingAbgeschlossen
    self.demoModus = demoModus
    self.googleVerbunden = googleVerbunden
    self.googleZugaenge = googleZugaenge
    self.ausgewaehltesZiel = ausgewaehltesZiel
    self.kanalPlaene = kanalPlaene
    self.kanaele = kanaele
    self.chancen = chancen
    self.produktionen = produktionen
    self.videos = videos
    self.provider = provider
    self.adsenseProfil = adsenseProfil
    self.medien = medien
    self.batchAuftraege = batchAuftraege
    self.automationsregeln = automationsregeln
    self.v11 = v11
  }

  init(from decoder: Decoder) throws {
    let c = try decoder.container(keyedBy: CodingKeys.self)
    onboardingAbgeschlossen =
      try c.decodeIfPresent(Bool.self, forKey: .onboardingAbgeschlossen) ?? false
    demoModus = try c.decodeIfPresent(Bool.self, forKey: .demoModus) ?? false
    googleVerbunden = try c.decodeIfPresent(Bool.self, forKey: .googleVerbunden) ?? false
    googleZugaenge = try c.decodeIfPresent([GoogleZugang].self, forKey: .googleZugaenge) ?? []
    ausgewaehltesZiel =
      try c.decodeIfPresent(Navigationsziel.self, forKey: .ausgewaehltesZiel) ?? .command
    kanalPlaene = try c.decodeIfPresent([KanalPlan].self, forKey: .kanalPlaene) ?? []
    kanaele = try c.decodeIfPresent([Kanal].self, forKey: .kanaele) ?? []
    chancen = try c.decodeIfPresent([Chance].self, forKey: .chancen) ?? []
    produktionen = try c.decodeIfPresent([Produktion].self, forKey: .produktionen) ?? []
    videos = try c.decodeIfPresent([VideoLeistung].self, forKey: .videos) ?? []
    provider = try c.decodeIfPresent([ProviderVerbindung].self, forKey: .provider) ?? []
    adsenseProfil =
      try c.decodeIfPresent(AdSenseProfil.self, forKey: .adsenseProfil) ?? AdSenseProfil()
    medien = try c.decodeIfPresent([MedienAsset].self, forKey: .medien) ?? []
    batchAuftraege = try c.decodeIfPresent([BatchAuftrag].self, forKey: .batchAuftraege) ?? []
    automationsregeln =
      try c.decodeIfPresent([Automationsregel].self, forKey: .automationsregeln) ?? []
    v11 = try c.decodeIfPresent(V11State.self, forKey: .v11)
  }
}
