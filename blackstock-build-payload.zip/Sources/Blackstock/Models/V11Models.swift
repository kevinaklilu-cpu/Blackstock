import Foundation

// MARK: - Blackstock v11 Core

/// Stable taxonomy used by UI and matching. It intentionally does not depend on the
/// currently loaded trend results, so filters such as Sport can never disappear.
enum TopicCategory: String, Codable, CaseIterable, Identifiable, Hashable {
  case gaming = "Gaming"
  case news = "News"
  case politics = "Politik"
  case technologyAI = "Technologie & KI"
  case finance = "Finanzen & Wirtschaft"
  case business = "Business"
  case sport = "Sport"
  case football = "Fußball"
  case formula1 = "Formel 1"
  case entertainment = "Entertainment"
  case creator = "Creator"
  case science = "Wissenschaft"
  case knowledge = "Wissen"
  case healthFitness = "Gesundheit & Fitness"
  case automotive = "Auto & Mobilität"
  case travel = "Reisen"
  case food = "Food"
  case lifestyle = "Lifestyle"

  var id: String { rawValue }

  var searchTerms: [String] {
    switch self {
    case .gaming: ["Gaming", "PlayStation", "Xbox", "Nintendo", "PC Gaming"]
    case .news: ["News", "Breaking News", "Aktuelles"]
    case .politics: ["Politik", "Bundestag", "EU Politik"]
    case .technologyAI: ["Technologie", "Künstliche Intelligenz", "AI", "KI"]
    case .finance: ["Finanzen", "Wirtschaft", "Börse", "Markets"]
    case .business: ["Business", "Unternehmen", "Startups"]
    case .sport: ["Sport", "Sports"]
    case .football: ["Fußball", "Bundesliga", "Champions League"]
    case .formula1: ["Formel 1", "Formula 1", "F1"]
    case .entertainment: ["Entertainment", "Film", "Serien", "Popkultur"]
    case .creator: ["Creator", "YouTube", "Social Media"]
    case .science: ["Wissenschaft", "Science", "Forschung"]
    case .knowledge: ["Wissen", "Erklärung", "Dokumentation"]
    case .healthFitness: ["Gesundheit", "Fitness", "Training"]
    case .automotive: ["Auto", "Mobilität", "Elektroauto"]
    case .travel: ["Reisen", "Travel"]
    case .food: ["Food", "Essen", "Kochen"]
    case .lifestyle: ["Lifestyle", "Leben", "Trends"]
    }
  }
}

enum TopicTaxonomy {
  static let stableCategories: [TopicCategory] = TopicCategory.allCases

  static func infer(from text: String) -> TopicCategory? {
    let haystack = text.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
    return stableCategories.first { category in
      category.searchTerms.contains { term in
        haystack.contains(term.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current))
      }
    }
  }
}

// MARK: - Accounts / channels

enum RevenueAccessStatus: String, Codable, CaseIterable, Identifiable, Hashable {
  case unknown = "Unbekannt"
  case notAuthorized = "Revenue-Zugriff nicht verbunden"
  case authorizedNoData = "Revenue-Zugriff verbunden"
  case available = "Revenue-Daten verfügbar"
  case forbidden = "Revenue für diesen Kanal nicht verfügbar"

  var id: String { rawValue }
  var canQueryMonetaryAnalytics: Bool { self == .authorizedNoData || self == .available }
}

enum ChannelPrivacy: String, Codable, CaseIterable, Identifiable, Hashable {
  case privateVideo = "Privat"
  case unlisted = "Nicht gelistet"
  case publicVideo = "Öffentlich"
  var id: String { rawValue }

  var apiValue: String {
    switch self {
    case .privateVideo: "private"
    case .unlisted: "unlisted"
    case .publicVideo: "public"
    }
  }
}

struct ChannelContentProfile: Codable, Hashable {
  var channelID: UUID
  var language: String = "Deutsch"
  var region: String = "DE"
  var topics: [TopicCategory] = []
  var customTopics: [String] = []
  var excludedTopics: [String] = []
  var desiredFormats: [VideoFormat] = [.short, .longform]
  var reviewBeforePublish: Bool = true
  var defaultPrivacy: ChannelPrivacy = .privateVideo
  var preferredUploadHour: Int? = nil
  var revenueAccess: RevenueAccessStatus = .unknown
  var analyticsAuthorized: Bool = false
  var uploadAuthorized: Bool = false
  var liveAuthorized: Bool = false

  var effectiveSearchTerms: [String] {
    let taxonomy = topics.flatMap(\.searchTerms)
    let all = taxonomy + customTopics
    let exclusions = excludedTopics.map {
      $0.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
    }
    return Array(Set(all.filter { candidate in
      let folded = candidate.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
      return !exclusions.contains(where: { folded.contains($0) || $0.contains(folded) })
    })).sorted()
  }
}

struct YouTubeChannelConnection: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var googleAccountID: UUID
  var localChannelID: UUID
  var youtubeChannelID: String
  var name: String
  var handle: String
  var thumbnailURL: String? = nil
  var active: Bool = true
  var connectedAt: Date = Date()
  var lastSyncAt: Date? = nil
}

// MARK: - Analytics

enum AnalyticsRangePreset: String, Codable, CaseIterable, Identifiable, Hashable {
  case sevenDays = "7 Tage"
  case twentyEightDays = "28 Tage"
  case ninetyDays = "90 Tage"
  case year = "365 Tage"
  case custom = "Benutzerdefiniert"

  var id: String { rawValue }
  var days: Int? {
    switch self {
    case .sevenDays: 7
    case .twentyEightDays: 28
    case .ninetyDays: 90
    case .year: 365
    case .custom: nil
    }
  }
}

enum AnalyticsMetric: String, Codable, CaseIterable, Identifiable, Hashable {
  case views = "Views"
  case watchTime = "Watchtime"
  case subscribers = "Subscribers"
  case revenue = "Revenue"
  var id: String { rawValue }
}

struct AnalyticsDailyPoint: Identifiable, Codable, Hashable {
  var id: String { "\(channelID.uuidString):\(Self.dayFormatter.string(from: date))" }
  var channelID: UUID
  var date: Date
  var views: Int
  var watchTimeMinutes: Double
  var subscribersGained: Int
  var subscribersLost: Int
  var estimatedRevenue: Double?

  var subscribersNet: Int { subscribersGained - subscribersLost }

  private static let dayFormatter: DateFormatter = {
    let f = DateFormatter()
    f.locale = Locale(identifier: "en_US_POSIX")
    f.calendar = Calendar(identifier: .gregorian)
    f.timeZone = TimeZone(secondsFromGMT: 0)
    f.dateFormat = "yyyy-MM-dd"
    return f
  }()
}

struct AnalyticsSummary: Hashable {
  var views: Int
  var watchTimeMinutes: Double
  var subscribersNet: Int
  /// nil means unavailable/incomplete, not zero.
  var estimatedRevenue: Double?
}

enum AnalyticsNormalizer {
  static func normalized(
    points: [AnalyticsDailyPoint],
    channelIDs: Set<UUID>,
    from start: Date,
    through end: Date,
    revenueComplete: Bool,
    calendar: Calendar = Calendar(identifier: .gregorian)
  ) -> [AnalyticsDailyPoint] {
    guard start <= end, !channelIDs.isEmpty else { return [] }
    var cal = calendar
    cal.timeZone = TimeZone(secondsFromGMT: 0) ?? .gmt
    let startDay = cal.startOfDay(for: start)
    let endDay = cal.startOfDay(for: end)

    let endExclusive = cal.date(byAdding: .day, value: 1, to: endDay) ?? endDay.addingTimeInterval(86_400)
    let selected = points.filter {
      channelIDs.contains($0.channelID) && $0.date >= startDay && $0.date < endExclusive
    }
    let grouped = Dictionary(grouping: selected) { cal.startOfDay(for: $0.date) }
    var result: [AnalyticsDailyPoint] = []
    var cursor = startDay
    while cursor <= endDay {
      let dayPoints = grouped[cursor] ?? []
      let views = dayPoints.reduce(0) { $0 + $1.views }
      let watch = dayPoints.reduce(0.0) { $0 + $1.watchTimeMinutes }
      let gained = dayPoints.reduce(0) { $0 + $1.subscribersGained }
      let lost = dayPoints.reduce(0) { $0 + $1.subscribersLost }
      let revenue: Double?
      if revenueComplete {
        revenue = dayPoints.reduce(0.0) { $0 + ($1.estimatedRevenue ?? 0) }
      } else {
        revenue = nil
      }
      // Aggregated dashboard points use a stable synthetic ID by choosing the first
      // selected channel. `id` is presentation-only and does not drive persistence.
      result.append(
        AnalyticsDailyPoint(
          channelID: channelIDs.min { $0.uuidString < $1.uuidString } ?? UUID(),
          date: cursor,
          views: views,
          watchTimeMinutes: watch,
          subscribersGained: gained,
          subscribersLost: lost,
          estimatedRevenue: revenue
        ))
      guard let next = cal.date(byAdding: .day, value: 1, to: cursor) else { break }
      cursor = next
    }
    return result
  }

  static func summary(_ points: [AnalyticsDailyPoint]) -> AnalyticsSummary {
    let allRevenueAvailable = points.allSatisfy { $0.estimatedRevenue != nil }
    return AnalyticsSummary(
      views: points.reduce(0) { $0 + $1.views },
      watchTimeMinutes: points.reduce(0.0) { $0 + $1.watchTimeMinutes },
      subscribersNet: points.reduce(0) { $0 + $1.subscribersNet },
      estimatedRevenue: allRevenueAvailable
        ? points.reduce(0.0) { $0 + ($1.estimatedRevenue ?? 0) }
        : nil
    )
  }
}

// MARK: - Trend references

struct TrendReference: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var provider: String = "YouTube"
  var providerReferenceID: String
  var sourcePage: String?
  var title: String
  var channelTitle: String?
  var publishedAt: Date?
  var category: TopicCategory?
  var views: Int?
  var likes: Int?
  var comments: Int?
  var durationSeconds: Double?
  var relevance: Double
  var velocity: Double
  var engagement: Double
  var relativePerformance: Double
  var saturation: Double
  var formatFit: Double
  var usableSourceAvailability: Double
  var signalCount: Int

  var score: Double {
    let weighted = relevance * 0.26 + velocity * 0.19 + engagement * 0.12
      + relativePerformance * 0.12 + (100 - saturation) * 0.10 + formatFit * 0.10
      + usableSourceAvailability * 0.11
    return min(100, max(0, weighted))
  }

  var explanation: String {
    let signals = max(1, signalCount)
    return "Relevanz \(Int(relevance)) · Geschwindigkeit \(Int(velocity)) · Engagement \(Int(engagement)) · \(signals) Signal\(signals == 1 ? "" : "e")"
  }
}

// MARK: - Rights-aware remote media

enum RightsStatus: String, Codable, CaseIterable, Identifiable, Hashable {
  case owned = "Eigentum"
  case licensed = "Lizenziert"
  case publicDomain = "Public Domain"
  case creativeCommonsCompatible = "Creative Commons – kompatibel"
  case unknown = "Unbekannt"
  case restricted = "Eingeschränkt"
  var id: String { rawValue }

  var potentiallyUsable: Bool {
    switch self {
    case .owned, .licensed, .publicDomain, .creativeCommonsCompatible: true
    case .unknown, .restricted: false
    }
  }
}

enum SourceAllowedUse: String, Codable, CaseIterable, Identifiable, Hashable {
  case edit = "Bearbeiten"
  case publish = "Veröffentlichen"
  case commercial = "Kommerziell"
  case attributionRequired = "Namensnennung erforderlich"
  case noDerivatives = "Keine Bearbeitung"
  var id: String { rawValue }
}

enum SourceProviderKind: String, Codable, CaseIterable, Identifiable, Hashable {
  case directHTTPS = "Direct HTTPS / Own Media"
  case userCloud = "Eigener Cloud-Speicher"
  case licensedProvider = "Lizenzierter Provider"
  case youtubeReference = "YouTube Trend Reference"
  var id: String { rawValue }
}

struct SourceAsset: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var provider: SourceProviderKind
  var providerAssetID: String?
  var remoteURL: String?
  var title: String
  var duration: Double?
  var creator: String?
  var sourcePage: String?
  var licenseType: String?
  var rightsStatus: RightsStatus
  var allowedUses: [SourceAllowedUse]
  var channelOwnership: Bool = false
  var transcript: String?
  var language: String?
  var topicTags: [String] = []
  var downloadedCachePath: String?
  var expiresAt: Date?
  var checksumSHA256: String?

  var canEdit: Bool {
    guard rightsStatus.potentiallyUsable else { return false }
    if rightsStatus == .owned || channelOwnership || rightsStatus == .publicDomain { return true }
    guard !allowedUses.contains(.noDerivatives) else { return false }
    guard licenseType?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false else {
      return false
    }
    return allowedUses.contains(.edit)
  }

  var canPublish: Bool {
    guard rightsStatus.potentiallyUsable else { return false }
    if rightsStatus == .owned || channelOwnership || rightsStatus == .publicDomain { return true }
    guard licenseType?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false else {
      return false
    }
    return allowedUses.contains(.publish)
  }

  var isExpired: Bool { expiresAt.map { $0 <= Date() } ?? false }

  var attributionSatisfied: Bool {
    guard allowedUses.contains(.attributionRequired) else { return true }
    let namedCreator = creator?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false
    let linkedSource = sourcePage?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false
    return namedCreator || linkedSource
  }

  /// Automatic publishing is intentionally stricter than manual review. Licensed/CC
  /// sources must explicitly allow commercial use because a connected YouTube channel
  /// can be monetized even when Blackstock cannot reliably infer its YPP state.
  var canAutoPublish: Bool {
    guard !isExpired, attributionSatisfied, canEdit, canPublish else { return false }
    if rightsStatus == .owned || channelOwnership || rightsStatus == .publicDomain { return true }
    return allowedUses.contains(.commercial)
  }
}

enum CropMode: String, Codable, CaseIterable, Identifiable, Hashable {
  case fit = "Fit"
  case fill = "Fill"
  case smartReframe = "Smart Reframe"
  var id: String { rawValue }
}

enum SourceAudioMode: String, Codable, CaseIterable, Identifiable, Hashable {
  case original = "Original"
  case muted = "Stumm"
  case ducked = "Abgesenkt"
  var id: String { rawValue }
}

enum CaptionMode: String, Codable, CaseIterable, Identifiable, Hashable {
  case none = "Keine"
  case auto = "Automatisch"
  case burnedIn = "Eingebrannt"
  var id: String { rawValue }
}

struct RemixSegment: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var sourceAssetID: UUID
  var startTime: Double
  var endTime: Double
  var cropMode: CropMode
  var speed: Double = 1
  var audioMode: SourceAudioMode = .original
  var captionMode: CaptionMode = .auto
  var order: Int

  var duration: Double { max(0, (endTime - startTime) / max(0.1, speed)) }
  var isValid: Bool { startTime >= 0 && endTime > startTime && speed > 0 }
}

struct RemixTimeline: Codable, Hashable {
  var format: VideoFormat
  var duration: Double
  var segments: [RemixSegment]
  var transitions: [String] = []
  var captions: Bool = true
  var voiceoverPath: String? = nil
  var musicSourceAssetID: UUID? = nil

  var calculatedDuration: Double { segments.reduce(0) { $0 + $1.duration } }

  var isValid: Bool {
    guard !segments.isEmpty, duration > 0, segments.allSatisfy(\.isValid) else { return false }
    let ordered = segments.sorted { $0.order < $1.order }
    guard ordered.map(\.order) == Array(0..<ordered.count) else { return false }
    guard abs(calculatedDuration - duration) <= max(0.5, duration * 0.01) else { return false }

    // A source may appear more than once, but the same source interval must never overlap.
    let grouped = Dictionary(grouping: ordered, by: \.sourceAssetID)
    for sourceSegments in grouped.values {
      let byStart = sourceSegments.sorted { $0.startTime < $1.startTime }
      for pair in zip(byStart, byStart.dropFirst()) where pair.0.endTime > pair.1.startTime {
        return false
      }
    }
    return true
  }
}

// MARK: - Production state machine

enum ProductionModeV11: String, Codable, CaseIterable, Identifiable, Hashable {
  case automatic = "Auto"
  case singleSource = "Single Source"
  case remix = "Remix"
  case longform = "Longform"
  case short = "Short"
  case live = "Live"
  var id: String { rawValue }
}

enum ProductionPhase: String, Codable, CaseIterable, Identifiable, Hashable {
  case draft = "Entwurf"
  case discoveringSources = "Quellen suchen"
  case analyzingSources = "Quellen analysieren"
  case planning = "Schnitt planen"
  case fetchingMedia = "Medien laden"
  case editing = "Schnitt vorbereiten"
  case rendering = "Rendern"
  case review = "Review"
  case ready = "Bereit"
  case uploading = "Upload"
  case scheduled = "Geplant"
  case published = "Veröffentlicht"
  case failed = "Fehlgeschlagen"

  var id: String { rawValue }

  var defaultProgress: Double {
    switch self {
    case .draft: 0.03
    case .discoveringSources: 0.12
    case .analyzingSources: 0.22
    case .planning: 0.34
    case .fetchingMedia: 0.46
    case .editing: 0.58
    case .rendering: 0.72
    case .review: 0.84
    case .ready: 0.90
    case .uploading: 0.95
    case .scheduled: 0.98
    case .published: 1.0
    case .failed: 0
    }
  }

  var recoverable: Bool {
    switch self {
    case .published: false
    default: true
    }
  }
}

struct ProductionCheckpoint: Codable, Hashable {
  var phase: ProductionPhase
  var updatedAt: Date
  var detail: String?
}

struct RenderValidation: Codable, Hashable {
  var duration: Double
  var width: Int
  var height: Int
  var hasVideo: Bool
  var hasAudio: Bool
  var fileSize: Int64
  var validatedAt: Date = Date()

  func matches(_ format: VideoFormat) -> Bool {
    guard hasVideo, width > 0, height > 0 else { return false }
    switch format {
    case .short: return height > width
    case .longform, .serie, .livestream: return width >= height
    }
  }
}

struct ProductionV11State: Codable, Hashable {
  var productionID: UUID
  var mode: ProductionModeV11 = .automatic
  var phase: ProductionPhase = .draft
  var sourceAssetIDs: [UUID] = []
  var timeline: RemixTimeline? = nil
  var checkpoint: ProductionCheckpoint? = nil
  var renderValidation: RenderValidation? = nil
  var reviewBeforePublishOverride: Bool? = nil
  var lastError: String? = nil
  var interrupted: Bool = false

  var progress: Double { phase.defaultProgress }
}

enum ReadyState: String, Codable, Hashable {
  case inProgress = "In Arbeit"
  case reviewRequired = "Review nötig"
  case ready = "Bereit"
}

enum ReadyIssueCode: String, Codable, Hashable {
  case sourceMissing
  case rightsUnclear
  case timelineInvalid
  case renderMissing
  case audioInvalid
  case formatInvalid
  case durationInvalid
  case titleMissing
  case descriptionMissing
  case thumbnailMissing
  case channelMissing
  case uploadConfigurationInvalid
}

struct ReadyIssue: Identifiable, Codable, Hashable {
  var id: String { code.rawValue + ":" + message }
  var code: ReadyIssueCode
  var message: String
}

struct ReadyCheck: Codable, Hashable {
  var state: ReadyState
  var issues: [ReadyIssue]
  var checkedAt: Date

  var canPublish: Bool { state == .ready && issues.isEmpty }
}

enum ReadyCheckEngine {
  static func evaluate(
    production: Produktion,
    v11: ProductionV11State?,
    sources: [SourceAsset],
    targetChannelExists: Bool,
    renderedFileExists: Bool,
    thumbnailFileExists: Bool
  ) -> ReadyCheck {
    var issues: [ReadyIssue] = []
    let timeline = v11?.timeline
    let usedIDs = Set(timeline?.segments.map(\.sourceAssetID) ?? v11?.sourceAssetIDs ?? [])
    let used = sources.filter { usedIDs.contains($0.id) }

    if usedIDs.isEmpty || used.count != usedIDs.count {
      issues.append(ReadyIssue(code: .sourceMissing, message: "Mindestens eine Schnittquelle fehlt."))
    }
    for source in used where !source.canAutoPublish {
      issues.append(
        ReadyIssue(code: .rightsUnclear, message: "Nutzungsrecht für „\(source.title)“ ist nicht vollständig geklärt."))
    }
    if timeline?.isValid != true {
      issues.append(ReadyIssue(code: .timelineInvalid, message: "Die Remix-Timeline ist noch nicht gültig."))
    }
    if !renderedFileExists {
      issues.append(ReadyIssue(code: .renderMissing, message: "Der finale Render fehlt."))
    } else if let validation = v11?.renderValidation {
      if !validation.hasAudio {
        issues.append(ReadyIssue(code: .audioInvalid, message: "Der finale Render enthält keine Audiospur."))
      }
      if !validation.matches(production.format) {
        issues.append(ReadyIssue(code: .formatInvalid, message: "Der finale Render hat nicht das erwartete Seitenformat für \(production.format.rawValue)."))
      }
      if let timeline, abs(validation.duration - timeline.duration) > max(2.0, timeline.duration * 0.06) {
        issues.append(ReadyIssue(code: .durationInvalid, message: "Renderdauer und geplante Timeline weichen zu stark voneinander ab."))
      }
    }
    if production.arbeitstitel.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
      issues.append(ReadyIssue(code: .titleMissing, message: "Titel fehlt."))
    }
    if (production.beschreibung ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
      issues.append(ReadyIssue(code: .descriptionMissing, message: "Beschreibung fehlt."))
    }
    if production.format != .short && !thumbnailFileExists {
      issues.append(ReadyIssue(code: .thumbnailMissing, message: "Thumbnail fehlt."))
    }
    if !targetChannelExists {
      issues.append(ReadyIssue(code: .channelMissing, message: "Zielkanal ist nicht verbunden."))
    }

    let needsReview = v11?.reviewBeforePublishOverride ?? (production.publikationsmodus == .review)
    let state: ReadyState
    if !issues.isEmpty {
      state = .inProgress
    } else if needsReview && v11?.phase != .ready && v11?.phase != .uploading && v11?.phase != .published {
      state = .reviewRequired
    } else {
      state = .ready
    }
    return ReadyCheck(state: state, issues: issues, checkedAt: Date())
  }
}

// MARK: - Upload persistence

enum UploadState: String, Codable, Hashable {
  case notStarted
  case sessionCreated
  case uploading
  case uploaded
  case thumbnailPending
  case complete
  case failed
}

struct UploadRecord: Identifiable, Codable, Hashable {
  var id: UUID = UUID()
  var productionID: UUID
  var channelID: UUID
  var sessionURL: String?
  var filePath: String
  var fileSize: Int64
  var confirmedBytes: Int64 = 0
  var youtubeVideoID: String? = nil
  var state: UploadState = .notStarted
  var lastError: String? = nil
  var updatedAt: Date = Date()
}

// MARK: - v11 persisted envelope

struct V11State: Codable, Hashable {
  var schemaVersion: Int = 11
  var channelConnections: [YouTubeChannelConnection] = []
  var channelProfiles: [ChannelContentProfile] = []
  var analyticsDaily: [AnalyticsDailyPoint] = []
  var trendReferences: [TrendReference] = []
  var sourceAssets: [SourceAsset] = []
  var productionStates: [ProductionV11State] = []
  var uploadRecords: [UploadRecord] = []
  var sourceManifestURLs: [String] = []
  var existingMediaFirst: Bool = true
  var allowAIFallback: Bool = false
  var remoteCacheLimitGB: Double = 20

  enum CodingKeys: String, CodingKey {
    case schemaVersion, channelConnections, channelProfiles, analyticsDaily, trendReferences
    case sourceAssets, productionStates, uploadRecords, sourceManifestURLs
    case existingMediaFirst, allowAIFallback, remoteCacheLimitGB
  }

  init() {}

  init(from decoder: Decoder) throws {
    let c = try decoder.container(keyedBy: CodingKeys.self)
    schemaVersion = try c.decodeIfPresent(Int.self, forKey: .schemaVersion) ?? 11
    channelConnections = try c.decodeIfPresent([YouTubeChannelConnection].self, forKey: .channelConnections) ?? []
    channelProfiles = try c.decodeIfPresent([ChannelContentProfile].self, forKey: .channelProfiles) ?? []
    analyticsDaily = try c.decodeIfPresent([AnalyticsDailyPoint].self, forKey: .analyticsDaily) ?? []
    trendReferences = try c.decodeIfPresent([TrendReference].self, forKey: .trendReferences) ?? []
    sourceAssets = try c.decodeIfPresent([SourceAsset].self, forKey: .sourceAssets) ?? []
    productionStates = try c.decodeIfPresent([ProductionV11State].self, forKey: .productionStates) ?? []
    uploadRecords = try c.decodeIfPresent([UploadRecord].self, forKey: .uploadRecords) ?? []
    sourceManifestURLs = try c.decodeIfPresent([String].self, forKey: .sourceManifestURLs) ?? []
    existingMediaFirst = try c.decodeIfPresent(Bool.self, forKey: .existingMediaFirst) ?? true
    allowAIFallback = try c.decodeIfPresent(Bool.self, forKey: .allowAIFallback) ?? false
    remoteCacheLimitGB = try c.decodeIfPresent(Double.self, forKey: .remoteCacheLimitGB) ?? 20
  }

  func profile(for channelID: UUID) -> ChannelContentProfile? {
    channelProfiles.first { $0.channelID == channelID }
  }

  mutating func upsertProfile(_ profile: ChannelContentProfile) {
    if let index = channelProfiles.firstIndex(where: { $0.channelID == profile.channelID }) {
      channelProfiles[index] = profile
    } else {
      channelProfiles.append(profile)
    }
  }

  func productionState(for productionID: UUID) -> ProductionV11State? {
    productionStates.first { $0.productionID == productionID }
  }

  mutating func upsertProductionState(_ state: ProductionV11State) {
    if let index = productionStates.firstIndex(where: { $0.productionID == state.productionID }) {
      productionStates[index] = state
    } else {
      productionStates.append(state)
    }
  }

  mutating func upsertUploadRecord(_ record: UploadRecord) {
    if let index = uploadRecords.firstIndex(where: { $0.productionID == record.productionID }) {
      uploadRecords[index] = record
    } else {
      uploadRecords.append(record)
    }
  }

  mutating func markInterruptedInFlightJobs() {
    let transient: Set<ProductionPhase> = [
      .discoveringSources, .analyzingSources, .planning, .fetchingMedia,
      .editing, .rendering, .uploading,
    ]
    for index in productionStates.indices where transient.contains(productionStates[index].phase) {
      productionStates[index].interrupted = true
      productionStates[index].lastError =
        "Die Produktion wurde während \(productionStates[index].phase.rawValue.lowercased()) unterbrochen und kann fortgesetzt werden."
      productionStates[index].checkpoint = ProductionCheckpoint(
        phase: productionStates[index].phase,
        updatedAt: Date(),
        detail: "Beim letzten App-Lauf unterbrochen – fortsetzen möglich")
    }
  }

  mutating func normalizeLegacy(kanaele: [Kanal], produktionen: [Produktion]) {
    for channel in kanaele where profile(for: channel.id) == nil {
      let inferred = TopicTaxonomy.infer(from: channel.thema).map { [$0] } ?? []
      upsertProfile(
        ChannelContentProfile(
          channelID: channel.id,
          topics: inferred,
          customTopics: channel.thema.isEmpty ? [] : [channel.thema],
          reviewBeforePublish: true,
          revenueAccess: channel.umsatz28Tage > 0 ? .available : .unknown,
          analyticsAuthorized: channel.datenherkunft == .live
        ))
    }
    for production in produktionen where productionState(for: production.id) == nil {
      let phase: ProductionPhase
      if production.youtubeVideoID != nil { phase = .published }
      else if production.status == .blockiert { phase = .failed }
      else if production.status == .live { phase = .published }
      else if production.status == .geplant { phase = .scheduled }
      else if production.status == .bereit { phase = .ready }
      else if production.status == .qualitaet { phase = .review }
      else if production.lokaleDatei != nil { phase = .review }
      else { phase = .draft }
      upsertProductionState(
        ProductionV11State(
          productionID: production.id,
          mode: production.format == .short ? .short : (production.format == .livestream ? .live : .automatic),
          phase: phase
        ))
    }
  }
}
