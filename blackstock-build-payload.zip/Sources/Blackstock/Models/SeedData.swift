import Foundation

struct SeedData {
  static func leererZustand() -> AppZustand {
    AppZustand(
      onboardingAbgeschlossen: false,
      demoModus: false,
      googleVerbunden: false,
      ausgewaehltesZiel: .command,
      kanalPlaene: [],
      kanaele: [],
      chancen: [],
      produktionen: [],
      videos: [],
      provider: standardProvider,
      adsenseProfil: AdSenseProfil()
    )
  }

  static var standardProvider: [ProviderVerbindung] {
    [
      ProviderVerbindung(
        typ: .research, name: "Recherche", verbunden: false,
        detail: "Noch kein Recherche-Anbieter verbunden"),
      ProviderVerbindung(
        typ: .voice, name: "Stimme", verbunden: false, detail: "Noch kein Voice-Anbieter verbunden"),
      ProviderVerbindung(
        typ: .image, name: "Thumbnails", verbunden: false,
        detail: "Noch kein Bild-Anbieter verbunden"),
      ProviderVerbindung(
        typ: .video, name: "Bildwelt & Video", verbunden: false,
        detail: "Noch kein Video-Anbieter verbunden"),
      ProviderVerbindung(
        typ: .music, name: "Musik & Sound", verbunden: false,
        detail: "Noch kein Audio-Anbieter verbunden"),
    ]
  }

  static func demoZustand() -> AppZustand {
    let sportAccess = UUID()
    let gamingAccess = UUID()
    let techAccess = UUID()
    let sport = Kanal(
      youtubeChannelID: "demo-sport", verbindungsID: sportAccess,
      name: "Blackstock Sport", thema: "Fußball & Sport", handle: "@blackstocksport",
      status: .monetarisiert,
      abonnenten: 84_200, views28Tage: 6_840_000, abonnenten28Tage: 12_420, umsatz28Tage: 2_814.40,
      qualitaetsScore: 96.1, vertrauensScore: 98.2, monetarisierungFortschritt: 1,
      letzterUpload: Date().addingTimeInterval(-25_200),
      naechsterUpload: Date().addingTimeInterval(14_400), autopilotAktiv: true,
      istDemo: true, yppStatus: .aktiv, gueltigeShortsViews90Tage: 14_200_000,
      wiedergabeStunden12Monate: 8_320,
      analyticsStand: Date().addingTimeInterval(-600), datenherkunft: .beispiel
    )
    let gaming = Kanal(
      youtubeChannelID: "demo-gaming", verbindungsID: gamingAccess,
      name: "Blackstock Gaming", thema: "Gaming", handle: "@blackstockgaming",
      status: .monetarisiert,
      abonnenten: 26_800, views28Tage: 3_930_000, abonnenten28Tage: 8_980, umsatz28Tage: 1_420.15,
      qualitaetsScore: 95.3, vertrauensScore: 97.6, monetarisierungFortschritt: 1,
      letzterUpload: Date().addingTimeInterval(-57_600),
      naechsterUpload: Date().addingTimeInterval(32_400), autopilotAktiv: true,
      istDemo: true, yppStatus: .aktiv, gueltigeShortsViews90Tage: 11_700_000,
      wiedergabeStunden12Monate: 4_860,
      analyticsStand: Date().addingTimeInterval(-600), datenherkunft: .beispiel
    )
    let tech = Kanal(
      youtubeChannelID: "demo-tech", verbindungsID: techAccess,
      name: "Blackstock Tech", thema: "Technologie & KI", handle: "@blackstocktech",
      status: .wachstum,
      abonnenten: 9_640, views28Tage: 1_680_000, abonnenten28Tage: 4_230, umsatz28Tage: 942.90,
      qualitaetsScore: 97.2, vertrauensScore: 99.0, monetarisierungFortschritt: 1,
      letzterUpload: Date().addingTimeInterval(-13_400),
      naechsterUpload: Date().addingTimeInterval(21_600), autopilotAktiv: false,
      istDemo: true, yppStatus: .aktiv, gueltigeShortsViews90Tage: 7_900_000,
      wiedergabeStunden12Monate: 5_100,
      analyticsStand: Date().addingTimeInterval(-600), datenherkunft: .beispiel
    )

    let now = Date()
    let chance1 = Chance(
      titel: "KI-Chip-Wettlauf beschleunigt sich", thema: "KI-Hardware",
      empfohlenerKanalID: tech.id,
      trendScore: 96, qualitaetsPotenzial: 95, abonnentenPotenzial: 93,
      viralitaetsWahrscheinlichkeit: 0.74, konfidenz: 0.94,
      risiko: .niedrig, quellenAnzahl: 9, primaerquellen: 3, widersprueche: 0,
      trendHalbwertszeitStunden: 18,
      empfohleneFormate: [.short, .longform],
      begruendung:
        "Hohe Nachfrage, stark beschleunigendes Momentum und noch überschaubare inhaltliche Sättigung.",
      entdecktAm: now.addingTimeInterval(-1_800), istDemo: true, momentum: 31, nachfrageScore: 94,
      wettbewerbScore: 68,
      contentGapScore: 86, umsatzPotenzial: 88, evergreenScore: 72, phase: .beschleunigend,
      trendVerlauf: demoTrend(
        werte: [38, 43, 51, 59, 67, 79, 88, 96], start: now.addingTimeInterval(-7 * 3600)),
      datenherkunft: .beispiel
    )
    let chance2 = Chance(
      titel: "Transfer-Gerücht entwickelt sich zum Breaking-Thema", thema: "Fußball",
      empfohlenerKanalID: sport.id,
      trendScore: 91, qualitaetsPotenzial: 89, abonnentenPotenzial: 90,
      viralitaetsWahrscheinlichkeit: 0.66, konfidenz: 0.88,
      risiko: .mittel, quellenAnzahl: 6, primaerquellen: 1, widersprueche: 1,
      trendHalbwertszeitStunden: 7,
      empfohleneFormate: [.short],
      begruendung:
        "Schnell wachsendes Interesse. Wegen widersprüchlicher Quellen nur mit vorsichtiger Formulierung veröffentlichen.",
      entdecktAm: now.addingTimeInterval(-1_100), istDemo: true, momentum: 46, nachfrageScore: 97,
      wettbewerbScore: 89,
      contentGapScore: 62, umsatzPotenzial: 69, evergreenScore: 18, phase: .beschleunigend,
      trendVerlauf: demoTrend(
        werte: [18, 25, 31, 42, 56, 71, 84, 91], start: now.addingTimeInterval(-4 * 3600)),
      datenherkunft: .beispiel
    )
    let chance3 = Chance(
      titel: "Neues Open-World-Spiel erzeugt ungewöhnlich starke Suchdynamik", thema: "Gaming",
      empfohlenerKanalID: gaming.id,
      trendScore: 88, qualitaetsPotenzial: 93, abonnentenPotenzial: 86,
      viralitaetsWahrscheinlichkeit: 0.59, konfidenz: 0.92,
      risiko: .niedrig, quellenAnzahl: 12, primaerquellen: 4, widersprueche: 0,
      trendHalbwertszeitStunden: 42,
      empfohleneFormate: [.short, .serie],
      begruendung: "Stabile Nachfrage mit Serienpotenzial und hoher visueller Qualität.",
      entdecktAm: now.addingTimeInterval(-3_900), istDemo: true, momentum: 22, nachfrageScore: 89,
      wettbewerbScore: 75,
      contentGapScore: 79, umsatzPotenzial: 80, evergreenScore: 61, phase: .entstehend,
      trendVerlauf: demoTrend(
        werte: [52, 56, 59, 64, 70, 76, 82, 88], start: now.addingTimeInterval(-12 * 3600)),
      datenherkunft: .beispiel
    )

    let q1 = Qualitaetsprofil(
      story: 96, hook: 95, visuals: 97, schnitt: 95, stimme: 98, audio: 96, thumbnail: 94,
      titel: 95, originalitaet: 97, fakten: 99, rechte: 100, policy: 99, technisch: 98)
    let q2 = Qualitaetsprofil(
      story: 91, hook: 93, visuals: 89, schnitt: 88, stimme: 95, audio: 92, thumbnail: 90,
      titel: 91, originalitaet: 94, fakten: 96, rechte: 98, policy: 99, technisch: 95)
    let q3 = Qualitaetsprofil(
      story: 88, hook: 92, visuals: 86, schnitt: 84, stimme: 81, audio: 88, thumbnail: 79,
      titel: 89, originalitaet: 91, fakten: 92, rechte: 96, policy: 98, technisch: 93)

    let p1 = Produktion(
      kanalID: tech.id, chanceID: chance1.id,
      arbeitstitel: "Warum der neue KI-Chip-Wettlauf jetzt eskaliert", format: .short,
      status: .qualitaet, erstelltAm: now.addingTimeInterval(-7_200), geplantFuer: nil,
      zielDauerSekunden: 52, skript: "",
      hook: "Der wichtigste KI-Kampf findet gerade nicht bei Chatbots statt.",
      thumbnailIdee: "Ein dominanter Chip als Einzelmotiv; keine Textwand.",
      voiceDirection: "Präzise, kontrolliert, hohe Neugier, kein künstliches Staunen.",
      storyboardNotizen: "Schneller Beweisaufbau, dann Erklärung.", qualitaet: q1, konfidenz: 0.96,
      erwarteteViews24h: 420_000, erwarteteAbonnenten: 2_900, erwarteterUmsatz: 136, istDemo: true,
      datenherkunft: .beispiel, letztePruefung: now.addingTimeInterval(-300),
      naechsterSchritt: "Finale Qualitätsfreigabe")
    let p2 = Produktion(
      kanalID: gaming.id, chanceID: chance3.id,
      arbeitstitel: "Das Detail, das beim neuen Open-World-Spiel fast jeder übersieht",
      format: .short, status: .visuals, erstelltAm: now.addingTimeInterval(-4_100),
      geplantFuer: nil, zielDauerSekunden: 44, skript: "",
      hook: "Alle reden über die Map. Das eigentlich Entscheidende ist etwas anderes.",
      thumbnailIdee: "Ein starkes Ingame-Detail, klare Tiefenstaffelung.",
      voiceDirection: "Direkt, neugierig, leicht schneller als Tech.",
      storyboardNotizen: "Visuelle Beweise zuerst.", qualitaet: q2, konfidenz: 0.91,
      erwarteteViews24h: 210_000, erwarteteAbonnenten: 1_600, erwarteterUmsatz: 72, istDemo: true,
      datenherkunft: .beispiel, naechsterSchritt: "Visual-Auswahl abschließen")
    let p3 = Produktion(
      kanalID: sport.id, chanceID: chance2.id,
      arbeitstitel: "Der Transfer, der gerade alles verändert", format: .short, status: .blockiert,
      erstelltAm: now.addingTimeInterval(-2_900), geplantFuer: nil, zielDauerSekunden: 38,
      skript: "", hook: "", thumbnailIdee: "", voiceDirection: "", storyboardNotizen: "",
      qualitaet: q3, konfidenz: 0.72, erwarteteViews24h: 310_000, erwarteteAbonnenten: 1_200,
      erwarteterUmsatz: 83,
      blockGrund:
        "Thumbnail-Qualität und Voice liegen unter Freigabegrenze; Quellenlage noch nicht stabil genug.",
      istDemo: true, datenherkunft: .beispiel, letztePruefung: now.addingTimeInterval(-200),
      naechsterSchritt: "Quellen neu prüfen")

    let v1 = VideoLeistung(
      youtubeVideoID: "demo-video-1", kanalID: sport.id,
      titel: "Warum dieses Spiel taktisch völlig gekippt ist", format: .short,
      veroeffentlichtAm: now.addingTimeInterval(-86_400), views: 812_400, views24h: 624_100,
      watchtimeMinuten: 418_000, durchschnittlicheWiedergabeProzent: 91, abonnentenGewonnen: 3_420,
      abonnentenVerloren: 41, likes: 54_100, kommentare: 4_900, shares: 18_400, umsatz: 184.40,
      rpm: 0.23, thumbnailCTR: 8.4, qualitaetsScore: 96.4, forecastFehlerProzent: 6.2,
      istDemo: true, datenherkunft: .beispiel, aktualisiertAm: now.addingTimeInterval(-600))
    let v2 = VideoLeistung(
      youtubeVideoID: "demo-video-2", kanalID: tech.id,
      titel: "Der wichtigste AI-Chip dieses Jahres?", format: .longform,
      veroeffentlichtAm: now.addingTimeInterval(-172_800), views: 248_300, views24h: 118_000,
      watchtimeMinuten: 1_402_000, durchschnittlicheWiedergabeProzent: 62,
      abonnentenGewonnen: 2_180, abonnentenVerloren: 19, likes: 17_700, kommentare: 1_560,
      shares: 4_890, umsatz: 1_126.30, rpm: 4.54, thumbnailCTR: 7.9, qualitaetsScore: 97.1,
      forecastFehlerProzent: -3.7, istDemo: true, datenherkunft: .beispiel,
      aktualisiertAm: now.addingTimeInterval(-600))

    let adsense = AdSenseProfil(
      status: .aktiv, zahlungsempfaenger: "Blackstock Media", identitaet: .bestaetigt,
      adresse: .bestaetigt, steuerinformationen: .bestaetigt, zahlungsmethode: .bestaetigt,
      auszahlungssperre: false, offenerBetrag: 5_177.45, letzteAuszahlung: 3_920.10,
      letzteAuszahlungAm: Calendar.current.date(byAdding: .month, value: -1, to: now),
      naechsteAuszahlungFruehestens: Calendar.current.date(byAdding: .day, value: 9, to: now),
      verknuepfteKanalIDs: [sport.id, gaming.id, tech.id], datenherkunft: .beispiel,
      aktualisiertAm: now.addingTimeInterval(-3_600))

    let demoZugaenge = [
      GoogleZugang(
        id: sportAccess, email: "sport@beispiel.blackstock", anzeigename: "Blackstock Sport",
        status: .verbunden, youtubeChannelID: sport.youtubeChannelID,
        youtubeChannelName: sport.name, verbundenAm: now, letzteSynchronisierung: now,
        datenherkunft: .beispiel),
      GoogleZugang(
        id: gamingAccess, email: "gaming@beispiel.blackstock", anzeigename: "Blackstock Gaming",
        status: .verbunden, youtubeChannelID: gaming.youtubeChannelID,
        youtubeChannelName: gaming.name, verbundenAm: now, letzteSynchronisierung: now,
        datenherkunft: .beispiel),
      GoogleZugang(
        id: techAccess, email: "tech@beispiel.blackstock", anzeigename: "Blackstock Tech",
        status: .verbunden, youtubeChannelID: tech.youtubeChannelID, youtubeChannelName: tech.name,
        verbundenAm: now, letzteSynchronisierung: now, datenherkunft: .beispiel),
    ]

    return AppZustand(
      onboardingAbgeschlossen: true, demoModus: true, googleVerbunden: true,
      googleZugaenge: demoZugaenge, ausgewaehltesZiel: .command, kanalPlaene: [],
      kanaele: [sport, gaming, tech], chancen: [chance1, chance2, chance3],
      produktionen: [p1, p2, p3], videos: [v1, v2],
      provider: standardProvider.map { p in
        var x = p
        x.verbunden = true
        x.detail = "Beispielmodus"
        return x
      }, adsenseProfil: adsense)
  }

  private static func demoTrend(werte: [Double], start: Date) -> [TrendPunkt] {
    werte.enumerated().map { index, wert in
      TrendPunkt(zeit: start.addingTimeInterval(Double(index) * 3600), wert: wert)
    }
  }
}
