import AppKit
import SwiftUI

enum BlackstockAppearance: String, CaseIterable, Identifiable {
  case system = "System"
  case light = "Hell"
  case dark = "Dunkel"
  var id: String { rawValue }

  var colorScheme: ColorScheme? {
    switch self {
    case .system: nil
    case .light: .light
    case .dark: .dark
    }
  }
}

extension NSColor {
  fileprivate static func bsDynamic(light: NSColor, dark: NSColor) -> NSColor {
    NSColor(name: nil) { appearance in
      let match = appearance.bestMatch(from: [.darkAqua, .aqua])
      return match == .darkAqua ? dark : light
    }
  }
}

extension Color {
  static let bsBackground = Color(
    nsColor: .bsDynamic(
      light: NSColor(calibratedRed: 1.0, green: 1.0, blue: 1.0, alpha: 1),
      dark: NSColor(calibratedRed: 0.055, green: 0.063, blue: 0.071, alpha: 1)
    ))
  static let bsSidebar = Color(
    nsColor: .bsDynamic(
      light: NSColor(calibratedRed: 0.985, green: 0.985, blue: 0.985, alpha: 1),
      dark: NSColor(calibratedRed: 0.050, green: 0.057, blue: 0.064, alpha: 1)
    ))
  static let bsSurface = Color(
    nsColor: .bsDynamic(
      light: NSColor(calibratedRed: 1.0, green: 1.0, blue: 1.0, alpha: 1),
      dark: NSColor(calibratedRed: 0.072, green: 0.081, blue: 0.090, alpha: 1)
    ))
  static let bsSurface2 = Color(
    nsColor: .bsDynamic(
      light: NSColor(calibratedRed: 0.965, green: 0.968, blue: 0.972, alpha: 1),
      dark: NSColor(calibratedRed: 0.090, green: 0.101, blue: 0.112, alpha: 1)
    ))
  static let bsSurface3 = Color(
    nsColor: .bsDynamic(
      light: NSColor(calibratedRed: 0.940, green: 0.944, blue: 0.950, alpha: 1),
      dark: NSColor(calibratedRed: 0.113, green: 0.125, blue: 0.137, alpha: 1)
    ))
  static let bsBorder = Color(
    nsColor: .bsDynamic(
      light: NSColor(calibratedWhite: 0.0, alpha: 0.095),
      dark: NSColor(calibratedWhite: 1.0, alpha: 0.105)
    ))
  static let bsBorderStrong = Color(
    nsColor: .bsDynamic(
      light: NSColor(calibratedWhite: 0.0, alpha: 0.16),
      dark: NSColor(calibratedWhite: 1.0, alpha: 0.18)
    ))
  static let bsText = Color(
    nsColor: .bsDynamic(
      light: NSColor(calibratedRed: 0.055, green: 0.055, blue: 0.060, alpha: 1),
      dark: NSColor(calibratedRed: 0.965, green: 0.970, blue: 0.975, alpha: 1)
    ))
  static let bsMuted = Color(
    nsColor: .bsDynamic(
      light: NSColor(calibratedRed: 0.36, green: 0.38, blue: 0.42, alpha: 1),
      dark: NSColor(calibratedRed: 0.66, green: 0.69, blue: 0.73, alpha: 1)
    ))
  static let bsMuted2 = Color(
    nsColor: .bsDynamic(
      light: NSColor(calibratedRed: 0.54, green: 0.56, blue: 0.59, alpha: 1),
      dark: NSColor(calibratedRed: 0.43, green: 0.46, blue: 0.50, alpha: 1)
    ))

  // Blackstock brand: YouTube-like red, but with the Blackstock B mark.
  static let bsRed = Color(red: 1.0, green: 0.105, blue: 0.125)
  static let bsRedDark = Color(red: 0.84, green: 0.055, blue: 0.075)

  // Semantic colors only – these are not brand accents.
  static let bsGreen = Color(red: 0.10, green: 0.72, blue: 0.34)
  static let bsGreenSoft = Color(red: 0.08, green: 0.52, blue: 0.24)
  static let bsBlue = Color(red: 0.16, green: 0.46, blue: 0.94)
  static let bsAmber = Color(red: 0.96, green: 0.61, blue: 0.11)
  static let bsPurple = Color(red: 0.48, green: 0.28, blue: 0.88)
}

struct BlackstockCardModifier: ViewModifier {
  var padding: CGFloat = 18
  var elevated: Bool = false

  func body(content: Content) -> some View {
    content
      .padding(padding)
      .background(
        RoundedRectangle(cornerRadius: 12, style: .continuous)
          .fill(Color.bsSurface)
      )
      .overlay(
        RoundedRectangle(cornerRadius: 12, style: .continuous)
          .stroke(elevated ? Color.bsBorderStrong : Color.bsBorder, lineWidth: 1)
      )
      .shadow(color: elevated ? Color.black.opacity(0.06) : .clear, radius: 12, x: 0, y: 4)
  }
}

extension View {
  func blackstockCard(_ padding: CGFloat = 18, elevated: Bool = false) -> some View {
    modifier(BlackstockCardModifier(padding: padding, elevated: elevated))
  }
}
