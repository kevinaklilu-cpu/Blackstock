import SwiftUI

@main
struct BlackstockApp: App {
  @StateObject private var store = AppStore()

  var body: some Scene {
    WindowGroup {
      RootView()
        .environmentObject(store)
        .frame(minWidth: 1240, minHeight: 800)
    }
    .windowStyle(.hiddenTitleBar)
    .windowToolbarStyle(.unifiedCompact)
    .commands {
      CommandGroup(replacing: .newItem) {}
      CommandMenu("Blackstock") {
        Button("Übersicht") { store.ausgewaehltesZiel = .command }
          .keyboardShortcut("1", modifiers: [.command])
        Button("Chancen") { store.ausgewaehltesZiel = .chancen }
          .keyboardShortcut("2", modifiers: [.command])
        Button("Erstellen") { store.ausgewaehltesZiel = .factory }
          .keyboardShortcut("3", modifiers: [.command])
        Button("Studio") { store.ausgewaehltesZiel = .produktionen }
          .keyboardShortcut("4", modifiers: [.command])
        Button("Inhalte") { store.ausgewaehltesZiel = .veroeffentlicht }
          .keyboardShortcut("5", modifiers: [.command])
        Button("Kalender") { store.ausgewaehltesZiel = .kalender }
          .keyboardShortcut("6", modifiers: [.command])
        Divider()
        Button("Live-Daten aktualisieren") { Task { await store.liveDatenAktualisieren() } }
          .keyboardShortcut("r", modifiers: [.command])
      }
    }
  }
}
