import Foundation

@MainActor
extension AppStore {
  // MARK: - Channel profiles

  func channelProfile(for channelID: UUID) -> ChannelContentProfile {
    if let profile = v11State.profile(for: channelID) { return profile }
    let topic = kanal(fuer: channelID)?.thema ?? ""
    var profile = ChannelContentProfile(channelID: channelID)
    profile.language = UserDefaults.standard.string(forKey: "blackstock.language") ?? "Deutsch"
    profile.region = UserDefaults.standard.string(forKey: "blackstock.region") ?? "DE"
    profile.topics = TopicTaxonomy.infer(from: topic).map { [$0] } ?? []
    profile.customTopics = topic.isEmpty ? [] : [topic]
    profile.reviewBeforePublish = UserDefaults.standard.object(forKey: "blackstock.reviewBeforePublish") == nil
      ? true : UserDefaults.standard.bool(forKey: "blackstock.reviewBeforePublish")
    profile.defaultPrivacy = ChannelPrivacy(
      rawValue: UserDefaults.standard.string(forKey: "blackstock.defaultPrivacy") ?? "") ?? .privateVideo
    return profile
  }

  func channelProfileSpeichern(_ profile: ChannelContentProfile) {
    v11State.upsertProfile(profile)
    speichern()
  }

  func channelTopics(for channelID: UUID?) -> [String] {
    guard let channelID else { return [] }
    return channelProfile(for: channelID).effectiveSearchTerms
  }

  var sourceManifestURLs: [String] { v11State.sourceManifestURLs }

  func sourceManifestHinzufuegen(_ raw: String) throws {
    let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
    guard let url = URL(string: value), url.scheme?.lowercased() == "https", url.host != nil else {
      throw SourceConnectorError.invalidURL
    }
    if !v11State.sourceManifestURLs.contains(url.absoluteString) {
      v11State.sourceManifestURLs.append(url.absoluteString)
      v11State.sourceManifestURLs.sort()
      speichern()
    }
  }

  func sourceManifestEntfernen(_ raw: String) {
    v11State.sourceManifestURLs.removeAll { $0 == raw }
    speichern()
  }

  // MARK: - Production v11

  func v11Produktion(for productionID: UUID) -> ProductionV11State {
    if let state = v11State.productionState(for: productionID) { return state }
    let format = produktionen.first(where: { $0.id == productionID })?.format ?? .short
    return ProductionV11State(
      productionID: productionID,
      mode: format == .short ? .short : (format == .livestream ? .live : .automatic),
      phase: .draft
    )
  }

  @discardableResult
  func v11ProduktionAusChance(_ chance: Chance, mode: ProductionModeV11 = .automatic) -> UUID? {
    let format: VideoFormat?
    switch mode {
    case .short: format = .short
    case .longform: format = .longform
    case .live: format = .livestream
    case .automatic, .singleSource, .remix:
      if let raw = UserDefaults.standard.string(forKey: "blackstock.defaultFormat"),
        let configured = VideoFormat(rawValue: raw)
      { format = configured } else { format = chance.empfohleneFormate.first }
    }
    guard let id = produktionAusChance(
      chance, format: format, modus: .studio, publikationsmodus: .review)
    else { return nil }
    var state = v11Produktion(for: id)
    state.mode = mode
    let targetChannelID = produktionen.first(where: { $0.id == id })?.kanalID
    let reviewBeforePublish = targetChannelID.map { channelProfile(for: $0).reviewBeforePublish } ?? true
    state.reviewBeforePublishOverride = reviewBeforePublish
    state.phase = .discoveringSources
    state.checkpoint = ProductionCheckpoint(
      phase: .discoveringSources, updatedAt: Date(), detail: "Produktion aus Trend gestartet")
    v11State.upsertProductionState(state)
    if let index = produktionen.firstIndex(where: { $0.id == id }) {
      produktionen[index].publikationsmodus = reviewBeforePublish ? .review : .nachGate
      produktionen[index].naechsterSchritt = "Erlaubte Quellen suchen"
      produktionen[index].status = .recherche
      produktionen[index].aktualisiertAm = Date()
    }
    speichern()
    return id
  }

  @discardableResult
  func v11ProduktionStartenAusChance(
    _ chance: Chance, mode: ProductionModeV11 = .automatic
  ) async -> UUID? {
    guard let id = v11ProduktionAusChance(chance, mode: mode) else { return nil }
    ausgewaehlteProduktionID = id
    ausgewaehltesZiel = .produktionen
    guard let production = produktionen.first(where: { $0.id == id }) else { return id }

    let reference = TrendReference(
      providerReferenceID: chance.quellenSchluessel ?? chance.id.uuidString,
      sourcePage: chance.quellenSchluessel?.hasPrefix("youtube:") == true
        ? "https://www.youtube.com/watch?v=" + (chance.quellenSchluessel?.replacingOccurrences(of: "youtube:", with: "") ?? "")
        : nil,
      title: chance.titel,
      channelTitle: nil,
      publishedAt: chance.entdecktAm,
      category: TopicTaxonomy.infer(from: "\(chance.thema) \(chance.titel)"),
      views: nil, likes: nil, comments: nil, durationSeconds: nil,
      relevance: chance.nachfrageScore,
      velocity: min(100, max(0, chance.trendScore + chance.momentum * 0.15)),
      engagement: min(100, max(0, chance.viralitaetsWahrscheinlichkeit * 100)),
      relativePerformance: chance.trendScore,
      saturation: chance.wettbewerbScore,
      formatFit: chance.empfohleneFormate.contains(production.format) ? 95 : 65,
      usableSourceAvailability: 0,
      signalCount: max(1, chance.quellenAnzahl))

    if !v11State.trendReferences.contains(where: { $0.providerReferenceID == reference.providerReferenceID }) {
      v11State.trendReferences.append(reference)
    }

    let connectors: [any SourceConnectorProtocol] = [
      DirectHTTPSSourceConnector(knownAssets: v11State.sourceAssets),
      RemoteManifestSourceConnector(
        manifestURLs: v11State.sourceManifestURLs, knownAssets: v11State.sourceAssets),
    ]
    let discovered = await SourceDiscoveryService(connectors: connectors).discover(
      trend: reference, profile: channelProfile(for: production.kanalID))
    for source in discovered { v11SourceAssetHinzufuegen(source, zu: id) }

    if discovered.isEmpty {
      v11PhaseSetzen(id, phase: .discoveringSources, detail: "Keine automatisch nutzbare Quelle gefunden")
      meldung = "Produktion angelegt. Es wurde noch keine rights-cleared Quelle im Remote-Medienkatalog gefunden."
      return id
    }

    v11PhaseSetzen(id, phase: .analyzingSources, detail: "\(discovered.count) erlaubte Quelle(n) automatisch gefunden")
    if existingMediaFirst {
      await v11ProduktionFortsetzen(id)
    }
    return id
  }

  func v11ProduktionsmodusSetzen(_ productionID: UUID, modus: ProductionModeV11) {
    var state = v11Produktion(for: productionID)
    state.mode = modus
    state.checkpoint = ProductionCheckpoint(phase: state.phase, updatedAt: Date(), detail: "Modus geändert")
    v11State.upsertProductionState(state)
    speichern()
  }

  func v11ReviewFreigeben(_ productionID: UUID) {
    let check = bereitCheck(for: productionID)
    guard check.issues.isEmpty else {
      meldung = check.issues.first?.message ?? "Die Produktion ist noch nicht freigabefähig."
      return
    }
    var state = v11Produktion(for: productionID)
    state.phase = .ready
    state.interrupted = false
    state.lastError = nil
    state.checkpoint = ProductionCheckpoint(
      phase: .ready, updatedAt: Date(), detail: "Review manuell freigegeben")
    v11State.upsertProductionState(state)
    if let index = produktionen.firstIndex(where: { $0.id == productionID }) {
      produktionen[index].status = .bereit
      produktionen[index].naechsterSchritt = "Bereit zum Veröffentlichen"
      produktionen[index].aktualisiertAm = Date()
    }
    speichern()
    meldung = "Review freigegeben. Die Produktion ist bereit zum Veröffentlichen."
  }

  func v11PhaseSetzen(_ productionID: UUID, phase: ProductionPhase, detail: String? = nil) {
    var state = v11Produktion(for: productionID)
    state.phase = phase
    state.lastError = phase == .failed ? state.lastError : nil
    state.interrupted = false
    state.checkpoint = ProductionCheckpoint(phase: phase, updatedAt: Date(), detail: detail)
    v11State.upsertProductionState(state)
    speichern()
  }

  func v11FehlerSetzen(_ productionID: UUID, detail: String) {
    var state = v11Produktion(for: productionID)
    state.lastError = detail
    state.phase = .failed
    state.checkpoint = ProductionCheckpoint(phase: .failed, updatedAt: Date(), detail: detail)
    v11State.upsertProductionState(state)
    speichern()
  }

  func v11SourceAssetHinzufuegen(_ asset: SourceAsset, zu productionID: UUID? = nil) {
    if let index = v11State.sourceAssets.firstIndex(where: { $0.id == asset.id }) {
      v11State.sourceAssets[index] = asset
    } else {
      v11State.sourceAssets.append(asset)
    }
    if let productionID {
      var state = v11Produktion(for: productionID)
      if !state.sourceAssetIDs.contains(asset.id) { state.sourceAssetIDs.append(asset.id) }
      v11State.upsertProductionState(state)
    }
    speichern()
  }

  func v11Sources(for productionID: UUID) -> [SourceAsset] {
    let ids = Set(v11Produktion(for: productionID).sourceAssetIDs)
    return v11State.sourceAssets.filter { ids.contains($0.id) }
  }

  func v11TimelineSetzen(_ timeline: RemixTimeline, fuer productionID: UUID) {
    var state = v11Produktion(for: productionID)
    state.timeline = timeline
    state.sourceAssetIDs = Array(Set(timeline.segments.map(\.sourceAssetID)))
    state.phase = .planning
    state.checkpoint = ProductionCheckpoint(phase: .planning, updatedAt: Date(), detail: "Remix-Timeline erstellt")
    v11State.upsertProductionState(state)
    speichern()
  }

  func bereitCheck(for productionID: UUID) -> ReadyCheck {
    guard let production = produktionen.first(where: { $0.id == productionID }) else {
      return ReadyCheck(
        state: .inProgress,
        issues: [ReadyIssue(code: .renderMissing, message: "Produktion wurde nicht gefunden.")],
        checkedAt: Date()
      )
    }
    let renderExists = production.lokaleDatei.map { FileManager.default.fileExists(atPath: $0) } ?? false
    let thumbExists = production.thumbnailDatei.map { FileManager.default.fileExists(atPath: $0) } ?? false
    return ReadyCheckEngine.evaluate(
      production: production,
      v11: v11State.productionState(for: productionID),
      sources: v11State.sourceAssets,
      targetChannelExists: kanal(fuer: production.kanalID)?.youtubeChannelID != nil,
      renderedFileExists: renderExists,
      thumbnailFileExists: thumbExists
    )
  }

  // MARK: - Analytics

  func analyticsPoints(
    channelID: UUID?,
    preset: AnalyticsRangePreset,
    customStart: Date? = nil,
    customEnd: Date? = nil,
    now: Date = Date()
  ) -> [AnalyticsDailyPoint] {
    let selectedIDs: Set<UUID>
    if let channelID {
      selectedIDs = [channelID]
    } else {
      selectedIDs = Set(liveKanaele.map(\.id))
    }
    guard !selectedIDs.isEmpty else { return [] }

    var calendar = Calendar(identifier: .gregorian)
    calendar.timeZone = TimeZone(secondsFromGMT: 0) ?? .gmt
    let end = calendar.startOfDay(for: customEnd ?? now)
    let start: Date
    if preset == .custom, let customStart {
      start = calendar.startOfDay(for: customStart)
    } else {
      let days = preset.days ?? 28
      start = calendar.date(byAdding: .day, value: -(days - 1), to: end) ?? end
    }
    let revenueComplete = selectedIDs.allSatisfy {
      let status = channelProfile(for: $0).revenueAccess
      return status == .available || status == .authorizedNoData
    }
    return AnalyticsNormalizer.normalized(
      points: v11State.analyticsDaily,
      channelIDs: selectedIDs,
      from: start,
      through: end,
      revenueComplete: revenueComplete,
      calendar: calendar
    )
  }

  func analyticsSummary(
    channelID: UUID?,
    preset: AnalyticsRangePreset,
    customStart: Date? = nil,
    customEnd: Date? = nil
  ) -> AnalyticsSummary {
    AnalyticsNormalizer.summary(
      analyticsPoints(
        channelID: channelID,
        preset: preset,
        customStart: customStart,
        customEnd: customEnd
      ))
  }

  func analyticsDailyUpsert(_ newPoints: [AnalyticsDailyPoint], for channelID: UUID) {
    let newDays = Set(newPoints.map { Calendar(identifier: .gregorian).startOfDay(for: $0.date) })
    v11State.analyticsDaily.removeAll {
      $0.channelID == channelID && newDays.contains(Calendar(identifier: .gregorian).startOfDay(for: $0.date))
    }
    v11State.analyticsDaily.append(contentsOf: newPoints)
    v11State.analyticsDaily.sort { $0.date < $1.date }
    speichern()
  }

  // MARK: - Settings

  var existingMediaFirst: Bool {
    get { v11State.existingMediaFirst }
    set {
      v11State.existingMediaFirst = newValue
      UserDefaults.standard.set(newValue, forKey: "blackstock.existingMediaFirst")
      speichern()
    }
  }

  var aiFallbackAllowed: Bool {
    get { v11State.allowAIFallback }
    set {
      v11State.allowAIFallback = newValue
      UserDefaults.standard.set(newValue, forKey: "blackstock.aiFallback")
      speichern()
    }
  }

  var remoteCacheLimitGB: Double {
    get { max(1, v11State.remoteCacheLimitGB) }
    set {
      v11State.remoteCacheLimitGB = max(1, min(500, newValue))
      UserDefaults.standard.set(v11State.remoteCacheLimitGB, forKey: "blackstock.remoteCacheLimitGB")
      speichern()
    }
  }

  // MARK: - Existing-media production pipeline

  @discardableResult
  func v11DirectSourceHinzufuegen(
    zu productionID: UUID,
    urlString: String,
    title: String,
    rights: RightsStatus,
    licenseType: String?,
    creator: String? = nil,
    transcript: String? = nil,
    commercialUseAllowed: Bool = false
  ) throws -> SourceAsset {
    let trimmed = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
    guard let url = URL(string: trimmed), url.scheme?.lowercased() == "https", url.host != nil else {
      throw SourceConnectorError.invalidURL
    }
    let owned = rights == .owned
    let uses: [SourceAllowedUse] = owned
      ? [.edit, .publish, .commercial]
      : (commercialUseAllowed ? [.edit, .publish, .commercial] : [.edit, .publish])
    let asset = SourceAsset(
      provider: .directHTTPS,
      providerAssetID: nil,
      remoteURL: url.absoluteString,
      title: title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? url.lastPathComponent : title,
      duration: nil,
      creator: creator,
      sourcePage: url.absoluteString,
      licenseType: owned ? "User-owned media" : licenseType,
      rightsStatus: rights,
      allowedUses: uses,
      channelOwnership: owned,
      transcript: transcript,
      language: channelProfile(for: produktionen.first(where: { $0.id == productionID })?.kanalID ?? UUID()).language,
      topicTags: []
    )
    if let reason = RightsService.blockingReason(asset) { throw SourceConnectorError.unsupported(reason) }
    v11SourceAssetHinzufuegen(asset, zu: productionID)
    v11PhaseSetzen(productionID, phase: .analyzingSources, detail: "Remote-Quelle hinzugefügt und Rechte geprüft")
    return asset
  }

  func v11SourceEntfernen(_ assetID: UUID, aus productionID: UUID) {
    var state = v11Produktion(for: productionID)
    state.sourceAssetIDs.removeAll { $0 == assetID }
    if state.timeline?.segments.contains(where: { $0.sourceAssetID == assetID }) == true {
      state.timeline = nil
      state.phase = .analyzingSources
    }
    v11State.upsertProductionState(state)
    // Das Asset bleibt im rights-aware Remote-Medienkatalog erhalten und kann für
    // spätere kanalrelevante Produktionen automatisch wiedergefunden werden.
    speichern()
  }

  func v11ProduktionFortsetzen(_ productionID: UUID) async {
    guard let pIndex = produktionen.firstIndex(where: { $0.id == productionID }) else { return }
    var state = v11Produktion(for: productionID)
    let initialSources = v11Sources(for: productionID)
    guard !initialSources.isEmpty else {
      v11FehlerSetzen(productionID, detail: "Es wurde noch keine erlaubte Remote-Quelle hinzugefügt. YouTube-Trendvideos selbst werden nicht heruntergeladen.")
      return
    }
    let blocked = initialSources.compactMap(RightsService.blockingReason)
    guard blocked.isEmpty else {
      v11FehlerSetzen(productionID, detail: blocked.first ?? "Quellenrechte sind nicht ausreichend geklärt.")
      return
    }

    istBeschaeftigt = true
    defer { istBeschaeftigt = false }
    do {
      v11PhaseSetzen(productionID, phase: .fetchingMedia, detail: "Remote-Medien werden intern geladen")
      var resolvedURLs: [UUID: URL] = [:]
      for original in initialSources {
        let connector: any SourceConnectorProtocol
        switch original.provider {
        case .directHTTPS:
          connector = DirectHTTPSSourceConnector(knownAssets: initialSources)
        case .userCloud:
          connector = RemoteManifestSourceConnector(
            manifestURLs: v11State.sourceManifestURLs, knownAssets: initialSources)
        case .licensedProvider:
          throw SourceConnectorError.unsupported("Für den lizenzierten Provider ist kein echter API-Adapter konfiguriert.")
        case .youtubeReference:
          throw SourceConnectorError.notDownloadableReference
        }
        let result = try await RemoteMediaCacheService.shared.fetch(asset: original, connector: connector)
        var updated = original
        updated.downloadedCachePath = result.url.path
        updated.checksumSHA256 = result.checksum
        if updated.duration == nil {
          updated.duration = try await MediaProbeService.shared.duration(of: result.url)
        }
        if let aIndex = v11State.sourceAssets.firstIndex(where: { $0.id == updated.id }) {
          v11State.sourceAssets[aIndex] = updated
        }
        resolvedURLs[updated.id] = result.url
        speichern()
      }

      state = v11Produktion(for: productionID)
      v11PhaseSetzen(productionID, phase: .planning, detail: "Remix-Timeline wird aus den tatsächlichen Quellen geplant")
      let currentSources = v11Sources(for: productionID)
      var timeline = try RemixPlannerService().plan(
        sources: currentSources,
        mode: state.mode,
        requestedFormat: produktionen[pIndex].format)
      if UserDefaults.standard.object(forKey: "blackstock.autoCaptions") != nil {
        timeline.captions = UserDefaults.standard.bool(forKey: "blackstock.autoCaptions")
      }
      v11TimelineSetzen(timeline, fuer: productionID)

      if timeline.format == .livestream || state.mode == .live {
        await livestreamVorbereiten(productionID)
        guard let target = livestreamRTMPZiel(productionID) else {
          throw LivePlayoutService.PlayoutError.launchFailed(
            produktionen.first(where: { $0.id == productionID })?.letzterFehler
              ?? "YouTube hat kein nutzbares RTMP-Ziel bereitgestellt.")
        }
        let orderedURLs = timeline.segments.sorted(by: { $0.order < $1.order }).compactMap {
          resolvedURLs[$0.sourceAssetID]
        }
        guard !orderedURLs.isEmpty else { throw LivePlayoutService.PlayoutError.noMedia }
        v11PhaseSetzen(
          productionID, phase: .ready,
          detail: "YouTube-Broadcast ist vorbereitet; RTMP-Playout wird gestartet")
        try await LivePlayoutService.shared.start(
          productionID: productionID,
          mediaURLs: orderedURLs,
          rtmpTarget: target,
          loop: true
        ) { [weak self] exitCode, requested in
          Task { @MainActor in
            self?.v11LivePlayoutBeendet(
              productionID, exitCode: exitCode, requested: requested)
          }
        }
        if let liveIndex = produktionen.firstIndex(where: { $0.id == productionID }) {
          produktionen[liveIndex].status = .live
          produktionen[liveIndex].naechsterSchritt = "RTMP-Playout aktiv"
          produktionen[liveIndex].letzterFehler = nil
          produktionen[liveIndex].aktualisiertAm = Date()
        }
        v11PhaseSetzen(
          productionID, phase: .published,
          detail: "Live: FFmpeg sendet tatsächlich Frames an den YouTube-Ingest")
        speichern()
        meldung = "Live Playout ist aktiv. Blackstock hat tatsächlich gesendete Frames bestätigt."
        return
      }

      v11PhaseSetzen(productionID, phase: .rendering, detail: "AVFoundation rendert die Remix-Timeline")
      let folder = try PersistenceService.shared.arbeitsordner("Produktionen/\(productionID.uuidString)")
      let output = folder.appendingPathComponent("Blackstock-\(productionID.uuidString).mp4")
      let watermark: URL? = {
        guard produktionen[pIndex].watermarkAktiv ?? true,
          let path = kanal(fuer: produktionen[pIndex].kanalID)?.branding?.logoPfad,
          FileManager.default.fileExists(atPath: path)
        else { return nil }
        return URL(fileURLWithPath: path)
      }()
      let render = try await MasterVideoService.shared.rendern(
        timeline: timeline,
        sourceURLs: resolvedURLs,
        optionen: .init(
          format: timeline.format,
          voiceover: nil,
          musik: nil,
          szenen: [],
          captions: timeline.captions,
          watermark: watermark),
        ziel: output)

      guard let latestIndex = produktionen.firstIndex(where: { $0.id == productionID }) else { return }
      let validation = try await MediaProbeService.shared.inspect(render)
      produktionen[latestIndex].lokaleDatei = render.path
      produktionen[latestIndex].format = timeline.format
      produktionen[latestIndex].masterRenderDatum = Date()
      produktionen[latestIndex].datenherkunft = .lokal
      produktionen[latestIndex].aktualisiertAm = Date()
      var renderedState = v11Produktion(for: productionID)
      renderedState.renderValidation = validation
      v11State.upsertProductionState(renderedState)

      // Metadata is intentionally generated after the final timeline is known.
      let profile = channelProfile(for: produktionen[latestIndex].kanalID)
      let trendTitle = produktionen[latestIndex].chanceSnapshot?.thema ?? produktionen[latestIndex].arbeitstitel
      let metadata = FinalMetadataService().make(
        trendTitle: trendTitle,
        profile: profile,
        sources: currentSources,
        timeline: timeline,
        fallbackTitle: produktionen[latestIndex].arbeitstitel)
      produktionen[latestIndex].arbeitstitel = metadata.title
      produktionen[latestIndex].beschreibung = ([metadata.description] + metadata.chapters + [metadata.hashtags.joined(separator: " ")])
        .filter { !$0.isEmpty }.joined(separator: "\n\n")
      produktionen[latestIndex].tags = metadata.tags
      produktionen[latestIndex].thumbnailIdee = metadata.thumbnailText

      if timeline.format != .short, let channel = kanal(fuer: produktionen[latestIndex].kanalID) {
        let frame = folder.appendingPathComponent("thumbnail-frame.png")
        let thumbnail = folder.appendingPathComponent("thumbnail.png")
        let background = try? await VideoFrameThumbnailService.shared.bestFrame(from: render, to: frame)
        let branding = channel.branding ?? KanalBranding()
        let generated = try ThumbnailService.shared.generieren(
          produktion: produktionen[latestIndex], kanal: channel, branding: branding,
          hintergrund: background, ziel: thumbnail)
        produktionen[latestIndex].thumbnailDatei = generated.path
      }

      let review = state.reviewBeforePublishOverride ?? profile.reviewBeforePublish
      produktionen[latestIndex].status = review ? .qualitaet : .bereit
      produktionen[latestIndex].naechsterSchritt = review ? "Video ansehen und Veröffentlichung prüfen" : "Bereit zum Veröffentlichen"
      speichern()
      let check = bereitCheck(for: productionID)
      if !check.issues.isEmpty {
        v11PhaseSetzen(productionID, phase: .review, detail: "Bereit-Check: \(check.issues.count) Problem(e)")
      } else {
        v11PhaseSetzen(productionID, phase: review ? .review : .ready, detail: review ? "Review erforderlich" : "Bereit zum Veröffentlichen")
      }
      try? await RemoteMediaCacheService.shared.cleanup(
        maxBytes: Int64(remoteCacheLimitGB * 1024 * 1024 * 1024),
        preserving: Set(resolvedURLs.values.map { $0.standardizedFileURL.path }))
      if review {
        meldung = "Render fertig. Die Produktion wartet auf dein Review."
      } else {
        meldung = "Render und Bereit-Check abgeschlossen. Veröffentlichung wird gestartet."
        istBeschaeftigt = false
        await produktionHochladen(productionID)
      }
    } catch is CancellationError {
      var interrupted = v11Produktion(for: productionID)
      interrupted.interrupted = true
      interrupted.lastError = "Vorgang wurde unterbrochen und kann erneut gestartet werden."
      v11State.upsertProductionState(interrupted)
      speichern()
      meldung = "Produktion unterbrochen. Der letzte persistierte Schritt bleibt erhalten."
    } catch {
      v11FehlerSetzen(productionID, detail: error.localizedDescription)
      if let i = produktionen.firstIndex(where: { $0.id == productionID }) {
        produktionen[i].letzterFehler = error.localizedDescription
        produktionen[i].status = .blockiert
        produktionen[i].naechsterSchritt = "Fehler beheben und ab letzter Phase erneut versuchen"
      }
      speichern()
      meldung = error.localizedDescription
    }
  }

  func v11LivestreamStoppen(_ productionID: UUID) {
    LivePlayoutService.shared.stop(productionID: productionID)
  }

  func v11LivePlayoutBeendet(_ productionID: UUID, exitCode: Int32, requested: Bool) {
    guard let index = produktionen.firstIndex(where: { $0.id == productionID }) else { return }
    if requested {
      produktionen[index].status = .bereit
      produktionen[index].naechsterSchritt = "Live Playout beendet"
      produktionen[index].letzterFehler = nil
      var state = v11Produktion(for: productionID)
      state.phase = .ready
      state.lastError = nil
      state.checkpoint = ProductionCheckpoint(
        phase: .ready, updatedAt: Date(), detail: "Live Playout vom Nutzer beendet")
      v11State.upsertProductionState(state)
      meldung = "Live Playout wurde beendet."
    } else {
      let detail = "Live Playout wurde unerwartet beendet (FFmpeg Exit \(exitCode))."
      produktionen[index].status = .blockiert
      produktionen[index].naechsterSchritt = "Live Playout prüfen und erneut starten"
      produktionen[index].letzterFehler = detail
      var state = v11Produktion(for: productionID)
      state.phase = .failed
      state.lastError = detail
      state.checkpoint = ProductionCheckpoint(
        phase: .failed, updatedAt: Date(), detail: detail)
      v11State.upsertProductionState(state)
      meldung = detail
    }
    produktionen[index].aktualisiertAm = Date()
    speichern()
  }

  func revenueZugriffVerbinden(channelID: UUID) async {
    guard let connection = v11State.channelConnections.first(where: { $0.localChannelID == channelID }) else {
      meldung = "Für diesen Kanal wurde keine Google-Verbindung gefunden."
      return
    }
    do {
      try await youtube.featureAutorisieren(.monetaryAnalytics, verbindungID: connection.googleAccountID)
      var profile = channelProfile(for: channelID)
      profile.revenueAccess = .authorizedNoData
      v11State.upsertProfile(profile)
      speichern()
      await liveDatenAktualisieren()
    } catch {
      meldung = error.localizedDescription
    }
  }

  func uploadBerechtigungVerbinden(channelID: UUID) async {
    guard let connection = v11State.channelConnections.first(where: { $0.localChannelID == channelID }) else { return }
    do {
      try await youtube.featureAutorisieren(.upload, verbindungID: connection.googleAccountID)
      var profile = channelProfile(for: channelID)
      profile.uploadAuthorized = true
      v11State.upsertProfile(profile)
      speichern()
    } catch { meldung = error.localizedDescription }
  }

  /// Resets persisted product state without fabricating demo data. OAuth/provider secrets
  /// deliberately remain in Keychain; orphaned tokens are inert until an account is connected again.
  func lokalenZustandZuruecksetzen() {
    let empty = SeedData.leererZustand()
    PersistenceService.shared.zuruecksetzen()
    onboardingAbgeschlossen = false
    demoModus = false
    googleVerbunden = false
    googleZugaenge = []
    ausgewaehltesZiel = .command
    kanalPlaene = []
    kanaele = []
    chancen = []
    produktionen = []
    videos = []
    provider = EnginePresetService.normalisieren(
      empty.provider.isEmpty ? SeedData.standardProvider : empty.provider)
    adsenseProfil = AdSenseProfil()
    medien = []
    batchAuftraege = []
    automationsregeln = []
    v11State = V11State()
    ausgewaehlteProduktionID = nil
    ausgewaehlterKanalID = nil
    apiEinrichtungsHinweis = nil
    _ = PersistenceService.shared.speichern(zustand)
    meldung = "Lokaler Blackstock-Zustand wurde zurückgesetzt. Schlüsselbund-Geheimnisse wurden nicht gelöscht."
  }

}
