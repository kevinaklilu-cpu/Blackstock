import SwiftUI

struct BlackstockMark: View {
  var size: CGFloat = 34

  var body: some View {
    let height = size * 0.70
    ZStack {
      RoundedRectangle(cornerRadius: height * 0.28, style: .continuous)
        .fill(Color.bsRed)
      HStack(spacing: size * 0.05) {
        Image(systemName: "play.fill")
          .font(.system(size: size * 0.22, weight: .black))
          .foregroundStyle(.white)
        Text("B")
          .font(.system(size: size * 0.32, weight: .black, design: .rounded))
          .foregroundStyle(.white)
          .offset(y: -0.3)
      }
    }
    .frame(width: size, height: height)
    .accessibilityLabel("Blackstock Play B")
  }
}

struct PageHeader: View {
  let titel: String
  let untertitel: String
  var trailing: AnyView? = nil
  var body: some View {
    HStack(alignment: .center, spacing: 18) {
      VStack(alignment: .leading, spacing: 5) {
        Text(titel)
          .font(.system(size: 27, weight: .semibold))
          .foregroundStyle(Color.bsText)
        Text(untertitel)
          .font(.system(size: 11.5))
          .foregroundStyle(Color.bsMuted)
      }
      Spacer()
      if let trailing { trailing }
    }
  }
}

struct AbschnittTitel: View {
  let titel: String
  var untertitel: String? = nil
  var trailing: AnyView? = nil
  var body: some View {
    HStack(alignment: .top) {
      VStack(alignment: .leading, spacing: 4) {
        Text(titel).font(.system(size: 16, weight: .semibold)).foregroundStyle(Color.bsText)
        if let untertitel {
          Text(untertitel).font(.system(size: 10.5)).foregroundStyle(Color.bsMuted)
        }
      }
      Spacer()
      if let trailing { trailing }
    }
  }
}

struct KPIKarte: View {
  let titel: String
  let wert: String
  var delta: String? = nil
  var symbol: String? = nil
  var akzent: Color = .bsRed
  var body: some View {
    VStack(alignment: .leading, spacing: 11) {
      HStack {
        Text(titel.uppercased()).font(.system(size: 9.5, weight: .semibold)).tracking(0.8)
          .foregroundStyle(Color.bsMuted)
        Spacer()
        if let symbol { Image(systemName: symbol).font(.system(size: 11)).foregroundStyle(akzent) }
      }
      Text(wert).font(.system(size: 26, weight: .semibold, design: .rounded)).monospacedDigit()
        .foregroundStyle(Color.bsText)
      if let delta {
        Text(delta).font(.system(size: 10.5, weight: .medium)).foregroundStyle(akzent)
      }
    }
    .blackstockCard(15)
  }
}

struct MetricCell: View {
  let label: String
  let value: String
  var detail: String? = nil
  var accent: Color = .bsText
  var body: some View {
    VStack(alignment: .leading, spacing: 3) {
      Text(label.uppercased()).font(.system(size: 8.5, weight: .semibold)).tracking(0.7)
        .foregroundStyle(Color.bsMuted)
      Text(value).font(.system(size: 14, weight: .semibold, design: .rounded)).monospacedDigit()
        .foregroundStyle(accent)
      if let detail { Text(detail).font(.system(size: 9)).foregroundStyle(Color.bsMuted) }
    }
  }
}

struct ScoreRing: View {
  let wert: Double
  let label: String
  var farbe: Color = .bsRed
  var body: some View {
    VStack(spacing: 7) {
      ZStack {
        Circle().stroke(Color.white.opacity(0.07), lineWidth: 6)
        Circle().trim(from: 0, to: min(max(wert / 100, 0), 1)).stroke(
          farbe, style: StrokeStyle(lineWidth: 6, lineCap: .round)
        ).rotationEffect(.degrees(-90))
        Text("\(Int(wert))").font(.system(size: 16, weight: .semibold, design: .rounded))
          .foregroundStyle(Color.bsText)
      }.frame(width: 58, height: 58)
      Text(label).font(.system(size: 9.5, weight: .medium)).foregroundStyle(Color.bsMuted)
    }
  }
}

struct VertrauenBadge: View {
  let konfidenz: Double
  var body: some View {
    let color = konfidenz >= 0.9 ? Color.bsGreen : (konfidenz >= 0.75 ? Color.bsAmber : Color.bsRed)
    HStack(spacing: 6) {
      Circle().fill(color).frame(width: 6, height: 6)
      Text("Vertrauen \(Int(konfidenz * 100)) %").font(.system(size: 10.5, weight: .medium))
        .foregroundStyle(Color.bsText.opacity(0.9))
    }
    .padding(.horizontal, 9).padding(.vertical, 5)
    .background(color.opacity(0.08)).clipShape(Capsule())
  }
}

struct DatenquelleBadge: View {
  let quelle: Datenherkunft
  var body: some View {
    let farbe: Color = quelle == .live ? .bsGreen : (quelle == .beispiel ? .bsAmber : .bsBlue)
    Text(quelle.rawValue.uppercased())
      .font(.system(size: 8, weight: .bold)).tracking(0.7).foregroundStyle(farbe)
      .padding(.horizontal, 7).padding(.vertical, 4)
      .background(farbe.opacity(0.08)).clipShape(Capsule())
  }
}

struct StatusPunkt: View {
  let text: String
  let farbe: Color
  var body: some View {
    HStack(spacing: 6) {
      Circle().fill(farbe).frame(width: 6, height: 6)
      Text(text).font(.system(size: 10.5, weight: .medium)).foregroundStyle(
        Color.bsText.opacity(0.88))
    }
  }
}

struct BlackstockFortschritt: View {
  let wert: Double
  var farbe: Color = .bsGreen
  var body: some View {
    GeometryReader { geo in
      ZStack(alignment: .leading) {
        Capsule().fill(Color.white.opacity(0.07))
        Capsule().fill(farbe).frame(width: geo.size.width * min(max(wert, 0), 1))
      }
    }.frame(height: 5)
  }
}

struct EmptyState: View {
  let symbol: String
  let titel: String
  let text: String
  let button: String?
  let action: (() -> Void)?
  var body: some View {
    VStack(spacing: 13) {
      ZStack {
        Circle().fill(Color.bsSurface2).frame(width: 56, height: 56)
        Image(systemName: symbol).font(.system(size: 22, weight: .medium)).foregroundStyle(
          Color.bsRed)
      }
      Text(titel).font(.system(size: 17, weight: .semibold)).foregroundStyle(Color.bsText)
      Text(text).multilineTextAlignment(.center).font(.system(size: 11.5)).foregroundStyle(
        Color.bsMuted
      ).frame(maxWidth: 460)
      if let button, let action {
        Button(button, action: action).buttonStyle(.borderedProminent).tint(Color.bsRed)
          .foregroundStyle(.white)
      }
    }
    .frame(maxWidth: .infinity, minHeight: 245)
    .blackstockCard()
  }
}

struct DecisionCard: View {
  let eyebrow: String
  let title: String
  let bodyText: String
  let confidence: Double
  var accent: Color = .bsRed
  var primaryTitle: String
  var primaryAction: () -> Void
  var secondaryTitle: String? = nil
  var secondaryAction: (() -> Void)? = nil
  var body: some View {
    VStack(alignment: .leading, spacing: 14) {
      Text(eyebrow.uppercased()).font(.system(size: 9, weight: .bold)).tracking(1).foregroundStyle(
        accent)
      Text(title).font(.system(size: 17, weight: .semibold)).foregroundStyle(Color.bsText)
      Text(bodyText).font(.system(size: 11)).foregroundStyle(Color.bsMuted).lineSpacing(3)
      HStack {
        VertrauenBadge(konfidenz: confidence)
        Spacer()
        if let secondaryTitle, let secondaryAction {
          Button(secondaryTitle, action: secondaryAction).buttonStyle(.bordered)
        }
        Button(primaryTitle, action: primaryAction).buttonStyle(.borderedProminent).tint(accent)
          .foregroundStyle(.white)
      }
    }.blackstockCard(18, elevated: true)
  }
}

extension KanalStatus {
  var color: Color {
    switch self {
    case .entwurf: .bsMuted
    case .verbunden: .bsBlue
    case .wachstum, .monetarisiert: .bsGreen
    case .pausiert: .bsAmber
    }
  }
}
extension Produktionsstatus {
  var color: Color {
    switch self {
    case .blockiert: .bsRed
    case .live: .bsGreen
    case .geplant: .bsBlue
    case .qualitaet: .bsAmber
    default: .bsText.opacity(0.76)
    }
  }
}
extension Risiko {
  var color: Color {
    switch self {
    case .niedrig: .bsGreen
    case .mittel: .bsAmber
    case .hoch, .kritisch: .bsRed
    }
  }
}
extension AdSenseStatus {
  var color: Color {
    switch self {
    case .aktiv: .bsGreen
    case .einrichtung: .bsBlue
    case .aktionErforderlich: .bsAmber
    case .pausiert: .bsRed
    case .nichtEingerichtet: .bsMuted
    }
  }
}
extension Int {
  var kompakt: String {
    let n = Double(self)
    if n >= 1_000_000 { return String(format: "%.1f Mio.", n / 1_000_000) }
    if n >= 1_000 { return String(format: "%.1f Tsd.", n / 1_000) }
    return "\(self)"
  }
}
extension Double { var euro: String { String(format: "%.2f €", self) } }
