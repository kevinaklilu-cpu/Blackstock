import Foundation

enum BlackstockRelease {
  static let fallbackVersion = "11.1.0"
  static let fallbackBuild = "1110"

  static var version: String {
    Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? fallbackVersion
  }

  static var build: String {
    Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? fallbackBuild
  }

  static var display: String { "Blackstock \(version) (\(build))" }
}
