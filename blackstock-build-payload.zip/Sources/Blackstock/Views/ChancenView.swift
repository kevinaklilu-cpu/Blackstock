import Charts
import SwiftUI

private enum ChancenSortierung: String, CaseIterable, Identifiable {
  case opportunity = "Opportunity"
  case trend = "Trend"
  case nachfrage = "Nachfrage"
  case contentGap = "Content-Lücke"
  case momentum = "Momentum"
  var id: String { rawValue }

  func wert(_ chance: Chance) -> Double {
    switch self {
    case .opportunity: chance.trendScore * chance.konfidenz * (0.72 + chance.contentGapScore / 220)
    case .trend: chance.trendScore
    case .nachfrage: chance.nachfrageScore
    case .contentGap: chance.contentGapScore
    case .momentum: chance.momentum
    }
  }
}

struct ChancenView: View {
  @EnvironmentObject private var store: AppStore
  @State private var selectedChannelID: UUID?
  @State private var minTrend = 0.0
  @State private var nurBeobachtet = false
  @State private var risikoFilter: Risiko?
  @State private var suche = ""
  @State private var sortierung: ChancenSortierung = .opportunity
  @State private var category: TopicCategory?
  @State private var formatFilter: VideoFormat?
  @State private var phaseFilter: TrendPhase?

  private var selectedProfile: ChannelContentProfile? {
    selectedChannelID.map(store.channelProfile(for:))
  }

  private var gefiltert: [Chance] {
    let query = suche.trimmingCharacters(in: .whitespacesAndNewlines)
      .folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
    return store.chancen.filter { chance in
      let haystack = "\(chance.titel) \(chance.thema) \(chance.begruendung)"
        .folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
      let inferred = TopicTaxonomy.infer(from: haystack)
      let channelFit: Bool = {
        guard let profile = selectedProfile else { return true }
        guard !profile.effectiveSearchTerms.isEmpty else { return true }
        let terms = profile.effectiveSearchTerms.map {
          $0.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
        }
        let excluded = profile.excludedTopics.map {
          $0.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
        }
        return terms.contains(where: haystack.contains) && !excluded.contains(where: haystack.contains)
      }()
      return (query.isEmpty || haystack.contains(query))
        && chance.trendScore >= minTrend
        && (!nurBeobachtet || chance.beobachtet)
        && (risikoFilter == nil || chance.risiko == risikoFilter)
        && (category.map { inferred == $0 || chance.thema.localizedCaseInsensitiveContains($0.rawValue) } ?? true)
        && (formatFilter.map { chance.empfohleneFormate.contains($0) } ?? true)
        && (phaseFilter.map { chance.phase == $0 } ?? true)
        && channelFit
    }.sorted { sortierung.wert($0) > sortierung.wert($1) }
  }

  private var discoveryTerms: [String] {
    var terms: [String] = []
    if let profile = selectedProfile { terms += profile.effectiveSearchTerms }
    if let category { terms += category.searchTerms }
    if terms.isEmpty { terms = TopicTaxonomy.stableCategories.flatMap(\.searchTerms) }
    let uniqueTerms: [String] = Array(Set(terms))
    return Array(uniqueTerms.prefix(24))
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 18) {
        PageHeader(
          titel: "Trends",
          untertitel: "Kanalbezogene YouTube-Signale mit nachvollziehbarer Relevanz – getrennt von tatsächlich nutzbaren Schnittquellen.",
          trailing: AnyView(actions))

        channelAndCategoryBar

        if store.chancen.isEmpty {
          EmptyState(
            symbol: "scope", titel: "Noch keine Trends analysiert",
            text: store.googleZugaenge.isEmpty
              ? "Verbinde zuerst Google/YouTube. Danach bewertet Blackstock Trends anhand des Kanalprofils."
              : "Starte eine Analyse. YouTube-Videos bleiben dabei Trendreferenzen und werden nicht automatisch als Schnittmaterial heruntergeladen.",
            button: store.googleZugaenge.isEmpty ? "Zu Kanäle" : "Trends analysieren"
          ) {
            if store.googleZugaenge.isEmpty { store.ausgewaehltesZiel = .konten }
            else { Task { await refresh() } }
          }
        } else {
          HStack(alignment: .top, spacing: 14) {
            marketMap
            topSignals
          }
          filterBar
          LazyVStack(spacing: 10) {
            ForEach(gefiltert) { chance in ChanceRow(chance: chance) }
          }
          if gefiltert.isEmpty {
            Text("Für diese Kanal-/Filterkombination wurden keine passenden Chancen gefunden.")
              .font(.system(size: 11)).foregroundStyle(Color.bsMuted)
              .frame(maxWidth: .infinity).padding(24)
          }
        }
      }
      .padding(26)
    }
  }

  private var actions: some View {
    Button { Task { await refresh() } } label: {
      Label(store.istBeschaeftigt ? "Analysiere …" : "Live-Signale aktualisieren", systemImage: "arrow.clockwise")
    }
    .buttonStyle(.borderedProminent).tint(Color.bsRed).foregroundStyle(.white)
    .disabled(store.istBeschaeftigt || store.googleZugaenge.isEmpty)
  }

  private var channelAndCategoryBar: some View {
    HStack(spacing: 12) {
      Picker("Kanal", selection: $selectedChannelID) {
        Text("Alle / Markt").tag(UUID?.none)
        ForEach(store.liveKanaele) { channel in Text(channel.name).tag(Optional(channel.id)) }
      }
      .frame(width: 230)
      Picker("Kategorie", selection: $category) {
        Text("Alle Kategorien").tag(TopicCategory?.none)
        ForEach(TopicTaxonomy.stableCategories) { item in Text(item.rawValue).tag(Optional(item)) }
      }
      .frame(width: 220)
      if let profile = selectedProfile {
        Text(profile.effectiveSearchTerms.isEmpty ? "Noch kein Content-Profil" : profile.effectiveSearchTerms.prefix(4).joined(separator: " · "))
          .font(.system(size: 9.5)).foregroundStyle(Color.bsMuted).lineLimit(1)
      }
      Spacer()
      Text("SPORT immer verfügbar")
        .font(.system(size: 8.5, weight: .semibold)).foregroundStyle(Color.bsMuted)
    }
    .padding(11).background(Color.bsSurface)
    .clipShape(RoundedRectangle(cornerRadius: 11))
    .overlay(RoundedRectangle(cornerRadius: 11).stroke(Color.bsBorder))
  }

  private func refresh() async {
    _ = await store.chancenAktualisieren(zusaetzlicheMarktThemen: discoveryTerms)
  }

  private var marketMap: some View {
    VStack(alignment: .leading, spacing: 13) {
      AbschnittTitel(
        titel: "Nachfrage vs. Wettbewerb",
        untertitel: "Hohe Nachfrage bei niedrigerer Sättigung ist besonders interessant")
      Chart(gefiltert.prefix(20)) { chance in
        PointMark(
          x: .value("Wettbewerb", chance.wettbewerbScore),
          y: .value("Nachfrage", chance.nachfrageScore))
          .symbolSize(max(70, chance.trendScore * 2.2))
          .foregroundStyle(by: .value("Phase", chance.phase.rawValue))
          .annotation(position: .top, spacing: 4) {
            Text(String(chance.thema.prefix(16))).font(.system(size: 8)).foregroundStyle(Color.bsMuted)
          }
      }
      .chartXScale(domain: 0...100).chartYScale(domain: 0...100)
      .chartXAxisLabel("Wettbewerb").chartYAxisLabel("Nachfrage")
      .frame(height: 240)
    }
    .blackstockCard().frame(maxWidth: .infinity)
  }

  private var topSignals: some View {
    VStack(alignment: .leading, spacing: 14) {
      AbschnittTitel(titel: "Markt jetzt", untertitel: "Stärkste Signale")
      ForEach(gefiltert.prefix(5)) { chance in
        HStack(spacing: 10) {
          VStack(alignment: .leading, spacing: 3) {
            Text(chance.thema).font(.system(size: 10.5, weight: .semibold)).foregroundStyle(Color.bsText)
            Text(chance.phase.rawValue).font(.system(size: 8.5)).foregroundStyle(Color.bsMuted)
          }
          Spacer()
          Text("\(Int(chance.trendScore))")
            .font(.system(size: 14, weight: .semibold, design: .rounded)).foregroundStyle(Color.bsGreen)
        }
        if chance.id != gefiltert.prefix(5).last?.id { Divider().overlay(Color.bsBorder) }
      }
    }
    .blackstockCard().frame(width: 300)
  }

  private var filterBar: some View {
    VStack(spacing: 10) {
      HStack(spacing: 10) {
        Image(systemName: "magnifyingglass").foregroundStyle(Color.bsMuted)
        TextField("Trends und Signale durchsuchen", text: $suche).textFieldStyle(.plain)
        Divider().frame(height: 20)
        Picker("Sortierung", selection: $sortierung) {
          ForEach(ChancenSortierung.allCases) { Text($0.rawValue).tag($0) }
        }
        .frame(width: 160)
        Text("\(gefiltert.count) von \(store.chancen.count)").font(.system(size: 9.5)).foregroundStyle(Color.bsMuted)
      }
      Divider().overlay(Color.bsBorder)
      HStack(spacing: 12) {
        Picker("Mindesttrend", selection: $minTrend) {
          Text("Alle").tag(0.0); Text("70+").tag(70.0); Text("85+").tag(85.0); Text("90+").tag(90.0)
        }.frame(width: 120)
        Picker("Risiko", selection: $risikoFilter) {
          Text("Alle Risiken").tag(Risiko?.none)
          Text("Niedrig").tag(Optional(Risiko.niedrig)); Text("Mittel").tag(Optional(Risiko.mittel)); Text("Hoch").tag(Optional(Risiko.hoch))
        }.frame(width: 145)
        Picker("Format", selection: $formatFilter) {
          Text("Alle Formate").tag(VideoFormat?.none)
          ForEach(VideoFormat.allCases, id: \.self) { Text($0.rawValue).tag(Optional($0)) }
        }.frame(width: 145)
        Picker("Phase", selection: $phaseFilter) {
          Text("Alle Phasen").tag(TrendPhase?.none)
          ForEach(TrendPhase.allCases) { Text($0.rawValue).tag(Optional($0)) }
        }.frame(width: 145)
        Toggle("Nur beobachtete", isOn: $nurBeobachtet).toggleStyle(.checkbox).font(.system(size: 10.5))
        Spacer()
        if !suche.isEmpty || minTrend > 0 || risikoFilter != nil || formatFilter != nil || phaseFilter != nil || nurBeobachtet {
          Button("Zurücksetzen") {
            suche = ""; minTrend = 0; risikoFilter = nil; formatFilter = nil; phaseFilter = nil; nurBeobachtet = false
          }.buttonStyle(.borderless).font(.system(size: 10))
        }
      }
    }
    .padding(11).background(Color.bsSurface)
    .clipShape(RoundedRectangle(cornerRadius: 11))
    .overlay(RoundedRectangle(cornerRadius: 11).stroke(Color.bsBorder))
  }
}

private struct ChanceRow: View {
  @EnvironmentObject private var store: AppStore
  let chance: Chance
  @State private var expanded = false

  var body: some View {
    VStack(alignment: .leading, spacing: 14) {
      HStack(alignment: .top, spacing: 14) {
        VStack(alignment: .leading, spacing: 6) {
          HStack(spacing: 8) {
            Text(chance.phase.rawValue.uppercased()).font(.system(size: 8, weight: .bold)).tracking(0.9).foregroundStyle(Color.bsGreen)
            DatenquelleBadge(quelle: chance.datenherkunft)
          }
          Text(chance.titel).font(.system(size: 14.5, weight: .semibold)).foregroundStyle(Color.bsText)
          Text(chance.begruendung).font(.system(size: 10)).foregroundStyle(Color.bsMuted).lineSpacing(3).lineLimit(expanded ? nil : 2)
        }
        Spacer()
        ScoreRing(wert: chance.trendScore, label: "Trend")
      }

      HStack(spacing: 24) {
        MetricCell(label: "Momentum", value: signed(chance.momentum) + " %", accent: chance.momentum >= 0 ? .bsGreen : .bsRed)
        MetricCell(label: "Nachfrage", value: "\(Int(chance.nachfrageScore))")
        MetricCell(label: "Wettbewerb", value: "\(Int(chance.wettbewerbScore))")
        MetricCell(label: "Content-Lücke", value: "\(Int(chance.contentGapScore))")
        MetricCell(label: "Signale", value: "\(chance.quellenAnzahl)")
        Spacer()
      }

      if expanded {
        HStack(alignment: .top, spacing: 14) {
          VStack(alignment: .leading, spacing: 9) {
            Text("WARUM EINE CHANCE?").font(.system(size: 8.5, weight: .bold)).tracking(0.8).foregroundStyle(Color.bsMuted)
            Text(chance.begruendung).font(.system(size: 10)).foregroundStyle(Color.bsText).lineSpacing(3)
            if !chance.trendVerlauf.isEmpty {
              Chart(chance.trendVerlauf) { point in
                LineMark(x: .value("Zeit", point.zeit), y: .value("Signal", point.wert))
                  .interpolationMethod(.catmullRom).foregroundStyle(Color.bsGreen)
              }.chartYAxis(.hidden).frame(height: 90)
            }
          }.frame(maxWidth: .infinity)
          VStack(alignment: .leading, spacing: 8) {
            Text("SIGNALBASIS").font(.system(size: 8.5, weight: .bold)).tracking(0.8).foregroundStyle(Color.bsMuted)
            detail("Quellen", "\(chance.quellenAnzahl)")
            detail("Primärsignale", "\(chance.primaerquellen)")
            detail("Widersprüche", "\(chance.widersprueche)")
            detail("Trendfenster", "~\(Int(chance.trendHalbwertszeitStunden)) h")
            Text("Trendvideo ≠ Schnittquelle")
              .font(.system(size: 8.5, weight: .semibold)).foregroundStyle(Color.bsAmber).padding(.top, 4)
          }.frame(width: 220)
        }
      }

      Divider().overlay(Color.bsBorder)
      HStack {
        VertrauenBadge(konfidenz: chance.konfidenz)
        StatusPunkt(text: "Risiko \(chance.risiko.rawValue)", farbe: chance.risiko.color)
        Spacer()
        Button(expanded ? "Weniger" : "Warum?") { withAnimation(.easeOut(duration: 0.15)) { expanded.toggle() } }
          .buttonStyle(.bordered)
        Button(chance.beobachtet ? "Nicht mehr beobachten" : "Beobachten") { store.chanceBeobachten(chance.id) }
          .buttonStyle(.bordered)
        Button {
          Task { _ = await store.v11ProduktionStartenAusChance(chance, mode: .automatic) }
        } label: {
          Label("Video erstellen", systemImage: "film.stack")
        }
        .buttonStyle(.borderedProminent).tint(Color.bsRed).foregroundStyle(.white)
        Menu {
          Button("Auto") { Task { _ = await store.v11ProduktionStartenAusChance(chance, mode: .automatic) } }
          Button("Ein Hauptvideo") { Task { _ = await store.v11ProduktionStartenAusChance(chance, mode: .singleSource) } }
          Button("Remix") { Task { _ = await store.v11ProduktionStartenAusChance(chance, mode: .remix) } }
          Button("Longform") { Task { _ = await store.v11ProduktionStartenAusChance(chance, mode: .longform) } }
          Button("Short") { Task { _ = await store.v11ProduktionStartenAusChance(chance, mode: .short) } }
          Button("Live Playout") { Task { _ = await store.v11ProduktionStartenAusChance(chance, mode: .live) } }
        } label: { Image(systemName: "chevron.down") }
        .menuStyle(.borderlessButton).frame(width: 24)
      }
    }
    .blackstockCard()
  }

  private func signed(_ n: Double) -> String { n >= 0 ? "+\(Int(n))" : "\(Int(n))" }
  private func detail(_ label: String, _ value: String) -> some View {
    HStack {
      Text(label).font(.system(size: 9)).foregroundStyle(Color.bsMuted)
      Spacer()
      Text(value).font(.system(size: 9.5, weight: .semibold)).foregroundStyle(Color.bsText)
    }
  }
}
