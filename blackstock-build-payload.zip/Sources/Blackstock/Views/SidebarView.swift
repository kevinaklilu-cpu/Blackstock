import SwiftUI

struct SidebarView: View {
  @EnvironmentObject private var store: AppStore

  private let primaryTargets: [Navigationsziel] = [
    .command, .chancen, .produktionen, .veroeffentlicht, .wachstum, .konten,
  ]

  private let secondaryTargets: [Navigationsziel] = [.einstellungen]

  var body: some View {
    ZStack {
      Color.bsSidebar.ignoresSafeArea()
      VStack(alignment: .leading, spacing: 12) {
        brand

        ScrollView(showsIndicators: false) {
          VStack(spacing: 4) {
            ForEach(primaryTargets) { target in navButton(target) }
            Divider().overlay(Color.bsBorder).padding(.vertical, 7)
            ForEach(secondaryTargets) { target in navButton(target) }
          }
        }

        Spacer()
        if store.liveKanaele.isEmpty {
          startCard
        } else {
          networkFooter
        }
      }
      .padding(.horizontal, 12)
      .padding(.vertical, 14)
    }
    .overlay(alignment: .trailing) {
      Rectangle().fill(Color.bsBorder).frame(width: 1)
    }
  }

  private var brand: some View {
    HStack(spacing: 11) {
      BlackstockMark(size: 38)
      Text("BLACKSTOCK")
        .font(.system(size: 16, weight: .bold))
        .foregroundStyle(Color.bsText)
      Spacer()
    }
    .padding(.horizontal, 8)
    .padding(.vertical, 7)
  }

  private func navButton(_ target: Navigationsziel) -> some View {
    Button {
      withAnimation(.easeOut(duration: 0.12)) {
        store.ausgewaehltesZiel = target
      }
      store.speichern()
    } label: {
      HStack(spacing: 14) {
        Image(systemName: target.symbol)
          .font(.system(size: 16, weight: .medium))
          .frame(width: 24)
        Text(target.titel)
          .font(.system(size: 13, weight: store.ausgewaehltesZiel == target ? .semibold : .regular))
        Spacer()
        if badgeCount(for: target) > 0 {
          Text("\(badgeCount(for: target))")
            .font(.system(size: 9, weight: .bold))
            .foregroundStyle(store.ausgewaehltesZiel == target ? Color.bsRed : Color.bsMuted)
        }
      }
      .foregroundStyle(store.ausgewaehltesZiel == target ? Color.bsRed : Color.bsText)
      .padding(.horizontal, 13)
      .frame(height: 44)
      .background(
        RoundedRectangle(cornerRadius: 10, style: .continuous)
          .fill(store.ausgewaehltesZiel == target ? Color.bsRed.opacity(0.10) : Color.clear)
      )
    }
    .buttonStyle(.plain)
  }

  private func badgeCount(for target: Navigationsziel) -> Int {
    switch target {
    case .chancen: store.chancen.filter { !$0.beobachtet }.count
    case .produktionen: store.aktiveProduktionen.count
    case .konten: store.kanalPlaene.filter { $0.status != .verbunden }.count
    default: 0
    }
  }

  private var startCard: some View {
    VStack(alignment: .leading, spacing: 10) {
      Text("Dein Netzwerk starten")
        .font(.system(size: 12.5, weight: .semibold))
        .foregroundStyle(Color.bsText)
      Text("Plane deinen ersten Blackstock-Kanal und verbinde danach YouTube.")
        .font(.system(size: 10.5))
        .foregroundStyle(Color.bsMuted)
        .lineSpacing(2)
      Button("Kanal einrichten") { store.ausgewaehltesZiel = .konten }
        .buttonStyle(.borderedProminent)
        .tint(Color.bsRed)
        .foregroundStyle(.white)
        .controlSize(.small)
    }
    .padding(14)
    .background(Color.bsSurface2)
    .clipShape(RoundedRectangle(cornerRadius: 12))
  }

  private var networkFooter: some View {
    HStack(spacing: 9) {
      BlackstockMark(size: 28)
      VStack(alignment: .leading, spacing: 1) {
        Text("Blackstock")
          .font(.system(size: 11, weight: .semibold))
          .foregroundStyle(Color.bsText)
        Text("\(store.liveKanaele.count) Kanal\(store.liveKanaele.count == 1 ? "" : "e") verbunden")
          .font(.system(size: 9.5))
          .foregroundStyle(Color.bsMuted)
      }
      Spacer()
      Circle().fill(Color.bsGreen).frame(width: 7, height: 7)
    }
    .padding(.horizontal, 8)
    .padding(.vertical, 7)
  }
}
