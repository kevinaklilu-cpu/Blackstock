import SwiftUI

struct ProduktionenView: View {
  @EnvironmentObject private var store: AppStore
  @State private var pendingDelete: Produktion?
  @State private var phase: ProductionPhase?

  private var liste: [Produktion] {
    store.produktionen.filter { production in
      guard let phase else { return true }
      return store.v11Produktion(for: production.id).phase == phase
    }.sorted { $0.erstelltAm > $1.erstelltAm }
  }

  private var selected: Produktion? {
    let id = store.ausgewaehlteProduktionID ?? liste.first?.id
    return id.flatMap { wanted in store.produktionen.first(where: { $0.id == wanted }) }
  }

  var body: some View {
    HStack(spacing: 0) {
      VStack(alignment: .leading, spacing: 0) {
        header
        Divider().overlay(Color.bsBorder)
        if liste.isEmpty {
          EmptyState(
            symbol: "film.stack",
            titel: "Keine Produktionen",
            text: "Starte in Trends eine neue Existing-Media-Produktion. YouTube-Trendvideos bleiben Referenzen; geschnitten werden nur freigegebene Quellen.",
            button: "Trends öffnen") { store.ausgewaehltesZiel = .chancen }
            .padding(20)
        } else {
          ScrollView {
            LazyVStack(spacing: 5) { ForEach(liste) { row($0) } }.padding(8)
          }
        }
        Divider().overlay(Color.bsBorder)
        HStack(spacing: 18) {
          metric("Aktiv", store.produktionen.filter { ![.published, .failed].contains(store.v11Produktion(for: $0.id).phase) }.count)
          metric("Review", store.produktionen.filter { store.v11Produktion(for: $0.id).phase == .review }.count)
          metric("Fehler", store.produktionen.filter { store.v11Produktion(for: $0.id).phase == .failed }.count)
        }.padding(12)
      }
      .frame(minWidth: 330, idealWidth: 370, maxWidth: 410)
      .background(Color.bsSidebar)

      Rectangle().fill(Color.bsBorder).frame(width: 1)
      if let selected {
        ProduktionsDetailView(produktionID: selected.id)
          .frame(maxWidth: .infinity, maxHeight: .infinity)
      } else {
        EmptyState(
          symbol: "scissors",
          titel: "Produktionsqueue ist leer",
          text: "Wähle einen kanalrelevanten Trend und starte eine Produktion.",
          button: "Trends öffnen") { store.ausgewaehltesZiel = .chancen }
          .padding(28).frame(maxWidth: .infinity, maxHeight: .infinity)
      }
    }
    .onAppear { if store.ausgewaehlteProduktionID == nil { store.ausgewaehlteProduktionID = liste.first?.id } }
  }

  private var header: some View {
    VStack(alignment: .leading, spacing: 12) {
      HStack {
        VStack(alignment: .leading, spacing: 3) {
          Text("Produktionen").font(.system(size: 22, weight: .semibold)).foregroundStyle(Color.bsText)
          Text("Remix, Review & Upload Queue").font(.system(size: 10)).foregroundStyle(Color.bsMuted)
        }
        Spacer()
        Button { store.ausgewaehltesZiel = .chancen } label: { Label("Neu", systemImage: "plus") }
          .buttonStyle(.borderedProminent).tint(Color.bsRed).foregroundStyle(.white)
      }
      Picker("Phase", selection: $phase) {
        Text("Alle Phasen").tag(ProductionPhase?.none)
        ForEach(ProductionPhase.allCases) { Text($0.rawValue).tag(Optional($0)) }
      }.labelsHidden()
    }.padding(18)
    .alert("Projekt wirklich löschen?", isPresented: Binding(
      get: { pendingDelete != nil },
      set: { if !$0 { pendingDelete = nil } })) {
        Button("Abbrechen", role: .cancel) { pendingDelete = nil }
        Button("Löschen", role: .destructive) {
          if let item = pendingDelete { store.produktionLoeschen(item.id, erzeugteDateienLoeschen: true) }
          pendingDelete = nil
        }
      } message: {
        Text("Nur von Blackstock erzeugte Arbeitsdateien werden entfernt. Importierte Originalmedien bleiben erhalten.")
      }

  }

  private func row(_ p: Produktion) -> some View {
    let state = store.v11Produktion(for: p.id)
    let ready = store.bereitCheck(for: p.id)
    let selected = store.ausgewaehlteProduktionID == p.id
    return Button { store.ausgewaehlteProduktionID = p.id } label: {
      VStack(alignment: .leading, spacing: 7) {
        HStack(alignment: .top, spacing: 9) {
          Image(systemName: p.format == .short ? "rectangle.portrait.fill" : (p.format == .livestream ? "dot.radiowaves.left.and.right" : "rectangle.fill"))
            .frame(width: 26, height: 26).foregroundStyle(selected ? Color.bsRed : Color.bsMuted)
          VStack(alignment: .leading, spacing: 3) {
            Text(p.arbeitstitel).font(.system(size: 10.5, weight: .semibold)).foregroundStyle(Color.bsText).lineLimit(2)
            Text("\(store.kanalName(fuer: p.kanalID)) · \(state.mode.rawValue)")
              .font(.system(size: 8.5)).foregroundStyle(Color.bsMuted)
          }
          Spacer()
          Text(state.phase.rawValue).font(.system(size: 8.5, weight: .semibold))
            .foregroundStyle(state.phase == .failed ? Color.bsRed : Color.bsText)
        }
        BlackstockFortschritt(wert: state.progress, farbe: state.phase == .failed ? .bsRed : .bsRed)
        HStack {
          Text(state.checkpoint?.detail ?? p.naechsterSchritt).lineLimit(1)
          Spacer()
          if ready.state == .ready { Text("Bereit") }
          else if !ready.issues.isEmpty { Text("\(ready.issues.count) Problem\(ready.issues.count == 1 ? "" : "e")") }
        }.font(.system(size: 8.2)).foregroundStyle(Color.bsMuted)
      }
      .padding(10)
      .background(RoundedRectangle(cornerRadius: 10).fill(selected ? Color.bsSurface2 : Color.clear))
    }
    .buttonStyle(.plain)
    .contextMenu {
      Button("Projekt löschen", role: .destructive) { pendingDelete = p }
    }
  }

  private func metric(_ label: String, _ value: Int) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text("\(value)").font(.system(size: 13, weight: .semibold)).foregroundStyle(Color.bsText)
      Text(label).font(.system(size: 8)).foregroundStyle(Color.bsMuted)
    }
  }
}
