import AVKit
import SwiftUI

struct ProduktionsDetailView: View {
  @EnvironmentObject private var store: AppStore
  let produktionID: UUID

  @State private var sourceURL = ""
  @State private var sourceTitle = ""
  @State private var sourceCreator = ""
  @State private var sourceLicense = ""
  @State private var sourceTranscript = ""
  @State private var sourceRights: RightsStatus = .owned
  @State private var sourceCommercialUse = false

  private var index: Int? { store.produktionen.firstIndex { $0.id == produktionID } }
  private var production: Produktion? { index.map { store.produktionen[$0] } }
  private var state: ProductionV11State { store.v11Produktion(for: produktionID) }
  private var sources: [SourceAsset] { store.v11Sources(for: produktionID) }
  private var ready: ReadyCheck { store.bereitCheck(for: produktionID) }

  var body: some View {
    ScrollView {
      if let production {
        VStack(alignment: .leading, spacing: 18) {
          HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 5) {
              Text(production.arbeitstitel).font(.system(size: 24, weight: .semibold)).foregroundStyle(Color.bsText)
              Text("\(store.kanalName(fuer: production.kanalID)) · \(production.format.rawValue) · \(state.phase.rawValue)")
                .font(.system(size: 10.5)).foregroundStyle(Color.bsMuted)
            }
            Spacer()
            Picker("Modus", selection: Binding(
              get: { state.mode },
              set: { store.v11ProduktionsmodusSetzen(produktionID, modus: $0) })) {
                ForEach(ProductionModeV11.allCases) { Text($0.rawValue).tag($0) }
              }.frame(width: 180)
          }

          pipelineCard(production)
          sourcesCard
          if let timeline = state.timeline { timelineCard(timeline) }
          if production.lokaleDatei != nil { reviewCard(production) }
          metadataCard(production)
          readyCard(production)
        }.padding(24)
      }
    }
  }

  private func pipelineCard(_ p: Produktion) -> some View {
    VStack(alignment: .leading, spacing: 12) {
      AbschnittTitel(titel: "Produktionspipeline", untertitel: "Source Discovery → Analyse → Timeline → Render → Metadata → Review/Upload")
      BlackstockFortschritt(wert: state.progress, farbe: state.phase == .failed ? .bsRed : .bsRed)
      HStack {
        StatusPunkt(text: state.phase.rawValue, farbe: state.phase == .failed ? .bsRed : .bsGreen)
        Text(state.checkpoint?.detail ?? p.naechsterSchritt).font(.system(size: 9.5)).foregroundStyle(Color.bsMuted)
        Spacer()
        Button(
          state.phase == .failed ? "Erneut versuchen"
            : ((p.format == .livestream || state.mode == .live) ? "Live Playout starten" : "Produktion fortsetzen")
        ) {
          Task { await store.v11ProduktionFortsetzen(produktionID) }
        }
        .buttonStyle(.borderedProminent).tint(Color.bsRed).foregroundStyle(.white)
        .disabled(store.istBeschaeftigt || sources.isEmpty)
      }
      if p.format == .livestream || state.mode == .live {
        HStack(spacing: 8) {
          Image(systemName: LivePlayoutService.shared.isAvailable ? "dot.radiowaves.left.and.right" : "exclamationmark.triangle")
            .foregroundStyle(LivePlayoutService.shared.isAvailable ? Color.bsGreen : Color.bsAmber)
          Text(
            LivePlayoutService.shared.isAvailable
              ? "Lokaler FFmpeg-Encoder erkannt. „Live“ wird erst nach tatsächlich gesendeten Frames gesetzt."
              : "Für echtes RTMP-Playout FFmpeg lokal installieren (z. B. brew install ffmpeg).")
            .font(.system(size: 9)).foregroundStyle(Color.bsMuted)
          Spacer()
          if LivePlayoutService.shared.isRunning(productionID: produktionID) {
            Button("Live Playout stoppen", role: .destructive) {
              store.v11LivestreamStoppen(produktionID)
            }.buttonStyle(.bordered)
          }
        }
      }
      if let error = state.lastError, !error.isEmpty {
        Text(error).font(.system(size: 9.5)).foregroundStyle(Color.bsRed).padding(9)
          .frame(maxWidth: .infinity, alignment: .leading).background(Color.bsRed.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 8))
      }
    }.blackstockCard()
  }

  private var sourcesCard: some View {
    VStack(alignment: .leading, spacing: 12) {
      AbschnittTitel(
        titel: "Quellen",
        untertitel: "Nur direkte HTTPS-Medien mit ausdrücklich geklärten Rechten. YouTube-Trendvideos werden nicht heruntergeladen.")
      if sources.isEmpty {
        Text("Noch keine Schnittquelle. Füge eigenes oder eindeutig lizenziertes Remote-Material hinzu.")
          .font(.system(size: 10)).foregroundStyle(Color.bsMuted)
      } else {
        ForEach(sources) { source in
          HStack(alignment: .top, spacing: 10) {
            Image(systemName: source.canAutoPublish ? "checkmark.shield.fill" : "exclamationmark.shield.fill")
              .foregroundStyle(source.canAutoPublish ? Color.bsGreen : Color.bsRed)
            VStack(alignment: .leading, spacing: 3) {
              Text(source.title).font(.system(size: 10.5, weight: .semibold)).foregroundStyle(Color.bsText)
              Text("\(source.rightsStatus.rawValue) · \(source.licenseType ?? "keine Lizenzangabe")")
                .font(.system(size: 8.5)).foregroundStyle(Color.bsMuted)
              if let duration = source.duration { Text(String(format: "%.0f s · %@", duration, source.provider.rawValue)).font(.system(size: 8)).foregroundStyle(Color.bsMuted2) }
            }
            Spacer()
            Button(role: .destructive) { store.v11SourceEntfernen(source.id, aus: produktionID) } label: { Image(systemName: "trash") }.buttonStyle(.borderless)
          }.padding(9).background(Color.bsSurface2).clipShape(RoundedRectangle(cornerRadius: 9))
        }
      }

      Divider().overlay(Color.bsBorder)
      Text("REMOTE-QUELLE HINZUFÜGEN").font(.system(size: 8.5, weight: .bold)).tracking(1).foregroundStyle(Color.bsMuted)
      TextField("https://…/video.mp4", text: $sourceURL).textFieldStyle(.roundedBorder)
      HStack {
        TextField("Titel", text: $sourceTitle).textFieldStyle(.roundedBorder)
        TextField("Urheber / Creator", text: $sourceCreator).textFieldStyle(.roundedBorder)
      }
      HStack {
        Picker("Rechte", selection: $sourceRights) { ForEach(RightsStatus.allCases) { Text($0.rawValue).tag($0) } }
        TextField(sourceRights == .owned ? "Eigentum wird dokumentiert" : "Lizenztyp / Vertrag", text: $sourceLicense)
          .textFieldStyle(.roundedBorder).disabled(sourceRights == .owned)
      }
      if sourceRights == .licensed || sourceRights == .creativeCommonsCompatible {
        Toggle("Kommerzielle Nutzung ist durch die Lizenz ausdrücklich erlaubt", isOn: $sourceCommercialUse)
          .font(.system(size: 9.5))
      }
      TextField("Optional: Transkript / Inhaltsbeschreibung für intelligentes Clipping", text: $sourceTranscript, axis: .vertical)
        .textFieldStyle(.roundedBorder).lineLimit(2...5)
      Button("Quelle prüfen & hinzufügen") {
        do {
          _ = try store.v11DirectSourceHinzufuegen(
            zu: produktionID, urlString: sourceURL, title: sourceTitle,
            rights: sourceRights, licenseType: sourceLicense.isEmpty ? nil : sourceLicense,
            creator: sourceCreator.isEmpty ? nil : sourceCreator,
            transcript: sourceTranscript.isEmpty ? nil : sourceTranscript,
            commercialUseAllowed: sourceCommercialUse)
          sourceURL = ""; sourceTitle = ""; sourceCreator = ""; sourceLicense = ""; sourceTranscript = ""; sourceCommercialUse = false
        } catch { store.meldung = error.localizedDescription }
      }.buttonStyle(.bordered)
    }.blackstockCard()
  }

  private func timelineCard(_ timeline: RemixTimeline) -> some View {
    VStack(alignment: .leading, spacing: 11) {
      AbschnittTitel(titel: "Remix-Timeline", untertitel: "\(timeline.format.rawValue) · \(Int(timeline.duration)) Sekunden · \(timeline.segments.count) Segmente")
      ForEach(timeline.segments.sorted(by: { $0.order < $1.order })) { segment in
        HStack {
          Text("\(segment.order + 1)").font(.system(size: 9, weight: .bold)).frame(width: 22)
          Text(sources.first(where: { $0.id == segment.sourceAssetID })?.title ?? "Quelle")
            .font(.system(size: 9.5, weight: .medium)).lineLimit(1)
          Spacer()
          Text(String(format: "%.1f–%.1f s", segment.startTime, segment.endTime)).font(.system(size: 8.5)).monospacedDigit()
          Text(segment.cropMode.rawValue).font(.system(size: 8.5)).foregroundStyle(Color.bsMuted)
        }.padding(.vertical, 3)
      }
    }.blackstockCard()
  }

  private func reviewCard(_ p: Produktion) -> some View {
    VStack(alignment: .leading, spacing: 12) {
      AbschnittTitel(titel: "Review", untertitel: "Der tatsächliche finale Render – nicht eine Vorschau aus Platzhalterdaten")
      if let path = p.lokaleDatei, FileManager.default.fileExists(atPath: path) {
        VideoPlayer(player: AVPlayer(url: URL(fileURLWithPath: path))).frame(minHeight: 280)
          .clipShape(RoundedRectangle(cornerRadius: 12))
      }
    }.blackstockCard()
  }

  private func metadataCard(_ p: Produktion) -> some View {
    VStack(alignment: .leading, spacing: 10) {
      AbschnittTitel(titel: "Finale Metadaten", untertitel: "Werden nach der tatsächlichen Timeline erzeugt und bleiben editierbar")
      TextField("Titel", text: productionBinding(\.arbeitstitel)).textFieldStyle(.roundedBorder)
      TextField("Beschreibung", text: optionalProductionBinding(\.beschreibung), axis: .vertical)
        .textFieldStyle(.roundedBorder).lineLimit(4...10)
      Text("Tags: \((p.tags ?? []).joined(separator: ", "))").font(.system(size: 9)).foregroundStyle(Color.bsMuted)
    }.blackstockCard()
  }

  private func readyCard(_ p: Produktion) -> some View {
    VStack(alignment: .leading, spacing: 11) {
      HStack {
        VStack(alignment: .leading, spacing: 3) {
          Text(ready.issues.isEmpty ? "Bereit zum Veröffentlichen" : "\(ready.issues.count) Problem\(ready.issues.count == 1 ? "" : "e")")
            .font(.system(size: 14, weight: .semibold)).foregroundStyle(Color.bsText)
          Text("Bereit-Check statt abstrakter Quality-Scores").font(.system(size: 9)).foregroundStyle(Color.bsMuted)
        }
        Spacer()
        StatusPunkt(text: ready.state.rawValue, farbe: ready.issues.isEmpty ? .bsGreen : .bsAmber)
      }
      ForEach(ready.issues) { issue in
        Label(issue.message, systemImage: "exclamationmark.circle").font(.system(size: 9.5)).foregroundStyle(Color.bsMuted)
      }
      HStack {
        Spacer()
        if p.format == .livestream || state.mode == .live {
          if LivePlayoutService.shared.isRunning(productionID: produktionID) {
            Button("Live Playout stoppen", role: .destructive) {
              store.v11LivestreamStoppen(produktionID)
            }.buttonStyle(.bordered)
          } else {
            Button("Live Playout starten") {
              Task { await store.v11ProduktionFortsetzen(produktionID) }
            }.buttonStyle(.borderedProminent).tint(Color.bsRed).foregroundStyle(.white)
              .disabled(!sources.allSatisfy(\.canAutoPublish) || sources.isEmpty || store.istBeschaeftigt)
          }
        } else if ready.state == .reviewRequired && ready.issues.isEmpty {
          Button("Review freigeben") { store.v11ReviewFreigeben(produktionID) }
            .buttonStyle(.borderedProminent).tint(Color.bsRed).foregroundStyle(.white)
            .disabled(store.istBeschaeftigt)
        } else {
          Button(p.youtubeVideoID == nil ? "Auf YouTube hochladen" : "Upload abschließen") {
            Task { await store.produktionHochladen(produktionID) }
          }.buttonStyle(.borderedProminent).tint(Color.bsRed).foregroundStyle(.white)
            .disabled(!ready.canPublish || store.istBeschaeftigt)
        }
      }
    }.blackstockCard(elevated: true)
  }

  private func productionBinding(_ keyPath: WritableKeyPath<Produktion, String>) -> Binding<String> {
    Binding(get: { index.map { store.produktionen[$0][keyPath: keyPath] } ?? "" }, set: { value in
      guard let i = index else { return }; store.produktionen[i][keyPath: keyPath] = value; store.speichern()
    })
  }

  private func optionalProductionBinding(_ keyPath: WritableKeyPath<Produktion, String?>) -> Binding<String> {
    Binding(get: { index.flatMap { store.produktionen[$0][keyPath: keyPath] } ?? "" }, set: { value in
      guard let i = index else { return }; store.produktionen[i][keyPath: keyPath] = value; store.speichern()
    })
  }
}
