import SwiftUI

private enum SettingsSection: String, CaseIterable, Identifiable {
  case general = "Allgemein"
  case youtube = "YouTube & Kanäle"
  case production = "Produktion"
  case publishing = "Veröffentlichung"
  case sources = "Quellen"
  case advanced = "Erweitert"
  var id: String { rawValue }
}

struct EinstellungenView: View {
  @EnvironmentObject private var store: AppStore
  @State private var section: SettingsSection = .general
  @State private var showsReset = false
  @AppStorage("blackstock.appearance") private var appearanceRaw = BlackstockAppearance.system.rawValue
  @AppStorage("blackstock.language") private var language = "Deutsch"
  @AppStorage("blackstock.region") private var region = "DE"
  @AppStorage("blackstock.defaultFormat") private var defaultFormatRaw = VideoFormat.short.rawValue
  @AppStorage("blackstock.autoCaptions") private var autoCaptions = true
  @AppStorage("blackstock.reviewBeforePublish") private var reviewBeforePublish = true
  @AppStorage("blackstock.defaultPrivacy") private var defaultPrivacyRaw = ChannelPrivacy.privateVideo.rawValue
  @State private var manifestURL = ""

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 20) {
        PageHeader(titel: "Einstellungen", untertitel: "Wenige globale Standards mit tatsächlicher Wirkung; kanalbezogene Regeln bleiben beim jeweiligen Kanal.")
        Picker("Bereich", selection: $section) {
          ForEach(SettingsSection.allCases) { Text($0.rawValue).tag($0) }
        }.pickerStyle(.segmented).frame(maxWidth: 900)
        switch section {
        case .general: general
        case .youtube: youtube
        case .production: production
        case .publishing: publishing
        case .sources: sources
        case .advanced: advanced
        }
      }.padding(28)
    }
    .alert("Lokalen Blackstock-Zustand zurücksetzen?", isPresented: $showsReset) {
      Button("Abbrechen", role: .cancel) {}
      Button("Zurücksetzen", role: .destructive) { store.lokalenZustandZuruecksetzen() }
    } message: { Text("Diese Aktion löscht den lokalen Blackstock-Zustand und startet das Onboarding neu. OAuth-/Provider-Geheimnisse bleiben ausschließlich im Keychain verwaltet.") }
  }

  private var general: some View {
    VStack(alignment: .leading, spacing: 14) {
      AbschnittTitel(titel: "Allgemein")
      Picker("Erscheinungsbild", selection: $appearanceRaw) {
        ForEach(BlackstockAppearance.allCases) { Text($0.rawValue).tag($0.rawValue) }
      }.frame(maxWidth: 320)
      HStack {
        TextField("Sprache", text: $language).textFieldStyle(.roundedBorder)
        TextField("Region", text: $region).textFieldStyle(.roundedBorder)
      }.frame(maxWidth: 540)
      Text("Sprache und Region werden als Default für neu verbundene Kanalprofile verwendet; bestehende Profile bleiben kanalbezogen editierbar.")
        .font(.system(size: 9.5)).foregroundStyle(Color.bsMuted)
    }.blackstockCard(elevated: true)
  }

  private var youtube: some View {
    VStack(alignment: .leading, spacing: 14) {
      AbschnittTitel(titel: "YouTube & Kanäle", untertitel: "Accounts, konkrete Kanäle und granular erteilte Berechtigungen")
      HStack(spacing: 12) {
        MetricCell(label: "Google Accounts", value: "\(store.googleZugaenge.count)")
        MetricCell(label: "YouTube Kanäle", value: "\(store.v11State.channelConnections.filter(\.active).count)")
        MetricCell(label: "Revenue autorisiert", value: "\(store.v11State.channelProfiles.filter { $0.revenueAccess.canQueryMonetaryAnalytics }.count)")
      }
      HStack {
        Button("Google-Account verbinden") { Task { _ = await store.googleZugangHinzufuegen() } }.buttonStyle(.borderedProminent).tint(Color.bsRed).foregroundStyle(.white)
        Button("Kanäle & Berechtigungen öffnen") { store.ausgewaehltesZiel = .konten }.buttonStyle(.bordered)
        Button("Synchronisieren") { Task { await store.liveDatenAktualisieren() } }.buttonStyle(.bordered)
      }
    }.blackstockCard()
  }

  private var production: some View {
    VStack(alignment: .leading, spacing: 14) {
      AbschnittTitel(titel: "Produktion", untertitel: "Existing Media First ist der Standard; AI ist nur ein optionaler Fallback")
      Toggle("Existing Media First", isOn: Binding(get: { store.existingMediaFirst }, set: { store.existingMediaFirst = $0 })).toggleStyle(.switch)
      Picker("Standardformat", selection: $defaultFormatRaw) {
        Text("Short").tag(VideoFormat.short.rawValue)
        Text("Longform").tag(VideoFormat.longform.rawValue)
        Text("Livestream").tag(VideoFormat.livestream.rawValue)
      }.frame(maxWidth: 300)
      Toggle("Automatische Captions", isOn: $autoCaptions).toggleStyle(.switch)
      Toggle("AI Fallback erlauben", isOn: Binding(get: { store.aiFallbackAllowed }, set: { store.aiFallbackAllowed = $0 })).toggleStyle(.switch)
      Text("AI-Fallback wird nicht als primäre Produktionsquelle behandelt und ersetzt keine Rechteprüfung für bestehendes Material.")
        .font(.system(size: 9.5)).foregroundStyle(Color.bsMuted)
    }.blackstockCard(elevated: true)
  }

  private var publishing: some View {
    VStack(alignment: .leading, spacing: 14) {
      AbschnittTitel(titel: "Veröffentlichung", untertitel: "Globale Defaults für neu verbundene Kanäle; pro Kanal überschreibbar")
      Toggle("Vor Veröffentlichung prüfen", isOn: $reviewBeforePublish).toggleStyle(.switch)
      Picker("Standard Privacy", selection: $defaultPrivacyRaw) {
        ForEach(ChannelPrivacy.allCases) { Text($0.rawValue).tag($0.rawValue) }
      }.frame(maxWidth: 300)
      Text("Bestehende Kanalprofile werden nicht heimlich überschrieben. Ändere deren Review-/Privacy-Regel direkt unter Kanäle → Content DNA.")
        .font(.system(size: 9.5)).foregroundStyle(Color.bsMuted)
    }.blackstockCard()
  }

  private var sources: some View {
    VStack(alignment: .leading, spacing: 14) {
      AbschnittTitel(titel: "Quellen", untertitel: "Remote-Connectoren, Rechte und Blackstocks interner Mediencache")
      HStack { Text("Direct HTTPS / Own Media"); Spacer(); StatusPunkt(text: "Aktiv", farbe: .bsGreen) }
      HStack { Text("User-owned Remote Manifest"); Spacer(); StatusPunkt(text: store.sourceManifestURLs.isEmpty ? "Nicht konfiguriert" : "Aktiv", farbe: store.sourceManifestURLs.isEmpty ? .bsMuted : .bsGreen) }
      HStack { Text("YouTube Trend Reference"); Spacer(); StatusPunkt(text: "Nur Metadata", farbe: .bsBlue) }
      HStack { Text("Licensed Provider"); Spacer(); StatusPunkt(text: "Adapter erforderlich", farbe: .bsAmber) }
      Divider().overlay(Color.bsBorder)
      Text("REMOTE-MEDIENKATALOG").font(.system(size: 8.5, weight: .bold)).tracking(0.8).foregroundStyle(Color.bsMuted)
      Text("Optionales HTTPS-JSON-Manifest für eigene Cloud-/CDN-Medien. Nur Einträge mit maschinenlesbaren Nutzungsrechten werden automatisch als Schnittquelle berücksichtigt.")
        .font(.system(size: 9.5)).foregroundStyle(Color.bsMuted)
      HStack {
        TextField("https://…/blackstock-media.json", text: $manifestURL).textFieldStyle(.roundedBorder)
        Button("Hinzufügen") {
          do {
            try store.sourceManifestHinzufuegen(manifestURL)
            manifestURL = ""
          } catch { store.meldung = error.localizedDescription }
        }.buttonStyle(.bordered)
      }
      ForEach(store.sourceManifestURLs, id: \.self) { url in
        HStack {
          Image(systemName: "externaldrive.connected.to.line.below").foregroundStyle(Color.bsGreen)
          Text(url).font(.system(size: 9)).lineLimit(1).truncationMode(.middle)
          Spacer()
          Button(role: .destructive) { store.sourceManifestEntfernen(url) } label: { Image(systemName: "trash") }.buttonStyle(.borderless)
        }.padding(8).background(Color.bsSurface2).clipShape(RoundedRectangle(cornerRadius: 8))
      }
      Divider().overlay(Color.bsBorder)
      HStack {
        Text("Cache Limit").frame(width: 100, alignment: .leading)
        Slider(value: Binding(get: { store.remoteCacheLimitGB }, set: { store.remoteCacheLimitGB = $0 }), in: 2...100, step: 1)
        Text("\(Int(store.remoteCacheLimitGB)) GB").monospacedDigit().frame(width: 60)
      }
      Button("Cache jetzt bereinigen") {
        Task {
          do { try await RemoteMediaCacheService.shared.cleanup(maxBytes: Int64(store.remoteCacheLimitGB * 1024 * 1024 * 1024)); store.meldung = "Remote-Media-Cache bereinigt." }
          catch { store.meldung = error.localizedDescription }
        }
      }.buttonStyle(.bordered)
    }.blackstockCard()
  }

  private var advanced: some View {
    VStack(alignment: .leading, spacing: 14) {
      AbschnittTitel(titel: "Erweitert", untertitel: "AI Provider sind technische Fallbacks und keine primäre Blackstock-UX")
      ForEach(store.provider) { provider in
        HStack {
          VStack(alignment: .leading, spacing: 2) {
            Text(provider.name).font(.system(size: 10.5, weight: .semibold))
            Text(provider.detail).font(.system(size: 8.5)).foregroundStyle(Color.bsMuted)
          }
          Spacer()
          StatusPunkt(text: provider.verbunden ? "Bereit" : "Nicht verbunden", farbe: provider.verbunden ? .bsGreen : .bsMuted)
        }.padding(9).background(Color.bsSurface2).clipShape(RoundedRectangle(cornerRadius: 9))
      }
      Divider().overlay(Color.bsBorder)
      HStack {
        VStack(alignment: .leading, spacing: 2) {
          Text(BlackstockRelease.display).font(.system(size: 10.5, weight: .semibold))
          Text("Schema v\(store.v11State.schemaVersion) · Native macOS").font(.system(size: 8.5)).foregroundStyle(Color.bsMuted)
        }
        Spacer()
        StatusPunkt(text: "v11", farbe: .bsGreen)
      }
      Button("Lokalen Zustand zurücksetzen", role: .destructive) { showsReset = true }.buttonStyle(.bordered)
    }.blackstockCard()
  }
}
