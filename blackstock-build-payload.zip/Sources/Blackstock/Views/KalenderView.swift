import SwiftUI

struct KalenderView: View {
  @EnvironmentObject private var store: AppStore
  @State private var kanalFilter: UUID?
  @State private var nurGeplant = false

  private var projekte: [Produktion] {
    store.produktionen
      .filter { kanalFilter == nil || $0.kanalID == kanalFilter }
      .filter { !nurGeplant || $0.geplantFuer != nil }
      .sorted {
        switch ($0.geplantFuer, $1.geplantFuer) {
        case (let l?, let r?): return l < r
        case (_?, nil): return true
        case (nil, _?): return false
        case (nil, nil): return $0.erstelltAm > $1.erstelltAm
        }
      }
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 18) {
        PageHeader(
          titel: "Kalender",
          untertitel:
            "Veröffentlichungen wie in einem Creator Studio planen. Blackstock hält Projekt, Kanal, Review-Status und Upload-Zeit an einem Ort.",
          trailing: AnyView(filter))

        HStack(spacing: 12) {
          stat("Geplant", store.produktionen.filter { $0.geplantFuer != nil }.count, .bsBlue)
          stat(
            "Review bereit",
            store.produktionen.filter { store.istFreigabeBereit($0) && $0.youtubeVideoID == nil }
              .count, .bsGreen)
          stat(
            "Offene Quality Gates",
            store.produktionen.filter { !$0.qualitaet.offeneGates.isEmpty }.count, .bsAmber)
          stat("Fehler", store.produktionen.filter { $0.letzterFehler != nil }.count, .bsRed)
        }

        if projekte.isEmpty {
          EmptyState(
            symbol: "calendar.badge.plus", titel: "Noch nichts geplant",
            text:
              "Plane fertige oder laufende Produktionen hier. Ein Upload wird erst ausgelöst, wenn Quality Gate und YouTube-Verbindung bereit sind.",
            button: "Zum Studio"
          ) { store.ausgewaehltesZiel = .produktionen }
        } else {
          VStack(spacing: 8) {
            ForEach(projekte) { p in projektRow(p) }
          }
        }
      }
      .padding(26)
    }
  }

  private var filter: some View {
    HStack(spacing: 10) {
      Toggle("Nur geplant", isOn: $nurGeplant)
        .toggleStyle(.switch)
        .controlSize(.small)
      Picker("Kanal", selection: $kanalFilter) {
        Text("Alle Kanäle").tag(UUID?.none)
        ForEach(store.kanaele) { Text($0.name).tag(Optional($0.id)) }
      }
      .frame(width: 210)
    }
  }

  private func stat(_ label: String, _ value: Int, _ color: Color) -> some View {
    VStack(alignment: .leading, spacing: 5) {
      Text("\(value)").font(.system(size: 22, weight: .semibold, design: .rounded))
        .foregroundStyle(Color.bsText)
      HStack(spacing: 6) {
        Circle().fill(color).frame(width: 6, height: 6)
        Text(label).font(.system(size: 9.5)).foregroundStyle(Color.bsMuted)
      }
    }
    .frame(maxWidth: .infinity, alignment: .leading)
    .blackstockCard(14)
  }

  private func projektRow(_ p: Produktion) -> some View {
    HStack(spacing: 14) {
      ZStack {
        RoundedRectangle(cornerRadius: 9, style: .continuous)
          .fill(Color.bsSurface3)
          .frame(width: 84, height: 48)
        Image(systemName: p.format == .short ? "rectangle.portrait.fill" : "play.rectangle.fill")
          .foregroundStyle(Color.bsRed)
      }

      VStack(alignment: .leading, spacing: 4) {
        Text(p.arbeitstitel)
          .font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Color.bsText)
          .lineLimit(1)
        Text("\(store.kanalName(fuer: p.kanalID)) · \(p.format.rawValue) · \(p.status.rawValue)")
          .font(.system(size: 9.2)).foregroundStyle(Color.bsMuted)
      }
      .frame(maxWidth: .infinity, alignment: .leading)

      StatusPunkt(
        text: store.istFreigabeBereit(p) ? "Upload bereit" : "Review offen",
        farbe: store.istFreigabeBereit(p) ? .bsGreen : .bsAmber)

      DatePicker(
        "",
        selection: Binding(
          get: { p.geplantFuer ?? Date().addingTimeInterval(3600) },
          set: { store.planungSetzen(p.id, datum: $0) }),
        displayedComponents: [.date, .hourAndMinute]
      )
      .labelsHidden()
      .frame(width: 190)

      Menu {
        Button("Planung entfernen") { store.planungSetzen(p.id, datum: nil) }
        Button("Im Studio öffnen") {
          store.ausgewaehlteProduktionID = p.id
          store.ausgewaehltesZiel = .produktionen
        }
        if store.istFreigabeBereit(p), p.youtubeVideoID == nil {
          Button("Jetzt zu YouTube senden") { Task { await store.produktionHochladen(p.id) } }
        }
      } label: {
        Image(systemName: "ellipsis").frame(width: 30)
      }
      .menuStyle(.borderlessButton)
    }
    .padding(13)
    .background(Color.bsSurface)
    .overlay(RoundedRectangle(cornerRadius: 11).stroke(Color.bsBorder, lineWidth: 1))
    .clipShape(RoundedRectangle(cornerRadius: 11))
  }
}
