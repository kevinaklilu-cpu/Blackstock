import SwiftUI

struct ContentFactoryView: View {
  @EnvironmentObject private var store: AppStore
  @State private var anzahl = 12
  @State private var format: VideoFormat = .short
  @State private var modus: Produktionsmodus = .studio
  @State private var publikationsmodus: Publikationsmodus = .review
  @State private var kanalID: UUID?
  @State private var batchName = "Neue Content-Serie"
  @State private var themenText = ""

  @AppStorage("automatikStufe") private var automatikStufe = "Produktion automatisch"
  @AppStorage("minConfidence") private var minConfidence = 0.90
  @AppStorage("minQuality") private var minQuality = 92.0
  @AppStorage("dailyProductionLimit") private var dailyLimit = 12
  @AppStorage("automationIntervalMinutes") private var automationIntervalMinutes = 240
  @AppStorage("automationCloudVisuals") private var automationCloudVisuals = false
  @State private var regelName = "Top-Chancen → Produktion"
  @State private var regelTrend = 90.0
  @State private var regelConfidence = 0.90
  @State private var regelFormat: VideoFormat = .short
  @State private var regelKanal: UUID?
  @State private var zeigtAutopilotDetails = false
  @State private var systemReport: CreatorSystemReport?

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 18) {
        PageHeader(
          titel: "Erstellen",
          untertitel:
            "Ein Thema oder eine ganze Serie produzieren. Blackstock übernimmt Redaktion, Medien, Voice, Thumbnail, Master-Render und Review automatisch.",
          trailing: AnyView(
            HStack(spacing: 8) {
              Button {
                store.ausgewaehltesZiel = .einstellungen
              } label: {
                Label("Engines", systemImage: "cpu")
              }.buttonStyle(.bordered)
              Button {
                store.ausgewaehltesZiel = .chancen
              } label: {
                Label("Chancen öffnen", systemImage: "chart.line.uptrend.xyaxis")
              }.buttonStyle(.bordered)
            })
        )

        HStack(alignment: .top, spacing: 14) {
          batchBuilder
          factoryStatus
        }

        pipelineCard
        autopilotCard

        VStack(alignment: .leading, spacing: 13) {
          AbschnittTitel(
            titel: "Produktionsserien",
            untertitel: "Jeder Batch erzeugt eigenständige Projekte mit eigener Qualitätsprüfung")
          if store.batchAuftraege.isEmpty {
            EmptyState(
              symbol: "bolt.rectangle", titel: "Noch keine Serie",
              text:
                "Wähle Kanal, Anzahl und Qualitätsmodus. Blackstock nimmt die stärksten Chancen aus deinem Feed und legt daraus einzelne Studio-Projekte an.",
              button: nil, action: nil)
          } else {
            ForEach(store.batchAuftraege) { batch in
              HStack(spacing: 14) {
                ZStack {
                  RoundedRectangle(cornerRadius: 10).fill(Color.bsRed.opacity(0.09)).frame(
                    width: 48, height: 48)
                  Image(systemName: "square.stack.3d.up.fill").foregroundStyle(Color.bsRed)
                }
                VStack(alignment: .leading, spacing: 4) {
                  Text(batch.name).font(.system(size: 12.5, weight: .semibold)).foregroundStyle(
                    Color.bsText)
                  Text(
                    "\(batch.anzahl) Projekte · \(batch.format.rawValue) · \(batch.modus.rawValue) · \(batch.publikationsmodus.rawValue)"
                  )
                  .font(.system(size: 9.5)).foregroundStyle(Color.bsMuted)
                }
                Spacer()
                StatusPunkt(
                  text: batch.status.rawValue, farbe: batch.status == .fertig ? .bsGreen : .bsBlue)
                if [.laeuft, .geplant, .review, .pausiert].contains(batch.status) {
                  Menu {
                    Button("Nur Redaktion erzeugen") {
                      Task { await store.batchProduktionspaketeErzeugen(batch.id) }
                    }
                    Button("Komplett bis Review produzieren") {
                      Task { await store.batchVollProduzieren(batch.id) }
                    }
                    Divider()
                    Button("Redaktionelle Sammelfreigabe") {
                      store.batchFreigabeBestaetigen(batch.id)
                    }
                    Button("Alle freigegebenen hochladen") {
                      Task { await store.batchBereiteProjekteHochladen(batch.id) }
                    }
                    Divider()
                    Button("Serie entfernen") {
                      store.batchLoeschen(batch.id, projekteLoeschen: false)
                    }
                    Button("Serie + Projekte löschen", role: .destructive) {
                      store.batchLoeschen(batch.id, projekteLoeschen: true)
                    }
                  } label: {
                    Label("Factory", systemImage: "bolt.fill")
                  }
                  .menuStyle(.borderlessButton)
                  .disabled(store.istBeschaeftigt)
                }
                Button("Studio") {
                  store.ausgewaehlteProduktionID = batch.produktionIDs.first
                  store.ausgewaehltesZiel = .produktionen
                }
                .buttonStyle(.bordered)
                .disabled(batch.produktionIDs.isEmpty)
              }
              .padding(13)
              .background(Color.bsSurface2)
              .clipShape(RoundedRectangle(cornerRadius: 11))
            }
          }
        }
        .blackstockCard()
      }
      .padding(26)
    }
    .onAppear {
      if kanalID == nil { kanalID = store.kanaele.first?.id }
      if regelKanal == nil { regelKanal = store.kanaele.first?.id }
      systemReport = store.creatorSystemPruefen()
    }
  }

  private var batchBuilder: some View {
    VStack(alignment: .leading, spacing: 15) {
      AbschnittTitel(
        titel: "Neue Serie",
        untertitel: "Trend → Redaktion → Medien → Render → Quality Gate → Review/Upload")

      TextField("Serienname", text: $batchName)
        .textFieldStyle(.roundedBorder)

      VStack(alignment: .leading, spacing: 6) {
        Text("THEMEN / IDEEN").font(.system(size: 8.5, weight: .bold)).tracking(0.8)
          .foregroundStyle(Color.bsMuted)
        TextEditor(text: $themenText)
          .font(.system(size: 10.5))
          .frame(minHeight: 86, maxHeight: 120)
          .padding(7)
          .background(Color.bsSurface2)
          .clipShape(RoundedRectangle(cornerRadius: 8))
          .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.bsBorder))
        Text(
          "Optional: ein Thema pro Zeile. Leer = stärkste Chancen aus dem Feed. Weniger Themen als Videos werden als unterschiedliche redaktionelle Perspektiven variiert."
        )
        .font(.system(size: 8.8)).foregroundStyle(Color.bsMuted2).lineSpacing(2)
      }

      HStack(spacing: 12) {
        VStack(alignment: .leading, spacing: 6) {
          Text("KANAL").font(.system(size: 8.5, weight: .bold)).tracking(0.8).foregroundStyle(
            Color.bsMuted)
          Picker("Kanal", selection: $kanalID) {
            Text("Automatisch zuordnen").tag(UUID?.none)
            ForEach(store.kanaele) { kanal in Text(kanal.name).tag(Optional(kanal.id)) }
          }
          .labelsHidden()
        }
        VStack(alignment: .leading, spacing: 6) {
          Text("ANZAHL").font(.system(size: 8.5, weight: .bold)).tracking(0.8).foregroundStyle(
            Color.bsMuted)
          Stepper("\(anzahl) Videos", value: $anzahl, in: 1...100)
            .font(.system(size: 10.5))
        }
      }

      VStack(alignment: .leading, spacing: 6) {
        Text("FORMAT").font(.system(size: 8.5, weight: .bold)).tracking(0.8).foregroundStyle(
          Color.bsMuted)
        Picker("Format", selection: $format) {
          ForEach(VideoFormat.allCases, id: \.self) { Text($0.rawValue).tag($0) }
        }.pickerStyle(.segmented)
      }

      VStack(alignment: .leading, spacing: 6) {
        Text("QUALITÄT").font(.system(size: 8.5, weight: .bold)).tracking(0.8).foregroundStyle(
          Color.bsMuted)
        Picker("Modus", selection: $modus) {
          ForEach(Produktionsmodus.allCases) { Text($0.rawValue).tag($0) }
        }.pickerStyle(.segmented)
        Text(modus.beschreibung).font(.system(size: 9.5)).foregroundStyle(Color.bsMuted)
      }

      VStack(alignment: .leading, spacing: 6) {
        Text("VERÖFFENTLICHUNG").font(.system(size: 8.5, weight: .bold)).tracking(0.8)
          .foregroundStyle(Color.bsMuted)
        Picker("Publishing", selection: $publikationsmodus) {
          ForEach(Publikationsmodus.allCases) { Text($0.rawValue).tag($0) }
        }
      }

      Button {
        let batch = serieAnlegen()
        guard batch.anzahl > 0 else { return }
        Task { await store.batchVollProduzieren(batch.id) }
      } label: {
        Label("Serie anlegen & produzieren", systemImage: "bolt.fill")
          .frame(maxWidth: .infinity)
      }
      .buttonStyle(.borderedProminent)
      .tint(Color.bsRed)
      .foregroundStyle(.white)
      .disabled(
        store.istBeschaeftigt
          || (store.chancen.isEmpty
            && themenText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
      )

      Button("Nur Projekte anlegen") {
        _ = serieAnlegen()
      }
      .buttonStyle(.bordered)
      .disabled(
        store.istBeschaeftigt
          || (store.chancen.isEmpty
            && themenText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
      )
    }
    .blackstockCard(18, elevated: true)
    .frame(maxWidth: .infinity)
  }

  private func serieAnlegen() -> BatchAuftrag {
    let themen = themenText.components(separatedBy: .newlines)
    let batch = store.batchAusThemenErstellen(
      name: batchName.isEmpty ? "Content-Serie" : batchName, kanalID: kanalID,
      themen: themen, anzahl: anzahl, format: format, modus: modus,
      publikationsmodus: publikationsmodus)
    store.meldung =
      batch.anzahl > 0
      ? "\(batch.anzahl) Studio-Projekte wurden angelegt."
      : "Es konnten keine Projekte angelegt werden. Füge Themen ein oder aktualisiere den Chancen-Feed."
    return batch
  }

  private func istPremiumEngineAktiv(_ typ: ProviderVerbindung.Typ) -> Bool {
    guard let provider = store.provider.first(where: { $0.typ == typ }) else { return false }
    return EnginePresetService.aktiviertesPreset(fuer: provider)?.premium == true
      && store.providerBereit(typ)
  }

  private var factoryStatus: some View {
    let report = systemReport ?? store.creatorSystemPruefen()
    return VStack(alignment: .leading, spacing: 14) {
      HStack(alignment: .top) {
        AbschnittTitel(
          titel: "Produktionsstatus",
          untertitel: "Echter Preflight vor Serien- und Ein-Klick-Produktion")
        Spacer()
        StatusPunkt(
          text: report.bereit ? "Bereit" : "Prüfen",
          farbe: report.bereit ? .bsGreen : .bsRed)
      }

      ForEach(report.checks.filter { $0.id != "youtube" }) { check in
        readiness(check.titel, check.bereit, check.detail)
      }
      readiness(
        "YouTube", report.checks.first(where: { $0.id == "youtube" })?.bereit == true,
        report.checks.first(where: { $0.id == "youtube" })?.detail ?? "Optional für Upload")

      Divider().overlay(Color.bsBorder)
      Button {
        systemReport = store.creatorSystemSelbsttest()
      } label: {
        Label("Produktionssystem prüfen", systemImage: "checkmark.shield")
          .frame(maxWidth: .infinity)
      }
      .buttonStyle(.bordered)

      Text(
        "Blackstock erzeugt Redaktion, Voice, Thumbnail, Visual-Track und Musik selbst. Premium-Provider ersetzen nur einzelne Stufen; fehlt ein Key oder schlägt eine Cloud-Stufe fehl, greift der lokale Fallback."
      )
      .font(.system(size: 9.5)).foregroundStyle(Color.bsMuted).lineSpacing(3)
    }
    .blackstockCard()
    .frame(width: 390)
  }

  private var pipelineCard: some View {
    VStack(alignment: .leading, spacing: 12) {
      AbschnittTitel(
        titel: "Blackstock Produktionspipeline",
        untertitel:
          "Alle Schritte sind vorkonfiguriert; Premium-Engines ersetzen automatisch nur die jeweilige lokale Stufe"
      )
      HStack(spacing: 6) {
        ForEach(
          [
            "Thema", "Redaktion", "Szenen", "Medien", "Voice", "Thumbnail", "Master", "Review",
            "Upload",
          ], id: \.self
        ) { step in
          Text(step)
            .font(.system(size: 9, weight: .semibold))
            .foregroundStyle(Color.bsText)
            .padding(.horizontal, 9).padding(.vertical, 7)
            .background(Color.bsSurface2)
            .clipShape(RoundedRectangle(cornerRadius: 7))
        }
      }
      Text(
        "Kein manueller Medienordner ist nötig: Blackstock legt Voice, Musik, Szenenbilder, Visuals, Thumbnail und Master intern im Arbeitsbereich an. Eigene oder lizenzierte Medien werden automatisch bevorzugt, wenn sie passen."
      )
      .font(.system(size: 9.6)).foregroundStyle(Color.bsMuted).lineSpacing(3)
    }
    .blackstockCard(16)
  }

  private var autopilotCard: some View {
    VStack(alignment: .leading, spacing: 14) {
      HStack(alignment: .top) {
        AbschnittTitel(
          titel: "Autopilot",
          untertitel:
            "Wiederkehrende Chancen automatisch in echte Projekte und Master-Render überführen – ohne die Quality Gates zu umgehen"
        )
        Spacer()
        Button {
          Task { await store.aktiveAutomationenAusfuehren() }
        } label: {
          Label("Jetzt ausführen", systemImage: "play.fill")
        }
        .buttonStyle(.borderedProminent)
        .tint(Color.bsRed)
        .foregroundStyle(.white)
        .disabled(store.istBeschaeftigt || store.automationsregeln.filter(\.aktiv).isEmpty)
      }

      HStack(spacing: 12) {
        VStack(alignment: .leading, spacing: 6) {
          Text("AUTONOMIE").font(.system(size: 8.5, weight: .bold)).tracking(0.8)
            .foregroundStyle(Color.bsMuted)
          Picker("Autonomie", selection: $automatikStufe) {
            Text("Aus").tag("Aus")
            Text("Assistiert").tag("Assistiert")
            Text("Produktion automatisch").tag("Produktion automatisch")
            Text("Smart Autopilot").tag("Smart Autopilot")
          }
          .labelsHidden()
          .frame(width: 220)
        }
        Divider().frame(height: 38)
        autopilotMetric("Quality Gate", "≥ \(Int(minQuality))")
        autopilotMetric("Vertrauen", "≥ \(Int(minConfidence * 100)) %")
        autopilotMetric("Tageslimit", "\(dailyLimit)")
        autopilotMetric("Scheduler", "\(automationIntervalMinutes) min")
        Spacer()
        Button(zeigtAutopilotDetails ? "Weniger" : "Regeln & Grenzen") {
          withAnimation(.easeInOut(duration: 0.16)) { zeigtAutopilotDetails.toggle() }
        }
        .buttonStyle(.bordered)
      }

      Text(autopilotBeschreibung)
        .font(.system(size: 9.5)).foregroundStyle(Color.bsMuted).lineSpacing(2.5)

      if !store.automationsregeln.isEmpty {
        VStack(spacing: 7) {
          ForEach(store.automationsregeln) { regel in
            HStack(spacing: 10) {
              Toggle(
                "",
                isOn: Binding(
                  get: { regel.aktiv },
                  set: { aktiv in
                    var copy = regel
                    copy.aktiv = aktiv
                    store.automationSpeichern(copy)
                  })
              )
              .labelsHidden().controlSize(.small)
              VStack(alignment: .leading, spacing: 2) {
                Text(regel.name).font(.system(size: 10.5, weight: .semibold)).foregroundStyle(
                  Color.bsText)
                Text(
                  "Score ≥ \(Int(regel.minTrendScore)) · Vertrauen ≥ \(Int(regel.minKonfidenz * 100)) % · \(regel.format.rawValue) · max. \(regel.maxProTag)/Tag"
                )
                .font(.system(size: 8.7)).foregroundStyle(Color.bsMuted)
              }
              Spacer()
              Button(role: .destructive) {
                store.automationLoeschen(regel.id)
              } label: {
                Image(systemName: "trash")
              }
              .buttonStyle(.plain).foregroundStyle(Color.bsMuted)
            }
            .padding(.horizontal, 11).padding(.vertical, 9)
            .background(Color.bsSurface2).clipShape(RoundedRectangle(cornerRadius: 9))
          }
        }
      }

      if zeigtAutopilotDetails {
        Divider().overlay(Color.bsBorder)
        HStack(alignment: .top, spacing: 18) {
          VStack(alignment: .leading, spacing: 12) {
            Text("Globale Grenzen").font(.system(size: 11.5, weight: .semibold)).foregroundStyle(
              Color.bsText)
            valueSlider(
              "Mindestvertrauen", value: $minConfidence, range: 0.75...0.99,
              text: "\(Int(minConfidence * 100)) %")
            valueSlider(
              "Mindestqualität", value: $minQuality, range: 80...99, text: "\(Int(minQuality))")
            Stepper("Max. \(dailyLimit) Produktionen pro Tag", value: $dailyLimit, in: 1...200)
              .font(.system(size: 10))
            Stepper(
              "Scheduler alle \(automationIntervalMinutes) Minuten",
              value: $automationIntervalMinutes, in: 180...720, step: 30
            )
            .font(.system(size: 10))
            Toggle("Premium-Cloud-Visuals in Automationen erlauben", isOn: $automationCloudVisuals)
              .toggleStyle(.switch).font(.system(size: 10))
            Text(
              automationCloudVisuals
                ? "Premium-Video darf verwendet werden; Provider-Kosten können entstehen."
                : "Cloud-Video bleibt aus. Blackstock erzeugt trotzdem automatisch den lokalen Visual-Track."
            )
            .font(.system(size: 8.8)).foregroundStyle(Color.bsMuted)
          }
          .frame(maxWidth: .infinity)

          VStack(alignment: .leading, spacing: 10) {
            Text("Neue Regel").font(.system(size: 11.5, weight: .semibold)).foregroundStyle(
              Color.bsText)
            TextField("Regelname", text: $regelName).textFieldStyle(.roundedBorder)
            Picker("Kanal", selection: $regelKanal) {
              Text("Automatisch").tag(UUID?.none)
              ForEach(store.kanaele) { Text($0.name).tag(Optional($0.id)) }
            }
            HStack {
              valueSlider("Trend", value: $regelTrend, range: 60...99, text: "≥ \(Int(regelTrend))")
              valueSlider(
                "Vertrauen", value: $regelConfidence, range: 0.70...0.99,
                text: "≥ \(Int(regelConfidence * 100)) %")
            }
            Picker("Format", selection: $regelFormat) {
              ForEach(VideoFormat.allCases, id: \.self) { Text($0.rawValue).tag($0) }
            }.pickerStyle(.segmented)
            Button("Regel aktivieren") {
              let regel = Automationsregel(
                name: regelName.isEmpty ? "Top-Chancen → Produktion" : regelName,
                aktiv: true, kanalID: regelKanal, minTrendScore: regelTrend,
                minKonfidenz: regelConfidence, modus: .studio,
                publikationsmodus: .review, format: regelFormat, maxProTag: min(dailyLimit, 100))
              store.automationSpeichern(regel)
              store.meldung = "Autopilot-Regel gespeichert."
            }
            .buttonStyle(.borderedProminent).tint(Color.bsRed).foregroundStyle(.white)
          }
          .frame(width: 430)
        }
      }
    }
    .blackstockCard()
  }

  private var autopilotBeschreibung: String {
    switch automatikStufe {
    case "Aus":
      return
        "Automatische Läufe sind deaktiviert. Manuelle Serien und Ein-Klick-Produktion bleiben verfügbar."
    case "Assistiert":
      return
        "Blackstock legt passende Projekte an; die weitere Produktion startest du bewusst selbst."
    case "Smart Autopilot":
      return
        "Blackstock produziert automatisch und darf Quality-Gate-bereite Projekte mit passendem Publishing-Modus weitergeben."
    default:
      return
        "Blackstock produziert passende Chancen automatisch bis zum Master-Render. Veröffentlichung bleibt standardmäßig im Review."
    }
  }

  private func autopilotMetric(_ title: String, _ value: String) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text(value).font(.system(size: 11, weight: .semibold, design: .rounded)).foregroundStyle(
        Color.bsText)
      Text(title).font(.system(size: 8.2)).foregroundStyle(Color.bsMuted)
    }
  }

  private func valueSlider(
    _ title: String, value: Binding<Double>, range: ClosedRange<Double>, text: String
  ) -> some View {
    VStack(alignment: .leading, spacing: 5) {
      HStack {
        Text(title).font(.system(size: 9.5)).foregroundStyle(Color.bsText)
        Spacer()
        Text(text).font(.system(size: 9.5, weight: .semibold)).foregroundStyle(Color.bsGreen)
      }
      Slider(value: value, in: range).tint(Color.bsRed)
    }
  }

  private func readiness(_ name: String, _ ready: Bool, _ detail: String) -> some View {
    HStack(spacing: 10) {
      Image(systemName: ready ? "checkmark.circle.fill" : "circle.dashed")
        .foregroundStyle(ready ? Color.bsGreen : Color.bsAmber)
      VStack(alignment: .leading, spacing: 2) {
        Text(name).font(.system(size: 10.5, weight: .medium)).foregroundStyle(Color.bsText)
        Text(detail).font(.system(size: 8.8)).foregroundStyle(Color.bsMuted)
      }
      Spacer()
    }
  }
}
