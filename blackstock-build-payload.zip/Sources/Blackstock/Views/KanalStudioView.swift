import AppKit
import SwiftUI

struct KanalStudioView: View {
  @EnvironmentObject private var store: AppStore
  @State private var tab = "Profil"
  @State private var customTopic = ""
  @State private var excludedTopic = ""

  private var channelID: UUID? { store.ausgewaehlterKanalID ?? store.kanaele.first?.id }
  private var channel: Kanal? { channelID.flatMap { id in store.kanaele.first(where: { $0.id == id }) } }
  private var profile: ChannelContentProfile? { channelID.map { store.channelProfile(for: $0) } }

  var body: some View {
    if store.kanaele.isEmpty {
      KontenView()
    } else {
      ScrollView {
        VStack(alignment: .leading, spacing: 18) {
          PageHeader(
            titel: "Kanäle",
            untertitel: "Kanalprofil, Content DNA, Berechtigungen und Monetarisierung – getrennt vom Google-Account modelliert.",
            trailing: AnyView(channelPicker))
          Picker("Bereich", selection: $tab) {
            ForEach(["Profil", "Content DNA", "Monetarisierung", "Branding", "Verbindung"], id: \.self) { Text($0).tag($0) }
          }.pickerStyle(.segmented).frame(maxWidth: 720)
          switch tab {
          case "Content DNA": contentDNA
          case "Monetarisierung": monetization
          case "Branding": branding
          case "Verbindung": KontenView()
          default: overview
          }
        }.padding(26)
      }
      .onAppear { if store.ausgewaehlterKanalID == nil { store.ausgewaehlterKanalID = store.kanaele.first?.id } }
    }
  }

  private var channelPicker: some View {
    Picker("Kanal", selection: Binding(get: { channelID }, set: { store.ausgewaehlterKanalID = $0 })) {
      ForEach(store.kanaele) { Text($0.name).tag(Optional($0.id)) }
    }.frame(width: 220)
  }

  @ViewBuilder private var overview: some View {
    if let channel, let profile {
      HStack(alignment: .top, spacing: 14) {
        VStack(alignment: .leading, spacing: 14) {
          ZStack(alignment: .bottomLeading) {
            RoundedRectangle(cornerRadius: 14).fill(LinearGradient(colors: [Color.bsRed.opacity(0.55), Color.bsSurface3], startPoint: .topLeading, endPoint: .bottomTrailing)).frame(height: 180)
            HStack(spacing: 14) {
              BlackstockMark(size: 72)
              VStack(alignment: .leading, spacing: 4) {
                Text(channel.name).font(.system(size: 23, weight: .bold)).foregroundStyle(.white)
                Text("\(channel.handle) · \(profile.language) · \(profile.region)").font(.system(size: 10.5)).foregroundStyle(.white.opacity(0.75))
              }
            }.padding(20)
          }
          HStack(spacing: 12) {
            KPIKarte(titel: "Abonnenten", wert: channel.abonnenten.kompakt, delta: channel.datenherkunft.rawValue, symbol: "person.2.fill")
            KPIKarte(titel: "Views · 28T", wert: channel.views28Tage.kompakt, delta: "YouTube Analytics", symbol: "play.rectangle.fill")
            KPIKarte(titel: "Revenue", wert: profile.revenueAccess == .available ? channel.umsatz28Tage.euro : "Nicht verfügbar", delta: profile.revenueAccess.rawValue, symbol: "eurosign.circle.fill", akzent: .bsGreen)
          }
        }.frame(maxWidth: .infinity)

        VStack(alignment: .leading, spacing: 12) {
          AbschnittTitel(titel: "Publishing Defaults", untertitel: "Diese Einstellungen wirken tatsächlich auf neue Produktionen")
          info("Review", profile.reviewBeforePublish ? "Vor Veröffentlichung prüfen" : "Automatisch veröffentlichen")
          info("Privacy", profile.defaultPrivacy.rawValue)
          info("Formate", profile.desiredFormats.map(\.rawValue).joined(separator: ", "))
          info("Analytics", profile.analyticsAuthorized ? "Verbunden" : "Nicht verbunden")
          info("Upload", profile.uploadAuthorized ? "Autorisiert" : "Bei Bedarf autorisieren")
        }.blackstockCard().frame(width: 360)
      }
    }
  }

  @ViewBuilder private var contentDNA: some View {
    if let channelID, let profile {
      VStack(alignment: .leading, spacing: 14) {
        AbschnittTitel(titel: "Content DNA", untertitel: "Diese Angaben steuern Trend Discovery, Source-Auswahl und Metadaten kanalbezogen")
        HStack(spacing: 12) {
          TextField("Sprache", text: profileBinding(\.language, channelID: channelID)).textFieldStyle(.roundedBorder)
          TextField("Region, z. B. DE", text: profileBinding(\.region, channelID: channelID)).textFieldStyle(.roundedBorder)
        }
        Text("Themen").font(.system(size: 9, weight: .bold)).foregroundStyle(Color.bsMuted)
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 145), spacing: 8)], spacing: 8) {
          ForEach(TopicTaxonomy.stableCategories) { topic in
            Toggle(topic.rawValue, isOn: Binding(
              get: { store.channelProfile(for: channelID).topics.contains(topic) },
              set: { enabled in
                var updated = store.channelProfile(for: channelID)
                if enabled { if !updated.topics.contains(topic) { updated.topics.append(topic) } }
                else { updated.topics.removeAll { $0 == topic } }
                store.channelProfileSpeichern(updated)
              })).toggleStyle(.checkbox)
          }
        }
        Divider().overlay(Color.bsBorder)
        HStack {
          TextField("Eigenes Thema", text: $customTopic).textFieldStyle(.roundedBorder)
          Button("Hinzufügen") {
            let value = customTopic.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !value.isEmpty else { return }
            var updated = store.channelProfile(for: channelID)
            if !updated.customTopics.contains(value) { updated.customTopics.append(value) }
            store.channelProfileSpeichern(updated); customTopic = ""
          }.buttonStyle(.bordered)
        }
        chips(profile.customTopics) { value in
          var updated = store.channelProfile(for: channelID); updated.customTopics.removeAll { $0 == value }; store.channelProfileSpeichern(updated)
        }
        HStack {
          TextField("Thema ausschließen", text: $excludedTopic).textFieldStyle(.roundedBorder)
          Button("Ausschließen") {
            let value = excludedTopic.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !value.isEmpty else { return }
            var updated = store.channelProfile(for: channelID)
            if !updated.excludedTopics.contains(value) { updated.excludedTopics.append(value) }
            store.channelProfileSpeichern(updated); excludedTopic = ""
          }.buttonStyle(.bordered)
        }
        chips(profile.excludedTopics) { value in
          var updated = store.channelProfile(for: channelID); updated.excludedTopics.removeAll { $0 == value }; store.channelProfileSpeichern(updated)
        }
        Divider().overlay(Color.bsBorder)
        HStack(spacing: 18) {
          Toggle("Shorts", isOn: formatBinding(.short, channelID: channelID)).toggleStyle(.checkbox)
          Toggle("Longform", isOn: formatBinding(.longform, channelID: channelID)).toggleStyle(.checkbox)
          Toggle("Livestream", isOn: formatBinding(.livestream, channelID: channelID)).toggleStyle(.checkbox)
        }
        Toggle("Vor Veröffentlichung prüfen", isOn: profileBinding(\.reviewBeforePublish, channelID: channelID)).toggleStyle(.switch)
        Picker("Standard Privacy", selection: profileBinding(\.defaultPrivacy, channelID: channelID)) {
          ForEach(ChannelPrivacy.allCases) { Text($0.rawValue).tag($0) }
        }.frame(maxWidth: 260)
      }.blackstockCard(elevated: true)
    }
  }

  @ViewBuilder private var monetization: some View {
    if let channel, let channelID, let profile {
      VStack(alignment: .leading, spacing: 14) {
        AbschnittTitel(titel: "Monetarisierung", untertitel: "Blackstock trennt API-Zugriff, verfügbare Revenue-Daten und den nicht über diese APIs verifizierbaren YPP-Status")
        HStack(spacing: 12) {
          statusCard("Analytics Revenue Access", profile.revenueAccess.rawValue, profile.revenueAccess.canQueryMonetaryAnalytics)
          statusCard("Revenue Data", profile.revenueAccess == .available ? "Verfügbar" : "Nicht verfügbar", profile.revenueAccess == .available)
          statusCard("Geschätzter Fortschritt", channel.monetarisierungFortschritt > 0 ? "\(Int(channel.monetarisierungFortschritt * 100)) %" : "Nicht ableitbar", false)
        }
        HStack {
          if !profile.revenueAccess.canQueryMonetaryAnalytics {
            Button("Monetarisierungsdaten verbinden") { Task { await store.revenueZugriffVerbinden(channelID: channelID) } }
              .buttonStyle(.borderedProminent).tint(Color.bsRed).foregroundStyle(.white)
          }
          Button("Exakten Status in YouTube Studio öffnen") {
            if let id = channel.youtubeChannelID, let url = URL(string: "https://studio.youtube.com/channel/\(id)/monetization") { NSWorkspace.shared.open(url) }
          }.buttonStyle(.bordered)
        }
        Text("Blackstock behauptet keinen YPP-Freigabestatus, wenn YouTube ihn über die verwendeten APIs nicht belastbar liefert.")
          .font(.system(size: 9.5)).foregroundStyle(Color.bsMuted)
      }.blackstockCard(elevated: true)
    }
  }

  @ViewBuilder private var branding: some View {
    if let channel {
      VStack(alignment: .leading, spacing: 14) {
        AbschnittTitel(titel: "Brand Kit", untertitel: "Bestehende Blackstock-Markenidentität und kanalbezogene Defaults")
        HStack(spacing: 16) {
          BlackstockMark(size: 100)
          VStack(alignment: .leading, spacing: 7) {
            info("Kanal", channel.name)
            info("Thumbnail", channel.branding?.thumbnailStil ?? "Editorial Contrast")
            info("Captions", channel.branding?.captionStil ?? "Dynamic Bold")
            info("Voice", channel.branding?.standardVoice ?? "Natürlich")
          }
        }
        Button("Brand Assets neu erzeugen") { store.brandAssetsGenerieren(channel.id) }.buttonStyle(.bordered)
      }.blackstockCard()
    }
  }

  private func info(_ key: String, _ value: String) -> some View {
    HStack { Text(key).foregroundStyle(Color.bsMuted); Spacer(); Text(value).foregroundStyle(Color.bsText).fontWeight(.medium) }.font(.system(size: 10.5))
  }

  private func statusCard(_ title: String, _ value: String, _ good: Bool) -> some View {
    VStack(alignment: .leading, spacing: 5) {
      Text(title.uppercased()).font(.system(size: 8, weight: .bold)).foregroundStyle(Color.bsMuted)
      Text(value).font(.system(size: 12, weight: .semibold)).foregroundStyle(good ? Color.bsGreen : Color.bsText)
    }.padding(12).frame(maxWidth: .infinity, alignment: .leading).background(Color.bsSurface2).clipShape(RoundedRectangle(cornerRadius: 10))
  }

  private func chips(_ values: [String], onRemove: @escaping (String) -> Void) -> some View {
    HStack(spacing: 6) {
      ForEach(values, id: \.self) { value in
        HStack(spacing: 4) { Text(value); Button { onRemove(value) } label: { Image(systemName: "xmark") }.buttonStyle(.borderless) }
          .font(.system(size: 8.5)).padding(.horizontal, 8).padding(.vertical, 5).background(Color.bsSurface2).clipShape(Capsule())
      }
    }
  }

  private func profileBinding<T>(
    _ keyPath: WritableKeyPath<ChannelContentProfile, T>, channelID: UUID
  ) -> Binding<T> {
    Binding(get: {
      store.channelProfile(for: channelID)[keyPath: keyPath]
    }, set: { value in
      var updated = store.channelProfile(for: channelID)
      updated[keyPath: keyPath] = value
      store.channelProfileSpeichern(updated)
    })
  }

  private func formatBinding(_ format: VideoFormat, channelID: UUID) -> Binding<Bool> {
    Binding(get: { store.channelProfile(for: channelID).desiredFormats.contains(format) }, set: { enabled in
      var updated = store.channelProfile(for: channelID)
      if enabled { if !updated.desiredFormats.contains(format) { updated.desiredFormats.append(format) } }
      else { updated.desiredFormats.removeAll { $0 == format }; if updated.desiredFormats.isEmpty { updated.desiredFormats = [.short] } }
      store.channelProfileSpeichern(updated)
    })
  }
}
