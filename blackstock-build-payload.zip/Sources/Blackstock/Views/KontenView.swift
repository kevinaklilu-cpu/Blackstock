import SwiftUI

struct KontenView: View {
  @EnvironmentObject private var store: AppStore
  @State private var zeigtNeu = false
  @State private var thema = ""

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 24) {
        PageHeader(
          titel: "Kanäle",
          untertitel:
            "Verwalte deine Blackstock-Kanäle, Google-Zugänge und die Einrichtung neuer YouTube-Kanäle.",
          trailing: AnyView(actions)
        )

        networkSummary
        zugangsSection

        if store.kanalPlaene.contains(where: { $0.status != .verbunden }) {
          planSection
        }

        if !store.kanaele.isEmpty {
          channelSection
        } else if store.kanalPlaene.isEmpty {
          EmptyState(
            symbol: "rectangle.stack.badge.plus",
            titel: "Dein Netzwerk beginnt hier",
            text:
              "Du brauchst noch keinen YouTube-Kanal. Lege zuerst ein Blackstock-Kanalprofil an. Blackstock bereitet Positionierung, Visual-DNA, Voice-DNA und Startformate vor.",
            button: "Ersten Kanal planen"
          ) { zeigtNeu = true }
        }
      }
      .padding(28)
    }
    .sheet(isPresented: $zeigtNeu) { newChannelSheet }
  }

  private var actions: some View {
    HStack(spacing: 9) {
      Button {
        Task { await store.liveDatenAktualisieren() }
      } label: {
        Label("Aktualisieren", systemImage: "arrow.clockwise")
      }
      .buttonStyle(.bordered)
      .disabled(store.googleZugaenge.isEmpty || store.istBeschaeftigt)

      Button {
        Task { _ = await store.googleZugangHinzufuegen() }
      } label: {
        Label("Mit Google verbinden", systemImage: "person.badge.plus")
      }
      .buttonStyle(.bordered)
      .disabled(store.istBeschaeftigt)

      Button {
        zeigtNeu = true
      } label: {
        Label("Kanal planen", systemImage: "plus")
      }
      .buttonStyle(.borderedProminent)
      .tint(Color.bsRed)
      .foregroundStyle(.white)
    }
  }

  private var networkSummary: some View {
    HStack(spacing: 0) {
      summary(
        "Google-Zugänge", "\(store.googleZugaenge.count)", "Getrennte sichere Anmeldungen", .bsBlue)
      Divider().overlay(Color.bsBorder).frame(height: 52).padding(.horizontal, 18)
      summary("Live-Kanäle", "\(store.liveKanaele.count)", "Mit YouTube verbunden", .bsGreen)
      Divider().overlay(Color.bsBorder).frame(height: 52).padding(.horizontal, 18)
      summary(
        "In Einrichtung", "\(store.kanalPlaene.filter { $0.status != .verbunden }.count)",
        "Vorbereitete Kanalprofile", .bsAmber)
      Divider().overlay(Color.bsBorder).frame(height: 52).padding(.horizontal, 18)
      summary(
        "Einnahmen · 28 T", store.gesamtUmsatz28Tage.euro, "Nur verfügbare Live-Daten", .bsText)
      Spacer(minLength: 0)
    }
    .blackstockCard(18, elevated: true)
  }

  private func summary(_ label: String, _ value: String, _ detail: String, _ color: Color)
    -> some View
  {
    VStack(alignment: .leading, spacing: 4) {
      Text(label.uppercased())
        .font(.system(size: 8, weight: .bold))
        .tracking(0.9)
        .foregroundStyle(Color.bsMuted)
      Text(value)
        .font(.system(size: 20, weight: .semibold, design: .rounded))
        .monospacedDigit()
        .foregroundStyle(color)
      Text(detail)
        .font(.system(size: 8.8))
        .foregroundStyle(Color.bsMuted2)
    }
    .frame(minWidth: 135, alignment: .leading)
  }

  private var zugangsSection: some View {
    VStack(alignment: .leading, spacing: 12) {
      AbschnittTitel(
        titel: "Zugänge",
        untertitel:
          "Verbinde Google sicher mit Blackstock. Ein Google-Konto kann mehrere YouTube-Kanäle verwalten; weitere Google-Zugänge lassen sich jederzeit ergänzen."
      )

      if store.googleZugaenge.isEmpty {
        Button {
          Task { _ = await store.googleZugangHinzufuegen() }
        } label: {
          HStack(spacing: 14) {
            ZStack {
              RoundedRectangle(cornerRadius: 12).fill(Color.bsSurface3).frame(width: 46, height: 46)
              Image(systemName: "person.badge.plus").font(.system(size: 17, weight: .medium))
                .foregroundStyle(Color.bsRed)
            }
            VStack(alignment: .leading, spacing: 3) {
              Text("Google-/YouTube-Zugang verbinden")
                .font(.system(size: 12.5, weight: .semibold))
                .foregroundStyle(Color.bsText)
              Text(
                "Einmal sicher bei Google anmelden. Danach übernimmt Blackstock Tokens, Kanal-ID und Synchronisierung."
              )
              .font(.system(size: 9.5))
              .foregroundStyle(Color.bsMuted)
            }
            Spacer()
            Image(systemName: "arrow.right")
              .foregroundStyle(Color.bsMuted)
          }
          .padding(16)
          .background(Color.bsSurface)
          .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.bsBorder, lineWidth: 1))
          .clipShape(RoundedRectangle(cornerRadius: 14))
        }
        .buttonStyle(.plain)

        if let signupURL = URL(string: "https://accounts.google.com/signup") {
          Link(destination: signupURL) {
            HStack(spacing: 6) {
              Image(systemName: "arrow.up.right.square")
              Text("Noch kein Google-Konto? Bei Google erstellen")
            }
            .font(.system(size: 10.5, weight: .medium))
            .foregroundStyle(Color.bsRed)
          }
        }
      } else {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 330), spacing: 12)], spacing: 12) {
          ForEach(store.googleZugaenge) { zugang in
            ZugangCard(zugang: zugang)
          }
        }
      }
    }
  }

  private var planSection: some View {
    VStack(alignment: .leading, spacing: 12) {
      AbschnittTitel(
        titel: "Einrichtung",
        untertitel: "Blackstock-Kanalprofile, die noch nicht vollständig mit YouTube verbunden sind"
      )
      ForEach(store.kanalPlaene.filter { $0.status != .verbunden }) { plan in
        KanalPlanCard(plan: plan)
      }
    }
  }

  private var channelSection: some View {
    VStack(alignment: .leading, spacing: 12) {
      AbschnittTitel(
        titel: "YouTube-Kanäle",
        untertitel: "Live-Performance, Monetarisierung, Qualität und operative Zuordnung"
      )
      LazyVGrid(columns: [GridItem(.adaptive(minimum: 380), spacing: 12)], spacing: 12) {
        ForEach(store.kanaele) { kanal in
          KanalCard(kanal: kanal)
            .onTapGesture { store.ausgewaehlterKanalID = kanal.id }
        }
      }
    }
  }

  private var newChannelSheet: some View {
    VStack(alignment: .leading, spacing: 20) {
      HStack(spacing: 13) {
        BlackstockMark(size: 40)
        VStack(alignment: .leading, spacing: 3) {
          Text("Kanalprofil anlegen")
            .font(.system(size: 20, weight: .semibold))
            .foregroundStyle(Color.bsText)
          Text("Der YouTube-Kanal muss noch nicht existieren.")
            .font(.system(size: 10))
            .foregroundStyle(Color.bsMuted)
        }
        Spacer()
      }

      VStack(alignment: .leading, spacing: 8) {
        Text("THEMENFELD")
          .font(.system(size: 8.5, weight: .bold))
          .tracking(0.9)
          .foregroundStyle(Color.bsMuted)
        TextField("z. B. Sport, Gaming, Technologie, KI", text: $thema)
          .textFieldStyle(.roundedBorder)
          .font(.system(size: 14))
      }

      if !thema.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
        VStack(alignment: .leading, spacing: 10) {
          Text("VORSCHAU")
            .font(.system(size: 8.5, weight: .bold))
            .tracking(0.9)
            .foregroundStyle(Color.bsMuted)
          HStack(spacing: 12) {
            BlackstockMark(size: 44)
            VStack(alignment: .leading, spacing: 4) {
              Text("Blackstock \(thema.trimmingCharacters(in: .whitespacesAndNewlines))")
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(Color.bsText)
              Text(
                "Originale Recherche · hochwertige Visuals · natürliche Stimme · kontrollierte Automation"
              )
              .font(.system(size: 9.5))
              .foregroundStyle(Color.bsMuted)
            }
          }
        }
        .blackstockCard()
      }

      HStack {
        Button("Abbrechen") { zeigtNeu = false }
          .buttonStyle(.bordered)
        Spacer()
        Button("Kanalprofil anlegen") {
          _ = store.kanalPlanAnlegen(thema: thema)
          thema = ""
          zeigtNeu = false
        }
        .buttonStyle(.borderedProminent)
        .tint(Color.bsRed)
        .foregroundStyle(.white)
        .disabled(thema.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
      }
    }
    .padding(26)
    .frame(width: 600)
    .background(Color.bsBackground)
  }
}

private struct ZugangCard: View {
  @EnvironmentObject private var store: AppStore
  let zugang: GoogleZugang

  var body: some View {
    VStack(alignment: .leading, spacing: 13) {
      HStack(spacing: 11) {
        ZStack {
          Circle().fill(Color.bsSurface3).frame(width: 38, height: 38)
          Text(String(zugang.anzeigename.prefix(1)).uppercased())
            .font(.system(size: 13, weight: .bold))
            .foregroundStyle(Color.bsText)
        }
        VStack(alignment: .leading, spacing: 2) {
          Text(zugang.youtubeChannelName ?? zugang.anzeigename)
            .font(.system(size: 12.5, weight: .semibold))
            .foregroundStyle(Color.bsText)
          Text(zugang.email)
            .font(.system(size: 9.2))
            .foregroundStyle(Color.bsMuted)
        }
        Spacer()
        StatusPunkt(text: zugang.status.rawValue, farbe: statusColor)
      }

      HStack {
        VStack(alignment: .leading, spacing: 3) {
          Text("YOUTUBE")
            .font(.system(size: 8, weight: .bold)).tracking(0.8).foregroundStyle(Color.bsMuted)
          Text(zugang.youtubeChannelName ?? "Noch kein Kanal")
            .font(.system(size: 10.5, weight: .medium))
            .foregroundStyle(zugang.youtubeChannelName == nil ? Color.bsMuted : Color.bsText)
        }
        Spacer()
        if let date = zugang.letzteSynchronisierung {
          VStack(alignment: .trailing, spacing: 3) {
            Text("LETZTER SYNC")
              .font(.system(size: 8, weight: .bold)).tracking(0.8).foregroundStyle(Color.bsMuted)
            Text(date.formatted(date: .omitted, time: .shortened))
              .font(.system(size: 10.5, weight: .medium))
              .foregroundStyle(Color.bsText)
          }
        }
      }

      Divider().overlay(Color.bsBorder)

      HStack {
        if zugang.status == .kanalFehlt {
          Text("Dieser Zugang ist bereit für einen neuen YouTube-Kanal.")
            .font(.system(size: 9))
            .foregroundStyle(Color.bsBlue)
        } else if zugang.status == .apiEinrichtung {
          Text("Google ist verbunden · YouTube-API muss noch aktiviert werden.")
            .font(.system(size: 9))
            .foregroundStyle(Color.bsAmber)
          Button("API aktivieren") { store.apiEinrichtungOeffnen() }
            .buttonStyle(.borderless)
            .font(.system(size: 9.5, weight: .semibold))
            .foregroundStyle(Color.bsRed)
          Button("Erneut prüfen") { Task { await store.apiEinrichtungErneutPruefen() } }
            .buttonStyle(.borderless)
            .font(.system(size: 9.5, weight: .medium))
            .foregroundStyle(Color.bsMuted)
        } else if zugang.status == .erneuern {
          Text("Die Verbindung muss erneut geprüft werden.")
            .font(.system(size: 9))
            .foregroundStyle(Color.bsAmber)
          Button("Erneut prüfen") { Task { await store.apiEinrichtungErneutPruefen() } }
            .buttonStyle(.borderless)
            .font(.system(size: 9.5, weight: .semibold))
            .foregroundStyle(Color.bsRed)
        } else {
          Text("Token sicher im macOS-Schlüsselbund")
            .font(.system(size: 9))
            .foregroundStyle(Color.bsMuted2)
        }
        Spacer()
        Button("Entfernen") { store.googleZugangEntfernen(zugang.id) }
          .buttonStyle(.plain)
          .font(.system(size: 9.5, weight: .medium))
          .foregroundStyle(Color.bsMuted)
      }
    }
    .blackstockCard(16)
  }

  private var statusColor: Color {
    switch zugang.status {
    case .verbunden: .bsGreen
    case .kanalFehlt, .bereit: .bsBlue
    case .apiEinrichtung, .erneuern: .bsAmber
    case .fehler: .bsRed
    }
  }
}

private struct KanalPlanCard: View {
  @EnvironmentObject private var store: AppStore
  let plan: KanalPlan

  var body: some View {
    VStack(alignment: .leading, spacing: 15) {
      HStack(alignment: .top) {
        BlackstockMark(size: 44)
        VStack(alignment: .leading, spacing: 4) {
          Text(plan.name)
            .font(.system(size: 14.5, weight: .semibold))
            .foregroundStyle(Color.bsText)
          Text("Noch nicht live · \(plan.thema)")
            .font(.system(size: 9.5))
            .foregroundStyle(Color.bsMuted)
        }
        Spacer()
        StatusPunkt(
          text: plan.status.rawValue, farbe: plan.status == .bereitZumVerbinden ? .bsGreen : .bsBlue
        )
      }

      BlackstockFortschritt(wert: plan.status.fortschritt, farbe: .bsBlue)

      HStack(spacing: 24) {
        MetricCell(label: "Handle-Idee", value: plan.handleVorschlag)
        MetricCell(label: "Startformate", value: "\(plan.startFormate.count)")
        MetricCell(label: "Uploads/Woche", value: "\(plan.empfohleneUploadsProWoche)")
        Spacer()
      }

      Text(plan.positionierung)
        .font(.system(size: 10.3))
        .foregroundStyle(Color.bsMuted)
        .lineSpacing(3)

      HStack(spacing: 9) {
        switch plan.status {
        case .vorgeschlagen, .vorbereitet:
          Button("Bei YouTube erstellen") {
            store.kanalPlanYoutubeStarten(plan.id)
          }
          .buttonStyle(.borderedProminent)
          .tint(Color.bsRed)
          .foregroundStyle(.white)
        case .youtubeErstellung, .bereitZumVerbinden:
          Button(store.istBeschaeftigt ? "Erkenne…" : "Jetzt erkennen") {
            Task { await store.kanalPlanVerbinden(plan.id) }
          }
          .buttonStyle(.borderedProminent)
          .tint(Color.bsRed)
          .foregroundStyle(.white)
          .disabled(store.istBeschaeftigt)
          Button("YouTube erneut öffnen") { store.kanalPlanYoutubeStarten(plan.id) }
            .buttonStyle(.bordered)
        case .verbunden:
          EmptyView()
        }
        Spacer()
        VertrauenBadge(konfidenz: plan.vertrauen)
      }
    }
    .blackstockCard(18, elevated: true)
  }
}

private struct KanalCard: View {
  let kanal: Kanal

  var body: some View {
    VStack(alignment: .leading, spacing: 15) {
      HStack(alignment: .top) {
        BlackstockMark(size: 46)
        VStack(alignment: .leading, spacing: 4) {
          Text(kanal.name)
            .font(.system(size: 14.5, weight: .semibold))
            .foregroundStyle(Color.bsText)
          Text(kanal.handle.isEmpty ? "YouTube-Kanal" : kanal.handle)
            .font(.system(size: 9.5))
            .foregroundStyle(Color.bsMuted)
        }
        Spacer()
        VStack(alignment: .trailing, spacing: 6) {
          StatusPunkt(text: kanal.status.rawValue, farbe: kanal.status.color)
          DatenquelleBadge(quelle: kanal.datenherkunft)
        }
      }

      HStack(spacing: 24) {
        MetricCell(label: "Abonnenten", value: kanal.abonnenten.kompakt)
        MetricCell(label: "Views · 28 T", value: kanal.views28Tage.kompakt)
        MetricCell(
          label: "Neue Abos · 28 T", value: "+\(kanal.abonnenten28Tage.kompakt)", accent: .bsGreen)
        MetricCell(label: "Einnahmen", value: kanal.umsatz28Tage.euro)
      }

      Divider().overlay(Color.bsBorder)

      HStack {
        VStack(alignment: .leading, spacing: 4) {
          Text("MONETARISIERUNG")
            .font(.system(size: 8, weight: .bold)).tracking(0.7).foregroundStyle(Color.bsMuted)
          Text(kanal.yppStatus.rawValue)
            .font(.system(size: 10.5, weight: .semibold))
            .foregroundStyle(Color.bsText)
        }
        Spacer()
        ScoreRing(wert: kanal.qualitaetsScore, label: "Qualität")
        ScoreRing(wert: kanal.vertrauensScore, label: "Vertrauen", farbe: .bsBlue)
      }
    }
    .blackstockCard(18)
  }
}
