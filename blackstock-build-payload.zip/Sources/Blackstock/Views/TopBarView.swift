import SwiftUI

struct TopBarView: View {
  @EnvironmentObject private var store: AppStore
  @State private var suche = ""
  @State private var zeigtTreffer = false

  var body: some View {
    HStack(spacing: 16) {
      Spacer(minLength: 12)

      HStack(spacing: 10) {
        Image(systemName: "magnifyingglass")
          .font(.system(size: 14, weight: .medium))
          .foregroundStyle(Color.bsMuted)
        TextField("Auf Blackstock suchen …", text: $suche)
          .textFieldStyle(.plain)
          .font(.system(size: 13))
          .onSubmit {
            zeigtTreffer = !suche.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
          }
        Text("⌘ K")
          .font(.system(size: 9, weight: .medium))
          .foregroundStyle(Color.bsMuted2)
          .padding(.horizontal, 7)
          .padding(.vertical, 4)
          .background(Color.bsSurface2)
          .clipShape(RoundedRectangle(cornerRadius: 6))
      }
      .padding(.horizontal, 14)
      .frame(maxWidth: 620, minHeight: 38)
      .background(Color.bsSurface2)
      .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
      .overlay(RoundedRectangle(cornerRadius: 11).stroke(Color.bsBorder, lineWidth: 1))
      .popover(isPresented: $zeigtTreffer, arrowEdge: .top) {
        GlobaleSucheView(query: suche)
          .environmentObject(store)
          .frame(width: 480, height: 420)
      }

      Spacer()

      Button {
        store.ausgewaehltesZiel = .factory
      } label: {
        Label("Erstellen", systemImage: "plus")
          .font(.system(size: 11.5, weight: .semibold))
      }
      .buttonStyle(.bordered)
      .controlSize(.large)

      Button {
        if store.apiEinrichtungsHinweis != nil {
          store.apiEinrichtungOeffnen()
        } else {
          Task { await store.liveDatenAktualisieren() }
        }
      } label: {
        Image(
          systemName: store.apiEinrichtungsHinweis != nil
            ? "exclamationmark.circle.fill" : "arrow.clockwise"
        )
        .font(.system(size: 14, weight: .medium))
        .frame(width: 24, height: 24)
      }
      .buttonStyle(.plain)
      .foregroundStyle(store.apiEinrichtungsHinweis != nil ? Color.bsRed : Color.bsText)
      .disabled(store.istBeschaeftigt || store.googleZugaenge.isEmpty)
      .help(
        store.googleZugaenge.isEmpty
          ? "Noch kein Google-Zugang verbunden"
          : (store.apiEinrichtungsHinweis != nil
            ? "YouTube-Einrichtung abschließen" : "Daten aktualisieren"))

      Menu {
        if store.googleZugaenge.isEmpty {
          Button("Mit Google verbinden") { Task { _ = await store.googleZugangHinzufuegen() } }
        } else {
          ForEach(store.googleZugaenge) { zugang in
            Text(zugang.email)
          }
        }
        Divider()
        Button("Einstellungen") { store.ausgewaehltesZiel = .einstellungen }
      } label: {
        ZStack {
          Circle().fill(Color.bsText).frame(width: 34, height: 34)
          Text(profileInitial)
            .font(.system(size: 12, weight: .bold))
            .foregroundStyle(Color.bsBackground)
        }
      }
      .menuStyle(.borderlessButton)
      .frame(width: 40)
    }
    .padding(.horizontal, 18)
    .frame(height: 58)
    .background(Color.bsBackground)
    .overlay(alignment: .bottom) { Divider().overlay(Color.bsBorder) }
  }

  private var profileInitial: String {
    if let first = store.googleZugaenge.first?.anzeigename.first {
      return String(first).uppercased()
    }
    return "B"
  }
}

private struct GlobaleSucheView: View {
  @EnvironmentObject private var store: AppStore
  let query: String

  private var q: String { query.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }
  private var kanaele: [Kanal] {
    store.kanaele.filter { $0.name.lowercased().contains(q) || $0.thema.lowercased().contains(q) }
      .prefix(5).map { $0 }
  }
  private var chancen: [Chance] {
    store.chancen.filter { $0.titel.lowercased().contains(q) || $0.thema.lowercased().contains(q) }
      .prefix(5).map { $0 }
  }
  private var produktionen: [Produktion] {
    store.produktionen.filter { $0.arbeitstitel.lowercased().contains(q) }.prefix(5).map { $0 }
  }
  private var videos: [VideoLeistung] {
    store.videos.filter { $0.titel.lowercased().contains(q) }.prefix(5).map { $0 }
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 18) {
        Text("Suchergebnisse")
          .font(.system(size: 16, weight: .semibold))
        if q.isEmpty {
          Text("Gib einen Kanal, ein Thema oder einen Videotitel ein.").foregroundStyle(
            Color.bsMuted)
        } else if kanaele.isEmpty && chancen.isEmpty && produktionen.isEmpty && videos.isEmpty {
          Text("Keine passenden Inhalte gefunden.").foregroundStyle(Color.bsMuted)
        } else {
          if !kanaele.isEmpty {
            section("Kanäle", kanaele.map { ($0.name, Navigationsziel.konten) })
          }
          if !chancen.isEmpty {
            section("Chancen", chancen.map { ($0.titel, Navigationsziel.chancen) })
          }
          if !produktionen.isEmpty {
            section("Studio", produktionen.map { ($0.arbeitstitel, Navigationsziel.produktionen) })
          }
          if !videos.isEmpty {
            section("Inhalte", videos.map { ($0.titel, Navigationsziel.veroeffentlicht) })
          }
        }
      }
      .padding(20)
    }
    .background(Color.bsBackground)
  }

  @ViewBuilder
  private func section(_ title: String, _ rows: [(String, Navigationsziel)]) -> some View {
    VStack(alignment: .leading, spacing: 7) {
      Text(title.uppercased())
        .font(.system(size: 9, weight: .bold))
        .tracking(0.8)
        .foregroundStyle(Color.bsMuted)
      ForEach(Array(rows.enumerated()), id: \.offset) { _, row in
        Button {
          store.ausgewaehltesZiel = row.1
        } label: {
          HStack {
            Text(row.0).lineLimit(1)
            Spacer()
            Image(systemName: "arrow.right")
              .foregroundStyle(Color.bsMuted)
          }
          .font(.system(size: 11.5, weight: .medium))
          .foregroundStyle(Color.bsText)
          .padding(.vertical, 7)
        }
        .buttonStyle(.plain)
      }
    }
  }
}
