import SwiftUI

struct RootView: View {
  @EnvironmentObject private var store: AppStore
  @Environment(\.scenePhase) private var scenePhase
  @AppStorage("blackstock.appearance") private var appearanceRaw = BlackstockAppearance.system
    .rawValue
  @State private var zeigtMeldung = false
  @State private var letzteSetupPruefung: Date = .distantPast

  private var appearance: BlackstockAppearance {
    BlackstockAppearance(rawValue: appearanceRaw) ?? .system
  }

  var body: some View {
    Group {
      if store.onboardingAbgeschlossen {
        HauptAppView()
      } else {
        OnboardingView()
      }
    }
    .preferredColorScheme(appearance.colorScheme)
    .background(Color.bsBackground)
    .onChange(of: store.meldung) { neuerWert in
      zeigtMeldung = neuerWert != nil
    }
    .alert("Blackstock", isPresented: $zeigtMeldung) {
      Button("OK") { store.meldung = nil }
    } message: {
      Text(store.meldung ?? "")
    }
    .onChange(of: scenePhase) { phase in
      guard phase == .active, store.apiEinrichtungsHinweis != nil, !store.istBeschaeftigt else {
        return
      }
      guard Date().timeIntervalSince(letzteSetupPruefung) > 3 else { return }
      letzteSetupPruefung = Date()
      Task {
        try? await Task.sleep(nanoseconds: 1_200_000_000)
        await store.apiEinrichtungErneutPruefen()
      }
    }
  }
}

struct HauptAppView: View {
  @EnvironmentObject private var store: AppStore

  var body: some View {
    NavigationSplitView {
      SidebarView()
        .navigationSplitViewColumnWidth(min: 200, ideal: 220, max: 245)
    } detail: {
      VStack(spacing: 0) {
        TopBarView()
        if let hinweis = store.apiEinrichtungsHinweis {
          APIEinrichtungsBanner(hinweis: hinweis)
            .environmentObject(store)
        }
        ZStack {
          Color.bsBackground.ignoresSafeArea()
          inhalt
        }
      }
    }
    .navigationSplitViewStyle(.balanced)
  }

  @ViewBuilder
  private var inhalt: some View {
    switch store.ausgewaehltesZiel {
    case .command: CommandView()
    case .chancen: ChancenView()
    case .factory: ProduktionenView()
    case .produktionen: ProduktionenView()
    case .veroeffentlicht: VeroeffentlichtView()
    case .kalender: VeroeffentlichtView()
    case .wachstum: WachstumView()
    case .konten: KanalStudioView()
    case .bibliothek: EinstellungenView()
    case .automatik: ProduktionenView()
    case .einnahmen: WachstumView()
    case .qualitaet: ProduktionenView()
    case .einstellungen: EinstellungenView()
    }
  }
}

private struct APIEinrichtungsBanner: View {
  @EnvironmentObject private var store: AppStore
  let hinweis: APIEinrichtungsHinweis

  var body: some View {
    HStack(spacing: 14) {
      ZStack {
        RoundedRectangle(cornerRadius: 10, style: .continuous)
          .fill(Color.bsRed.opacity(0.10))
          .frame(width: 38, height: 38)
        Image(systemName: "play.rectangle.on.rectangle")
          .font(.system(size: 16, weight: .semibold))
          .foregroundStyle(Color.bsRed)
      }

      VStack(alignment: .leading, spacing: 3) {
        Text(hinweis.titel)
          .font(.system(size: 12.5, weight: .semibold))
          .foregroundStyle(Color.bsText)
        Text(hinweis.text)
          .font(.system(size: 10.5))
          .foregroundStyle(Color.bsMuted)
          .lineLimit(2)
        if let projektID = hinweis.projektID {
          Text("Google-Cloud-Projekt · \(projektID)")
            .font(.system(size: 9.5, weight: .medium))
            .foregroundStyle(Color.bsMuted2)
        }
      }

      Spacer(minLength: 20)

      Button("API aktivieren") {
        store.apiEinrichtungOeffnen()
      }
      .buttonStyle(.borderedProminent)
      .tint(Color.bsRed)
      .foregroundStyle(.white)

      Button("Erneut prüfen") {
        Task { await store.apiEinrichtungErneutPruefen() }
      }
      .buttonStyle(.bordered)
      .disabled(store.istBeschaeftigt)
    }
    .padding(.horizontal, 18)
    .padding(.vertical, 10)
    .background(Color.bsSurface2)
    .overlay(alignment: .bottom) { Rectangle().fill(Color.bsBorder).frame(height: 1) }
  }
}
