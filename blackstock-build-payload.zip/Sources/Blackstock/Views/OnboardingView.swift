import AppKit
import SwiftUI
import UniformTypeIdentifiers

struct OnboardingView: View {
  @EnvironmentObject private var store: AppStore
  @State private var schritt = 0
  @State private var ausgewaehlteThemen: Set<String> = ["Technologie"]
  @State private var eigenesThema = ""
  @State private var oauthStatus = OAuthKonfigurationsstatus()
  @State private var googleResultat: GoogleZugang?

  private let vorschlaege = [
    "Sport", "Gaming", "Technologie", "KI", "Kultur", "Wirtschaft", "Wissenschaft",
  ]

  var body: some View {
    ZStack {
      Color.bsBackground.ignoresSafeArea()
      HStack(spacing: 0) {
        leftRail
        Divider().overlay(Color.bsBorder)
        currentStep
          .frame(maxWidth: .infinity, maxHeight: .infinity)
          .padding(42)
      }
    }
    .frame(minWidth: 1040, minHeight: 680)
    .onAppear { oauthStatus = store.youtube.oauthKonfigurationsstatus() }
  }

  private var leftRail: some View {
    VStack(alignment: .leading, spacing: 24) {
      HStack(spacing: 11) {
        BlackstockMark(size: 38)
        VStack(alignment: .leading, spacing: 1) {
          Text("BLACKSTOCK")
            .font(.system(size: 14, weight: .bold))
            .tracking(1.4)
            .foregroundStyle(Color.bsText)
          Text("MEDIA OPERATING SYSTEM")
            .font(.system(size: 7.5, weight: .semibold))
            .tracking(1.25)
            .foregroundStyle(Color.bsMuted)
        }
      }

      VStack(alignment: .leading, spacing: 10) {
        railStep(0, "Willkommen", "Grundlage")
        railStep(1, "Kanäle", "Kanalprofile")
        railStep(2, "Google & YouTube", "Zugriff")
        railStep(3, "Bereit", "Start")
      }

      Spacer()

      VStack(alignment: .leading, spacing: 7) {
        Label("Native macOS-App", systemImage: "laptopcomputer")
        Label("Tokens im Schlüsselbund", systemImage: "key.fill")
        Label("Keine Demo-Daten", systemImage: "checkmark.seal")
      }
      .font(.system(size: 9.5, weight: .medium))
      .foregroundStyle(Color.bsMuted)
    }
    .padding(26)
    .frame(width: 250)
    .frame(maxHeight: .infinity, alignment: .topLeading)
    .background(Color.bsSidebar)
  }

  private func railStep(_ index: Int, _ title: String, _ detail: String) -> some View {
    HStack(spacing: 10) {
      ZStack {
        Circle()
          .fill(
            index < schritt ? Color.bsGreen : (index == schritt ? Color.bsRed : Color.bsSurface3)
          )
          .frame(width: 24, height: 24)
        if index < schritt {
          Image(systemName: "checkmark")
            .font(.system(size: 9, weight: .bold))
            .foregroundStyle(.white)
        } else {
          Text("\(index + 1)")
            .font(.system(size: 8.5, weight: .bold))
            .foregroundStyle(index == schritt ? Color.white : Color.bsMuted)
        }
      }
      VStack(alignment: .leading, spacing: 1) {
        Text(title)
          .font(.system(size: 10.5, weight: index == schritt ? .semibold : .medium))
          .foregroundStyle(index <= schritt ? Color.bsText : Color.bsMuted)
        Text(detail)
          .font(.system(size: 8.5))
          .foregroundStyle(Color.bsMuted2)
      }
    }
  }

  @ViewBuilder
  private var currentStep: some View {
    switch schritt {
    case 0: willkommen
    case 1: netzwerk
    case 2: google
    default: fertig
    }
  }

  private var willkommen: some View {
    VStack(alignment: .leading, spacing: 28) {
      Spacer()
      BlackstockMark(size: 74)
      VStack(alignment: .leading, spacing: 12) {
        Text("Dein YouTube-Mediennetzwerk.\nEin System.")
          .font(.system(size: 42, weight: .semibold))
          .foregroundStyle(Color.bsText)
          .tracking(-0.8)
        Text(
          "Blackstock organisiert Kanäle, erkennt Themenchancen, steuert Produktionen, prüft Qualität und Vertrauen, veröffentlicht kontrolliert und verfolgt Wachstum sowie Einnahmen."
        )
        .font(.system(size: 13))
        .foregroundStyle(Color.bsMuted)
        .lineSpacing(5)
        .frame(maxWidth: 650, alignment: .leading)
      }

      HStack(spacing: 18) {
        feature(
          "scope", "Chancen",
          "Aktuelle Themen nach Nachfrage, Momentum, Wettbewerb und Vertrauen bewerten.")
        feature(
          "movieclapper", "Produktionen",
          "Videos von Recherche bis Upload als nachvollziehbare Produktionspipeline steuern.")
        feature(
          "chart.line.uptrend.xyaxis", "Lernen",
          "Performance, Abonnenten und Einnahmen pro Kanal und Video auswerten.")
      }

      HStack {
        Button("Einrichtung starten") { withAnimation(.easeInOut(duration: 0.18)) { schritt = 1 } }
          .buttonStyle(.borderedProminent)
          .tint(Color.bsRed)
          .foregroundStyle(.white)
          .controlSize(.large)
        Spacer()
        Text("Keine bestehenden YouTube-Kanäle erforderlich.")
          .font(.system(size: 9.5))
          .foregroundStyle(Color.bsMuted2)
      }
      Spacer()
    }
    .frame(maxWidth: 860, alignment: .leading)
  }

  private var netzwerk: some View {
    VStack(alignment: .leading, spacing: 24) {
      PageHeader(
        titel: "Deine Kanäle planen",
        untertitel:
          "Wähle die Themenfelder, mit denen Blackstock starten soll. Die YouTube-Kanäle müssen noch nicht existieren."
      )

      VStack(alignment: .leading, spacing: 13) {
        Text("THEMENFELDER")
          .font(.system(size: 8.5, weight: .bold))
          .tracking(1)
          .foregroundStyle(Color.bsMuted)

        FlowLayout(spacing: 8) {
          ForEach(vorschlaege, id: \.self) { thema in
            Button {
              if ausgewaehlteThemen.contains(thema) {
                ausgewaehlteThemen.remove(thema)
              } else {
                ausgewaehlteThemen.insert(thema)
              }
            } label: {
              HStack(spacing: 7) {
                Circle()
                  .fill(ausgewaehlteThemen.contains(thema) ? Color.bsRed : Color.bsMuted2)
                  .frame(width: 6, height: 6)
                Text(thema)
                  .font(.system(size: 11, weight: .medium))
              }
              .foregroundStyle(ausgewaehlteThemen.contains(thema) ? Color.bsText : Color.bsMuted)
              .padding(.horizontal, 12)
              .padding(.vertical, 8)
              .background(ausgewaehlteThemen.contains(thema) ? Color.bsSurface3 : Color.bsSurface)
              .overlay(
                RoundedRectangle(cornerRadius: 9).stroke(
                  ausgewaehlteThemen.contains(thema) ? Color.bsRed.opacity(0.28) : Color.bsBorder,
                  lineWidth: 1)
              )
              .clipShape(RoundedRectangle(cornerRadius: 9))
            }
            .buttonStyle(.plain)
          }
        }

        HStack {
          TextField("Eigenes Themenfeld", text: $eigenesThema)
            .textFieldStyle(.roundedBorder)
          Button("Hinzufügen") {
            let sauber = eigenesThema.trimmingCharacters(in: .whitespacesAndNewlines)
            if !sauber.isEmpty {
              ausgewaehlteThemen.insert(sauber)
              eigenesThema = ""
            }
          }
          .buttonStyle(.bordered)
          .disabled(eigenesThema.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
      }
      .blackstockCard(20, elevated: true)

      VStack(alignment: .leading, spacing: 10) {
        Text("BLACKSTOCK BEREITET VOR")
          .font(.system(size: 8.5, weight: .bold)).tracking(1).foregroundStyle(Color.bsMuted)
        HStack(spacing: 16) {
          prep("person.2.wave.2", "Zielgruppe")
          prep("rectangle.3.group", "Formate")
          prep("waveform", "Voice-DNA")
          prep("photo.stack", "Visual-DNA")
          prep("calendar.badge.clock", "Uploadstrategie")
        }
      }

      Spacer()
      HStack {
        Button("Zurück") { schritt = 0 }.buttonStyle(.bordered)
        Spacer()
        Button("Kanäle vorbereiten") {
          for thema in ausgewaehlteThemen.sorted()
          where !store.kanalPlaene.contains(where: {
            $0.thema.caseInsensitiveCompare(thema) == .orderedSame
          }) {
            _ = store.kanalPlanAnlegen(thema: thema)
          }
          withAnimation(.easeInOut(duration: 0.18)) { schritt = 2 }
        }
        .buttonStyle(.borderedProminent)
        .tint(Color.bsRed)
        .foregroundStyle(.white)
        .disabled(ausgewaehlteThemen.isEmpty)
      }
    }
    .frame(maxWidth: 860)
  }

  private var google: some View {
    VStack(alignment: .leading, spacing: 24) {
      PageHeader(
        titel: "Google & YouTube verbinden",
        untertitel:
          "Ein sicherer Login. Blackstock speichert niemals dein Google-Passwort. Weitere Zugänge kannst du später im Netzwerk ergänzen."
      )

      HStack(spacing: 16) {
        googleInfo(
          "lock.shield.fill", "Sicher", "OAuth-Tokens liegen verschlüsselt im macOS-Schlüsselbund.")
        googleInfo(
          "person.2.badge.gearshape", "Mehrere Zugänge",
          "Jeder Kanal kann seinem eigenen Google-/YouTube-Zugang zugeordnet werden.")
        googleInfo(
          "rectangle.stack.badge.plus", "0 Kanäle ist normal",
          "Wenn noch kein Kanal existiert, bleibt der Google-Zugang bereit und Blackstock führt dich anschließend durch die Erstellung."
        )
      }

      VStack(alignment: .leading, spacing: 14) {
        HStack {
          VStack(alignment: .leading, spacing: 3) {
            Text("GOOGLE-ANMELDUNG")
              .font(.system(size: 8.5, weight: .bold)).tracking(1).foregroundStyle(Color.bsMuted)
            Text(oauthStatus.zustand.rawValue)
              .font(.system(size: 13, weight: .semibold))
              .foregroundStyle(oauthReady ? Color.bsGreen : Color.bsAmber)
          }
          Spacer()
          StatusPunkt(
            text: oauthReady ? "Bereit" : "Einrichtung erforderlich",
            farbe: oauthReady ? .bsGreen : .bsAmber)
        }

        if !oauthReady {
          Text(
            "In einer ausgelieferten Blackstock-App ist diese Freigabe bereits eingebaut. Dieser Entwicklungs-Build benötigt einmalig eine Google-OAuth-Datei vom Typ „Desktop-App“. Web-Clients werden nicht akzeptiert, damit kein redirect_uri_mismatch entsteht."
          )
          .font(.system(size: 10.3))
          .foregroundStyle(Color.bsMuted)
          .lineSpacing(3)
          HStack {
            Button("Desktop-OAuth-Datei auswählen…") { importiereOAuthDatei() }
              .buttonStyle(.borderedProminent)
              .tint(Color.bsAmber)
              .foregroundStyle(.black)
            Button("Google Cloud öffnen") { store.youtube.oeffneGoogleCloudKonfiguration() }
              .buttonStyle(.bordered)
          }
        } else if let googleResultat {
          HStack(spacing: 12) {
            ZStack {
              Circle().fill(Color.bsSurface3).frame(width: 40, height: 40)
              Text(String(googleResultat.anzeigename.prefix(1)).uppercased())
                .font(.system(size: 13, weight: .bold)).foregroundStyle(Color.bsText)
            }
            VStack(alignment: .leading, spacing: 3) {
              Text(googleResultat.youtubeChannelName ?? googleResultat.anzeigename)
                .font(.system(size: 12.5, weight: .semibold)).foregroundStyle(Color.bsText)
              Text(googleResultat.email)
                .font(.system(size: 9.5)).foregroundStyle(Color.bsMuted)
            }
            Spacer()
            let farbe: Color =
              googleResultat.status == .verbunden
              ? .bsGreen : (googleResultat.status == .apiEinrichtung ? .bsAmber : .bsBlue)
            StatusPunkt(text: googleResultat.status.rawValue, farbe: farbe)
          }
          if googleResultat.status == .apiEinrichtung, store.apiEinrichtungsHinweis != nil {
            HStack(spacing: 10) {
              Image(systemName: "info.circle.fill").foregroundStyle(Color.bsAmber)
              Text(
                "Google ist bereits verbunden. Aktiviere jetzt einmalig die YouTube-API; Blackstock prüft nach der Rückkehr automatisch weiter."
              )
              .font(.system(size: 10))
              .foregroundStyle(Color.bsMuted)
              Spacer()
              Button("API aktivieren") { store.apiEinrichtungOeffnen() }
                .buttonStyle(.borderedProminent)
                .tint(Color.bsRed)
                .foregroundStyle(.white)
            }
          }
        } else {
          Button {
            Task { googleResultat = await store.googleZugangHinzufuegen() }
          } label: {
            HStack {
              Image(systemName: "person.crop.circle.badge.checkmark")
              Text(store.istBeschaeftigt ? "Google wird verbunden…" : "Mit Google fortfahren")
              Spacer()
              Image(systemName: "arrow.right")
            }
          }
          .buttonStyle(.borderedProminent)
          .tint(Color.bsRed)
          .foregroundStyle(.white)
          .controlSize(.large)
          .disabled(store.istBeschaeftigt)
        }
      }
      .blackstockCard(20, elevated: true)

      Spacer()
      HStack {
        Button("Zurück") { schritt = 1 }.buttonStyle(.bordered)
        Button("Später verbinden") { withAnimation { schritt = 3 } }
          .buttonStyle(.plain)
          .font(.system(size: 10, weight: .medium))
          .foregroundStyle(Color.bsMuted)
        Spacer()
        Button("Weiter") { withAnimation { schritt = 3 } }
          .buttonStyle(.borderedProminent)
          .tint(Color.bsRed)
          .foregroundStyle(.white)
          .disabled(!store.googleVerbunden && googleResultat == nil)
      }
    }
    .frame(maxWidth: 860)
  }

  private var fertig: some View {
    VStack(alignment: .leading, spacing: 26) {
      Spacer()
      ZStack {
        Circle().fill(Color.bsGreen.opacity(0.10)).frame(width: 72, height: 72)
        Image(systemName: "checkmark")
          .font(.system(size: 25, weight: .semibold))
          .foregroundStyle(Color.bsGreen)
      }

      VStack(alignment: .leading, spacing: 10) {
        Text("Blackstock ist bereit.")
          .font(.system(size: 34, weight: .semibold))
          .foregroundStyle(Color.bsText)
        Text(
          "Deine Kanalprofile sind vorbereitet. Im Netzwerk siehst du jetzt genau, welche Kanäle noch bei YouTube erstellt werden müssen, welche Zugänge verbunden sind und welche nächsten Schritte anstehen."
        )
        .font(.system(size: 12.5))
        .foregroundStyle(Color.bsMuted)
        .lineSpacing(4)
        .frame(maxWidth: 650, alignment: .leading)
      }

      HStack(spacing: 12) {
        setupStat("Kanalprofile", "\(store.kanalPlaene.count)", .bsBlue)
        setupStat("Google-Zugänge", "\(store.googleZugaenge.count)", .bsGreen)
        setupStat(
          "Live-Kanäle", "\(store.liveKanaele.count)",
          store.liveKanaele.isEmpty ? .bsMuted : .bsGreen)
      }

      Button("Blackstock öffnen") { store.onboardingAbschliessen(demo: false) }
        .buttonStyle(.borderedProminent)
        .tint(Color.bsRed)
        .foregroundStyle(.white)
        .controlSize(.large)

      Spacer()
    }
    .frame(maxWidth: 860, alignment: .leading)
  }

  private var oauthReady: Bool {
    oauthStatus.zustand == .eingebaut || oauthStatus.zustand == .importiert
  }

  private func importiereOAuthDatei() {
    let panel = NSOpenPanel()
    panel.title = "Google Desktop OAuth auswählen"
    panel.message = "Wähle die JSON-Datei eines Google-OAuth-Clients vom Typ Desktop-App."
    panel.allowedContentTypes = [.json]
    panel.allowsMultipleSelection = false
    panel.canChooseDirectories = false
    guard panel.runModal() == .OK, let url = panel.url else { return }
    do {
      try store.youtube.importiereDesktopOAuthDatei(url)
      oauthStatus = store.youtube.oauthKonfigurationsstatus()
      store.meldung = "Google-Anmeldung ist korrekt als Desktop-App eingerichtet."
    } catch {
      oauthStatus = store.youtube.oauthKonfigurationsstatus()
      store.meldung = error.localizedDescription
    }
  }

  private func feature(_ symbol: String, _ title: String, _ text: String) -> some View {
    VStack(alignment: .leading, spacing: 10) {
      Image(systemName: symbol).font(.system(size: 17, weight: .medium)).foregroundStyle(
        Color.bsGreen)
      Text(title).font(.system(size: 12.5, weight: .semibold)).foregroundStyle(Color.bsText)
      Text(text).font(.system(size: 9.5)).foregroundStyle(Color.bsMuted).lineSpacing(2)
    }
    .frame(maxWidth: .infinity, minHeight: 110, alignment: .topLeading)
    .blackstockCard(15)
  }

  private func prep(_ symbol: String, _ title: String) -> some View {
    HStack(spacing: 7) {
      Image(systemName: symbol).font(.system(size: 10)).foregroundStyle(Color.bsGreen)
      Text(title).font(.system(size: 9.5, weight: .medium)).foregroundStyle(Color.bsText)
    }
    .padding(.horizontal, 10).padding(.vertical, 8)
    .background(Color.bsSurface)
    .clipShape(RoundedRectangle(cornerRadius: 9))
  }

  private func googleInfo(_ symbol: String, _ title: String, _ text: String) -> some View {
    VStack(alignment: .leading, spacing: 9) {
      Image(systemName: symbol).font(.system(size: 17)).foregroundStyle(Color.bsGreen)
      Text(title).font(.system(size: 12.5, weight: .semibold)).foregroundStyle(Color.bsText)
      Text(text).font(.system(size: 9.5)).foregroundStyle(Color.bsMuted).fixedSize(
        horizontal: false, vertical: true)
    }
    .frame(maxWidth: .infinity, minHeight: 105, alignment: .topLeading)
    .blackstockCard(15)
  }

  private func setupStat(_ label: String, _ value: String, _ color: Color) -> some View {
    VStack(alignment: .leading, spacing: 4) {
      Text(label.uppercased()).font(.system(size: 8, weight: .bold)).tracking(0.8).foregroundStyle(
        Color.bsMuted)
      Text(value).font(.system(size: 23, weight: .semibold, design: .rounded)).foregroundStyle(
        color)
    }
    .frame(width: 150, alignment: .leading)
    .blackstockCard(14)
  }
}

private struct FlowLayout<Content: View>: View {
  let spacing: CGFloat
  @ViewBuilder let content: Content

  init(spacing: CGFloat = 8, @ViewBuilder content: () -> Content) {
    self.spacing = spacing
    self.content = content()
  }

  var body: some View {
    HStack(spacing: spacing) { content }
      .fixedSize(horizontal: false, vertical: true)
  }
}
