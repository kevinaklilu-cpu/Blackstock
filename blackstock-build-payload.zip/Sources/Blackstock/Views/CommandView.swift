import Charts
import SwiftUI

struct CommandView: View {
  @EnvironmentObject private var store: AppStore
  @State private var selectedChannelID: UUID?
  @State private var range: AnalyticsRangePreset = .twentyEightDays
  @State private var metric: AnalyticsMetric = .views
  @State private var customStart = Calendar.current.date(byAdding: .day, value: -27, to: Date()) ?? Date()
  @State private var customEnd = Date()

  private var points: [AnalyticsDailyPoint] {
    store.analyticsPoints(
      channelID: selectedChannelID, preset: range,
      customStart: range == .custom ? customStart : nil,
      customEnd: range == .custom ? customEnd : nil)
  }

  private var summary: AnalyticsSummary {
    AnalyticsNormalizer.summary(points)
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 18) {
        header
        controls
        kpis
        chartCard
        HStack(alignment: .top, spacing: 14) {
          trendCard.frame(maxWidth: .infinity)
          productionCard.frame(maxWidth: .infinity)
          recentVideos.frame(maxWidth: .infinity)
        }
      }
      .padding(.horizontal, 28)
      .padding(.vertical, 24)
    }
    .background(Color.bsBackground)
  }

  private var header: some View {
    HStack(alignment: .firstTextBaseline) {
      VStack(alignment: .leading, spacing: 5) {
        Text("Übersicht")
          .font(.system(size: 31, weight: .bold))
          .foregroundStyle(Color.bsText)
        Text("Performance, aktuelle Chancen und Produktionsqueue auf einen Blick.")
          .font(.system(size: 13))
          .foregroundStyle(Color.bsMuted)
      }
      Spacer()
      if store.liveKanaele.isEmpty {
        Button("YouTube verbinden") { store.ausgewaehltesZiel = .konten }
          .buttonStyle(.borderedProminent)
          .tint(Color.bsRed)
          .foregroundStyle(.white)
      } else {
        Button {
          Task { await store.liveDatenAktualisieren() }
        } label: {
          Label(store.istBeschaeftigt ? "Aktualisiere …" : "Aktualisieren", systemImage: "arrow.clockwise")
        }
        .buttonStyle(.bordered)
        .disabled(store.istBeschaeftigt)
      }
    }
  }

  private var controls: some View {
    HStack(spacing: 12) {
      Picker("Kanal", selection: $selectedChannelID) {
        Text("Alle Kanäle").tag(UUID?.none)
        ForEach(store.liveKanaele) { kanal in
          Text(kanal.name).tag(Optional(kanal.id))
        }
      }
      .frame(width: 220)

      Picker("Zeitraum", selection: $range) {
        ForEach(AnalyticsRangePreset.allCases) { item in Text(item.rawValue).tag(item) }
      }
      .frame(width: 170)

      if range == .custom {
        DatePicker("Von", selection: $customStart, displayedComponents: .date)
          .labelsHidden()
        Text("–").foregroundStyle(Color.bsMuted)
        DatePicker("Bis", selection: $customEnd, displayedComponents: .date)
          .labelsHidden()
      }
      Spacer()
    }
  }

  private var kpis: some View {
    HStack(spacing: 12) {
      dashboardKPI("Aufrufe", summary.views > 0 ? summary.views.kompakt : "–", "eye.fill")
      dashboardKPI("Watchtime", summary.watchTimeMinutes > 0 ? watchTimeText(summary.watchTimeMinutes) : "–", "clock.fill")
      dashboardKPI("Abonnenten netto", summary.subscribersNet == 0 && points.isEmpty ? "–" : signed(summary.subscribersNet), "person.badge.plus")
      dashboardKPI(
        "Geschätzter Umsatz",
        summary.estimatedRevenue.map(\.euro) ?? "Nicht verfügbar",
        summary.estimatedRevenue == nil ? "lock.fill" : "eurosign.circle.fill")
    }
  }

  private func dashboardKPI(_ title: String, _ value: String, _ icon: String) -> some View {
    HStack(spacing: 14) {
      ZStack {
        RoundedRectangle(cornerRadius: 12).fill(Color.bsRed.opacity(0.08)).frame(width: 46, height: 46)
        Image(systemName: icon).font(.system(size: 18, weight: .semibold)).foregroundStyle(Color.bsRed)
      }
      VStack(alignment: .leading, spacing: 4) {
        Text(title).font(.system(size: 10.5, weight: .medium)).foregroundStyle(Color.bsMuted)
        Text(value).font(.system(size: 21, weight: .bold, design: .rounded)).monospacedDigit()
          .foregroundStyle(Color.bsText).lineLimit(1)
      }
      Spacer()
    }
    .blackstockCard(15)
    .frame(maxWidth: .infinity)
  }

  private var chartCard: some View {
    VStack(alignment: .leading, spacing: 14) {
      HStack {
        VStack(alignment: .leading, spacing: 3) {
          Text("Performance").font(.system(size: 14, weight: .semibold)).foregroundStyle(Color.bsText)
          Text("Tageswerte aus YouTube Analytics · keine kumulierten Video-Gesamtwerte")
            .font(.system(size: 9.5)).foregroundStyle(Color.bsMuted)
        }
        Spacer()
        Picker("Kennzahl", selection: $metric) {
          ForEach(AnalyticsMetric.allCases) { item in
            if item != .revenue || summary.estimatedRevenue != nil {
              Text(item.rawValue).tag(item)
            }
          }
        }
        .pickerStyle(.segmented)
        .frame(width: 410)
      }

      if points.isEmpty {
        VStack(spacing: 10) {
          Image(systemName: "chart.xyaxis.line").font(.system(size: 24)).foregroundStyle(Color.bsMuted)
          Text("Noch keine Analytics-Tageswerte für diese Auswahl")
            .font(.system(size: 12, weight: .semibold)).foregroundStyle(Color.bsText)
          Text("Verbinde einen Kanal und aktualisiere Analytics. Blackstock erzeugt hier keine Demo- oder Zufallsdaten.")
            .font(.system(size: 10)).foregroundStyle(Color.bsMuted).multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, minHeight: 230)
      } else {
        Chart(points) { point in
          LineMark(
            x: .value("Datum", point.date),
            y: .value(metric.rawValue, metricValue(point)))
            .interpolationMethod(.monotone)
            .foregroundStyle(Color.bsRed)
          AreaMark(
            x: .value("Datum", point.date),
            y: .value(metric.rawValue, metricValue(point)))
            .foregroundStyle(Color.bsRed.opacity(0.06))
        }
        .chartXAxis {
          AxisMarks(values: .automatic(desiredCount: 7)) { _ in
            AxisGridLine().foregroundStyle(Color.bsBorder.opacity(0.6))
            AxisValueLabel(format: .dateTime.day().month(.abbreviated))
          }
        }
        .chartYAxis {
          AxisMarks(position: .leading) { _ in
            AxisGridLine().foregroundStyle(Color.bsBorder.opacity(0.6))
            AxisValueLabel()
          }
        }
        .frame(height: 270)
      }
    }
    .blackstockCard(18)
  }

  private func metricValue(_ point: AnalyticsDailyPoint) -> Double {
    switch metric {
    case .views: Double(point.views)
    case .watchTime: point.watchTimeMinutes / 60
    case .subscribers: Double(point.subscribersNet)
    case .revenue: point.estimatedRevenue ?? 0
    }
  }

  private var trendCard: some View {
    dashboardCard(title: "Trend-Chancen", subtitle: "Kanalrelevante Signale", destination: .chancen) {
      let list = store.chancen.filter { !$0.istDemo || store.demoModus }
        .sorted { $0.trendScore > $1.trendScore }.prefix(4)
      if list.isEmpty {
        compactEmpty("Noch keine Trends geladen", button: "Trends öffnen") { store.ausgewaehltesZiel = .chancen }
      } else {
        VStack(spacing: 11) {
          ForEach(Array(list)) { chance in
            HStack(spacing: 10) {
              VStack(alignment: .leading, spacing: 3) {
                Text(chance.titel).font(.system(size: 10.5, weight: .semibold)).foregroundStyle(Color.bsText).lineLimit(2)
                Text("\(chance.thema) · \(Int(chance.trendScore)) Trend")
                  .font(.system(size: 8.5)).foregroundStyle(Color.bsMuted)
              }
              Spacer()
              Image(systemName: "chevron.right").font(.system(size: 9)).foregroundStyle(Color.bsMuted2)
            }
          }
        }
      }
    }
  }

  private var productionCard: some View {
    dashboardCard(title: "Produktionsqueue", subtitle: "Nächste operative Schritte", destination: .produktionen) {
      let list = store.produktionen.filter { store.v11Produktion(for: $0.id).phase != .published }
        .sorted { $0.erstelltAm > $1.erstelltAm }.prefix(4)
      if list.isEmpty {
        compactEmpty("Keine aktive Produktion", button: "Trends öffnen") { store.ausgewaehltesZiel = .chancen }
      } else {
        VStack(spacing: 11) {
          ForEach(Array(list)) { production in
            let state = store.v11Produktion(for: production.id)
            HStack(spacing: 10) {
              Image(systemName: production.format == .short ? "rectangle.portrait.fill" : "rectangle.fill")
                .foregroundStyle(Color.bsRed).frame(width: 18)
              VStack(alignment: .leading, spacing: 4) {
                Text(production.arbeitstitel).font(.system(size: 10.5, weight: .semibold)).foregroundStyle(Color.bsText).lineLimit(1)
                HStack(spacing: 7) {
                  Text(state.phase.rawValue).font(.system(size: 8.5)).foregroundStyle(Color.bsMuted)
                  BlackstockFortschritt(wert: state.progress, farbe: .bsRed).frame(width: 80)
                }
              }
              Spacer()
            }
          }
        }
      }
    }
  }

  private var recentVideos: some View {
    dashboardCard(title: "Neueste Videos", subtitle: "Zuletzt veröffentlichte Inhalte", destination: .veroeffentlicht) {
      let list = store.videos.filter { !$0.istDemo || store.demoModus }
        .sorted { $0.veroeffentlichtAm > $1.veroeffentlichtAm }.prefix(4)
      if list.isEmpty {
        compactEmpty("Noch nichts veröffentlicht", button: "Produktionen öffnen") { store.ausgewaehltesZiel = .produktionen }
      } else {
        VStack(spacing: 11) {
          ForEach(Array(list)) { video in
            HStack {
              VStack(alignment: .leading, spacing: 3) {
                Text(video.titel).font(.system(size: 10.5, weight: .semibold)).foregroundStyle(Color.bsText).lineLimit(1)
                Text("\(video.views.kompakt) Views · \(video.format.rawValue)")
                  .font(.system(size: 8.5)).foregroundStyle(Color.bsMuted)
              }
              Spacer()
            }
          }
        }
      }
    }
  }

  private func dashboardCard<Content: View>(
    title: String, subtitle: String, destination: Navigationsziel,
    @ViewBuilder content: () -> Content
  ) -> some View {
    VStack(alignment: .leading, spacing: 14) {
      HStack {
        VStack(alignment: .leading, spacing: 2) {
          Text(title).font(.system(size: 12.5, weight: .semibold)).foregroundStyle(Color.bsText)
          Text(subtitle).font(.system(size: 9)).foregroundStyle(Color.bsMuted)
        }
        Spacer()
        Button("Öffnen") { store.ausgewaehltesZiel = destination }
          .buttonStyle(.plain).font(.system(size: 9.5, weight: .semibold)).foregroundStyle(Color.bsRed)
      }
      content()
    }
    .blackstockCard(16)
  }

  private func compactEmpty(_ text: String, button: String, action: @escaping () -> Void) -> some View {
    VStack(spacing: 9) {
      Text(text).font(.system(size: 10.5)).foregroundStyle(Color.bsMuted)
      Button(button, action: action).buttonStyle(.bordered).controlSize(.small)
    }
    .frame(maxWidth: .infinity, minHeight: 100)
  }

  private func watchTimeText(_ minutes: Double) -> String {
    let hours = minutes / 60
    return hours >= 1_000 ? String(format: "%.1f Tsd. h", hours / 1_000) : String(format: "%.1f h", hours)
  }

  private func signed(_ value: Int) -> String { value > 0 ? "+\(value.kompakt)" : value.kompakt }
}
