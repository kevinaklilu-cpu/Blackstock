import AppKit
import SwiftUI

private enum ContentCenterTab: String, CaseIterable, Identifiable {
  case alle = "Alle"
  case entwürfe = "Entwürfe"
  case review = "Review"
  case geplant = "Geplant"
  case veröffentlicht = "Veröffentlicht"
  case fehler = "Fehler"
  var id: String { rawValue }
}

struct VeroeffentlichtView: View {
  @EnvironmentObject private var store: AppStore
  @State private var kanalFilter: UUID?
  @State private var tab: ContentCenterTab = .alle
  @State private var suche = ""
  @State private var formatFilter: VideoFormat?
  @State private var zeitraumTage: Int?
  @State private var pendingDelete: Produktion?

  private var projekte: [Produktion] {
    let query = suche.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    return store.produktionen.filter { p in
      let kanalPasst = kanalFilter == nil || p.kanalID == kanalFilter
      let suchePasst =
        query.isEmpty || p.arbeitstitel.lowercased().contains(query)
        || (p.beschreibung ?? "").lowercased().contains(query)
      let formatPasst = formatFilter == nil || p.format == formatFilter
      let zeitPasst: Bool = {
        guard let days = zeitraumTage else { return true }
        let datum = p.aktualisiertAm ?? p.erstelltAm
        return datum >= Calendar.current.date(byAdding: .day, value: -days, to: Date()) ?? .distantPast
      }()
      let phase = store.v11State.productionState(for: p.id)?.phase
      let tabPasst: Bool = {
        switch tab {
        case .alle: return true
        case .entwürfe:
          return phase.map { [.draft, .discoveringSources, .analyzingSources, .planning, .fetchingMedia, .editing, .rendering].contains($0) }
            ?? (![.bereit, .geplant, .live, .blockiert].contains(p.status) && p.letzterFehler == nil)
        case .review: return phase == .review || phase == .ready
        case .geplant: return phase == .scheduled || p.geplantFuer != nil || p.status == .geplant
        case .veröffentlicht: return phase == .published || p.youtubeVideoID != nil || p.status == .live
        case .fehler: return phase == .failed || p.letzterFehler != nil || p.status == .blockiert
        }
      }()
      return kanalPasst && suchePasst && formatPasst && zeitPasst && tabPasst
    }.sorted { ($0.aktualisiertAm ?? $0.erstelltAm) > ($1.aktualisiertAm ?? $1.erstelltAm) }
  }

  private var veroeffentlichteVideos: [VideoLeistung] {
    guard tab == .alle || tab == .veröffentlicht else { return [] }
    let query = suche.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    return store.videos.filter { v in
      let zeitPasst: Bool = {
        guard let days = zeitraumTage else { return true }
        return v.veroeffentlichtAm >= Calendar.current.date(byAdding: .day, value: -days, to: Date()) ?? .distantPast
      }()
      return (kanalFilter == nil || v.kanalID == kanalFilter)
        && (formatFilter == nil || v.format == formatFilter)
        && zeitPasst
        && (query.isEmpty || v.titel.lowercased().contains(query))
    }.sorted { $0.veroeffentlichtAm > $1.veroeffentlichtAm }
  }

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 18) {
        PageHeader(
          titel: "Inhalte",
          untertitel:
            "Professionelle Content-Liste für Produktionen, Review, Planung, Uploads und veröffentlichte YouTube-Videos – mit echten Leistungsdaten statt Quality-Scores.",
          trailing: AnyView(headerActions))

        metrics
        controls

        if projekte.isEmpty && veroeffentlichteVideos.isEmpty {
          EmptyState(
            symbol: "play.rectangle.on.rectangle", titel: "Keine Inhalte in dieser Ansicht",
            text:
              "Erstelle Inhalte aus Chancen oder starte eine Serie in Erstellen. Blackstock führt Projekte bis Master, Review und Upload.",
            button: "Content erstellen"
          ) { store.ausgewaehltesZiel = .produktionen }
        } else {
          if !projekte.isEmpty { projektTabelle }
          if !veroeffentlichteVideos.isEmpty { publishedSection }
        }
      }
      .padding(26)
    }
    .alert("Projekt löschen?", isPresented: Binding(
      get: { pendingDelete != nil },
      set: { if !$0 { pendingDelete = nil } }
    )) {
      Button("Abbrechen", role: .cancel) { pendingDelete = nil }
      Button("Projekt und erzeugte Arbeitsdateien löschen", role: .destructive) {
        if let item = pendingDelete { store.produktionLoeschen(item.id, erzeugteDateienLoeschen: true) }
        pendingDelete = nil
      }
    } message: {
      Text("Nur von Blackstock verwaltete/erzeugte Arbeitsdateien werden gelöscht. Importierte oder gemeinsam genutzte Originalquellen bleiben erhalten.")
    }
  }

  private var headerActions: some View {
    HStack(spacing: 9) {
      Button {
        store.ausgewaehltesZiel = .produktionen
      } label: {
        Label("Neue Produktion", systemImage: "plus")
      }
      .buttonStyle(.borderedProminent).tint(Color.bsRed).foregroundStyle(.white)
    }
  }

  private var metrics: some View {
    HStack(spacing: 12) {
      metric("Projekte", store.produktionen.count, .bsBlue)
      metric(
        "Review bereit",
        store.produktionen.filter { $0.lokaleDatei != nil && $0.youtubeVideoID == nil }.count,
        .bsGreen)
      metric("Geplant", store.produktionen.filter { $0.geplantFuer != nil }.count, .bsAmber)
      metric("Veröffentlicht", store.videos.count, .bsRed)
    }
  }

  private func metric(_ label: String, _ value: Int, _ color: Color) -> some View {
    HStack(spacing: 10) {
      Circle().fill(color).frame(width: 8, height: 8)
      VStack(alignment: .leading, spacing: 2) {
        Text("\(value)").font(.system(size: 18, weight: .semibold, design: .rounded))
          .foregroundStyle(Color.bsText)
        Text(label).font(.system(size: 9.3)).foregroundStyle(Color.bsMuted)
      }
      Spacer()
    }
    .frame(maxWidth: .infinity)
    .blackstockCard(13)
  }

  private var controls: some View {
    VStack(alignment: .leading, spacing: 12) {
      Picker("Status", selection: $tab) {
        ForEach(ContentCenterTab.allCases) { Text($0.rawValue).tag($0) }
      }
      .pickerStyle(.segmented)

      HStack(spacing: 10) {
        HStack(spacing: 8) {
          Image(systemName: "magnifyingglass").foregroundStyle(Color.bsMuted)
          TextField("Titel oder Beschreibung suchen", text: $suche)
            .textFieldStyle(.plain)
        }
        .padding(.horizontal, 11).frame(height: 34)
        .background(Color.bsSurface2).clipShape(RoundedRectangle(cornerRadius: 8))
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.bsBorder))

        Picker("Kanal", selection: $kanalFilter) {
          Text("Alle Kanäle").tag(UUID?.none)
          ForEach(store.kanaele) { Text($0.name).tag(Optional($0.id)) }
        }
        .frame(width: 190)
        Picker("Format", selection: $formatFilter) {
          Text("Alle Formate").tag(VideoFormat?.none)
          ForEach(VideoFormat.allCases, id: \.self) { Text($0.rawValue).tag(Optional($0)) }
        }.frame(width: 150)
        Picker("Zeitraum", selection: $zeitraumTage) {
          Text("Gesamt").tag(Int?.none)
          Text("7 Tage").tag(Optional(7)); Text("28 Tage").tag(Optional(28)); Text("90 Tage").tag(Optional(90)); Text("365 Tage").tag(Optional(365))
        }.frame(width: 135)
      }
    }
  }

  private var projektTabelle: some View {
    VStack(spacing: 0) {
      tableHeader
      ForEach(projekte) { p in
        projektRow(p)
        Divider().overlay(Color.bsBorder)
      }
    }
    .blackstockCard(0)
  }

  private var tableHeader: some View {
    HStack {
      Text("INHALT").frame(maxWidth: .infinity, alignment: .leading)
      Text("FORMAT").frame(width: 76, alignment: .leading)
      Text("STATUS").frame(width: 100, alignment: .leading)
      Text("VIEWS").frame(width: 72, alignment: .trailing)
      Text("WATCHTIME").frame(width: 82, alignment: .trailing)
      Text("CTR").frame(width: 64, alignment: .trailing)
      Text("REVENUE").frame(width: 82, alignment: .trailing)
      Text("VERÖFFENTLICHUNG").frame(width: 132, alignment: .trailing)
      Text("").frame(width: 34)
    }
    .font(.system(size: 8.5, weight: .bold)).tracking(1).foregroundStyle(Color.bsMuted)
    .padding(.horizontal, 16).padding(.vertical, 11).background(Color.bsSurface2)
  }

  private func projektRow(_ p: Produktion) -> some View {
    HStack(spacing: 12) {
      thumbnail(p)
      VStack(alignment: .leading, spacing: 4) {
        Text(p.arbeitstitel).font(.system(size: 11.5, weight: .semibold)).foregroundStyle(
          Color.bsText
        )
        .lineLimit(1)
        Text(
          "\(store.kanalName(fuer: p.kanalID)) · \(p.format.rawValue) · \(p.modus?.rawValue ?? "Studio")"
        )
        .font(.system(size: 9)).foregroundStyle(Color.bsMuted)
        if let text = p.letzterFehler, !text.isEmpty {
          Text(text).font(.system(size: 8.7)).foregroundStyle(Color.bsRed).lineLimit(1)
        } else if let description = p.beschreibung, !description.isEmpty {
          Text(description.replacingOccurrences(of: "\n", with: " "))
            .font(.system(size: 8.7)).foregroundStyle(Color.bsMuted2).lineLimit(1)
        }
      }
      .frame(maxWidth: .infinity, alignment: .leading)

      Text(p.format.rawValue).font(.system(size: 9.2, weight: .medium)).foregroundStyle(Color.bsText)
        .frame(width: 76, alignment: .leading)

      StatusPunkt(text: statusText(p), farbe: statusColor(p))
        .frame(width: 100, alignment: .leading)

      let performance = performanceForProduction(p)
      Text(performance.map { $0.views.kompakt } ?? "–").frame(width: 72, alignment: .trailing)
      Text(performance.map { watchtimeText($0.watchtimeMinuten) } ?? "–").frame(width: 82, alignment: .trailing)
      Text(performance?.thumbnailCTR.map { String(format: "%.1f%%", $0) } ?? "–").frame(width: 64, alignment: .trailing)
      Text(revenueText(performance)).frame(width: 82, alignment: .trailing)

      Text(publicationText(p))
        .font(.system(size: 9.3)).foregroundStyle(Color.bsMuted)
        .frame(width: 132, alignment: .trailing)

      Menu {
        Button("Öffnen") {
          store.ausgewaehlteProduktionID = p.id
          store.ausgewaehltesZiel = .produktionen
        }
        Button("Analytics") { store.ausgewaehltesZiel = .wachstum }
        if let youtubeID = p.youtubeVideoID, let url = URL(string: "https://www.youtube.com/watch?v=\(youtubeID)") {
          Button("Auf YouTube öffnen") { NSWorkspace.shared.open(url) }
        }
        Button("Duplizieren") { _ = store.produktionDuplizieren(p.id) }
        Button("Metadaten bearbeiten") {
          store.ausgewaehlteProduktionID = p.id
          store.ausgewaehltesZiel = .produktionen
        }
        if let path = p.lokaleDatei, FileManager.default.fileExists(atPath: path) {
          Button("Master im Finder zeigen") {
            NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: path)])
          }
        }
        if store.istFreigabeBereit(p), p.youtubeVideoID == nil, p.lokaleDatei != nil {
          Divider()
          Button("Zu YouTube hochladen") { Task { await store.produktionHochladen(p.id) } }
        }
        Divider()
        Button("Projekt löschen …", role: .destructive) { pendingDelete = p }
      } label: {
        Image(systemName: "ellipsis").frame(width: 34)
      }
      .menuStyle(.borderlessButton)
    }
    .padding(.horizontal, 16).padding(.vertical, 11)
  }

  private func thumbnail(_ p: Produktion) -> some View {
    ZStack {
      RoundedRectangle(cornerRadius: 7).fill(Color.bsSurface3)
      if let path = p.thumbnailDatei, let image = NSImage(contentsOfFile: path) {
        Image(nsImage: image).resizable().scaledToFill()
      } else {
        Image(systemName: p.format == .short ? "rectangle.portrait.fill" : "play.rectangle.fill")
          .foregroundStyle(Color.bsMuted)
      }
    }
    .frame(width: 86, height: 49).clipShape(RoundedRectangle(cornerRadius: 7))
  }

  private func statusText(_ p: Produktion) -> String {
    if let phase = store.v11State.productionState(for: p.id)?.phase { return phase.rawValue }
    if p.youtubeVideoID != nil || p.status == .live { return "Veröffentlicht" }
    if p.letzterFehler != nil || p.status == .blockiert { return "Fehlgeschlagen" }
    if p.geplantFuer != nil || p.status == .geplant { return "Geplant" }
    return p.status.rawValue
  }

  private func statusColor(_ p: Produktion) -> Color {
    switch store.v11State.productionState(for: p.id)?.phase {
    case .published: return .bsGreen
    case .scheduled: return .bsBlue
    case .failed: return .bsRed
    case .review, .ready: return .bsGreen
    case .uploading, .rendering, .fetchingMedia, .editing, .planning, .analyzingSources, .discoveringSources: return .bsAmber
    default: break
    }
    if p.youtubeVideoID != nil || p.status == .live { return .bsGreen }
    if p.letzterFehler != nil || p.status == .blockiert { return .bsRed }
    return .bsMuted
  }

  private func performanceForProduction(_ p: Produktion) -> VideoLeistung? {
    if let youtubeID = p.youtubeVideoID,
       let exact = store.videos.first(where: { $0.youtubeVideoID == youtubeID }) { return exact }
    return nil
  }

  private func watchtimeText(_ minutes: Int) -> String {
    if minutes >= 60 { return String(format: "%.1f h", Double(minutes) / 60.0) }
    return "\(minutes) min"
  }

  private func revenueText(_ performance: VideoLeistung?) -> String {
    guard let performance, performance.umsatzVerfuegbar == true else { return "–" }
    return performance.umsatz.euro
  }

  private func publicationText(_ p: Produktion) -> String {
    if let planned = p.geplantFuer { return planned.formatted(date: .abbreviated, time: .shortened) }
    if let video = performanceForProduction(p) { return video.veroeffentlichtAm.formatted(date: .abbreviated, time: .omitted) }
    return "–"
  }

  private var publishedSection: some View {
    VStack(alignment: .leading, spacing: 10) {
      AbschnittTitel(
        titel: "Veröffentlichte Videos",
        untertitel: "Synchronisierte YouTube-Leistung und lokale Veröffentlichungshistorie")
      VStack(spacing: 0) {
        ForEach(veroeffentlichteVideos) { video in
          HStack(spacing: 12) {
            ZStack {
              RoundedRectangle(cornerRadius: 7).fill(Color.bsSurface3)
              Image(systemName: "play.fill").foregroundStyle(Color.bsRed)
            }.frame(width: 76, height: 43)
            VStack(alignment: .leading, spacing: 3) {
              Text(video.titel).font(.system(size: 11, weight: .medium)).foregroundStyle(
                Color.bsText
              )
              .lineLimit(1)
              Text("\(store.kanalName(fuer: video.kanalID)) · \(video.format.rawValue)")
                .font(.system(size: 8.8)).foregroundStyle(Color.bsMuted)
            }.frame(maxWidth: .infinity, alignment: .leading)
            Text(video.views.kompakt).frame(width: 80, alignment: .trailing)
            Text(video.thumbnailCTR.map { String(format: "%.1f%% CTR", $0) } ?? "–")
              .frame(width: 80, alignment: .trailing)
            Text(video.umsatz.euro).frame(width: 90, alignment: .trailing)
            Menu {
              if let youtubeID = video.youtubeVideoID,
                let url = URL(string: "https://www.youtube.com/watch?v=\(youtubeID)")
              {
                Button("Auf YouTube öffnen") { NSWorkspace.shared.open(url) }
              }
              Button("Lokalen Eintrag entfernen", role: .destructive) {
                store.videoEintragLoeschen(video.id)
              }
            } label: {
              Image(systemName: "ellipsis").frame(width: 34)
            }
            .menuStyle(.borderlessButton)
          }
          .font(.system(size: 10, design: .rounded)).foregroundStyle(Color.bsText)
          .padding(.horizontal, 16).padding(.vertical, 11)
          Divider().overlay(Color.bsBorder)
        }
      }.blackstockCard(0)
    }
  }
}
