import SwiftUI
import UniformTypeIdentifiers

struct BibliothekView: View {
  @EnvironmentObject private var store: AppStore
  @State private var importer = false
  @State private var relinkImporter = false
  @State private var relinkAssetID: UUID?
  @State private var herkunft: MedienHerkunft = .eigen

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 18) {
        PageHeader(
          titel: "Mediathek",
          untertitel:
            "Alle Medien an einem Ort. Blackstock verwaltet automatisch erzeugte Bilder, Voice, Musik und Visuals intern; eigene Aufnahmen oder lizenzierte Assets kannst du optional ergänzen.",
          trailing: AnyView(
            HStack {
              Picker("Herkunft", selection: $herkunft) {
                ForEach(MedienHerkunft.allCases) { Text($0.rawValue).tag($0) }
              }
              .frame(width: 170)
              Button {
                importer = true
              } label: {
                Label("Medien importieren", systemImage: "plus")
              }
              .buttonStyle(.borderedProminent).tint(Color.bsRed).foregroundStyle(.white)
            })
        )

        HStack(spacing: 12) {
          KPIKarte(
            titel: "Assets", wert: "\(store.medien.count)", delta: "lokal referenziert",
            symbol: "square.stack.3d.up")
          KPIKarte(
            titel: "Eigene Medien", wert: "\(store.medien.filter { $0.herkunft == .eigen }.count)",
            delta: "bevorzugt", symbol: "video.fill", akzent: .bsGreen)
          KPIKarte(
            titel: "Rechte unklar", wert: "\(store.medien.filter { $0.herkunft == .unklar }.count)",
            delta: "blockiert Auto-Publish", symbol: "exclamationmark.shield", akzent: .bsAmber)
          KPIKarte(
            titel: "Datei fehlt", wert: "\(store.fehlendeMedien().count)", delta: "neu verknüpfen",
            symbol: "externaldrive.badge.exclamationmark",
            akzent: store.fehlendeMedien().isEmpty ? .bsGreen : .bsRed)
        }

        if store.medien.isEmpty {
          EmptyState(
            symbol: "square.stack.3d.up", titel: "Noch keine eigenen Medien",
            text:
              "Du musst nichts importieren, um Content zu produzieren: Blackstock erzeugt benötigte Medien automatisch. Eigene Videos, Gameplay oder lizenzierte Assets sind optional und werden bevorzugt, wenn sie passen.",
            button: "Optional Medien importieren"
          ) { importer = true }
        } else {
          LazyVGrid(columns: [GridItem(.adaptive(minimum: 230), spacing: 12)], spacing: 12) {
            ForEach(store.medien) { asset in
              assetCard(asset)
            }
          }
        }
      }
      .padding(26)
    }
    .fileImporter(
      isPresented: $importer, allowedContentTypes: [.movie, .image, .audio],
      allowsMultipleSelection: true
    ) { result in
      switch result {
      case .success(let urls):
        let before = store.medien.count
        store.medienImportieren(urls, herkunft: herkunft)
        let imported = max(0, store.medien.count - before)
        store.meldung =
          "\(imported) Medien wurden mit Rechteherkunft „\(herkunft.rawValue)“ importiert."
      case .failure(let error):
        store.meldung = error.localizedDescription
      }
    }
    .fileImporter(
      isPresented: $relinkImporter, allowedContentTypes: [.movie, .image, .audio]
    ) { result in
      guard let assetID = relinkAssetID else { return }
      defer { relinkAssetID = nil }
      switch result {
      case .success(let url):
        store.medienNeuVerknuepfen(assetID, mit: url)
        store.meldung = "Asset wurde neu verknüpft."
      case .failure(let error):
        store.meldung = error.localizedDescription
      }
    }
  }

  private func assetCard(_ asset: MedienAsset) -> some View {
    let vorhanden = FileManager.default.fileExists(atPath: asset.lokalerPfad)
    return VStack(alignment: .leading, spacing: 11) {
      ZStack {
        RoundedRectangle(cornerRadius: 10).fill(Color.bsSurface3).frame(height: 112)
        Image(systemName: icon(asset.typ)).font(.system(size: 26)).foregroundStyle(
          vorhanden ? Color.bsRed : Color.bsMuted)
        if !vorhanden {
          VStack {
            HStack {
              Spacer()
              Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(Color.bsAmber)
                .padding(8)
            }
            Spacer()
          }
        }
      }
      Text(asset.name).font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Color.bsText)
        .lineLimit(2)
      HStack {
        StatusPunkt(
          text: vorhanden ? "Datei verfügbar" : "Datei fehlt", farbe: vorhanden ? .bsGreen : .bsRed)
        Spacer()
        Text(asset.herkunft.rawValue).font(.system(size: 8.5, weight: .medium)).foregroundStyle(
          asset.herkunft.autoPublishingErlaubt ? Color.bsGreen : Color.bsAmber)
      }
      Text(asset.lokalerPfad).font(.system(size: 8.5)).foregroundStyle(Color.bsMuted2).lineLimit(1)
      HStack {
        if !vorhanden {
          Button("Neu verknüpfen") {
            relinkAssetID = asset.id
            relinkImporter = true
          }
          .buttonStyle(.bordered)
          .controlSize(.small)
        }
        Spacer()
        Button(role: .destructive) {
          store.medienEntfernen(asset.id)
        } label: {
          Label("Entfernen", systemImage: "trash")
        }
        .buttonStyle(.plain).font(.system(size: 9)).foregroundStyle(Color.bsMuted)
      }
    }
    .blackstockCard(12)
  }

  private func icon(_ typ: MedienTyp) -> String {
    switch typ {
    case .video: "film.fill"
    case .bild: "photo.fill"
    case .audio: "waveform"
    }
  }
}
