import AppKit
import CryptoKit
import Foundation
import Network

@MainActor
final class YouTubeService: ObservableObject {
  struct Aktualisierung {
    var kanal: Kanal?
    var videos: [VideoLeistung]
    var dailyAnalytics: [AnalyticsDailyPoint] = []
    var revenueAccess: RevenueAccessStatus = .unknown
  }

  struct VerbindungsErgebnis {
    var zugang: GoogleZugang
    var kanal: Kanal?
    var kanaele: [Kanal] = []
    var einrichtungsHinweis: APIEinrichtungsHinweis? = nil
  }

  enum OAuthFeature: String {
    case base
    case upload
    case monetaryAnalytics
    case liveManagement
  }

  struct DailyAnalyticsResult {
    var points: [AnalyticsDailyPoint]
    var revenueAccess: RevenueAccessStatus
  }

  struct LiveSetup {
    var broadcastID: String
    var streamID: String
    var ingestionAddress: String
    var streamName: String
  }

  enum YouTubeFehler: LocalizedError {
    case nichtKonfiguriert
    case falscherOAuthClientTyp
    case oauthFehlgeschlagen(String)
    case keinKanal
    case serviceDeaktiviert(dienst: String, projektID: String?, aktivierungsURL: URL?)
    case quotaErschoepft
    case apiFehler(String)

    var errorDescription: String? {
      switch self {
      case .nichtKonfiguriert:
        return
          "Die Google-Anmeldung ist in diesem Build noch nicht freigegeben. Importiere einmalig eine Google-Desktop-OAuth-Datei oder verwende einen veröffentlichten Blackstock-Build mit integrierter Google-Konfiguration."
      case .falscherOAuthClientTyp:
        return
          "Diese OAuth-Datei gehört zu einer Webanwendung. Blackstock benötigt einen Google-OAuth-Client vom Typ „Desktop-App“."
      case .oauthFehlgeschlagen(let detail):
        return "Google-Anmeldung fehlgeschlagen: \(detail)"
      case .keinKanal:
        return
          "Google ist verbunden, aber für diesen Zugang existiert noch kein YouTube-Kanal. Du kannst ihn jetzt in Blackstock vorbereiten und einmalig bei YouTube anlegen."
      case .serviceDeaktiviert(let dienst, _, _):
        return
          "\(dienst) ist für das Google-Cloud-Projekt von Blackstock noch nicht aktiviert. Dein Google-Zugang ist in Ordnung; aktiviere den Dienst einmal und prüfe anschließend erneut."
      case .quotaErschoepft:
        return
          "Das YouTube-API-Kontingent dieses Google-Cloud-Projekts ist aktuell ausgeschöpft. Blackstock behält deine Verbindung und versucht es nach der Quoten-Erneuerung erneut."
      case .apiFehler(let detail):
        return detail
      }
    }

    var einrichtungsHinweis: APIEinrichtungsHinweis? {
      guard case .serviceDeaktiviert(let dienst, let projektID, let aktivierungsURL) = self else {
        return nil
      }
      return APIEinrichtungsHinweis(
        titel: "Noch ein Schritt für YouTube",
        text:
          "Dein Google-Konto ist erfolgreich verbunden. Für das verwendete Google-Cloud-Projekt muss \(dienst) noch einmalig aktiviert werden.",
        dienst: dienst,
        projektID: projektID,
        aktivierungsURL: aktivierungsURL
      )
    }
  }

  @Published var verbunden = false
  @Published var googleVerbunden = false
  @Published var letzterStatus = "Nicht verbunden"
  @Published var letzterAPIEinrichtungsHinweis: APIEinrichtungsHinweis?

  private let keychain = KeychainService.shared
  private var aktiveVerbindungID: UUID?
  private var trendCacheKey: String?
  private var trendCacheDatum: Date?
  private var trendCache: [Chance] = []

  private struct OAuthClientBlock: Decodable {
    let clientID: String
    let projectID: String?
    let clientSecret: String?
    let authURI: String?
    let tokenURI: String?
    let redirectURIs: [String]?

    enum CodingKeys: String, CodingKey {
      case clientID = "client_id"
      case projectID = "project_id"
      case clientSecret = "client_secret"
      case authURI = "auth_uri"
      case tokenURI = "token_uri"
      case redirectURIs = "redirect_uris"
    }
  }

  private struct OAuthClientFile: Decodable {
    let installed: OAuthClientBlock?
    let web: OAuthClientBlock?
  }

  private struct OAuthClientConfig {
    let clientID: String
    let clientSecret: String?
    let quelle: OAuthKonfigurationsstatus.Zustand
  }

  private let baseScopes = [
    "openid",
    "email",
    "profile",
    "https://www.googleapis.com/auth/youtube.readonly",
    "https://www.googleapis.com/auth/yt-analytics.readonly",
  ]

  private let uploadScope = "https://www.googleapis.com/auth/youtube.upload"
  private let monetaryScope = "https://www.googleapis.com/auth/yt-analytics-monetary.readonly"
  private let liveScope = "https://www.googleapis.com/auth/youtube"

  func oeffneKanalErstellung(vorgeschlagenerName: String) {
    NSPasteboard.general.clearContents()
    NSPasteboard.general.setString(vorgeschlagenerName, forType: .string)
    if let url = URL(string: "https://www.youtube.com/channel_switcher") {
      NSWorkspace.shared.open(url)
    }
  }

  func oeffneGoogleCloudKonfiguration() {
    if let url = URL(string: "https://console.cloud.google.com/apis/credentials") {
      NSWorkspace.shared.open(url)
    }
  }

  func oeffneAPIEinrichtung(_ hinweis: APIEinrichtungsHinweis) {
    if let url = hinweis.aktivierungsURL {
      NSWorkspace.shared.open(url)
      return
    }
    if let projektID = hinweis.projektID,
      let url = Self.aktivierungsURL(dienst: hinweis.dienst, projektID: projektID)
    {
      NSWorkspace.shared.open(url)
      return
    }
    if let url = URL(string: "https://console.cloud.google.com/apis/library") {
      NSWorkspace.shared.open(url)
    }
  }

  func aktuelleProjektID() -> String? {
    if let embedded = Bundle.main.url(forResource: "GoogleOAuth", withExtension: "json"),
      let data = try? Data(contentsOf: embedded),
      let file = try? JSONDecoder().decode(OAuthClientFile.self, from: data),
      let id = file.installed?.projectID, !id.isEmpty
    {
      return id
    }
    return UserDefaults.standard.string(forKey: "googleOAuthProjectID")
  }

  func standardDataAPIHinweis() -> APIEinrichtungsHinweis {
    let projectID = aktuelleProjektID()
    return APIEinrichtungsHinweis(
      titel: "YouTube-Verbindung fertigstellen",
      text:
        "Google ist bereits verbunden. Aktiviere jetzt einmalig die YouTube Data API v3 für das verwendete Google-Cloud-Projekt. Danach kann Blackstock deine Kanäle, Videos und Trends laden.",
      dienst: "YouTube Data API v3",
      projektID: projectID,
      aktivierungsURL: projectID.flatMap {
        Self.aktivierungsURL(dienst: "YouTube Data API v3", projektID: $0)
      }
    )
  }

  func gespeicherterAPIEinrichtungsHinweis() -> APIEinrichtungsHinweis? {
    guard let dienst = UserDefaults.standard.string(forKey: "blackstock.missingAPIService"),
      !dienst.isEmpty
    else { return nil }
    let projectID = UserDefaults.standard.string(forKey: "blackstock.missingAPIProjectID")
    let url =
      UserDefaults.standard.string(forKey: "blackstock.missingAPIActivationURL").flatMap(
        URL.init(string:))
      ?? projectID.flatMap { Self.aktivierungsURL(dienst: dienst, projektID: $0) }
    return APIEinrichtungsHinweis(
      titel: "YouTube-Verbindung fertigstellen",
      text:
        "Google ist bereits verbunden. Für den vollständigen Blackstock-Zugriff muss \(dienst) noch einmalig aktiviert werden.",
      dienst: dienst,
      projektID: projectID,
      aktivierungsURL: url
    )
  }

  private func speichereAPIEinrichtungsHinweis(dienst: String, projektID: String?, url: URL?) {
    UserDefaults.standard.set(dienst, forKey: "blackstock.missingAPIService")
    UserDefaults.standard.set(projektID, forKey: "blackstock.missingAPIProjectID")
    UserDefaults.standard.set(url?.absoluteString, forKey: "blackstock.missingAPIActivationURL")
  }

  private func loescheGespeichertenAPIEinrichtungsHinweis() {
    UserDefaults.standard.removeObject(forKey: "blackstock.missingAPIService")
    UserDefaults.standard.removeObject(forKey: "blackstock.missingAPIProjectID")
    UserDefaults.standard.removeObject(forKey: "blackstock.missingAPIActivationURL")
  }

  private static func aktivierungsURL(dienst: String, projektID: String) -> URL? {
    let serviceID: String
    if dienst.localizedCaseInsensitiveContains("Analytics") {
      serviceID = "youtubeanalytics.googleapis.com"
    } else {
      serviceID = "youtube.googleapis.com"
    }
    var comps = URLComponents(string: "https://console.cloud.google.com/apis/library/\(serviceID)")
    comps?.queryItems = [URLQueryItem(name: "project", value: projektID)]
    return comps?.url
  }

  func oauthKonfigurationsstatus() -> OAuthKonfigurationsstatus {
    if let embedded = Bundle.main.url(forResource: "GoogleOAuth", withExtension: "json"),
      let data = try? Data(contentsOf: embedded),
      let file = try? JSONDecoder().decode(OAuthClientFile.self, from: data),
      file.installed != nil
    {
      return OAuthKonfigurationsstatus(
        zustand: .eingebaut, detail: "Google-Anmeldung ist in Blackstock integriert.")
    }
    if let id = UserDefaults.standard.string(forKey: "googleOAuthClientID"), !id.isEmpty {
      let kind = UserDefaults.standard.string(forKey: "googleOAuthClientType") ?? ""
      if kind == "installed" {
        return OAuthKonfigurationsstatus(
          zustand: .importiert, detail: "Desktop-OAuth ist lokal eingerichtet.")
      }
      return OAuthKonfigurationsstatus(
        zustand: .ungueltig,
        detail: "Die gespeicherte OAuth-Konfiguration ist nicht als Desktop-App bestätigt.")
    }
    return OAuthKonfigurationsstatus(
      zustand: .fehlt,
      detail: "Für diesen Entwicklungs-Build fehlt noch die einmalige Desktop-OAuth-Freigabe.")
  }

  func importiereDesktopOAuthDatei(_ url: URL) throws {
    let data = try Data(contentsOf: url)
    let file = try JSONDecoder().decode(OAuthClientFile.self, from: data)
    guard let installed = file.installed else {
      if file.web != nil { throw YouTubeFehler.falscherOAuthClientTyp }
      throw YouTubeFehler.oauthFehlgeschlagen(
        "Die Datei enthält keine Google-Desktop-OAuth-Konfiguration.")
    }
    UserDefaults.standard.set(installed.clientID, forKey: "googleOAuthClientID")
    UserDefaults.standard.set(installed.projectID, forKey: "googleOAuthProjectID")
    UserDefaults.standard.set("installed", forKey: "googleOAuthClientType")
    if let secret = installed.clientSecret, !secret.isEmpty {
      guard keychain.speichern(secret, schluessel: "googleOAuthClientSecret") else {
        throw YouTubeFehler.oauthFehlgeschlagen(
          "OAuth-Client-Secret konnte nicht sicher im macOS-Schlüsselbund gespeichert werden.")
      }
    }
  }

  func entferneLokaleOAuthKonfiguration() {
    UserDefaults.standard.removeObject(forKey: "googleOAuthClientID")
    UserDefaults.standard.removeObject(forKey: "googleOAuthProjectID")
    UserDefaults.standard.removeObject(forKey: "googleOAuthClientType")
    keychain.loeschen("googleOAuthClientSecret")
  }

  func googleZugangHinzufuegen() async throws -> VerbindungsErgebnis {
    letzterAPIEinrichtungsHinweis = nil
    let verbindungsID = UUID()
    aktiveVerbindungID = verbindungsID
    try await autorisieren(verbindungID: verbindungsID, requestedScopes: baseScopes)
    googleVerbunden = true

    let profil = (try? await ladeGoogleProfil()) ?? (email: "Google-Konto", name: "Google")
    var kanal: Kanal?
    var gefundeneKanaele: [Kanal] = []
    var hinweis: APIEinrichtungsHinweis?
    do {
      gefundeneKanaele = try await ladeKanaele()
      kanal = gefundeneKanaele.first
      hinweis = letzterAPIEinrichtungsHinweis
    } catch let fehler as YouTubeFehler {
      if let setup = fehler.einrichtungsHinweis {
        hinweis = setup
        letzterAPIEinrichtungsHinweis = setup
      } else {
        throw fehler
      }
    }

    let status: Verbindungsstatus =
      kanal != nil ? .verbunden : (hinweis != nil ? .apiEinrichtung : .kanalFehlt)
    let zugang = GoogleZugang(
      id: verbindungsID,
      email: profil.email,
      anzeigename: profil.name,
      status: status,
      youtubeChannelID: kanal?.youtubeChannelID,
      youtubeChannelName: kanal?.name,
      verbundenAm: Date(),
      letzteSynchronisierung: Date(),
      datenherkunft: .live
    )
    if hinweis != nil {
      letzterStatus = "Google verbunden · YouTube-API noch aktivieren"
    } else {
      letzterStatus =
        kanal == nil
        ? "Google verbunden · noch kein YouTube-Kanal"
        : "Verbunden mit \(kanal?.name ?? "YouTube")"
    }
    verbunden = kanal != nil
    if hinweis == nil { loescheGespeichertenAPIEinrichtungsHinweis() }
    return VerbindungsErgebnis(zugang: zugang, kanal: kanal, kanaele: gefundeneKanaele, einrichtungsHinweis: hinweis)
  }

  func kanalUndAnalyticsAktualisieren(verbindungID: UUID) async throws -> Aktualisierung {
    letzterAPIEinrichtungsHinweis = nil
    try await autorisierenWennNoetig(verbindungID: verbindungID)
    let kanal = try await ladeKanal()
    let latest = try await ladeNeuesteVideos(kanal: kanal)
    var daily: [AnalyticsDailyPoint] = []
    var revenueAccess: RevenueAccessStatus = .unknown
    if let kanal, let youtubeChannelID = kanal.youtubeChannelID {
      let end = Date()
      let start = Calendar(identifier: .gregorian).date(byAdding: .day, value: -364, to: end) ?? end
      if let result = try? await dailyAnalytics(
        verbindungID: verbindungID, youtubeChannelID: youtubeChannelID, localChannelID: kanal.id,
        startDate: start, endDate: end)
      {
        daily = result.points
        revenueAccess = result.revenueAccess
      }
    }
    if letzterAPIEinrichtungsHinweis == nil { loescheGespeichertenAPIEinrichtungsHinweis() }
    return Aktualisierung(kanal: kanal, videos: latest, dailyAnalytics: daily, revenueAccess: revenueAccess)
  }

  func kanalLaden(verbindungID: UUID) async throws -> Kanal? {
    try await kanaeleLaden(verbindungID: verbindungID).first
  }

  func kanaeleLaden(verbindungID: UUID) async throws -> [Kanal] {
    letzterAPIEinrichtungsHinweis = nil
    try await autorisierenWennNoetig(verbindungID: verbindungID)
    return try await ladeKanaele().map { input in
      var kanal = input
      kanal.verbindungsID = verbindungID
      return kanal
    }
  }

  func videosLaden(verbindungID: UUID, kanal: Kanal) async throws -> [VideoLeistung] {
    letzterAPIEinrichtungsHinweis = nil
    try await autorisierenWennNoetig(verbindungID: verbindungID)
    return try await ladeNeuesteVideos(kanal: kanal)
  }

  func verbindungTrennen(_ id: UUID) {
    keychain.loeschen(tokenKey("accessToken", id: id))
    keychain.loeschen(tokenKey("refreshToken", id: id))
    keychain.loeschen(tokenKey("expiry", id: id))
    keychain.loeschen(tokenKey("scopes", id: id))
    if aktiveVerbindungID == id { aktiveVerbindungID = nil }
  }

  func alleVerbindungenTrennen(_ ids: [UUID]) {
    ids.forEach(verbindungTrennen)
    verbunden = false
    googleVerbunden = false
    letzterStatus = "Nicht verbunden"
  }

  func aktiveVerbindungSetzen(_ id: UUID?) {
    aktiveVerbindungID = id
  }

  func gewaehrteScopes(verbindungID: UUID) -> Set<String> {
    Set((keychain.lesen(tokenKey("scopes", id: verbindungID)) ?? "")
      .split(separator: " ").map(String.init))
  }

  func featureAutorisiert(_ feature: OAuthFeature, verbindungID: UUID) -> Bool {
    let scopes = gewaehrteScopes(verbindungID: verbindungID)
    switch feature {
    case .base:
      return Set(baseScopes).isSubset(of: scopes)
    case .upload:
      return scopes.contains(uploadScope) || scopes.contains(liveScope)
    case .monetaryAnalytics:
      return scopes.contains(monetaryScope)
    case .liveManagement:
      return scopes.contains(liveScope)
    }
  }

  func featureAutorisieren(_ feature: OAuthFeature, verbindungID: UUID) async throws {
    var requested = Set(baseScopes)
    requested.formUnion(gewaehrteScopes(verbindungID: verbindungID))
    switch feature {
    case .base: break
    case .upload: requested.insert(uploadScope)
    case .monetaryAnalytics: requested.insert(monetaryScope)
    case .liveManagement: requested.insert(liveScope)
    }

    do {
      try await autorisierenWennNoetig(verbindungID: verbindungID)
      if featureAutorisiert(feature, verbindungID: verbindungID) { return }
    } catch {
      // Ein expliziter Feature-Aufruf ist zugleich der Recovery-Pfad für eine
      // abgelaufene Verbindung: gezielte Reauthorization statt Account-Löschung.
    }
    try await autorisieren(verbindungID: verbindungID, requestedScopes: requested.sorted())
    guard featureAutorisiert(feature, verbindungID: verbindungID) else {
      throw YouTubeFehler.oauthFehlgeschlagen(
        "Google hat die benötigte Berechtigung nicht erteilt. Die betroffene Funktion bleibt deaktiviert.")
    }
  }

  // MARK: - OAuth

  private func clientConfig() throws -> OAuthClientConfig {
    if let embedded = Bundle.main.url(forResource: "GoogleOAuth", withExtension: "json") {
      let data = try Data(contentsOf: embedded)
      let file = try JSONDecoder().decode(OAuthClientFile.self, from: data)
      if let installed = file.installed {
        return OAuthClientConfig(
          clientID: installed.clientID, clientSecret: installed.clientSecret, quelle: .eingebaut)
      }
      if file.web != nil { throw YouTubeFehler.falscherOAuthClientTyp }
    }

    guard let id = UserDefaults.standard.string(forKey: "googleOAuthClientID"), !id.isEmpty else {
      throw YouTubeFehler.nichtKonfiguriert
    }
    guard UserDefaults.standard.string(forKey: "googleOAuthClientType") == "installed" else {
      throw YouTubeFehler.falscherOAuthClientTyp
    }
    return OAuthClientConfig(
      clientID: id, clientSecret: keychain.lesen("googleOAuthClientSecret"), quelle: .importiert)
  }

  private func autorisierenWennNoetig(verbindungID: UUID) async throws {
    aktiveVerbindungID = verbindungID
    let config = try clientConfig()
    if let token = keychain.lesen(tokenKey("accessToken", id: verbindungID)), !token.isEmpty {
      if let expiryString = keychain.lesen(tokenKey("expiry", id: verbindungID)),
        let expiry = TimeInterval(expiryString),
        Date().timeIntervalSince1970 < expiry - 90
      {
        googleVerbunden = true
        return
      }
      if let refresh = keychain.lesen(tokenKey("refreshToken", id: verbindungID)), !refresh.isEmpty
      {
        try await refreshAccessToken(
          refreshToken: refresh, verbindungID: verbindungID, config: config)
        googleVerbunden = true
        return
      }
    }
    throw YouTubeFehler.oauthFehlgeschlagen(
      "Die Anmeldung ist abgelaufen. Verbinde diesen Google-Zugang erneut.")
  }

  private func autorisieren(verbindungID: UUID, requestedScopes: [String]) async throws {
    let config = try clientConfig()
    let verifier = Self.randomVerifier()
    let challenge = Self.codeChallenge(for: verifier)
    let oauthState = Self.randomVerifier()
    let server = OAuthLoopbackServer()
    let port = try await server.start(expectedState: oauthState)
    let redirectURI = "http://127.0.0.1:\(port)"

    var components = try urlKomponenten("https://accounts.google.com/o/oauth2/v2/auth")
    components.queryItems = [
      URLQueryItem(name: "client_id", value: config.clientID),
      URLQueryItem(name: "redirect_uri", value: redirectURI),
      URLQueryItem(name: "response_type", value: "code"),
      URLQueryItem(name: "scope", value: requestedScopes.joined(separator: " ")),
      URLQueryItem(name: "access_type", value: "offline"),
      URLQueryItem(name: "include_granted_scopes", value: "true"),
      URLQueryItem(name: "prompt", value: "consent select_account"),
      URLQueryItem(name: "code_challenge", value: challenge),
      URLQueryItem(name: "code_challenge_method", value: "S256"),
      URLQueryItem(name: "state", value: oauthState),
    ]
    guard let url = components.url else {
      server.stop()
      throw YouTubeFehler.oauthFehlgeschlagen("Ungültige Login-URL")
    }
    NSWorkspace.shared.open(url)
    do {
      let code = try await server.waitForCode()
      try await exchangeCode(
        code, verifier: verifier, redirectURI: redirectURI, verbindungID: verbindungID,
        config: config, requestedScopes: requestedScopes)
      server.stop()
      googleVerbunden = true
    } catch {
      server.stop()
      throw error
    }
  }

  private func exchangeCode(
    _ code: String, verifier: String, redirectURI: String, verbindungID: UUID,
    config: OAuthClientConfig, requestedScopes: [String]
  ) async throws {
    var items = [
      URLQueryItem(name: "code", value: code),
      URLQueryItem(name: "client_id", value: config.clientID),
      URLQueryItem(name: "code_verifier", value: verifier),
      URLQueryItem(name: "redirect_uri", value: redirectURI),
      URLQueryItem(name: "grant_type", value: "authorization_code"),
    ]
    if let secret = config.clientSecret, !secret.isEmpty {
      items.append(URLQueryItem(name: "client_secret", value: secret))
    }
    try await tokenRequest(items: items, verbindungID: verbindungID, requestedScopes: requestedScopes)
  }

  private func refreshAccessToken(
    refreshToken: String, verbindungID: UUID, config: OAuthClientConfig
  ) async throws {
    var items = [
      URLQueryItem(name: "refresh_token", value: refreshToken),
      URLQueryItem(name: "client_id", value: config.clientID),
      URLQueryItem(name: "grant_type", value: "refresh_token"),
    ]
    if let secret = config.clientSecret, !secret.isEmpty {
      items.append(URLQueryItem(name: "client_secret", value: secret))
    }
    try await tokenRequest(items: items, verbindungID: verbindungID, requestedScopes: nil)
  }

  private func tokenRequest(
    items: [URLQueryItem], verbindungID: UUID, requestedScopes: [String]?
  ) async throws {
    var c = URLComponents()
    c.queryItems = items
    var request = URLRequest(url: try sichereURL("https://oauth2.googleapis.com/token"))
    request.httpMethod = "POST"
    request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
    request.httpBody = c.percentEncodedQuery?.data(using: .utf8)

    let (data, response) = try await URLSession.shared.data(for: request)
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
      let text = String(data: data, encoding: .utf8) ?? "Tokenfehler"
      throw YouTubeFehler.oauthFehlgeschlagen(text)
    }
    let token = try JSONDecoder().decode(TokenResponse.self, from: data)
    guard
      keychain.speichern(token.accessToken, schluessel: tokenKey("accessToken", id: verbindungID))
    else {
      throw YouTubeFehler.oauthFehlgeschlagen(
        "Zugriffstoken konnte nicht sicher im macOS-Schlüsselbund gespeichert werden.")
    }
    if let refresh = token.refreshToken {
      guard keychain.speichern(refresh, schluessel: tokenKey("refreshToken", id: verbindungID))
      else {
        throw YouTubeFehler.oauthFehlgeschlagen(
          "Refresh-Token konnte nicht sicher im macOS-Schlüsselbund gespeichert werden.")
      }
    }
    let expiry = Date().timeIntervalSince1970 + Double(token.expiresIn)
    guard keychain.speichern(String(expiry), schluessel: tokenKey("expiry", id: verbindungID))
    else {
      throw YouTubeFehler.oauthFehlgeschlagen(
        "Token-Ablaufzeit konnte nicht sicher gespeichert werden.")
    }
    let granted = token.scope?.split(separator: " ").map(String.init) ?? requestedScopes
    if let granted, !granted.isEmpty {
      guard keychain.speichern(granted.sorted().joined(separator: " "), schluessel: tokenKey("scopes", id: verbindungID)) else {
        throw YouTubeFehler.oauthFehlgeschlagen("OAuth-Berechtigungen konnten nicht sicher gespeichert werden.")
      }
    }
    aktiveVerbindungID = verbindungID
  }

  private func tokenKey(_ name: String, id: UUID) -> String {
    "youtube.\(id.uuidString).\(name)"
  }

  private func ladeGoogleProfil() async throws -> (email: String, name: String) {
    let url = try sichereURL("https://openidconnect.googleapis.com/v1/userinfo")
    let (data, response) = try await URLSession.shared.data(for: authorizedRequest(url))
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
      throw YouTubeFehler.apiFehler("Google-Profil konnte nicht geladen werden")
    }
    let profil = try JSONDecoder().decode(GoogleProfil.self, from: data)
    return (profil.email ?? "Google-Konto", profil.name ?? profil.email ?? "Google")
  }

  // MARK: - Data API

  private func accessToken() throws -> String {
    guard let id = aktiveVerbindungID else {
      throw YouTubeFehler.oauthFehlgeschlagen("Kein Google-Zugang ausgewählt")
    }
    guard let token = keychain.lesen(tokenKey("accessToken", id: id)), !token.isEmpty else {
      throw YouTubeFehler.oauthFehlgeschlagen(
        "Kein Zugriffstoken für diesen Google-Zugang vorhanden")
    }
    return token
  }

  private func authorizedRequest(_ url: URL) throws -> URLRequest {
    var request = URLRequest(url: url)
    request.setValue("Bearer \(try accessToken())", forHTTPHeaderField: "Authorization")
    return request
  }

  private func googleAPIFehler(
    data: Data, httpStatus: Int, fallback: String, standardDienst: String
  ) -> YouTubeFehler {
    if let env = try? JSONDecoder().decode(GoogleAPIErrorEnvelope.self, from: data) {
      let reason =
        env.error.details?.compactMap { $0.reason }.first ?? env.error.errors?.first?.reason
      let metadata = env.error.details?.compactMap { $0.metadata }.first
      let service = metadata?.service ?? ""
      let serviceTitle =
        metadata?.serviceTitle
        ?? (service.contains("youtubeanalytics") ? "YouTube Analytics API" : standardDienst)
      let consumer = metadata?.consumer ?? ""
      let projectFromConsumer = consumer.split(separator: "/").last.map(String.init)
      let projectID = projectFromConsumer ?? aktuelleProjektID()
      let activation =
        metadata?.activationUrl.flatMap(URL.init(string:))
        ?? projectID.flatMap { Self.aktivierungsURL(dienst: serviceTitle, projektID: $0) }

      if reason == "SERVICE_DISABLED" || reason == "accessNotConfigured"
        || env.error.errors?.contains(where: { $0.reason == "accessNotConfigured" }) == true
      {
        speichereAPIEinrichtungsHinweis(dienst: serviceTitle, projektID: projectID, url: activation)
        return .serviceDeaktiviert(
          dienst: serviceTitle, projektID: projectID, aktivierungsURL: activation)
      }
      if reason == "quotaExceeded" || reason == "dailyLimitExceeded"
        || reason == "rateLimitExceeded"
      {
        return .quotaErschoepft
      }
      if httpStatus == 401 {
        return .oauthFehlgeschlagen(
          "Die Google-Freigabe ist abgelaufen. Melde den Zugang einmal neu an.")
      }
      let message = env.error.message.trimmingCharacters(in: .whitespacesAndNewlines)
      if !message.isEmpty { return .apiFehler(message) }
    }
    if httpStatus == 401 {
      return .oauthFehlgeschlagen(
        "Die Google-Freigabe ist abgelaufen. Melde den Zugang einmal neu an.")
    }
    return .apiFehler(fallback)
  }

  private struct ChannelAnalyticsSummary {
    var views: Int
    var subscriberNetto: Int
    var revenue: Double?
    var revenueAccess: RevenueAccessStatus
  }

  private func ladeKanal() async throws -> Kanal? {
    try await ladeKanaele().first
  }

  private func ladeKanaele() async throws -> [Kanal] {
    let url = try sichereURL(
      "https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics,contentDetails,status&mine=true"
    )
    let (data, response) = try await URLSession.shared.data(for: authorizedRequest(url))
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
      let status = (response as? HTTPURLResponse)?.statusCode ?? -1
      throw googleAPIFehler(
        data: data, httpStatus: status, fallback: "Kanal konnte nicht geladen werden.",
        standardDienst: "YouTube Data API v3")
    }
    let result = try JSONDecoder().decode(ChannelListResponse.self, from: data)
    var channels: [Kanal] = []
    for item in result.items {
      var analytics: ChannelAnalyticsSummary?
      do {
        analytics = try await ladeKanalAnalytics(channelID: item.id)
      } catch let fehler as YouTubeFehler {
        if let setup = fehler.einrichtungsHinweis { letzterAPIEinrichtungsHinweis = setup }
        analytics = nil
      }
      channels.append(
        Kanal(
          youtubeChannelID: item.id,
          verbindungsID: aktiveVerbindungID,
          name: item.snippet.title,
          thema: item.snippet.description.isEmpty
            ? "YouTube-Kanal" : String(item.snippet.description.prefix(80)),
          handle: item.snippet.customUrl ?? "",
          // The Data/Analytics APIs do not expose the exact YPP approval state here.
          status: .verbunden,
          abonnenten: Int(item.statistics.subscriberCount ?? "0") ?? 0,
          views28Tage: analytics?.views ?? 0,
          abonnenten28Tage: analytics?.subscriberNetto ?? 0,
          umsatz28Tage: analytics?.revenue ?? 0,
          qualitaetsScore: 0,
          vertrauensScore: 0,
          monetarisierungFortschritt: 0,
          letzterUpload: nil,
          naechsterUpload: nil,
          autopilotAktiv: false,
          istDemo: false,
          yppStatus: .nichtBerechtigt,
          gueltigeShortsViews90Tage: 0,
          wiedergabeStunden12Monate: 0,
          analyticsStand: Date(),
          datenherkunft: .live,
          branding: nil
        ))
    }
    return channels
  }

  private func ladeKanalAnalytics(channelID: String) async throws -> ChannelAnalyticsSummary {
    let formatter = Self.analyticsDayFormatter
    let end = Date()
    let start = Calendar(identifier: .gregorian).date(byAdding: .day, value: -27, to: end)
      ?? end.addingTimeInterval(-27 * 86_400)
    let canRevenue = aktiveVerbindungID.map {
      featureAutorisiert(.monetaryAnalytics, verbindungID: $0)
    } ?? false

    func request(includeRevenue: Bool) async throws -> AnalyticsResponse {
      var comps = try urlKomponenten("https://youtubeanalytics.googleapis.com/v2/reports")
      let metrics = includeRevenue
        ? "views,subscribersGained,subscribersLost,estimatedRevenue"
        : "views,subscribersGained,subscribersLost"
      comps.queryItems = [
        URLQueryItem(name: "ids", value: "channel==\(channelID)"),
        URLQueryItem(name: "startDate", value: formatter.string(from: start)),
        URLQueryItem(name: "endDate", value: formatter.string(from: end)),
        URLQueryItem(name: "metrics", value: metrics),
      ]
      let (data, response) = try await URLSession.shared.data(
        for: authorizedRequest(try urlAusKomponenten(comps)))
      guard let http = response as? HTTPURLResponse else {
        throw YouTubeFehler.apiFehler("Keine Analytics-Antwort")
      }
      guard (200..<300).contains(http.statusCode) else {
        throw googleAPIFehler(
          data: data, httpStatus: http.statusCode,
          fallback: "Analytics konnte nicht geladen werden.",
          standardDienst: "YouTube Analytics API")
      }
      return try JSONDecoder().decode(AnalyticsResponse.self, from: data)
    }

    if canRevenue {
      do {
        let result = try await request(includeRevenue: true)
        let row = result.rows?.first ?? []
        return ChannelAnalyticsSummary(
          views: row.safeInt(at: 0),
          subscriberNetto: row.safeInt(at: 1) - row.safeInt(at: 2),
          revenue: row.safeDouble(at: 3),
          revenueAccess: .available)
      } catch let error as YouTubeFehler {
        // Monetary metrics can be forbidden for channels without monetary data.
        if case .apiFehler = error {
          let fallback = try await request(includeRevenue: false)
          let row = fallback.rows?.first ?? []
          return ChannelAnalyticsSummary(
            views: row.safeInt(at: 0),
            subscriberNetto: row.safeInt(at: 1) - row.safeInt(at: 2),
            revenue: nil,
            revenueAccess: .forbidden)
        }
        throw error
      }
    }

    let result = try await request(includeRevenue: false)
    let row = result.rows?.first ?? []
    return ChannelAnalyticsSummary(
      views: row.safeInt(at: 0),
      subscriberNetto: row.safeInt(at: 1) - row.safeInt(at: 2),
      revenue: nil,
      revenueAccess: .notAuthorized)
  }

  func dailyAnalytics(
    verbindungID: UUID,
    youtubeChannelID: String,
    localChannelID: UUID,
    startDate: Date,
    endDate: Date
  ) async throws -> DailyAnalyticsResult {
    try await autorisierenWennNoetig(verbindungID: verbindungID)
    let formatter = Self.analyticsDayFormatter
    let canRevenue = featureAutorisiert(.monetaryAnalytics, verbindungID: verbindungID)

    func request(includeRevenue: Bool) async throws -> (AnalyticsResponse, Int) {
      var comps = try urlKomponenten("https://youtubeanalytics.googleapis.com/v2/reports")
      let metrics = includeRevenue
        ? "views,estimatedMinutesWatched,subscribersGained,subscribersLost,estimatedRevenue"
        : "views,estimatedMinutesWatched,subscribersGained,subscribersLost"
      comps.queryItems = [
        URLQueryItem(name: "ids", value: "channel==\(youtubeChannelID)"),
        URLQueryItem(name: "startDate", value: formatter.string(from: startDate)),
        URLQueryItem(name: "endDate", value: formatter.string(from: endDate)),
        URLQueryItem(name: "dimensions", value: "day"),
        URLQueryItem(name: "metrics", value: metrics),
        URLQueryItem(name: "sort", value: "day"),
      ]
      let (data, response) = try await URLSession.shared.data(
        for: authorizedRequest(try urlAusKomponenten(comps)))
      guard let http = response as? HTTPURLResponse else {
        throw YouTubeFehler.apiFehler("Keine Analytics-Antwort")
      }
      if (200..<300).contains(http.statusCode) {
        return (try JSONDecoder().decode(AnalyticsResponse.self, from: data), http.statusCode)
      }
      if http.statusCode == 403 && includeRevenue {
        return (AnalyticsResponse(rows: nil), 403)
      }
      throw googleAPIFehler(
        data: data, httpStatus: http.statusCode,
        fallback: "Tages-Analytics konnten nicht geladen werden.",
        standardDienst: "YouTube Analytics API")
    }

    var revenueStatus: RevenueAccessStatus = canRevenue ? .authorizedNoData : .notAuthorized
    var includeRevenue = canRevenue
    var response = try await request(includeRevenue: includeRevenue)
    if response.1 == 403 && includeRevenue {
      revenueStatus = .forbidden
      includeRevenue = false
      response = try await request(includeRevenue: false)
    } else if includeRevenue {
      revenueStatus = .available
    }

    let points: [AnalyticsDailyPoint] = (response.0.rows ?? []).compactMap { row in
      guard let dateString = row.first?.stringValue,
        let date = formatter.date(from: dateString)
      else { return nil }
      return AnalyticsDailyPoint(
        channelID: localChannelID,
        date: date,
        views: row.safeInt(at: 1),
        watchTimeMinutes: row.safeDouble(at: 2),
        subscribersGained: row.safeInt(at: 3),
        subscribersLost: row.safeInt(at: 4),
        estimatedRevenue: includeRevenue ? row.safeDouble(at: 5) : nil)
    }
    return DailyAnalyticsResult(points: points.sorted { $0.date < $1.date }, revenueAccess: revenueStatus)
  }

  private static let analyticsDayFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.locale = Locale(identifier: "en_US_POSIX")
    formatter.calendar = Calendar(identifier: .gregorian)
    formatter.timeZone = TimeZone(secondsFromGMT: 0)
    formatter.dateFormat = "yyyy-MM-dd"
    return formatter
  }()

  private func ladeNeuesteVideos(kanal: Kanal?) async throws -> [VideoLeistung] {
    guard let channel = try await ladeChannelRaw(channelID: kanal?.youtubeChannelID),
      let uploads = channel.contentDetails.relatedPlaylists.uploads
    else { return [] }
    var comps = try urlKomponenten("https://www.googleapis.com/youtube/v3/playlistItems")
    comps.queryItems = [
      URLQueryItem(name: "part", value: "snippet,contentDetails"),
      URLQueryItem(name: "playlistId", value: uploads),
      URLQueryItem(name: "maxResults", value: "25"),
    ]
    let (data, response) = try await URLSession.shared.data(
      for: authorizedRequest(try urlAusKomponenten(comps)))
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
      let status = (response as? HTTPURLResponse)?.statusCode ?? -1
      throw googleAPIFehler(
        data: data, httpStatus: status, fallback: "YouTube-Videos konnten nicht geladen werden.",
        standardDienst: "YouTube Data API v3")
    }
    let playlist = try JSONDecoder().decode(PlaylistItemsResponse.self, from: data)
    let ids = playlist.items.compactMap { $0.contentDetails.videoId }
    guard !ids.isEmpty else { return [] }

    var vComps = try urlKomponenten("https://www.googleapis.com/youtube/v3/videos")
    vComps.queryItems = [
      URLQueryItem(name: "part", value: "snippet,statistics,contentDetails,status"),
      URLQueryItem(name: "id", value: ids.joined(separator: ",")),
    ]
    let (vData, vResponse) = try await URLSession.shared.data(
      for: authorizedRequest(try urlAusKomponenten(vComps)))
    guard let vHTTP = vResponse as? HTTPURLResponse, (200..<300).contains(vHTTP.statusCode) else {
      let status = (vResponse as? HTTPURLResponse)?.statusCode ?? -1
      throw googleAPIFehler(
        data: vData, httpStatus: status, fallback: "Video-Details konnten nicht geladen werden.",
        standardDienst: "YouTube Data API v3")
    }
    let detail = try JSONDecoder().decode(VideoListResponse.self, from: vData)
    let analytics = (try? await ladeVideoAnalytics(ids: ids, channelID: kanal?.youtubeChannelID ?? channel.id)) ?? [:]
    let dateFormatter = ISO8601DateFormatter()

    return detail.items.map { item in
      let a = analytics[item.id]
      let views = Int(item.statistics.viewCount ?? "0") ?? 0
      let rpm = views > 0 && a?.revenue != nil ? ((a?.revenue ?? 0) / Double(views) * 1000) : 0
      return VideoLeistung(
        youtubeVideoID: item.id,
        kanalID: kanal?.id ?? UUID(),
        titel: item.snippet.title,
        format: item.snippet.title.contains("#Shorts") ? .short : .longform,
        veroeffentlichtAm: dateFormatter.date(from: item.snippet.publishedAt) ?? Date(),
        views: views,
        views24h: 0,
        watchtimeMinuten: a?.watchMinutes ?? 0,
        durchschnittlicheWiedergabeProzent: a?.avgPercent ?? 0,
        abonnentenGewonnen: a?.subsGained ?? 0,
        abonnentenVerloren: a?.subsLost ?? 0,
        likes: Int(item.statistics.likeCount ?? "0") ?? 0,
        kommentare: Int(item.statistics.commentCount ?? "0") ?? 0,
        shares: a?.shares ?? 0,
        umsatz: a?.revenue ?? 0,
        umsatzVerfuegbar: a?.revenue != nil,
        rpm: rpm,
        thumbnailCTR: nil,
        qualitaetsScore: 0,
        forecastFehlerProzent: nil,
        istDemo: false
      )
    }
  }

  private struct VideoAnalyticsRow {
    var watchMinutes: Int
    var avgPercent: Double
    var subsGained: Int
    var subsLost: Int
    var shares: Int
    var revenue: Double?
  }

  private func ladeVideoAnalytics(ids: [String], channelID: String) async throws -> [String: VideoAnalyticsRow] {
    guard !ids.isEmpty else { return [:] }
    let formatter = DateFormatter()
    formatter.locale = Locale(identifier: "en_US_POSIX")
    formatter.calendar = Calendar(identifier: .gregorian)
    formatter.timeZone = TimeZone(secondsFromGMT: 0)
    formatter.dateFormat = "yyyy-MM-dd"
    // VideoLeistung.views stammt aus der Data API und ist ein Lifetime-Wert. Deshalb
    // werden die übrigen Kennzahlen ebenfalls seit YouTube-Start abgefragt statt
    // einen versteckten 90-Tage-Zeitraum mit Lifetime-Views zu vermischen.
    let start = formatter.date(from: "2005-04-01") ?? Date(timeIntervalSince1970: 1_112_313_600)
    let end = Date()
    let mayRequestRevenue = aktiveVerbindungID.map { featureAutorisiert(.monetaryAnalytics, verbindungID: $0) } ?? false

    func request(includeRevenue: Bool) async throws -> (AnalyticsResponse, Bool) {
      var comps = try urlKomponenten("https://youtubeanalytics.googleapis.com/v2/reports")
      let metrics =
        includeRevenue
        ? "estimatedMinutesWatched,averageViewPercentage,subscribersGained,subscribersLost,shares,estimatedRevenue"
        : "estimatedMinutesWatched,averageViewPercentage,subscribersGained,subscribersLost,shares"
      comps.queryItems = [
        URLQueryItem(name: "ids", value: "channel==\(channelID)"),
        URLQueryItem(name: "startDate", value: formatter.string(from: start)),
        URLQueryItem(name: "endDate", value: formatter.string(from: end)),
        URLQueryItem(name: "dimensions", value: "video"),
        URLQueryItem(name: "filters", value: "video==" + ids.joined(separator: ",")),
        URLQueryItem(name: "metrics", value: metrics),
        URLQueryItem(name: "maxResults", value: "200"),
      ]
      let (data, response) = try await URLSession.shared.data(
        for: authorizedRequest(try urlAusKomponenten(comps)))
      guard let http = response as? HTTPURLResponse else {
        throw YouTubeFehler.apiFehler("Keine Video-Analytics-Antwort")
      }
      if http.statusCode == 403 && includeRevenue {
        return try await request(includeRevenue: false)
      }
      guard (200..<300).contains(http.statusCode) else {
        throw googleAPIFehler(
          data: data, httpStatus: http.statusCode,
          fallback: "Video-Analytics konnten nicht geladen werden.",
          standardDienst: "YouTube Analytics API")
      }
      return (try JSONDecoder().decode(AnalyticsResponse.self, from: data), includeRevenue)
    }

    let (result, revenueIncluded) = try await request(includeRevenue: mayRequestRevenue)
    var map: [String: VideoAnalyticsRow] = [:]
    for row in result.rows ?? [] {
      guard !row.isEmpty else { continue }
      let id = row[0].stringValue
      guard !id.isEmpty else { continue }
      map[id] = VideoAnalyticsRow(
        watchMinutes: row.safeInt(at: 1),
        avgPercent: row.safeDouble(at: 2),
        subsGained: row.safeInt(at: 3),
        subsLost: row.safeInt(at: 4),
        shares: row.safeInt(at: 5),
        revenue: revenueIncluded ? row.safeDouble(at: 6) : nil
      )
    }
    return map
  }

  private func ladeChannelRaw(channelID: String? = nil) async throws -> ChannelItem? {
    var comps = try urlKomponenten("https://www.googleapis.com/youtube/v3/channels")
    var items = [
      URLQueryItem(name: "part", value: "snippet,statistics,contentDetails,status")
    ]
    if let channelID, !channelID.isEmpty {
      items.append(URLQueryItem(name: "id", value: channelID))
    } else {
      items.append(URLQueryItem(name: "mine", value: "true"))
    }
    comps.queryItems = items
    let (data, response) = try await URLSession.shared.data(for: authorizedRequest(try urlAusKomponenten(comps)))
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
      let status = (response as? HTTPURLResponse)?.statusCode ?? -1
      throw googleAPIFehler(
        data: data, httpStatus: status, fallback: "Kanalstatus konnte nicht geladen werden.",
        standardDienst: "YouTube Data API v3")
    }
    return try JSONDecoder().decode(ChannelListResponse.self, from: data).items.first
  }

  // MARK: - Trend Intelligence

  func trendChancen(fuer kanaele: [Kanal], zusaetzlicheThemen: [String] = [], region: String = "DE")
    async throws -> [Chance]
  {
    guard let id = aktiveVerbindungID else {
      throw YouTubeFehler.oauthFehlgeschlagen("Kein Google-Zugang ausgewählt")
    }
    try await autorisierenWennNoetig(verbindungID: id)

    let cacheThemen = (kanaele.map(\.thema) + zusaetzlicheThemen)
      .map { $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }
      .filter { !$0.isEmpty }
      .sorted()
    let cacheKey = ([region.uppercased()] + cacheThemen).joined(separator: "|")
    if trendCacheKey == cacheKey,
      let datum = trendCacheDatum,
      Date().timeIntervalSince(datum) < 300,
      !trendCache.isEmpty
    {
      return trendCache
    }

    var result: [Chance] = []
    var geseheneVideoIDs = Set<String>()
    let iso = ISO8601DateFormatter()

    // 1) Breiter aktueller YouTube-Markt: mostPopular.
    var popular = try urlKomponenten("https://www.googleapis.com/youtube/v3/videos")
    popular.queryItems = [
      URLQueryItem(name: "part", value: "snippet,statistics"),
      URLQueryItem(name: "chart", value: "mostPopular"),
      URLQueryItem(name: "regionCode", value: region),
      URLQueryItem(name: "maxResults", value: "50"),
    ]
    let (popularData, popularResponse) = try await URLSession.shared.data(
      for: authorizedRequest(try urlAusKomponenten(popular)))
    guard let popularHTTP = popularResponse as? HTTPURLResponse,
      (200..<300).contains(popularHTTP.statusCode)
    else {
      let status = (popularResponse as? HTTPURLResponse)?.statusCode ?? -1
      throw googleAPIFehler(
        data: popularData, httpStatus: status,
        fallback: "Aktuelle YouTube-Trends konnten nicht geladen werden.",
        standardDienst: "YouTube Data API v3")
    }
    let popularVideos = try JSONDecoder().decode(VideoListResponse.self, from: popularData)
    for video in popularVideos.items {
      geseheneVideoIDs.insert(video.id)
      let match = bestesKanalMatching(titel: video.snippet.title, kanaele: kanaele)
      if let chance = chanceAusVideo(
        video,
        thema: match?.thema ?? "YouTube Trends",
        kanalID: match?.id,
        signal: "YouTube · meistgesehen in \(region)",
        basisBoost: 7,
        iso: iso
      ) {
        result.append(chance)
      }
    }

    // 2) Kanal- und Plan-Themen: frische Videos mit hoher aktueller Geschwindigkeit.
    let alleThemen = Array(
      Set(
        (kanaele.map(\.thema) + zusaetzlicheThemen)
          .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
          .filter { !$0.isEmpty })
    ).sorted()
    // Sechs Suchabfragen pro Lauf halten das YouTube-Quota kontrollierbar.
    // Bei vielen Themen rotiert Blackstock alle drei Stunden durch die Kategorien,
    // statt dauerhaft nur dieselben sechs Themen zu bevorzugen.
    let themen: [String] = {
      guard alleThemen.count > 6 else { return alleThemen }
      let slot = Int(Date().timeIntervalSince1970 / (3 * 3600))
      let start = (slot * 6) % alleThemen.count
      return (0..<6).map { alleThemen[(start + $0) % alleThemen.count] }
    }()
    let publishedAfter = iso.string(from: Date().addingTimeInterval(-72 * 3600))

    for thema in themen {
      var comps = try urlKomponenten("https://www.googleapis.com/youtube/v3/search")
      comps.queryItems = [
        URLQueryItem(name: "part", value: "snippet"),
        URLQueryItem(name: "type", value: "video"),
        URLQueryItem(name: "order", value: "viewCount"),
        URLQueryItem(name: "maxResults", value: "25"),
        URLQueryItem(name: "publishedAfter", value: publishedAfter),
        URLQueryItem(name: "regionCode", value: region),
        URLQueryItem(name: "q", value: thema),
      ]
      let (searchData, searchResponse) = try await URLSession.shared.data(
        for: authorizedRequest(try urlAusKomponenten(comps)))
      guard let searchHTTP = searchResponse as? HTTPURLResponse,
        (200..<300).contains(searchHTTP.statusCode)
      else {
        let status = (searchResponse as? HTTPURLResponse)?.statusCode ?? -1
        throw googleAPIFehler(
          data: searchData, httpStatus: status,
          fallback: "YouTube-Suche konnte nicht geladen werden.",
          standardDienst: "YouTube Data API v3")
      }
      let search = try JSONDecoder().decode(SearchResponse.self, from: searchData)
      let ids = search.items.compactMap { $0.id.videoId }.filter { !geseheneVideoIDs.contains($0) }
      guard !ids.isEmpty else { continue }

      var detailComps = try urlKomponenten("https://www.googleapis.com/youtube/v3/videos")
      detailComps.queryItems = [
        URLQueryItem(name: "part", value: "snippet,statistics"),
        URLQueryItem(name: "id", value: ids.joined(separator: ",")),
      ]
      let (detailData, detailResponse) = try await URLSession.shared.data(
        for: authorizedRequest(try urlAusKomponenten(detailComps)))
      guard let detailHTTP = detailResponse as? HTTPURLResponse,
        (200..<300).contains(detailHTTP.statusCode)
      else {
        let status = (detailResponse as? HTTPURLResponse)?.statusCode ?? -1
        throw googleAPIFehler(
          data: detailData, httpStatus: status,
          fallback: "YouTube-Video-Details konnten nicht geladen werden.",
          standardDienst: "YouTube Data API v3")
      }
      let videos = try JSONDecoder().decode(VideoListResponse.self, from: detailData)
      let kanal = kanaele.first(where: {
        $0.thema.localizedCaseInsensitiveContains(thema)
          || thema.localizedCaseInsensitiveContains($0.thema)
      })

      for video in videos.items {
        geseheneVideoIDs.insert(video.id)
        if let chance = chanceAusVideo(
          video,
          thema: thema,
          kanalID: kanal?.id,
          signal: "YouTube · starkes frisches Signal für \(thema)",
          basisBoost: 3,
          iso: iso
        ) {
          result.append(chance)
        }
      }
    }

    // Ähnliche Titel nicht mehrfach zeigen.
    var titelKeys = Set<String>()
    let dedupliziert =
      result
      .sorted { opportunityValue($0) > opportunityValue($1) }
      .filter { chance in
        let key = normalisierterTitel(chance.titel)
        guard !titelKeys.contains(key) else { return false }
        titelKeys.insert(key)
        return true
      }

    let ausgabe = Array(dedupliziert.prefix(160))
    trendCacheKey = cacheKey
    trendCacheDatum = Date()
    trendCache = ausgabe
    return ausgabe
  }

  private func chanceAusVideo(
    _ video: VideoItem, thema: String, kanalID: UUID?, signal: String, basisBoost: Double,
    iso: ISO8601DateFormatter
  ) -> Chance? {
    let published = iso.date(from: video.snippet.publishedAt) ?? Date().addingTimeInterval(-3600)
    let hours = max(0.5, Date().timeIntervalSince(published) / 3600)
    let views = Double(Int(video.statistics.viewCount ?? "0") ?? 0)
    let likes = Double(Int(video.statistics.likeCount ?? "0") ?? 0)
    let comments = Double(Int(video.statistics.commentCount ?? "0") ?? 0)
    let velocity = views / hours
    let likeRate = views > 0 ? likes / views : 0
    let commentRate = views > 0 ? comments / views : 0

    let velocityComponent = min(44.0, max(0, log10(max(velocity, 1)) * 9.8))
    let engagementComponent = min(25.0, likeRate * 340 + commentRate * 880)
    let recencyComponent = max(0, 12 - min(12, hours / 6))
    let trendScore = min(
      99, 22 + basisBoost + velocityComponent + engagementComponent + recencyComponent)
    guard trendScore >= 58 else { return nil }

    let confidence = min(
      0.90, 0.58 + min(0.17, views / 2_500_000) + min(0.09, max(0, 72 - hours) / 72 * 0.09))
    let viral = min(0.88, max(0.16, (trendScore - 42) / 70))
    let competition = min(96, 42 + trendScore * 0.48)
    let contentGap = max(22, 100 - competition * 0.55)
    let phase: TrendPhase =
      hours < 12 && trendScore > 78 ? .beschleunigend : (hours < 36 ? .entstehend : .hoehepunkt)
    let risk: Risiko = confidence >= 0.79 ? .niedrig : .mittel

    return Chance(
      titel: video.snippet.title,
      thema: thema,
      empfohlenerKanalID: kanalID,
      trendScore: trendScore,
      qualitaetsPotenzial: min(97, 70 + trendScore * 0.23),
      abonnentenPotenzial: min(96, 63 + trendScore * 0.27),
      viralitaetsWahrscheinlichkeit: viral,
      konfidenz: confidence,
      risiko: risk,
      quellenAnzahl: 1,
      primaerquellen: 0,
      widersprueche: 0,
      trendHalbwertszeitStunden: max(4, 42 - (trendScore - 58) * 0.58),
      empfohleneFormate: trendScore > 88 ? [.short, .longform] : [.short],
      begruendung:
        "\(signal). Das erkannte Video ist ausschließlich ein Marktsignal. Blackstock darf daraus weder Fakten noch Formulierungen übernehmen; vor der Produktion ist unabhängige Recherche und Claim-Verifikation erforderlich.",
      entdecktAm: Date(),
      istDemo: false,
      momentum: max(0, trendScore - 50),
      nachfrageScore: trendScore,
      wettbewerbScore: competition,
      contentGapScore: contentGap,
      umsatzPotenzial: min(95, 48 + trendScore * 0.42),
      evergreenScore: phase == .beschleunigend ? 42 : 58,
      phase: phase,
      trendVerlauf: [],
      datenherkunft: .live,
      beobachtet: false,
      quellenSchluessel: "youtube:\(video.id)"
    )
  }

  private func bestesKanalMatching(titel: String, kanaele: [Kanal]) -> Kanal? {
    let lower = titel.lowercased()
    return kanaele.max { lhs, rhs in
      matchingScore(lhs.thema, in: lower) < matchingScore(rhs.thema, in: lower)
    }.flatMap { matchingScore($0.thema, in: lower) > 0 ? $0 : nil }
  }

  private func matchingScore(_ thema: String, in text: String) -> Int {
    let words = thema.lowercased().split { !$0.isLetter && !$0.isNumber }.filter { $0.count >= 3 }
    return words.reduce(0) { $0 + (text.contains($1) ? 1 : 0) }
  }

  private func normalisierterTitel(_ title: String) -> String {
    title.lowercased().filter { $0.isLetter || $0.isNumber || $0 == " " }.split(separator: " ")
      .prefix(8).joined(separator: " ")
  }

  private func opportunityValue(_ chance: Chance) -> Double {
    chance.trendScore * chance.konfidenz * (0.65 + chance.abonnentenPotenzial / 230)
  }

  // MARK: - Livestreams

  func livestreamEinrichten(
    titel: String, beschreibung: String, start: Date, privatStatus: String = "private"
  ) async throws -> LiveSetup {
    guard let verbindungID = aktiveVerbindungID else {
      throw YouTubeFehler.oauthFehlgeschlagen("Kein Google-Zugang ausgewählt")
    }
    try await featureAutorisieren(.liveManagement, verbindungID: verbindungID)
    guard start > Date().addingTimeInterval(60) else {
      throw YouTubeFehler.apiFehler(
        "Der Livestream-Start muss mindestens wenige Minuten in der Zukunft liegen.")
    }
    let privacy =
      ["private", "unlisted", "public"].contains(privatStatus) ? privatStatus : "private"
    let iso = ISO8601DateFormatter()

    var broadcastComponents = try urlKomponenten(
      "https://www.googleapis.com/youtube/v3/liveBroadcasts")
    broadcastComponents.queryItems = [
      URLQueryItem(name: "part", value: "snippet,status,contentDetails")
    ]
    var broadcastRequest = try authorizedRequest(try urlAusKomponenten(broadcastComponents))
    broadcastRequest.httpMethod = "POST"
    broadcastRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
    broadcastRequest.httpBody = try JSONSerialization.data(withJSONObject: [
      "snippet": [
        "title": String(titel.prefix(100)),
        "description": beschreibung,
        "scheduledStartTime": iso.string(from: start),
      ],
      "status": [
        "privacyStatus": privacy,
        "selfDeclaredMadeForKids": false,
      ],
      "contentDetails": [
        "enableAutoStart": true,
        "enableAutoStop": true,
        "enableDvr": true,
        "recordFromStart": true,
      ],
    ])
    let (broadcastData, broadcastResponse) = try await URLSession.shared.data(for: broadcastRequest)
    guard let bHTTP = broadcastResponse as? HTTPURLResponse, (200..<300).contains(bHTTP.statusCode)
    else {
      throw googleAPIFehler(
        data: broadcastData, httpStatus: (broadcastResponse as? HTTPURLResponse)?.statusCode ?? -1,
        fallback: "YouTube-Livestream konnte nicht angelegt werden.",
        standardDienst: "YouTube Data API v3")
    }
    struct BroadcastResponse: Decodable { let id: String }
    let broadcast = try JSONDecoder().decode(BroadcastResponse.self, from: broadcastData)

    var streamComponents = try urlKomponenten("https://www.googleapis.com/youtube/v3/liveStreams")
    streamComponents.queryItems = [URLQueryItem(name: "part", value: "snippet,cdn,status")]
    var streamRequest = try authorizedRequest(try urlAusKomponenten(streamComponents))
    streamRequest.httpMethod = "POST"
    streamRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
    streamRequest.httpBody = try JSONSerialization.data(withJSONObject: [
      "snippet": ["title": String((titel + " · Blackstock Stream").prefix(100))],
      "cdn": [
        "frameRate": "30fps",
        "ingestionType": "rtmp",
        "resolution": "1080p",
      ],
    ])
    let (streamData, streamResponse) = try await URLSession.shared.data(for: streamRequest)
    guard let sHTTP = streamResponse as? HTTPURLResponse, (200..<300).contains(sHTTP.statusCode)
    else {
      throw googleAPIFehler(
        data: streamData, httpStatus: (streamResponse as? HTTPURLResponse)?.statusCode ?? -1,
        fallback: "YouTube-Livestream-Encoder konnte nicht angelegt werden.",
        standardDienst: "YouTube Data API v3")
    }
    struct StreamResponse: Decodable {
      struct CDN: Decodable {
        struct IngestionInfo: Decodable {
          let ingestionAddress: String
          let streamName: String
        }
        let ingestionInfo: IngestionInfo
      }
      let id: String
      let cdn: CDN
    }
    let stream = try JSONDecoder().decode(StreamResponse.self, from: streamData)

    var bindComponents = try urlKomponenten(
      "https://www.googleapis.com/youtube/v3/liveBroadcasts/bind")
    bindComponents.queryItems = [
      URLQueryItem(name: "id", value: broadcast.id),
      URLQueryItem(name: "streamId", value: stream.id),
      URLQueryItem(name: "part", value: "id,snippet,contentDetails,status"),
    ]
    var bindRequest = try authorizedRequest(try urlAusKomponenten(bindComponents))
    bindRequest.httpMethod = "POST"
    let (bindData, bindResponse) = try await URLSession.shared.data(for: bindRequest)
    guard let bindHTTP = bindResponse as? HTTPURLResponse, (200..<300).contains(bindHTTP.statusCode)
    else {
      throw googleAPIFehler(
        data: bindData, httpStatus: (bindResponse as? HTTPURLResponse)?.statusCode ?? -1,
        fallback: "YouTube-Broadcast und Stream konnten nicht verbunden werden.",
        standardDienst: "YouTube Data API v3")
    }

    return LiveSetup(
      broadcastID: broadcast.id, streamID: stream.id,
      ingestionAddress: stream.cdn.ingestionInfo.ingestionAddress,
      streamName: stream.cdn.ingestionInfo.streamName)
  }

  // MARK: - Upload

  struct ResumableUploadStatus {
    var sessionURL: String
    var confirmedBytes: Int64
    var totalBytes: Int64
  }

  func videoHochladen(
    datei: URL, titel: String, beschreibung: String, tags: [String],
    privacyStatus: String = "private", geplantFuer: Date? = nil, bestehendeSessionURL: String? = nil,
    bestaetigteBytes: Int64 = 0,
    fortschritt: ((ResumableUploadStatus) -> Void)? = nil
  ) async throws -> String {
    guard FileManager.default.fileExists(atPath: datei.path) else {
      throw YouTubeFehler.apiFehler(
        "Die ausgewählte Videodatei existiert nicht mehr. Wähle den finalen Render erneut aus.")
    }
    let attributes = try FileManager.default.attributesOfItem(atPath: datei.path)
    let size = (attributes[.size] as? NSNumber)?.int64Value ?? 0
    guard size > 0 else {
      throw YouTubeFehler.apiFehler("Die Videodatei ist leer und kann nicht hochgeladen werden.")
    }
    guard let id = aktiveVerbindungID else {
      throw YouTubeFehler.oauthFehlgeschlagen("Kein Google-Zugang ausgewählt")
    }
    try await featureAutorisieren(.upload, verbindungID: id)

    let safeTitle = String(titel.trimmingCharacters(in: .whitespacesAndNewlines).prefix(100))
    guard !safeTitle.isEmpty else {
      throw YouTubeFehler.apiFehler("Der YouTube-Titel darf nicht leer sein.")
    }
    var tagBudget = 0
    var safeTags: [String] = []
    for raw in tags {
      let tag = String(raw.trimmingCharacters(in: .whitespacesAndNewlines).prefix(30))
      guard !tag.isEmpty else { continue }
      let next = tagBudget + tag.count
      if next > 450 { break }
      safeTags.append(tag)
      tagBudget = next
    }

    let uploadURL: URL
    var offset = max(0, min(bestaetigteBytes, size))
    if let existing = bestehendeSessionURL, let existingURL = URL(string: existing) {
      uploadURL = existingURL
      let status = try await uploadSessionStatus(uploadURL: uploadURL, totalSize: size)
      if let completed = status.videoID { return completed }
      offset = status.confirmedBytes
      fortschritt?(ResumableUploadStatus(sessionURL: uploadURL.absoluteString, confirmedBytes: offset, totalBytes: size))
    } else {
      let normalizedPrivacy = ["private", "unlisted", "public"].contains(privacyStatus)
        ? privacyStatus : "private"
      let effectivePrivacy = geplantFuer == nil ? normalizedPrivacy : "private"
      let metadata = UploadMetadata(
        snippet: .init(title: safeTitle, description: beschreibung, tags: safeTags, categoryId: "22"),
        status: .init(
          privacyStatus: effectivePrivacy,
          publishAt: geplantFuer.map { ISO8601DateFormatter().string(from: $0) })
      )
      let body = try JSONEncoder().encode(metadata)
      var request = URLRequest(
        url: try sichereURL(
          "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status"
        ))
      request.httpMethod = "POST"
      request.setValue("Bearer \(try accessToken())", forHTTPHeaderField: "Authorization")
      request.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
      request.setValue(String(size), forHTTPHeaderField: "X-Upload-Content-Length")
      request.setValue(Self.mimeType(for: datei), forHTTPHeaderField: "X-Upload-Content-Type")
      request.httpBody = body
      let (data, response) = try await URLSession.shared.data(for: request)
      guard let http = response as? HTTPURLResponse,
        (200..<300).contains(http.statusCode),
        let location = http.value(forHTTPHeaderField: "Location"),
        let createdURL = URL(string: location)
      else {
        let status = (response as? HTTPURLResponse)?.statusCode ?? -1
        throw googleAPIFehler(
          data: data, httpStatus: status,
          fallback: "Hochlade-Sitzung konnte nicht gestartet werden.",
          standardDienst: "YouTube Data API v3")
      }
      uploadURL = createdURL
      offset = 0
      fortschritt?(ResumableUploadStatus(sessionURL: uploadURL.absoluteString, confirmedBytes: 0, totalBytes: size))
    }

    let handle = try FileHandle(forReadingFrom: datei)
    defer { try? handle.close() }
    let chunkSize: Int64 = 8 * 1024 * 1024
    while offset < size {
      try Task.checkCancellation()
      try handle.seek(toOffset: UInt64(offset))
      let count = Int(min(chunkSize, size - offset))
      guard let chunk = try handle.read(upToCount: count), !chunk.isEmpty else {
        throw YouTubeFehler.apiFehler("Die Videodatei konnte während des Uploads nicht weiter gelesen werden.")
      }
      let chunkEnd = offset + Int64(chunk.count) - 1
      var request = URLRequest(url: uploadURL)
      request.httpMethod = "PUT"
      request.timeoutInterval = 120
      request.setValue(Self.mimeType(for: datei), forHTTPHeaderField: "Content-Type")
      request.setValue(String(chunk.count), forHTTPHeaderField: "Content-Length")
      request.setValue("bytes \(offset)-\(chunkEnd)/\(size)", forHTTPHeaderField: "Content-Range")
      request.httpBody = chunk

      do {
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
          throw YouTubeFehler.apiFehler("YouTube hat keine gültige Upload-Antwort geliefert.")
        }
        if (200..<300).contains(http.statusCode) {
          let result = try JSONDecoder().decode(UploadResponse.self, from: data)
          fortschritt?(ResumableUploadStatus(sessionURL: uploadURL.absoluteString, confirmedBytes: size, totalBytes: size))
          return result.id
        }
        if http.statusCode == 308 {
          if let confirmed = Self.confirmedUploadBytes(from: http) {
            offset = confirmed
          } else {
            // 308 ohne Range ist nicht eindeutig. Den Session-Stand aktiv abfragen,
            // statt den gerade gesendeten Chunk ungeprüft als angekommen zu markieren.
            let status = try await uploadSessionStatus(uploadURL: uploadURL, totalSize: size)
            if let completed = status.videoID { return completed }
            offset = status.confirmedBytes
          }
          fortschritt?(ResumableUploadStatus(sessionURL: uploadURL.absoluteString, confirmedBytes: offset, totalBytes: size))
          continue
        }
        throw googleAPIFehler(
          data: data, httpStatus: http.statusCode,
          fallback: "Video konnte nicht hochgeladen werden.",
          standardDienst: "YouTube Data API v3")
      } catch is CancellationError {
        throw CancellationError()
      } catch {
        // Der Session-Status ist die Quelle der Wahrheit nach einem Transportfehler.
        // Wenn die Statusabfrage ebenfalls scheitert, bleiben Session-URL und der
        // zuletzt bestätigte Offset persistiert und der nächste Retry setzt dort an.
        if let status = try? await uploadSessionStatus(uploadURL: uploadURL, totalSize: size) {
          if let completed = status.videoID { return completed }
          offset = status.confirmedBytes
          fortschritt?(ResumableUploadStatus(sessionURL: uploadURL.absoluteString, confirmedBytes: offset, totalBytes: size))
        }
        throw error
      }
    }
    let final = try await uploadSessionStatus(uploadURL: uploadURL, totalSize: size)
    if let completed = final.videoID { return completed }
    throw YouTubeFehler.apiFehler("YouTube hat den Upload noch nicht als abgeschlossen bestätigt.")
  }

  private func uploadSessionStatus(uploadURL: URL, totalSize: Int64) async throws -> (confirmedBytes: Int64, videoID: String?) {
    var request = URLRequest(url: uploadURL)
    request.httpMethod = "PUT"
    request.setValue("0", forHTTPHeaderField: "Content-Length")
    request.setValue("bytes */\(totalSize)", forHTTPHeaderField: "Content-Range")
    let (data, response) = try await URLSession.shared.data(for: request)
    guard let http = response as? HTTPURLResponse else {
      throw YouTubeFehler.apiFehler("Upload-Session konnte nicht geprüft werden.")
    }
    if (200..<300).contains(http.statusCode) {
      return (totalSize, try JSONDecoder().decode(UploadResponse.self, from: data).id)
    }
    if http.statusCode == 308 {
      return (Self.confirmedUploadBytes(from: http) ?? 0, nil)
    }
    throw googleAPIFehler(
      data: data, httpStatus: http.statusCode,
      fallback: "Upload-Session konnte nicht fortgesetzt werden.",
      standardDienst: "YouTube Data API v3")
  }

  private static func confirmedUploadBytes(from response: HTTPURLResponse) -> Int64? {
    guard let range = response.value(forHTTPHeaderField: "Range") else { return nil }
    let tail = range.split(separator: "-").last.flatMap { Int64($0) }
    return tail.map { $0 + 1 }
  }

  func thumbnailHochladen(videoID: String, datei: URL) async throws {
    guard FileManager.default.fileExists(atPath: datei.path) else {
      throw YouTubeFehler.apiFehler("Die Thumbnail-Datei existiert nicht mehr.")
    }
    guard let id = aktiveVerbindungID else {
      throw YouTubeFehler.oauthFehlgeschlagen("Kein Google-Zugang ausgewählt")
    }
    try await autorisierenWennNoetig(verbindungID: id)
    let ext = datei.pathExtension.lowercased()
    let mime = ext == "png" ? "image/png" : "image/jpeg"
    let data = try Data(contentsOf: datei)
    var comps = try urlKomponenten("https://www.googleapis.com/upload/youtube/v3/thumbnails/set")
    comps.queryItems = [
      URLQueryItem(name: "videoId", value: videoID),
      URLQueryItem(name: "uploadType", value: "media"),
    ]
    var request = URLRequest(url: try urlAusKomponenten(comps))
    request.httpMethod = "POST"
    request.setValue("Bearer \(try accessToken())", forHTTPHeaderField: "Authorization")
    request.setValue(mime, forHTTPHeaderField: "Content-Type")
    request.setValue(String(data.count), forHTTPHeaderField: "Content-Length")
    request.httpBody = data
    let (responseData, response) = try await URLSession.shared.data(for: request)
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
      let status = (response as? HTTPURLResponse)?.statusCode ?? -1
      throw googleAPIFehler(
        data: responseData, httpStatus: status,
        fallback: "Thumbnail konnte nicht zu YouTube hochgeladen werden.",
        standardDienst: "YouTube Data API v3")
    }
  }

  private func sichereURL(_ raw: String) throws -> URL {
    guard let url = URL(string: raw) else {
      throw YouTubeFehler.apiFehler("Ungültige interne Google-/YouTube-URL.")
    }
    return url
  }

  private func urlKomponenten(_ raw: String) throws -> URLComponents {
    guard let components = URLComponents(string: raw) else {
      throw YouTubeFehler.apiFehler("Ungültige interne Google-/YouTube-URL.")
    }
    return components
  }

  private func urlAusKomponenten(_ components: URLComponents) throws -> URL {
    guard let url = components.url else {
      throw YouTubeFehler.apiFehler(
        "Die Google-/YouTube-Anfrage konnte nicht als URL aufgebaut werden.")
    }
    return url
  }

  // MARK: - Helpers

  private static func randomVerifier() -> String {
    var bytes = [UInt8](repeating: 0, count: 48)
    _ = SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes)
    return Data(bytes).base64URLEncodedString()
  }

  private static func codeChallenge(for verifier: String) -> String {
    let digest = SHA256.hash(data: Data(verifier.utf8))
    return Data(digest).base64URLEncodedString()
  }

  private static func mimeType(for url: URL) -> String {
    switch url.pathExtension.lowercased() {
    case "mov": return "video/quicktime"
    case "m4v": return "video/x-m4v"
    default: return "video/mp4"
    }
  }
}

private struct GoogleProfil: Decodable {
  let email: String?
  let name: String?
}

extension Data {
  fileprivate func base64URLEncodedString() -> String {
    base64EncodedString()
      .replacingOccurrences(of: "+", with: "-")
      .replacingOccurrences(of: "/", with: "_")
      .replacingOccurrences(of: "=", with: "")
  }
}

private struct TokenResponse: Decodable {
  let accessToken: String
  let expiresIn: Int
  let refreshToken: String?
  let scope: String?

  enum CodingKeys: String, CodingKey {
    case accessToken = "access_token"
    case expiresIn = "expires_in"
    case refreshToken = "refresh_token"
    case scope
  }
}

private struct ChannelListResponse: Decodable { let items: [ChannelItem] }
private struct ChannelItem: Decodable {
  let id: String
  let snippet: ChannelSnippet
  let statistics: ChannelStatistics
  let contentDetails: ChannelContentDetails
}
private struct ChannelSnippet: Decodable {
  let title: String
  let description: String
  let customUrl: String?
}
private struct ChannelStatistics: Decodable {
  let viewCount: String?
  let subscriberCount: String?
  let videoCount: String?
}
private struct ChannelContentDetails: Decodable { let relatedPlaylists: RelatedPlaylists }
private struct RelatedPlaylists: Decodable { let uploads: String? }

private struct AnalyticsResponse: Decodable {
  let rows: [[AnalyticsValue]]?
}

private enum AnalyticsValue: Decodable {
  case int(Int)
  case double(Double)
  case string(String)

  init(from decoder: Decoder) throws {
    let c = try decoder.singleValueContainer()
    if let i = try? c.decode(Int.self) {
      self = .int(i)
      return
    }
    if let d = try? c.decode(Double.self) {
      self = .double(d)
      return
    }
    self = .string((try? c.decode(String.self)) ?? "")
  }

  var intValue: Int {
    switch self {
    case .int(let v): v
    case .double(let v): Int(v)
    case .string(let v): Int(v) ?? 0
    }
  }
  var doubleValue: Double {
    switch self {
    case .int(let v): Double(v)
    case .double(let v): v
    case .string(let v): Double(v) ?? 0
    }
  }
  var stringValue: String {
    switch self {
    case .int(let v): String(v)
    case .double(let v): String(v)
    case .string(let v): v
    }
  }
}

extension Array where Element == AnalyticsValue {
  fileprivate func safeInt(at index: Int) -> Int {
    indices.contains(index) ? self[index].intValue : 0
  }
  fileprivate func safeDouble(at index: Int) -> Double {
    indices.contains(index) ? self[index].doubleValue : 0
  }
}

private struct PlaylistItemsResponse: Decodable {
  let items: [PlaylistItem]
}
private struct PlaylistItem: Decodable {
  let contentDetails: PlaylistContentDetails
}
private struct PlaylistContentDetails: Decodable { let videoId: String? }

private struct VideoListResponse: Decodable { let items: [VideoItem] }
private struct VideoItem: Decodable {
  let id: String
  let snippet: VideoSnippet
  let statistics: VideoStatistics
}
private struct VideoSnippet: Decodable {
  let title: String
  let publishedAt: String
}
private struct VideoStatistics: Decodable {
  let viewCount: String?
  let likeCount: String?
  let commentCount: String?
}

private struct SearchResponse: Decodable { let items: [SearchItem] }
private struct SearchItem: Decodable { let id: SearchID }
private struct SearchID: Decodable { let videoId: String? }

private struct UploadMetadata: Encodable {
  struct Snippet: Encodable {
    let title: String
    let description: String
    let tags: [String]
    let categoryId: String
  }
  struct Status: Encodable {
    let privacyStatus: String
    let publishAt: String?
  }
  let snippet: Snippet
  let status: Status
}
private struct UploadResponse: Decodable { let id: String }

private struct GoogleAPIErrorEnvelope: Decodable {
  let error: GoogleAPIErrorBody
}

private struct GoogleAPIErrorBody: Decodable {
  let code: Int?
  let message: String
  let status: String?
  let errors: [GoogleAPIErrorItem]?
  let details: [GoogleAPIErrorDetail]?
}

private struct GoogleAPIErrorItem: Decodable {
  let reason: String?
  let message: String?
}

private struct GoogleAPIErrorDetail: Decodable {
  let reason: String?
  let metadata: GoogleAPIErrorMetadata?
}

private struct GoogleAPIErrorMetadata: Decodable {
  let serviceTitle: String?
  let service: String?
  let consumer: String?
  let activationUrl: String?
}
