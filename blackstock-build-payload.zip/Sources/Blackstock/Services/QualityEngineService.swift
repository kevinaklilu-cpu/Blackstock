import Foundation

struct LokaleQualitaetsBewertung {
  var story: Double?
  var hook: Double?
  var titel: Double?
  var originalitaet: Double?
  var rechte: Double?
  var hinweise: [String]
}

final class QualityEngineService {
  static let shared = QualityEngineService()

  func bewerten(produktion: Produktion, medien: [MedienAsset], andereProduktionen: [Produktion])
    -> LokaleQualitaetsBewertung
  {
    var hinweise: [String] = []

    let script = produktion.skript.trimmingCharacters(in: .whitespacesAndNewlines)
    let hook = produktion.hook.trimmingCharacters(in: .whitespacesAndNewlines)
    let title = produktion.arbeitstitel.trimmingCharacters(in: .whitespacesAndNewlines)

    let storyScore: Double? = {
      guard !script.isEmpty else { return nil }
      let words = script.split(whereSeparator: { $0.isWhitespace }).count
      var score = 82.0
      if words >= 80 { score += 5 }
      if words >= 160 { score += 4 }
      if words > 2_500 { score -= 5 }
      if script.contains("[VERIFY]") {
        score -= 3
        hinweise.append("Skript enthält noch [VERIFY]-Marker")
      }
      if script.contains("?") { score += 1 }
      return clamp(score)
    }()

    let hookScore: Double? = {
      guard !hook.isEmpty else { return nil }
      let chars = hook.count
      var score = 86.0
      if chars >= 20 && chars <= 120 { score += 6 }
      if chars > 180 {
        score -= 12
        hinweise.append("Hook ist sehr lang")
      }
      if hook.lowercased().hasPrefix("in diesem video") {
        score -= 8
        hinweise.append("Hook startet generisch")
      }
      return clamp(score)
    }()

    let titleScore: Double? = {
      guard !title.isEmpty else { return nil }
      var score = 88.0
      if title.count >= 28 && title.count <= 70 { score += 6 }
      if title.count > 95 {
        score -= 15
        hinweise.append("Titel ist für YouTube sehr lang")
      }
      if title == title.uppercased() && title.count > 12 {
        score -= 5
        hinweise.append("Titel besteht fast nur aus Großbuchstaben")
      }
      return clamp(score)
    }()

    let originalityScore: Double? = {
      guard !script.isEmpty else { return nil }
      let current = tokens(script + " " + title)
      guard !current.isEmpty else { return nil }
      var maxOverlap = 0.0
      for other in andereProduktionen where other.id != produktion.id {
        let otherTokens = tokens(other.skript + " " + other.arbeitstitel)
        guard !otherTokens.isEmpty else { continue }
        let intersection = current.intersection(otherTokens).count
        let union = current.union(otherTokens).count
        if union > 0 { maxOverlap = max(maxOverlap, Double(intersection) / Double(union)) }
      }
      if maxOverlap > 0.72 { hinweise.append("Hohe Textähnlichkeit zu einem bestehenden Projekt") }
      return clamp(98 - maxOverlap * 35)
    }()

    let rightsScore: Double? = {
      guard !medien.isEmpty else { return nil }
      if medien.contains(where: { $0.herkunft == .unklar }) {
        hinweise.append("Mindestens ein Asset hat ungeklärte Herkunft")
        return 40
      }
      return 100
    }()

    return LokaleQualitaetsBewertung(
      story: storyScore,
      hook: hookScore,
      titel: titleScore,
      originalitaet: originalityScore,
      rechte: rightsScore,
      hinweise: hinweise
    )
  }

  private func tokens(_ text: String) -> Set<String> {
    Set(
      text.lowercased()
        .components(separatedBy: CharacterSet.alphanumerics.inverted)
        .filter { $0.count >= 4 })
  }

  private func clamp(_ value: Double) -> Double { max(0, min(100, value)) }
}
