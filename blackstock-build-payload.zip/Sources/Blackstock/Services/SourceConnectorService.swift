import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct SourceSearchRequest: Hashable {
  var query: String
  var topicTags: [String]
  var language: String?
  var maxResults: Int = 12
}

struct SourceLicenseInfo: Hashable {
  var rightsStatus: RightsStatus
  var licenseType: String?
  var allowedUses: [SourceAllowedUse]
  var attribution: String?
}

protocol SourceConnectorProtocol {
  var kind: SourceProviderKind { get }
  var displayName: String { get }
  func authorize() async throws
  func search(_ request: SourceSearchRequest) async throws -> [SourceAsset]
  func resolve(_ asset: SourceAsset) async throws -> SourceAsset
  func downloadURL(for asset: SourceAsset) async throws -> URL
  func licenseInfo(for asset: SourceAsset) async throws -> SourceLicenseInfo
  func thumbnailURL(for asset: SourceAsset) async throws -> URL?
  func transcript(for asset: SourceAsset) async throws -> String?
}

enum SourceConnectorError: LocalizedError {
  case unsupported(String)
  case invalidURL
  case rightsMissing
  case notDownloadableReference

  var errorDescription: String? {
    switch self {
    case .unsupported(let detail): return detail
    case .invalidURL: return "Die Remote-Medienadresse ist ungültig."
    case .rightsMissing: return "Die Quelle hat keinen ausreichend geklärten maschinenlesbaren Rechtezustand."
    case .notDownloadableReference:
      return "Ein YouTube-Trendvideo ist nur eine Referenz und keine automatisch downloadbare Schnittquelle."
    }
  }
}

/// Connector for user-controlled HTTPS media. Blackstock never infers rights from the URL;
/// callers must attach explicit rights metadata before a source becomes publishable.
final class DirectHTTPSSourceConnector: SourceConnectorProtocol {
  let kind: SourceProviderKind = .directHTTPS
  let displayName = "Direct HTTPS / Own Media"
  private var knownAssets: [SourceAsset]

  init(knownAssets: [SourceAsset] = []) {
    self.knownAssets = knownAssets.filter { $0.provider == .directHTTPS }
  }

  func authorize() async throws {}

  func search(_ request: SourceSearchRequest) async throws -> [SourceAsset] {
    let query = request.query.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
    let tags = request.topicTags.map {
      $0.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
    }
    return knownAssets.filter { asset in
      let haystack = ([asset.title] + asset.topicTags).joined(separator: " ")
        .folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
      return query.isEmpty || haystack.contains(query) || tags.contains(where: haystack.contains)
    }.prefix(request.maxResults).map { $0 }
  }

  func resolve(_ asset: SourceAsset) async throws -> SourceAsset {
    guard asset.provider == .directHTTPS else {
      throw SourceConnectorError.unsupported("Diese Quelle gehört nicht zum Direct-HTTPS-Connector.")
    }
    _ = try validatedURL(asset)
    return asset
  }

  func downloadURL(for asset: SourceAsset) async throws -> URL {
    guard asset.canEdit else { throw SourceConnectorError.rightsMissing }
    return try validatedURL(asset)
  }

  func licenseInfo(for asset: SourceAsset) async throws -> SourceLicenseInfo {
    SourceLicenseInfo(
      rightsStatus: asset.rightsStatus,
      licenseType: asset.licenseType,
      allowedUses: asset.allowedUses,
      attribution: asset.allowedUses.contains(.attributionRequired) ? asset.creator : nil
    )
  }

  func thumbnailURL(for asset: SourceAsset) async throws -> URL? { nil }
  func transcript(for asset: SourceAsset) async throws -> String? { asset.transcript }

  private func validatedURL(_ asset: SourceAsset) throws -> URL {
    guard let raw = asset.remoteURL, let url = URL(string: raw), url.scheme?.lowercased() == "https",
      url.host != nil
    else { throw SourceConnectorError.invalidURL }
    return url
  }
}

/// Deliberately metadata-only. It is a product-level guard against accidentally turning
/// a YouTube discovery result into a ripped source file.
final class YouTubeTrendReferenceConnector: SourceConnectorProtocol {
  let kind: SourceProviderKind = .youtubeReference
  let displayName = "YouTube Trend Reference"

  func authorize() async throws {}
  func search(_ request: SourceSearchRequest) async throws -> [SourceAsset] { [] }
  func resolve(_ asset: SourceAsset) async throws -> SourceAsset { asset }
  func downloadURL(for asset: SourceAsset) async throws -> URL {
    throw SourceConnectorError.notDownloadableReference
  }
  func licenseInfo(for asset: SourceAsset) async throws -> SourceLicenseInfo {
    SourceLicenseInfo(rightsStatus: .restricted, licenseType: nil, allowedUses: [], attribution: nil)
  }
  func thumbnailURL(for asset: SourceAsset) async throws -> URL? { nil }
  func transcript(for asset: SourceAsset) async throws -> String? { nil }
}

/// User-owned remote media catalogue. The manifest is a plain HTTPS JSON document whose
/// entries carry explicit machine-readable rights. This provides a real cloud/CDN workflow
/// without requiring the user to download files to the Mac first.
final class RemoteManifestSourceConnector: SourceConnectorProtocol {
  let kind: SourceProviderKind = .userCloud
  let displayName = "User-owned Remote Manifest"

  struct Manifest: Decodable {
    var version: Int?
    var assets: [ManifestAsset]
  }

  struct ManifestAsset: Decodable {
    var id: String?
    var url: String
    var title: String
    var duration: Double?
    var creator: String?
    var sourcePage: String?
    var licenseType: String?
    var rights: String
    var allowedUses: [String]
    var channelOwnership: Bool?
    var transcript: String?
    var language: String?
    var topicTags: [String]?
    var expiresAt: Date?
  }

  private let manifestURLs: [URL]
  private let knownAssets: [SourceAsset]

  init(manifestURLs: [String], knownAssets: [SourceAsset] = []) {
    self.manifestURLs = manifestURLs.compactMap { raw in
      guard let url = URL(string: raw), url.scheme?.lowercased() == "https", url.host != nil else { return nil }
      return url
    }
    self.knownAssets = knownAssets.filter { $0.provider == .userCloud }
  }

  func authorize() async throws {}

  func search(_ request: SourceSearchRequest) async throws -> [SourceAsset] {
    var assets = knownAssets
    for url in manifestURLs {
      do { assets.append(contentsOf: try await loadManifest(url)) }
      catch { continue }
    }
    var seen = Set<String>()
    let query = Self.fold(request.query)
    let tags = request.topicTags.map(Self.fold)
    return assets.filter { asset in
      let key = asset.providerAssetID ?? asset.remoteURL ?? asset.id.uuidString
      guard seen.insert(key).inserted else { return false }
      guard RightsService.canEnterAutomaticRender(asset) else { return false }
      let haystack = Self.fold(([asset.title] + asset.topicTags).joined(separator: " "))
      return query.isEmpty || haystack.contains(query) || tags.contains(where: haystack.contains)
    }.prefix(request.maxResults).map { $0 }
  }

  func resolve(_ asset: SourceAsset) async throws -> SourceAsset {
    guard asset.provider == .userCloud else {
      throw SourceConnectorError.unsupported("Diese Quelle gehört nicht zum Remote-Manifest-Connector.")
    }
    _ = try validatedURL(asset)
    return asset
  }

  func downloadURL(for asset: SourceAsset) async throws -> URL {
    guard RightsService.canEnterAutomaticRender(asset) else { throw SourceConnectorError.rightsMissing }
    return try validatedURL(asset)
  }

  func licenseInfo(for asset: SourceAsset) async throws -> SourceLicenseInfo {
    SourceLicenseInfo(
      rightsStatus: asset.rightsStatus,
      licenseType: asset.licenseType,
      allowedUses: asset.allowedUses,
      attribution: asset.allowedUses.contains(.attributionRequired) ? asset.creator : nil)
  }

  func thumbnailURL(for asset: SourceAsset) async throws -> URL? { nil }
  func transcript(for asset: SourceAsset) async throws -> String? { asset.transcript }

  private func loadManifest(_ url: URL) async throws -> [SourceAsset] {
    var request = URLRequest(url: url)
    request.timeoutInterval = 30
    request.setValue("application/json", forHTTPHeaderField: "Accept")
    let (data, response) = try await URLSession.shared.data(for: request)
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
      throw SourceConnectorError.unsupported("Remote-Medienmanifest konnte nicht geladen werden.")
    }
    guard data.count <= 2 * 1024 * 1024 else {
      throw SourceConnectorError.unsupported("Remote-Medienmanifest ist größer als 2 MB.")
    }
    let decoder = JSONDecoder()
    decoder.dateDecodingStrategy = .iso8601
    let manifest = try decoder.decode(Manifest.self, from: data)
    return manifest.assets.compactMap(Self.makeAsset)
  }

  private static func makeAsset(_ item: ManifestAsset) -> SourceAsset? {
    guard let url = URL(string: item.url), url.scheme?.lowercased() == "https", url.host != nil else { return nil }
    guard let rights = parseRights(item.rights) else { return nil }
    let uses = item.allowedUses.compactMap(parseUse)
    let ownership = item.channelOwnership ?? (rights == .owned)
    let asset = SourceAsset(
      provider: .userCloud,
      providerAssetID: item.id,
      remoteURL: url.absoluteString,
      title: item.title.trimmingCharacters(in: .whitespacesAndNewlines),
      duration: item.duration,
      creator: item.creator,
      sourcePage: item.sourcePage ?? url.absoluteString,
      licenseType: rights == .owned ? (item.licenseType ?? "User-owned media") : item.licenseType,
      rightsStatus: rights,
      allowedUses: uses,
      channelOwnership: ownership,
      transcript: item.transcript,
      language: item.language,
      topicTags: item.topicTags ?? [],
      expiresAt: item.expiresAt)
    return RightsService.canEnterAutomaticRender(asset) ? asset : nil
  }

  private static func parseRights(_ raw: String) -> RightsStatus? {
    switch raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
    case "owned", "eigentum": return .owned
    case "licensed", "lizenziert": return .licensed
    case "publicdomain", "public_domain", "public domain": return .publicDomain
    case "creativecommonscompatible", "creative_commons_compatible", "cc-compatible": return .creativeCommonsCompatible
    case "unknown", "unbekannt": return .unknown
    case "restricted", "eingeschränkt", "eingeschraenkt": return .restricted
    default: return nil
    }
  }

  private static func parseUse(_ raw: String) -> SourceAllowedUse? {
    switch raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
    case "edit", "bearbeiten": return .edit
    case "publish", "veröffentlichen", "veroeffentlichen": return .publish
    case "commercial", "kommerziell": return .commercial
    case "attributionrequired", "attribution_required", "namensnennung": return .attributionRequired
    case "noderivatives", "no_derivatives", "keine bearbeitung": return .noDerivatives
    default: return nil
    }
  }

  private func validatedURL(_ asset: SourceAsset) throws -> URL {
    guard let raw = asset.remoteURL, let url = URL(string: raw), url.scheme?.lowercased() == "https", url.host != nil else {
      throw SourceConnectorError.invalidURL
    }
    return url
  }

  private static func fold(_ value: String) -> String {
    value.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
  }
}

/// Extension point for licensed stock/media vendors. It intentionally does not fake a
/// provider API when no provider/account is configured.
final class LicensedProviderConnector: SourceConnectorProtocol {
  let kind: SourceProviderKind = .licensedProvider
  let displayName: String

  init(displayName: String = "Lizenzierter Provider") { self.displayName = displayName }

  func authorize() async throws {
    throw SourceConnectorError.unsupported("Für diesen lizenzierten Provider ist noch kein echter API-Adapter konfiguriert.")
  }
  func search(_ request: SourceSearchRequest) async throws -> [SourceAsset] { [] }
  func resolve(_ asset: SourceAsset) async throws -> SourceAsset { asset }
  func downloadURL(for asset: SourceAsset) async throws -> URL {
    throw SourceConnectorError.unsupported("Kein Download-Adapter für den lizenzierten Provider konfiguriert.")
  }
  func licenseInfo(for asset: SourceAsset) async throws -> SourceLicenseInfo {
    SourceLicenseInfo(
      rightsStatus: asset.rightsStatus, licenseType: asset.licenseType,
      allowedUses: asset.allowedUses, attribution: asset.creator)
  }
  func thumbnailURL(for asset: SourceAsset) async throws -> URL? { nil }
  func transcript(for asset: SourceAsset) async throws -> String? { asset.transcript }
}

enum RightsService {
  static func canEnterAutomaticRender(_ asset: SourceAsset) -> Bool {
    asset.canEdit && asset.canPublish
  }

  static func blockingReason(_ asset: SourceAsset) -> String? {
    guard asset.rightsStatus.potentiallyUsable else {
      return "Rechtezustand „\(asset.rightsStatus.rawValue)“ blockiert automatische Nutzung."
    }
    if asset.isExpired { return "Die Nutzungsberechtigung bzw. Remote-Quelle ist abgelaufen." }
    if asset.rightsStatus != .owned && asset.rightsStatus != .publicDomain && !asset.channelOwnership
      && asset.licenseType?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty != false
    {
      return "Lizenztyp fehlt."
    }
    guard asset.attributionSatisfied else {
      return "Die Lizenz verlangt Namensnennung, aber Creator/Quellseite fehlt."
    }
    guard asset.canEdit else { return "Bearbeitung ist für diese Quelle nicht freigegeben." }
    guard asset.canPublish else { return "Veröffentlichung ist für diese Quelle nicht freigegeben." }
    if asset.rightsStatus == .licensed || asset.rightsStatus == .creativeCommonsCompatible {
      guard asset.allowedUses.contains(.commercial) else {
        return "Für automatische Veröffentlichung fehlt die ausdrücklich erlaubte kommerzielle Nutzung."
      }
    }
    return nil
  }
}

final class SourceDiscoveryService {
  private let connectors: [any SourceConnectorProtocol]

  init(connectors: [any SourceConnectorProtocol]) { self.connectors = connectors }

  func discover(
    trend: TrendReference,
    profile: ChannelContentProfile,
    maxResults: Int = 16
  ) async -> [SourceAsset] {
    var result: [SourceAsset] = []
    let request = SourceSearchRequest(
      query: trend.title,
      topicTags: profile.effectiveSearchTerms,
      language: profile.language,
      maxResults: maxResults)
    for connector in connectors where connector.kind != .youtubeReference {
      do {
        result.append(contentsOf: try await connector.search(request))
      } catch {
        // One provider must not make source discovery fail as a whole.
        continue
      }
    }
    var seen = Set<String>()
    return result.filter { asset in
      guard RightsService.canEnterAutomaticRender(asset) else { return false }
      let key = asset.providerAssetID ?? asset.remoteURL ?? asset.id.uuidString
      return seen.insert("\(asset.provider.rawValue):\(key)").inserted
    }.prefix(maxResults).map { $0 }
  }
}
