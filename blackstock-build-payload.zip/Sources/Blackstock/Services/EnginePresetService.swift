import Foundation

struct EnginePreset: Identifiable, Hashable {
  let id: String
  let typ: ProviderVerbindung.Typ
  let name: String
  let detail: String
  let basisURL: String
  let modell: String
  let optionen: [String: String]
  let umgebungsvariable: String?
  let verbindungsURL: String?
  let brauchtAPIKey: Bool
  let premium: Bool
}

enum EnginePresetService {
  static let presets: [EnginePreset] = [
    EnginePreset(
      id: "apple-intelligence", typ: .research, name: "Apple Intelligence",
      detail: "On-device Creator auf macOS 26 · kein API-Key und keine API-Kosten",
      basisURL: "apple://foundation-models", modell: "system-language-model",
      optionen: ["adapter": "apple-foundation", "quality": "studio"],
      umgebungsvariable: nil, verbindungsURL: nil, brauchtAPIKey: false, premium: false),
    EnginePreset(
      id: "local-creator", typ: .research, name: "Blackstock Local Creator",
      detail: "Lokale Redaktion und Produktionsstruktur · kein API-Key erforderlich",
      basisURL: "local://creator", modell: "blackstock-editorial-v1",
      optionen: ["adapter": "local", "quality": "studio"],
      umgebungsvariable: nil, verbindungsURL: nil, brauchtAPIKey: false, premium: false),
    EnginePreset(
      id: "openai-creator", typ: .research, name: "OpenAI Creator",
      detail: "Redaktion, Hooks, Skripte, Szenen, Titel und Metadaten",
      basisURL: "https://api.openai.com/v1", modell: "gpt-5.6-terra",
      optionen: ["adapter": "openai-responses", "quality": "balanced"],
      umgebungsvariable: "OPENAI_API_KEY", verbindungsURL: "https://platform.openai.com/api-keys",
      brauchtAPIKey: true, premium: true),
    EnginePreset(
      id: "local-voice", typ: .voice, name: "macOS Natural Voice",
      detail: "Lokale Voice ohne API-Key · funktioniert offline",
      basisURL: "local://macos", modell: "macos-speech",
      optionen: ["adapter": "local", "voice": "auto"], umgebungsvariable: nil,
      verbindungsURL: nil, brauchtAPIKey: false, premium: false),
    EnginePreset(
      id: "openai-voice", typ: .voice, name: "OpenAI Voice",
      detail: "Natürliche Cloud-Stimme mit steuerbarer Sprechweise",
      basisURL: "https://api.openai.com/v1", modell: "gpt-4o-mini-tts",
      optionen: [
        "adapter": "openai", "voice": "marin",
        "instructions": "Natürlich, präzise, warm und nicht überinszeniert.",
      ], umgebungsvariable: "OPENAI_API_KEY",
      verbindungsURL: "https://platform.openai.com/api-keys",
      brauchtAPIKey: true, premium: true),
    EnginePreset(
      id: "elevenlabs-v3", typ: .voice, name: "ElevenLabs v3",
      detail: "Expressive Premium-Stimme · 70+ Sprachen",
      basisURL: "https://api.elevenlabs.io/v1", modell: "eleven_v3",
      optionen: ["adapter": "elevenlabs", "voice": "JBFqnCBsd6RMkjVDRZzb"],
      umgebungsvariable: "ELEVENLABS_API_KEY",
      verbindungsURL: "https://elevenlabs.io/app/settings/api-keys",
      brauchtAPIKey: true, premium: true),
    EnginePreset(
      id: "local-thumbnail", typ: .image, name: "Blackstock Thumbnail",
      detail: "Lokaler 1280×720 Brand-Renderer · immer verfügbar",
      basisURL: "local://thumbnail", modell: "blackstock-thumbnail-v2",
      optionen: ["adapter": "local"], umgebungsvariable: nil, verbindungsURL: nil,
      brauchtAPIKey: false, premium: false),
    EnginePreset(
      id: "openai-image", typ: .image, name: "OpenAI Image",
      detail: "Premium-Hintergrundbild + Blackstock Brand-Layer",
      basisURL: "https://api.openai.com/v1", modell: "gpt-image-2.5-sunburst",
      optionen: ["adapter": "openai-image"], umgebungsvariable: "OPENAI_API_KEY",
      verbindungsURL: "https://platform.openai.com/api-keys", brauchtAPIKey: true, premium: true),
    EnginePreset(
      id: "local-visual", typ: .video, name: "Blackstock Local Visual",
      detail: "Lokaler animierter Visual-Track · kein Cloud-Key erforderlich",
      basisURL: "local://visual", modell: "blackstock-visual-v1",
      optionen: ["adapter": "local"], umgebungsvariable: nil, verbindungsURL: nil,
      brauchtAPIKey: false, premium: false),
    EnginePreset(
      id: "runway-gen45", typ: .video, name: "Runway Gen-4.5",
      detail: "Premium Text/Image-to-Video · 9:16 und 16:9",
      basisURL: "https://api.dev.runwayml.com/v1", modell: "gen4.5",
      optionen: ["adapter": "runway", "apiVersion": "2024-11-06"],
      umgebungsvariable: "RUNWAYML_API_SECRET",
      verbindungsURL: "https://dev.runwayml.com/settings/api-keys",
      brauchtAPIKey: true, premium: true),
    EnginePreset(
      id: "local-music", typ: .music, name: "Blackstock Auto Music",
      detail: "Lokal erzeugtes dezentes Musikbett · keine Dateien vom Nutzer erforderlich",
      basisURL: "local://music", modell: "blackstock-music-v1",
      optionen: ["adapter": "local"], umgebungsvariable: nil, verbindungsURL: nil,
      brauchtAPIKey: false, premium: false),
  ]

  static func presets(fuer typ: ProviderVerbindung.Typ) -> [EnginePreset] {
    presets.filter { $0.typ == typ }
  }

  static func preset(id: String?) -> EnginePreset? {
    guard let id else { return nil }
    return presets.first { $0.id == id }
  }

  static func standardPreset(fuer typ: ProviderVerbindung.Typ) -> EnginePreset {
    let preferredID: String
    switch typ {
    case .research: preferredID = "local-creator"
    case .voice: preferredID = "local-voice"
    case .image: preferredID = "local-thumbnail"
    case .video: preferredID = "local-visual"
    case .music: preferredID = "local-music"
    }
    if let preferred = preset(id: preferredID) { return preferred }
    if let fallback = presets(fuer: typ).first { return fallback }
    // Der Katalog ist statisch vollständig; dieser Fallback verhindert trotzdem einen App-Crash,
    // falls ein späterer Refactor einen Typ versehentlich ohne Preset lässt.
    return EnginePreset(
      id: "local-fallback-\(typ.rawValue)", typ: typ, name: "Lokale Engine",
      detail: "Sicherer lokaler Fallback", basisURL: "local://fallback", modell: "local",
      optionen: ["adapter": "local"], umgebungsvariable: nil, verbindungsURL: nil,
      brauchtAPIKey: false, premium: false)
  }

  static func aktiviertesPreset(fuer provider: ProviderVerbindung) -> EnginePreset? {
    if let id = provider.optionen?["preset"], let preset = preset(id: id) { return preset }
    return presets(fuer: provider.typ).first {
      $0.basisURL == provider.basisURL && $0.modell == provider.modell
    }
  }

  static func anwenden(_ preset: EnginePreset, auf provider: ProviderVerbindung)
    -> ProviderVerbindung
  {
    var result = provider
    result.name = preset.name
    result.detail = preset.detail
    result.basisURL = preset.basisURL
    result.modell = preset.modell
    result.optionen = preset.optionen.merging(["preset": preset.id]) { current, _ in current }
    if !preset.brauchtAPIKey {
      result.apiKeyVorhanden = true
      result.verbunden = true
    } else {
      result.verbunden = result.apiKeyVorhanden ?? false
    }
    return result
  }

  /// Alte leere Standardprovider werden auf sichere Defaults migriert. Eigene konfigurierte Provider bleiben erhalten.
  static func normalisieren(_ provider: [ProviderVerbindung]) -> [ProviderVerbindung] {
    var result = provider
    for typ in [ProviderVerbindung.Typ.research, .voice, .image, .video, .music] {
      if let index = result.firstIndex(where: { $0.typ == typ }) {
        let current = result[index]
        let empty = (current.basisURL ?? "").isEmpty && (current.modell ?? "").isEmpty
        let discontinuedAppleImage =
          current.optionen?["preset"] == "apple-image"
          || current.basisURL == "apple://image-playground"
        if empty || discontinuedAppleImage {
          result[index] = anwenden(standardPreset(fuer: typ), auf: current)
        }
      } else {
        let preset = standardPreset(fuer: typ)
        let base = ProviderVerbindung(
          typ: typ, name: preset.name, verbunden: !preset.brauchtAPIKey, detail: preset.detail,
          basisURL: preset.basisURL, modell: preset.modell,
          apiKeyVorhanden: !preset.brauchtAPIKey,
          optionen: preset.optionen.merging(["preset": preset.id]) { current, _ in current })
        result.append(base)
      }
    }
    return result
  }
}
