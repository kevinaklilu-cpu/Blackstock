import Foundation
import Security

final class KeychainService {
  static let shared = KeychainService()
  private let service = "de.blackstock.app"

  @discardableResult
  func speichern(_ wert: String, schluessel: String) -> Bool {
    let data = Data(wert.utf8)
    let query: [String: Any] = [
      kSecClass as String: kSecClassGenericPassword,
      kSecAttrService as String: service,
      kSecAttrAccount as String: schluessel,
    ]

    let update: [String: Any] = [kSecValueData as String: data]
    let updateStatus = SecItemUpdate(query as CFDictionary, update as CFDictionary)
    if updateStatus == errSecSuccess { return true }
    guard updateStatus == errSecItemNotFound else {
      print("Blackstock: Keychain-Update fehlgeschlagen (\(updateStatus)) für \(schluessel)")
      return false
    }

    var insert = query
    insert[kSecValueData as String] = data
    insert[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
    let addStatus = SecItemAdd(insert as CFDictionary, nil)
    if addStatus != errSecSuccess {
      print("Blackstock: Keychain-Speicherung fehlgeschlagen (\(addStatus)) für \(schluessel)")
    }
    return addStatus == errSecSuccess
  }

  func lesen(_ schluessel: String) -> String? {
    let query: [String: Any] = [
      kSecClass as String: kSecClassGenericPassword,
      kSecAttrService as String: service,
      kSecAttrAccount as String: schluessel,
      kSecReturnData as String: true,
      kSecMatchLimit as String: kSecMatchLimitOne,
    ]
    var item: CFTypeRef?
    guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess,
      let data = item as? Data
    else { return nil }
    return String(data: data, encoding: .utf8)
  }

  @discardableResult
  func loeschen(_ schluessel: String) -> Bool {
    let query: [String: Any] = [
      kSecClass as String: kSecClassGenericPassword,
      kSecAttrService as String: service,
      kSecAttrAccount as String: schluessel,
    ]
    let status = SecItemDelete(query as CFDictionary)
    return status == errSecSuccess || status == errSecItemNotFound
  }
}
