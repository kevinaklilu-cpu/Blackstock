import AVFoundation
import AppKit
import Foundation

final class VideoFrameThumbnailService {
  static let shared = VideoFrameThumbnailService()

  enum FrameError: LocalizedError {
    case noFrame
    case writeFailed
    var errorDescription: String? {
      switch self {
      case .noFrame: "Aus dem fertigen Video konnte kein geeignetes Thumbnail-Frame extrahiert werden."
      case .writeFailed: "Das ausgewählte Thumbnail-Frame konnte nicht gespeichert werden."
      }
    }
  }

  /// Extracts a representative frame from the finished video. Multiple positions are tried so
  /// an intro fade/black first frame is not blindly used. The first sufficiently bright frame wins;
  /// otherwise the best successfully extracted frame is retained.
  func bestFrame(from videoURL: URL, to outputURL: URL) async throws -> URL {
    let asset = AVURLAsset(url: videoURL)
    let duration = try await asset.load(.duration)
    let seconds = CMTimeGetSeconds(duration)
    guard seconds.isFinite, seconds > 0 else { throw FrameError.noFrame }
    let generator = AVAssetImageGenerator(asset: asset)
    generator.appliesPreferredTrackTransform = true
    generator.maximumSize = CGSize(width: 1600, height: 900)
    generator.requestedTimeToleranceBefore = CMTime(seconds: 0.35, preferredTimescale: 600)
    generator.requestedTimeToleranceAfter = CMTime(seconds: 0.35, preferredTimescale: 600)

    let fractions: [Double] = [0.08, 0.18, 0.33, 0.52, 0.72]
    var best: (CGImage, Double)?
    for fraction in fractions {
      let time = CMTime(seconds: max(0.2, seconds * fraction), preferredTimescale: 600)
      if let image = try? await generator.image(at: time).image {
        let score = luminanceScore(image)
        if best.map({ score > $0.1 }) ?? true { best = (image, score) }
        if score > 0.22 { break }
      }
    }
    guard let image = best?.0 else { throw FrameError.noFrame }
    let bitmap = NSBitmapImageRep(cgImage: image)
    guard let data = bitmap.representation(using: .png, properties: [:]) else {
      throw FrameError.writeFailed
    }
    try FileManager.default.createDirectory(at: outputURL.deletingLastPathComponent(), withIntermediateDirectories: true)
    try data.write(to: outputURL, options: .atomic)
    return outputURL
  }

  private func luminanceScore(_ image: CGImage) -> Double {
    let width = 32, height = 18
    var pixels = [UInt8](repeating: 0, count: width * height * 4)
    guard let context = CGContext(
      data: &pixels, width: width, height: height, bitsPerComponent: 8,
      bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
    else { return 0 }
    context.interpolationQuality = .low
    context.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
    var sum = 0.0
    var variation = 0.0
    var previous = 0.0
    for i in stride(from: 0, to: pixels.count, by: 4) {
      let y = (0.2126 * Double(pixels[i]) + 0.7152 * Double(pixels[i + 1]) + 0.0722 * Double(pixels[i + 2])) / 255.0
      sum += y
      variation += abs(y - previous)
      previous = y
    }
    let count = Double(width * height)
    return min(1, (sum / count) * 0.7 + (variation / count) * 0.3)
  }
}
