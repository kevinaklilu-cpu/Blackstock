import AppKit
import CoreGraphics
import CoreText
import Foundation
import ImageIO
import UniformTypeIdentifiers

final class ThumbnailService {
  static let shared = ThumbnailService()

  enum ThumbnailFehler: LocalizedError {
    case render
    case schreiben

    var errorDescription: String? {
      switch self {
      case .render: return "Thumbnail konnte nicht gerendert werden."
      case .schreiben: return "Thumbnail konnte nicht als PNG gespeichert werden."
      }
    }
  }

  func generieren(
    produktion: Produktion,
    kanal: Kanal,
    branding: KanalBranding,
    hintergrund: URL? = nil,
    ziel: URL
  ) throws -> URL {
    let width = 1280
    let height = 720
    let colorSpace = CGColorSpaceCreateDeviceRGB()
    guard
      let context = CGContext(
        data: nil, width: width, height: height, bitsPerComponent: 8,
        bytesPerRow: 0, space: colorSpace,
        bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
    else { throw ThumbnailFehler.render }

    let canvas = CGRect(x: 0, y: 0, width: width, height: height)
    context.setFillColor(CGColor(red: 0.035, green: 0.035, blue: 0.04, alpha: 1))
    context.fill(canvas)

    if let hintergrund, let bg = loadCGImage(hintergrund) {
      let target = aspectFillRect(imageSize: CGSize(width: bg.width, height: bg.height), in: canvas)
      context.saveGState()
      context.setAlpha(0.82)
      context.draw(bg, in: target)
      context.restoreGState()
      context.setFillColor(CGColor(gray: 0, alpha: 0.42))
      context.fill(canvas)
    } else {
      let accent = color(from: branding.akzentHex)
      let gradient = CGGradient(
        colorsSpace: colorSpace,
        colors: [accent.copy(alpha: 0.86) ?? accent, CGColor(gray: 0.02, alpha: 1)] as CFArray,
        locations: [0, 1])
      if let gradient {
        context.drawLinearGradient(
          gradient, start: CGPoint(x: 80, y: height), end: CGPoint(x: width, y: 0),
          options: [])
      }
      context.setFillColor(CGColor(gray: 0, alpha: 0.18))
      context.fill(canvas)
    }

    let accent = color(from: branding.akzentHex)
    context.setFillColor(accent)
    context.addPath(
      CGPath(
        roundedRect: CGRect(x: 64, y: 70, width: 16, height: 580), cornerWidth: 8, cornerHeight: 8,
        transform: nil))
    context.fillPath()

    let raw =
      (produktion.thumbnailIdee.isEmpty ? produktion.arbeitstitel : produktion.thumbnailIdee)
      .trimmingCharacters(in: .whitespacesAndNewlines)
    let short = String((raw.isEmpty ? produktion.arbeitstitel : raw).prefix(88))
    let fontSize: CGFloat = short.count > 58 ? 62 : (short.count > 36 ? 70 : 80)
    drawText(
      short.uppercased(), in: CGRect(x: 112, y: 205, width: 940, height: 390),
      fontSize: fontSize, weight: .bold, color: CGColor(gray: 1, alpha: 1), context: context)

    let topic = produktion.chanceSnapshot?.thema ?? kanal.thema
    drawText(
      String(topic.uppercased().prefix(46)), in: CGRect(x: 114, y: 142, width: 780, height: 48),
      fontSize: 25, weight: .semibold, color: CGColor(gray: 1, alpha: 0.82), context: context)
    drawText(
      String(kanal.name.uppercased().prefix(42)), in: CGRect(x: 114, y: 92, width: 780, height: 42),
      fontSize: 22, weight: .medium, color: CGColor(gray: 1, alpha: 0.64), context: context)

    drawMark(in: CGRect(x: 1090, y: 70, width: 118, height: 82), accent: accent, context: context)

    guard let cg = context.makeImage() else { throw ThumbnailFehler.render }
    try FileManager.default.createDirectory(
      at: ziel.deletingLastPathComponent(), withIntermediateDirectories: true)
    try? FileManager.default.removeItem(at: ziel)
    guard
      let destination = CGImageDestinationCreateWithURL(
        ziel as CFURL, UTType.png.identifier as CFString, 1, nil)
    else { throw ThumbnailFehler.schreiben }
    CGImageDestinationAddImage(destination, cg, nil)
    guard CGImageDestinationFinalize(destination) else { throw ThumbnailFehler.schreiben }
    return ziel
  }

  /// Letzter Notfallpfad: erzeugt ein gültiges 1280×720 PNG ausschließlich mit AppKit.
  /// Dieser Pfad ist absichtlich simpel, damit ein Thumbnail-Fehler niemals eine komplette Produktion blockiert.
  func generierenNotfall(
    produktion: Produktion, kanal: Kanal, branding: KanalBranding, ziel: URL
  ) throws -> URL {
    let size = NSSize(width: 1280, height: 720)
    let image = NSImage(size: size)
    image.lockFocus()
    defer { image.unlockFocus() }

    let rect = NSRect(origin: .zero, size: size)
    NSColor(calibratedWhite: 0.045, alpha: 1).setFill()
    rect.fill()

    let accent = NSColor(cgColor: color(from: branding.akzentHex)) ?? .systemRed
    accent.setFill()
    NSBezierPath(roundedRect: NSRect(x: 58, y: 60, width: 18, height: 600), xRadius: 9, yRadius: 9)
      .fill()

    let raw =
      (produktion.thumbnailIdee.isEmpty ? produktion.arbeitstitel : produktion.thumbnailIdee)
      .trimmingCharacters(in: .whitespacesAndNewlines)
    let words = raw.split { !$0.isLetter && !$0.isNumber }.prefix(5).map(String.init)
    let text = String(
      (words.isEmpty ? [produktion.arbeitstitel] : words).joined(separator: " ").uppercased()
        .prefix(58))
    let paragraph = NSMutableParagraphStyle()
    paragraph.alignment = .left
    paragraph.lineBreakMode = .byWordWrapping
    let attributes: [NSAttributedString.Key: Any] = [
      .font: NSFont.systemFont(ofSize: text.count > 36 ? 62 : 74, weight: .black),
      .foregroundColor: NSColor.white,
      .paragraphStyle: paragraph,
    ]
    (text as NSString).draw(
      with: NSRect(x: 112, y: 235, width: 920, height: 300),
      options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attributes)

    let topic = produktion.chanceSnapshot?.thema ?? kanal.thema
    let meta: [NSAttributedString.Key: Any] = [
      .font: NSFont.systemFont(ofSize: 24, weight: .semibold),
      .foregroundColor: NSColor(calibratedWhite: 0.82, alpha: 1),
    ]
    (String(topic.uppercased().prefix(48)) as NSString).draw(
      in: NSRect(x: 112, y: 175, width: 850, height: 40), withAttributes: meta)

    let markRect = NSRect(x: 1080, y: 570, width: 120, height: 82)
    NSColor.white.setFill()
    NSBezierPath(roundedRect: markRect, xRadius: 20, yRadius: 20).fill()
    let markAttributes: [NSAttributedString.Key: Any] = [
      .font: NSFont.systemFont(ofSize: 40, weight: .black),
      .foregroundColor: NSColor.black,
    ]
    ("▶ B" as NSString).draw(
      in: NSRect(x: 1093, y: 590, width: 100, height: 50), withAttributes: markAttributes)

    guard let tiff = image.tiffRepresentation,
      let rep = NSBitmapImageRep(data: tiff),
      let png = rep.representation(using: .png, properties: [:])
    else { throw ThumbnailFehler.render }
    try FileManager.default.createDirectory(
      at: ziel.deletingLastPathComponent(), withIntermediateDirectories: true)
    try png.write(to: ziel, options: .atomic)
    return ziel
  }

  private enum TextWeight { case medium, semibold, bold }

  private func drawText(
    _ text: String, in rect: CGRect, fontSize: CGFloat, weight: TextWeight, color: CGColor,
    context: CGContext
  ) {
    let fontName: CFString = {
      switch weight {
      case .medium: return "HelveticaNeue-Medium" as CFString
      case .semibold: return "HelveticaNeue-Bold" as CFString
      case .bold: return "HelveticaNeue-CondensedBlack" as CFString
      }
    }()
    let font = CTFontCreateWithName(fontName, fontSize, nil)
    let attributes: [CFString: Any] = [
      kCTFontAttributeName: font,
      kCTForegroundColorAttributeName: color,
    ]
    guard
      let attributed = CFAttributedStringCreate(
        kCFAllocatorDefault, text as CFString, attributes as CFDictionary)
    else { return }
    let framesetter = CTFramesetterCreateWithAttributedString(attributed)
    let path = CGPath(rect: rect, transform: nil)
    let frame = CTFramesetterCreateFrame(framesetter, CFRange(location: 0, length: 0), path, nil)
    context.saveGState()
    context.textMatrix = .identity
    CTFrameDraw(frame, context)
    context.restoreGState()
  }

  private func drawMark(in rect: CGRect, accent: CGColor, context: CGContext) {
    context.setFillColor(CGColor(gray: 1, alpha: 1))
    context.addPath(CGPath(roundedRect: rect, cornerWidth: 20, cornerHeight: 20, transform: nil))
    context.fillPath()

    let play = CGMutablePath()
    play.move(to: CGPoint(x: rect.minX + 18, y: rect.minY + 18))
    play.addLine(to: CGPoint(x: rect.minX + 18, y: rect.maxY - 18))
    play.addLine(to: CGPoint(x: rect.minX + 50, y: rect.midY))
    play.closeSubpath()
    context.setFillColor(accent)
    context.addPath(play)
    context.fillPath()

    drawText(
      "B", in: CGRect(x: rect.minX + 52, y: rect.minY + 12, width: 48, height: 58),
      fontSize: 45, weight: .bold, color: CGColor(gray: 0.04, alpha: 1), context: context)
  }

  private func loadCGImage(_ url: URL) -> CGImage? {
    guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
    return CGImageSourceCreateImageAtIndex(source, 0, nil)
  }

  private func aspectFillRect(imageSize: CGSize, in rect: CGRect) -> CGRect {
    guard imageSize.width > 0, imageSize.height > 0 else { return rect }
    let scale = max(rect.width / imageSize.width, rect.height / imageSize.height)
    let w = imageSize.width * scale
    let h = imageSize.height * scale
    return CGRect(x: rect.midX - w / 2, y: rect.midY - h / 2, width: w, height: h)
  }

  private func color(from hex: String) -> CGColor {
    var value = hex.trimmingCharacters(in: .whitespacesAndNewlines)
    if value.hasPrefix("#") { value.removeFirst() }
    guard value.count == 6, let rgb = Int(value, radix: 16) else {
      return CGColor(red: 1, green: 0.08, blue: 0.12, alpha: 1)
    }
    return CGColor(
      red: CGFloat((rgb >> 16) & 0xFF) / 255,
      green: CGFloat((rgb >> 8) & 0xFF) / 255,
      blue: CGFloat(rgb & 0xFF) / 255,
      alpha: 1)
  }
}
