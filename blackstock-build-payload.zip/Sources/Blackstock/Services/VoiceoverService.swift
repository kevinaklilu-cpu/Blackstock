import AVFoundation
import Foundation

final class VoiceoverService {
  static let shared = VoiceoverService()

  enum VoiceFehler: LocalizedError {
    case keinText
    case keinAudio
    case schreiben(String)

    var errorDescription: String? {
      switch self {
      case .keinText: "Für das Voiceover fehlt ein Skript."
      case .keinAudio: "macOS hat für dieses Voiceover keine Audiodaten erzeugt."
      case .schreiben(let detail): "Voiceover konnte nicht gespeichert werden: \(detail)"
      }
    }
  }

  struct Stimme: Identifiable, Hashable {
    let id: String
    let name: String
    let sprache: String
  }

  func verfuegbareStimmen(sprache: String? = nil) -> [Stimme] {
    AVSpeechSynthesisVoice.speechVoices()
      .filter { voice in
        guard let sprache else { return true }
        return voice.language.lowercased().hasPrefix(sprache.lowercased())
      }
      .map { Stimme(id: $0.identifier, name: $0.name, sprache: $0.language) }
      .sorted { ($0.sprache, $0.name) < ($1.sprache, $1.name) }
  }

  func generieren(
    text: String,
    sprache: String = "de-DE",
    voiceIdentifier: String? = nil,
    rate: Float = 0.48,
    pitch: Float = 1.0,
    ziel: URL
  ) async throws -> URL {
    let sauber = text.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !sauber.isEmpty else { throw VoiceFehler.keinText }

    try FileManager.default.createDirectory(
      at: ziel.deletingLastPathComponent(), withIntermediateDirectories: true)
    try? FileManager.default.removeItem(at: ziel)

    let utterance = AVSpeechUtterance(string: sauber)
    if let voiceIdentifier, let voice = AVSpeechSynthesisVoice(identifier: voiceIdentifier) {
      utterance.voice = voice
    } else {
      utterance.voice = AVSpeechSynthesisVoice(language: sprache)
    }
    utterance.rate = max(
      AVSpeechUtteranceMinimumSpeechRate, min(rate, AVSpeechUtteranceMaximumSpeechRate))
    utterance.pitchMultiplier = max(0.5, min(pitch, 2.0))
    utterance.volume = 1.0

    let synthesizer = AVSpeechSynthesizer()
    return try await withCheckedThrowingContinuation { continuation in
      let lock = NSLock()
      var audioFile: AVAudioFile?
      var finished = false
      var wroteFrames = false

      synthesizer.write(utterance) { buffer in
        lock.lock()
        defer { lock.unlock() }
        guard !finished else { return }
        guard let pcm = buffer as? AVAudioPCMBuffer else {
          finished = true
          continuation.resume(throwing: VoiceFehler.keinAudio)
          return
        }

        if pcm.frameLength == 0 {
          finished = true
          if wroteFrames, FileManager.default.fileExists(atPath: ziel.path) {
            continuation.resume(returning: ziel)
          } else {
            continuation.resume(throwing: VoiceFehler.keinAudio)
          }
          return
        }

        do {
          if audioFile == nil {
            audioFile = try AVAudioFile(forWriting: ziel, settings: pcm.format.settings)
          }
          try audioFile?.write(from: pcm)
          wroteFrames = true
        } catch {
          finished = true
          synthesizer.stopSpeaking(at: .immediate)
          continuation.resume(throwing: VoiceFehler.schreiben(error.localizedDescription))
        }
      }
    }
  }
}
