import AVFoundation
import CoreGraphics
import CoreText
import CoreVideo
import Foundation
import ImageIO

actor LocalVisualService {
  static let shared = LocalVisualService()

  enum VisualFehler: LocalizedError {
    case writer
    case buffer
    case export(String)

    var errorDescription: String? {
      switch self {
      case .writer: return "Der lokale Visual-Renderer konnte nicht gestartet werden."
      case .buffer: return "Der lokale Visual-Renderer konnte keinen Videoframe erzeugen."
      case .export(let detail): return "Lokaler Visual-Render fehlgeschlagen: \(detail)"
      }
    }
  }

  func rendern(
    produktion: Produktion, kanal: Kanal, branding: KanalBranding,
    szenenbilder: [URL] = [], ziel: URL
  ) async throws -> URL {
    let vertical = produktion.format == .short
    let width = vertical ? 1080 : 1920
    let height = vertical ? 1920 : 1080
    let sceneDuration = produktion.paket?.szenen.reduce(0.0) { $0 + max(1, $1.dauerSekunden) } ?? 0
    let requested = max(Double(produktion.zielDauerSekunden), sceneDuration)
    let maxDuration = produktion.format == .short ? 60.0 : 900.0
    let duration = Int(max(8, min(requested, maxDuration)))

    try FileManager.default.createDirectory(
      at: ziel.deletingLastPathComponent(), withIntermediateDirectories: true)
    try? FileManager.default.removeItem(at: ziel)
    let writer = try AVAssetWriter(outputURL: ziel, fileType: .mp4)
    let input = AVAssetWriterInput(
      mediaType: .video,
      outputSettings: [
        AVVideoCodecKey: AVVideoCodecType.h264,
        AVVideoWidthKey: width,
        AVVideoHeightKey: height,
        AVVideoCompressionPropertiesKey: [
          AVVideoAverageBitRateKey: vertical ? 8_000_000 : 10_000_000,
          AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel,
        ],
      ])
    input.expectsMediaDataInRealTime = false
    let adaptor = AVAssetWriterInputPixelBufferAdaptor(
      assetWriterInput: input,
      sourcePixelBufferAttributes: [
        kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA),
        kCVPixelBufferWidthKey as String: width,
        kCVPixelBufferHeightKey as String: height,
      ])
    guard writer.canAdd(input) else { throw VisualFehler.writer }
    writer.add(input)
    guard writer.startWriting() else {
      throw VisualFehler.export(writer.error?.localizedDescription ?? "Writer konnte nicht starten")
    }
    writer.startSession(atSourceTime: .zero)

    let scenes: [ProduktionsSzene] = {
      if let source = produktion.paket?.szenen, !source.isEmpty { return source }
      return [
        ProduktionsSzene(
          titel: produktion.arbeitstitel,
          narration: produktion.hook.isEmpty ? produktion.arbeitstitel : produktion.hook,
          visualDirection: produktion.chanceSnapshot?.thema ?? kanal.thema,
          dauerSekunden: Double(duration))
      ]
    }()
    let fallbackBackground = produktion.thumbnailDatei.flatMap {
      loadCGImage(URL(fileURLWithPath: $0))
    }
    let sceneBackgrounds = szenenbilder.compactMap(loadCGImage)
    let fps: Int = {
      switch produktion.modus ?? .studio {
      case .fast: return vertical ? 12 : 10
      case .studio: return vertical ? 18 : 14
      case .master: return vertical ? 24 : 18
      }
    }()
    let totalFrames = max(duration * fps, scenes.count * fps)

    for frame in 0..<totalFrames {
      while !input.isReadyForMoreMediaData {
        try await Task.sleep(nanoseconds: 4_000_000)
      }
      let progress = Double(frame) / Double(max(1, totalFrames - 1))
      let sceneIndex = min(scenes.count - 1, max(0, Int(progress * Double(scenes.count))))
      let scene = scenes[sceneIndex]
      let sceneBackground: CGImage? =
        sceneBackgrounds.isEmpty
        ? fallbackBackground
        : sceneBackgrounds[min(sceneIndex, sceneBackgrounds.count - 1)]
      let pixel = try makePixelBuffer(
        width: width, height: height,
        projectTitle: produktion.arbeitstitel,
        sceneTitle: scene.titel,
        narration: scene.narration,
        visualDirection: scene.visualDirection,
        kanal: kanal.name,
        accentHex: branding.akzentHex,
        progress: progress,
        background: sceneBackground)
      let time = CMTime(value: CMTimeValue(frame), timescale: CMTimeScale(fps))
      guard adaptor.append(pixel, withPresentationTime: time) else {
        throw VisualFehler.export(
          writer.error?.localizedDescription ?? "Frame konnte nicht geschrieben werden")
      }
    }
    input.markAsFinished()
    await withCheckedContinuation { continuation in
      writer.finishWriting { continuation.resume() }
    }
    guard writer.status == .completed, FileManager.default.fileExists(atPath: ziel.path) else {
      throw VisualFehler.export(
        writer.error?.localizedDescription ?? "Export wurde nicht abgeschlossen")
    }
    return ziel
  }

  private func makePixelBuffer(
    width: Int, height: Int, projectTitle: String, sceneTitle: String, narration: String,
    visualDirection: String, kanal: String, accentHex: String, progress: Double,
    background: CGImage?
  ) throws -> CVPixelBuffer {
    var pixelBuffer: CVPixelBuffer?
    let attrs: [CFString: Any] = [
      kCVPixelBufferCGImageCompatibilityKey: true,
      kCVPixelBufferCGBitmapContextCompatibilityKey: true,
    ]
    let status = CVPixelBufferCreate(
      kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA,
      attrs as CFDictionary, &pixelBuffer)
    guard status == kCVReturnSuccess, let buffer = pixelBuffer else { throw VisualFehler.buffer }
    CVPixelBufferLockBaseAddress(buffer, [])
    defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
    guard let base = CVPixelBufferGetBaseAddress(buffer) else { throw VisualFehler.buffer }
    let colorSpace = CGColorSpaceCreateDeviceRGB()
    guard
      let context = CGContext(
        data: base, width: width, height: height, bitsPerComponent: 8,
        bytesPerRow: CVPixelBufferGetBytesPerRow(buffer), space: colorSpace,
        bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue
          | CGBitmapInfo.byteOrder32Little.rawValue)
    else { throw VisualFehler.buffer }

    let canvas = CGRect(x: 0, y: 0, width: width, height: height)
    context.setFillColor(CGColor(gray: 0.025, alpha: 1))
    context.fill(canvas)

    if let background {
      let zoom = CGFloat(1.04 + 0.05 * sin(progress * .pi))
      let rect = aspectFillRect(
        imageSize: CGSize(width: background.width, height: background.height), in: canvas,
        zoom: zoom)
      context.saveGState()
      context.setAlpha(0.58)
      context.draw(background, in: rect)
      context.restoreGState()
      context.setFillColor(CGColor(gray: 0, alpha: 0.45))
      context.fill(canvas)
    }

    let accent = color(hex: accentHex)
    if let glow = CGGradient(
      colorsSpace: colorSpace,
      colors: [accent.copy(alpha: 0.72) ?? accent, CGColor(gray: 0, alpha: 0)] as CFArray,
      locations: [0, 1])
    {
      context.drawRadialGradient(
        glow,
        startCenter: CGPoint(
          x: CGFloat(width) * (0.30 + 0.08 * sin(progress * .pi * 2)),
          y: CGFloat(height) * 0.70),
        startRadius: 0,
        endCenter: CGPoint(x: CGFloat(width) * 0.40, y: CGFloat(height) * 0.62),
        endRadius: CGFloat(max(width, height)) * 0.70,
        options: [])
    }

    let scale = CGFloat(width) / 1920
    drawText(
      String(sceneTitle.prefix(72)).uppercased(),
      rect: CGRect(
        x: 90 * scale, y: CGFloat(height) * 0.54, width: CGFloat(width) - 180 * scale,
        height: CGFloat(height) * 0.22),
      size: 80 * scale, bold: true, color: CGColor(gray: 1, alpha: 1), context: context)
    drawText(
      String(narration.prefix(180)),
      rect: CGRect(
        x: 94 * scale, y: CGFloat(height) * 0.36, width: CGFloat(width) - 188 * scale,
        height: CGFloat(height) * 0.17),
      size: 34 * scale, bold: false, color: CGColor(gray: 1, alpha: 0.86), context: context)
    drawText(
      String(visualDirection.prefix(120)),
      rect: CGRect(
        x: 94 * scale, y: CGFloat(height) * 0.23, width: CGFloat(width) - 188 * scale,
        height: CGFloat(height) * 0.10),
      size: 25 * scale, bold: false, color: accent.copy(alpha: 0.92) ?? accent, context: context)
    drawText(
      "BLACKSTOCK · \(kanal.uppercased())",
      rect: CGRect(x: 92 * scale, y: 72 * scale, width: CGFloat(width) * 0.58, height: 54 * scale),
      size: 26 * scale, bold: true, color: CGColor(gray: 1, alpha: 0.72), context: context)
    drawText(
      String(projectTitle.prefix(65)),
      rect: CGRect(
        x: CGFloat(width) * 0.62, y: 72 * scale, width: CGFloat(width) * 0.31,
        height: 54 * scale),
      size: 21 * scale, bold: false, color: CGColor(gray: 1, alpha: 0.48), context: context)

    context.setFillColor(CGColor(gray: 1, alpha: 0.18))
    context.fill(
      CGRect(x: 92 * scale, y: 48 * scale, width: CGFloat(width) - 184 * scale, height: 5 * scale))
    context.setFillColor(accent)
    context.fill(
      CGRect(
        x: 92 * scale, y: 48 * scale, width: (CGFloat(width) - 184 * scale) * CGFloat(progress),
        height: 5 * scale))
    return buffer
  }

  private func drawText(
    _ text: String, rect: CGRect, size: CGFloat, bold: Bool, color: CGColor, context: CGContext
  ) {
    let font = CTFontCreateWithName(
      (bold ? "HelveticaNeue-Bold" : "HelveticaNeue") as CFString, size, nil)
    let attributes: [CFString: Any] = [
      kCTFontAttributeName: font,
      kCTForegroundColorAttributeName: color,
    ]
    guard
      let attributed = CFAttributedStringCreate(
        kCFAllocatorDefault, text as CFString, attributes as CFDictionary)
    else { return }
    let framesetter = CTFramesetterCreateWithAttributedString(attributed)
    let path = CGPath(rect: rect, transform: nil)
    let frame = CTFramesetterCreateFrame(framesetter, CFRange(location: 0, length: 0), path, nil)
    context.saveGState()
    context.textMatrix = .identity
    CTFrameDraw(frame, context)
    context.restoreGState()
  }

  private func loadCGImage(_ url: URL) -> CGImage? {
    guard FileManager.default.fileExists(atPath: url.path),
      let source = CGImageSourceCreateWithURL(url as CFURL, nil)
    else { return nil }
    return CGImageSourceCreateImageAtIndex(source, 0, nil)
  }

  private func aspectFillRect(imageSize: CGSize, in rect: CGRect, zoom: CGFloat) -> CGRect {
    guard imageSize.width > 0, imageSize.height > 0 else { return rect }
    let scale = max(rect.width / imageSize.width, rect.height / imageSize.height) * zoom
    let w = imageSize.width * scale
    let h = imageSize.height * scale
    return CGRect(x: rect.midX - w / 2, y: rect.midY - h / 2, width: w, height: h)
  }

  private func color(hex: String) -> CGColor {
    var value = hex.trimmingCharacters(in: .whitespacesAndNewlines)
    if value.hasPrefix("#") { value.removeFirst() }
    guard value.count == 6, let rgb = Int(value, radix: 16) else {
      return CGColor(red: 1, green: 0.08, blue: 0.12, alpha: 1)
    }
    return CGColor(
      red: CGFloat((rgb >> 16) & 255) / 255,
      green: CGFloat((rgb >> 8) & 255) / 255,
      blue: CGFloat(rgb & 255) / 255,
      alpha: 1)
  }
}
