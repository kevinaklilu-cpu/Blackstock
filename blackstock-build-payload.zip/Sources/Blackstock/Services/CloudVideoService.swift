import Foundation

#if canImport(FoundationNetworking)
  import FoundationNetworking
#endif

actor CloudVideoService {
  static let shared = CloudVideoService()

  enum CloudVideoFehler: LocalizedError {
    case konfiguration(String)
    case request(String)
    case generation(String)
    case timeout
    case download(String)

    var errorDescription: String? {
      switch self {
      case .konfiguration(let text): return text
      case .request(let text): return "Video-Provider: \(text)"
      case .generation(let text): return "Video-Generierung fehlgeschlagen: \(text)"
      case .timeout: return "Die Video-Generierung hat das Zeitlimit überschritten."
      case .download(let text): return "Video-Download fehlgeschlagen: \(text)"
      }
    }
  }

  private struct VideoJob: Decodable {
    struct JobError: Decodable {
      var code: String?
      var message: String?
    }
    var id: String
    var status: String
    var progress: Double?
    var error: JobError?
  }

  private struct RunwayTask: Decodable {
    var id: String
    var status: String?
    var output: [String]?
    var failure: String?
  }

  func generieren(
    prompt: String,
    format: VideoFormat,
    provider: ProviderVerbindung,
    apiKey: String,
    ziel: URL,
    sekunden: Int = 8,
    fortschritt: (@Sendable (Double) -> Void)? = nil
  ) async throws -> URL {
    let trimmed = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else {
      throw CloudVideoFehler.konfiguration("Der Szenen-Prompt ist leer.")
    }
    guard let basis = provider.basisURL?.trimmingCharacters(in: .whitespacesAndNewlines),
      !basis.isEmpty,
      let baseURL = URL(string: basis)
    else {
      throw CloudVideoFehler.konfiguration("Für die Video-Engine fehlt eine gültige Basis-URL.")
    }
    let model = provider.modell?.trimmingCharacters(in: .whitespacesAndNewlines)
    guard let model, !model.isEmpty else {
      throw CloudVideoFehler.konfiguration("Für die Video-Engine fehlt ein Modell.")
    }

    if provider.optionen?["adapter"] == "runway" {
      return try await runwayGenerieren(
        prompt: trimmed, format: format, baseURL: baseURL, model: model, apiKey: apiKey,
        ziel: ziel, sekunden: sekunden,
        apiVersion: provider.optionen?["apiVersion"] ?? "2024-11-06", fortschritt: fortschritt)
    }

    let seconds = [4, 8, 12].min(by: { abs($0 - sekunden) < abs($1 - sekunden) }) ?? 8
    let size = format == .short ? "720x1280" : "1280x720"
    let createURL = endpoint(baseURL: baseURL, path: "videos")
    var request = URLRequest(url: createURL)
    request.httpMethod = "POST"
    request.timeoutInterval = 90
    request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")

    let boundary = "Blackstock-\(UUID().uuidString)"
    request.setValue(
      "multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
    request.httpBody = multipart(
      boundary: boundary,
      fields: [
        "model": model,
        "prompt": String(trimmed.prefix(32_000)),
        "seconds": String(seconds),
        "size": size,
      ])

    let (data, response) = try await URLSession.shared.data(for: request)
    guard let http = response as? HTTPURLResponse else {
      throw CloudVideoFehler.request("Ungültige Server-Antwort.")
    }
    guard (200..<300).contains(http.statusCode) else {
      throw CloudVideoFehler.request(serverText(data, status: http.statusCode))
    }
    var job: VideoJob
    do { job = try JSONDecoder().decode(VideoJob.self, from: data) } catch {
      throw CloudVideoFehler.request(
        "Job-Antwort konnte nicht gelesen werden: \(error.localizedDescription)")
    }

    fortschritt?(max(0, min(1, (job.progress ?? 0) / 100)))
    let deadline = Date().addingTimeInterval(30 * 60)
    while job.status == "queued" || job.status == "in_progress" {
      try Task.checkCancellation()
      guard Date() < deadline else { throw CloudVideoFehler.timeout }
      try await Task.sleep(for: .seconds(8))
      job = try await jobAbrufen(id: job.id, baseURL: baseURL, apiKey: apiKey)
      fortschritt?(max(0, min(1, (job.progress ?? 0) / 100)))
    }

    guard job.status == "completed" else {
      throw CloudVideoFehler.generation(
        job.error?.message ?? job.error?.code ?? "Unbekannter Provider-Fehler")
    }

    let contentURL = endpoint(baseURL: baseURL, path: "videos/\(job.id)/content")
    var download = URLRequest(url: contentURL)
    download.timeoutInterval = 180
    download.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
    let (bytes, downloadResponse) = try await URLSession.shared.data(for: download)
    guard let dHTTP = downloadResponse as? HTTPURLResponse,
      (200..<300).contains(dHTTP.statusCode)
    else {
      let status = (downloadResponse as? HTTPURLResponse)?.statusCode ?? -1
      throw CloudVideoFehler.download(serverText(bytes, status: status))
    }
    guard !bytes.isEmpty else {
      throw CloudVideoFehler.download("Der Provider lieferte eine leere Datei.")
    }
    try FileManager.default.createDirectory(
      at: ziel.deletingLastPathComponent(), withIntermediateDirectories: true)
    try bytes.write(to: ziel, options: .atomic)
    fortschritt?(1)
    return ziel
  }

  private func runwayGenerieren(
    prompt: String, format: VideoFormat, baseURL: URL, model: String, apiKey: String,
    ziel: URL, sekunden: Int, apiVersion: String, fortschritt: (@Sendable (Double) -> Void)?
  ) async throws -> URL {
    let duration = sekunden <= 5 ? 5 : 10
    let preferredRatio = format == .short ? "720:1280" : "1280:720"
    let compatibilityRatio = format == .short ? "768:1280" : "1280:768"
    let ratios =
      preferredRatio == compatibilityRatio
      ? [preferredRatio] : [preferredRatio, compatibilityRatio]
    let createURL = endpoint(baseURL: baseURL, path: "image_to_video")
    var task: RunwayTask?
    var lastData = Data()
    var lastStatus = -1

    for ratio in ratios {
      var request = URLRequest(url: createURL)
      request.httpMethod = "POST"
      request.timeoutInterval = 90
      request.setValue("application/json", forHTTPHeaderField: "Content-Type")
      request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
      request.setValue(apiVersion, forHTTPHeaderField: "X-Runway-Version")
      request.httpBody = try JSONSerialization.data(withJSONObject: [
        "model": model,
        "promptText": String(prompt.prefix(10_000)),
        "ratio": ratio,
        "duration": duration,
      ])
      let (data, response) = try await URLSession.shared.data(for: request)
      let status = (response as? HTTPURLResponse)?.statusCode ?? -1
      lastData = data
      lastStatus = status
      if (200..<300).contains(status) {
        task = try JSONDecoder().decode(RunwayTask.self, from: data)
        break
      }
      // Runway hat das Format für Gen-4.5 erweitert. Ältere/strengere API-Validierungen
      // akzeptieren noch die 2024-11-06-Auflösungen; nur bei Validation wird daher erneut versucht.
      if ![400, 422].contains(status) { break }
    }
    guard var task else {
      throw CloudVideoFehler.request(serverText(lastData, status: lastStatus))
    }
    fortschritt?(0.05)
    let deadline = Date().addingTimeInterval(30 * 60)
    var attempt = 0
    while ["PENDING", "THROTTLED", "RUNNING"].contains(task.status ?? "PENDING") {
      try Task.checkCancellation()
      guard Date() < deadline else { throw CloudVideoFehler.timeout }
      attempt += 1
      let delay = min(12.0, 5.0 + Double(attempt % 4))
      try await Task.sleep(for: .seconds(delay))
      var poll = URLRequest(url: endpoint(baseURL: baseURL, path: "tasks/\(task.id)"))
      poll.timeoutInterval = 60
      poll.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
      poll.setValue(apiVersion, forHTTPHeaderField: "X-Runway-Version")
      let (pollData, pollResponse) = try await URLSession.shared.data(for: poll)
      guard let pollHTTP = pollResponse as? HTTPURLResponse,
        (200..<300).contains(pollHTTP.statusCode)
      else {
        throw CloudVideoFehler.request(
          serverText(pollData, status: (pollResponse as? HTTPURLResponse)?.statusCode ?? -1))
      }
      task = try JSONDecoder().decode(RunwayTask.self, from: pollData)
      fortschritt?(min(0.9, 0.08 + Double(attempt) * 0.04))
    }
    guard task.status == "SUCCEEDED", let raw = task.output?.first, let remote = URL(string: raw)
    else {
      throw CloudVideoFehler.generation(
        task.failure ?? "Runway-Task endete mit Status \(task.status ?? "unbekannt")")
    }
    let (bytes, downloadResponse) = try await URLSession.shared.data(from: remote)
    guard let dHTTP = downloadResponse as? HTTPURLResponse, (200..<300).contains(dHTTP.statusCode),
      !bytes.isEmpty
    else {
      throw CloudVideoFehler.download("Runway-Ausgabe konnte nicht heruntergeladen werden.")
    }
    try FileManager.default.createDirectory(
      at: ziel.deletingLastPathComponent(), withIntermediateDirectories: true)
    try bytes.write(to: ziel, options: .atomic)
    fortschritt?(1)
    return ziel
  }

  private func jobAbrufen(id: String, baseURL: URL, apiKey: String) async throws -> VideoJob {
    var request = URLRequest(url: endpoint(baseURL: baseURL, path: "videos/\(id)"))
    request.timeoutInterval = 60
    request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
    let (data, response) = try await URLSession.shared.data(for: request)
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
      throw CloudVideoFehler.request(
        serverText(data, status: (response as? HTTPURLResponse)?.statusCode ?? -1))
    }
    do { return try JSONDecoder().decode(VideoJob.self, from: data) } catch {
      throw CloudVideoFehler.request(
        "Job-Status konnte nicht gelesen werden: \(error.localizedDescription)")
    }
  }

  private func endpoint(baseURL: URL, path: String) -> URL {
    var base = baseURL.absoluteString
    while base.hasSuffix("/") { base.removeLast() }
    return URL(string: "\(base)/\(path)") ?? baseURL
  }

  private func multipart(boundary: String, fields: [String: String]) -> Data {
    var data = Data()
    func append(_ text: String) {
      if let bytes = text.data(using: .utf8) { data.append(bytes) }
    }
    for key in fields.keys.sorted() {
      guard let value = fields[key] else { continue }
      append("--\(boundary)\r\n")
      append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
      append("\(value)\r\n")
    }
    append("--\(boundary)--\r\n")
    return data
  }

  private func serverText(_ data: Data, status: Int) -> String {
    if let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
      let error = object["error"] as? [String: Any],
      let message = error["message"] as? String
    {
      return "HTTP \(status): \(message)"
    }
    let text =
      String(data: data, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    return text.isEmpty ? "HTTP \(status)" : "HTTP \(status): \(String(text.prefix(800)))"
  }
}
