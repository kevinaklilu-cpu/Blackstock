import AVFoundation
import AppKit
import Foundation
import QuartzCore

final class MasterVideoService {
  static let shared = MasterVideoService()

  struct Optionen {
    var format: VideoFormat
    var voiceover: URL?
    var musik: URL?
    var szenen: [ProduktionsSzene]
    var captions: Bool
    var watermark: URL?
  }

  enum MasterFehler: LocalizedError {
    case keineClips
    case dateiFehlt(String)
    case keineVideospur(String)
    case exportNichtVerfuegbar
    case mp4NichtUnterstuetzt
    case export(String)

    var errorDescription: String? {
      switch self {
      case .keineClips: "Für den Master-Render fehlt mindestens ein Video-Clip."
      case .dateiFehlt(let name): "Die Datei „\(name)“ wurde verschoben oder gelöscht."
      case .keineVideospur(let name): "„\(name)“ enthält keine Videospur."
      case .exportNichtVerfuegbar: "Der Master-Export konnte nicht gestartet werden."
      case .mp4NichtUnterstuetzt: "Dieser Medienmix kann nicht als MP4 exportiert werden."
      case .export(let detail): "Master-Render fehlgeschlagen: \(detail)"
      }
    }
  }

  func rendern(clips: [URL], optionen: Optionen, ziel: URL) async throws -> URL {
    guard !clips.isEmpty else { throw MasterFehler.keineClips }
    for url in clips where !FileManager.default.fileExists(atPath: url.path) {
      throw MasterFehler.dateiFehlt(url.lastPathComponent)
    }

    try FileManager.default.createDirectory(
      at: ziel.deletingLastPathComponent(), withIntermediateDirectories: true)
    try? FileManager.default.removeItem(at: ziel)

    let composition = AVMutableComposition()
    guard
      let videoTrack = composition.addMutableTrack(
        withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid)
    else { throw MasterFehler.exportNichtVerfuegbar }
    let originalAudio = composition.addMutableTrack(
      withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)

    var cursor = CMTime.zero
    var segments: [(source: AVAssetTrack, range: CMTimeRange, start: CMTime, outputDuration: CMTime)] = []
    for clip in clips {
      let asset = AVURLAsset(url: clip)
      let duration = try await asset.load(.duration)
      let seconds = CMTimeGetSeconds(duration)
      guard duration.isValid, seconds.isFinite, seconds > 0 else {
        throw MasterFehler.export("\(clip.lastPathComponent) hat keine gültige Dauer.")
      }
      guard let sourceVideo = try await asset.loadTracks(withMediaType: .video).first else {
        throw MasterFehler.keineVideospur(clip.lastPathComponent)
      }
      let range = CMTimeRange(start: .zero, duration: duration)
      try videoTrack.insertTimeRange(range, of: sourceVideo, at: cursor)
      if let sourceAudio = try await asset.loadTracks(withMediaType: .audio).first {
        try originalAudio?.insertTimeRange(range, of: sourceAudio, at: cursor)
      }
      segments.append((sourceVideo, range, cursor, duration))
      cursor = CMTimeAdd(cursor, duration)
    }

    let renderSize: CGSize =
      optionen.format == .short
      ? CGSize(width: 1080, height: 1920)
      : CGSize(width: 1920, height: 1080)
    let videoComposition = try await makeVideoComposition(
      compositionVideo: videoTrack, segments: segments, renderSize: renderSize,
      totalDuration: cursor, optionen: optionen)

    var audioParameters: [AVAudioMixInputParameters] = []
    if let originalAudio {
      let p = AVMutableAudioMixInputParameters(track: originalAudio)
      p.setVolume(optionen.voiceover == nil ? 0.92 : 0.24, at: .zero)
      audioParameters.append(p)
    }

    if let voice = optionen.voiceover, FileManager.default.fileExists(atPath: voice.path) {
      let asset = AVURLAsset(url: voice)
      if let source = try await asset.loadTracks(withMediaType: .audio).first,
        let destination = composition.addMutableTrack(
          withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
      {
        let voiceDuration = try await asset.load(.duration)
        let duration = min(cursor, voiceDuration)
        try destination.insertTimeRange(
          CMTimeRange(start: .zero, duration: duration), of: source, at: .zero)
        let p = AVMutableAudioMixInputParameters(track: destination)
        p.setVolume(1.0, at: .zero)
        audioParameters.append(p)
      }
    }

    if let music = optionen.musik, FileManager.default.fileExists(atPath: music.path) {
      let asset = AVURLAsset(url: music)
      if let source = try await asset.loadTracks(withMediaType: .audio).first,
        let destination = composition.addMutableTrack(
          withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
      {
        let musicDuration = try await asset.load(.duration)
        guard CMTimeGetSeconds(musicDuration) > 0 else {
          throw MasterFehler.export("Die Musikdatei hat keine gültige Dauer.")
        }
        var musicCursor = CMTime.zero
        while CMTimeCompare(musicCursor, cursor) < 0 {
          let remaining = CMTimeSubtract(cursor, musicCursor)
          let chunk = min(remaining, musicDuration)
          try destination.insertTimeRange(
            CMTimeRange(start: .zero, duration: chunk), of: source, at: musicCursor)
          musicCursor = CMTimeAdd(musicCursor, chunk)
        }
        let p = AVMutableAudioMixInputParameters(track: destination)
        p.setVolume(0.12, at: .zero)
        audioParameters.append(p)
      }
    }

    let audioMix = AVMutableAudioMix()
    audioMix.inputParameters = audioParameters

    guard
      let exporter = AVAssetExportSession(
        asset: composition, presetName: AVAssetExportPresetHighestQuality)
    else { throw MasterFehler.exportNichtVerfuegbar }
    guard exporter.supportedFileTypes.contains(.mp4) else {
      throw MasterFehler.mp4NichtUnterstuetzt
    }
    exporter.outputURL = ziel
    exporter.outputFileType = .mp4
    exporter.shouldOptimizeForNetworkUse = true
    exporter.videoComposition = videoComposition
    exporter.audioMix = audioMix

    await withCheckedContinuation { continuation in
      exporter.exportAsynchronously { continuation.resume() }
    }
    switch exporter.status {
    case .completed:
      guard FileManager.default.fileExists(atPath: ziel.path) else {
        throw MasterFehler.export("Die Exportdatei fehlt nach Abschluss.")
      }
      return ziel
    case .failed, .cancelled:
      throw MasterFehler.export(exporter.error?.localizedDescription ?? "Unbekannter Exportfehler")
    default:
      throw MasterFehler.export(
        exporter.error?.localizedDescription ?? "Export wurde nicht abgeschlossen")
    }
  }

  /// Renders the v11 rights-aware timeline. Source resolution/download happens outside this
  /// service; the renderer only accepts explicitly resolved managed file URLs.
  func rendern(
    timeline: RemixTimeline,
    sourceURLs: [UUID: URL],
    optionen: Optionen,
    ziel: URL
  ) async throws -> URL {
    guard timeline.isValid, !timeline.segments.isEmpty else { throw MasterFehler.keineClips }
    try FileManager.default.createDirectory(
      at: ziel.deletingLastPathComponent(), withIntermediateDirectories: true)
    try? FileManager.default.removeItem(at: ziel)

    let composition = AVMutableComposition()
    guard let videoTrack = composition.addMutableTrack(
      withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid)
    else { throw MasterFehler.exportNichtVerfuegbar }
    let originalAudio = composition.addMutableTrack(
      withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
    let audioParameters = originalAudio.map { AVMutableAudioMixInputParameters(track: $0) }

    var cursor = CMTime.zero
    var visualSegments: [(source: AVAssetTrack, range: CMTimeRange, start: CMTime, outputDuration: CMTime)] = []
    for segment in timeline.segments.sorted(by: { $0.order < $1.order }) {
      guard let url = sourceURLs[segment.sourceAssetID], FileManager.default.fileExists(atPath: url.path) else {
        throw MasterFehler.dateiFehlt(segment.sourceAssetID.uuidString)
      }
      let asset = AVURLAsset(url: url)
      let assetDuration = try await asset.load(.duration)
      let maxSeconds = CMTimeGetSeconds(assetDuration)
      guard maxSeconds.isFinite, maxSeconds > 0 else {
        throw MasterFehler.export("Eine Timeline-Quelle hat keine gültige Dauer.")
      }
      let startSeconds = max(0, min(segment.startTime, maxSeconds))
      let endSeconds = max(startSeconds, min(segment.endTime, maxSeconds))
      guard endSeconds - startSeconds > 0.05 else {
        throw MasterFehler.export("Ein Timeline-Segment liegt außerhalb der Quelldauer.")
      }
      guard let sourceVideo = try await asset.loadTracks(withMediaType: .video).first else {
        throw MasterFehler.keineVideospur(url.lastPathComponent)
      }
      let sourceRange = CMTimeRange(
        start: CMTime(seconds: startSeconds, preferredTimescale: 600),
        duration: CMTime(seconds: endSeconds - startSeconds, preferredTimescale: 600))
      let outputDuration = CMTime(
        seconds: (endSeconds - startSeconds) / max(0.1, segment.speed), preferredTimescale: 600)
      try videoTrack.insertTimeRange(sourceRange, of: sourceVideo, at: cursor)
      if CMTimeCompare(outputDuration, sourceRange.duration) != 0 {
        videoTrack.scaleTimeRange(
          CMTimeRange(start: cursor, duration: sourceRange.duration), toDuration: outputDuration)
      }

      if segment.audioMode != .muted,
        let sourceAudio = try await asset.loadTracks(withMediaType: .audio).first,
        let originalAudio
      {
        try originalAudio.insertTimeRange(sourceRange, of: sourceAudio, at: cursor)
        if CMTimeCompare(outputDuration, sourceRange.duration) != 0 {
          originalAudio.scaleTimeRange(
            CMTimeRange(start: cursor, duration: sourceRange.duration), toDuration: outputDuration)
        }
        audioParameters?.setVolume(segment.audioMode == .ducked ? 0.25 : 0.92, at: cursor)
      } else {
        audioParameters?.setVolume(0, at: cursor)
      }
      visualSegments.append((sourceVideo, sourceRange, cursor, outputDuration))
      cursor = CMTimeAdd(cursor, outputDuration)
    }

    let renderSize: CGSize = timeline.format == .short
      ? CGSize(width: 1080, height: 1920) : CGSize(width: 1920, height: 1080)
    let timelineOptions = Optionen(
      format: timeline.format, voiceover: optionen.voiceover, musik: optionen.musik,
      szenen: optionen.szenen, captions: timeline.captions && optionen.captions,
      watermark: optionen.watermark)
    let videoComposition = try await makeVideoComposition(
      compositionVideo: videoTrack, segments: visualSegments, renderSize: renderSize,
      totalDuration: cursor, optionen: timelineOptions)

    var mixParameters: [AVAudioMixInputParameters] = []
    if let audioParameters { mixParameters.append(audioParameters) }

    if let voice = optionen.voiceover, FileManager.default.fileExists(atPath: voice.path) {
      let voiceAsset = AVURLAsset(url: voice)
      if let source = try await voiceAsset.loadTracks(withMediaType: .audio).first,
        let destination = composition.addMutableTrack(
          withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
      {
        let voiceDuration = try await voiceAsset.load(.duration)
        let duration = min(cursor, voiceDuration)
        try destination.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of: source, at: .zero)
        let p = AVMutableAudioMixInputParameters(track: destination)
        p.setVolume(1.0, at: .zero)
        mixParameters.append(p)
      }
    }

    if let music = optionen.musik, FileManager.default.fileExists(atPath: music.path) {
      let musicAsset = AVURLAsset(url: music)
      if let source = try await musicAsset.loadTracks(withMediaType: .audio).first,
        let destination = composition.addMutableTrack(
          withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
      {
        let musicDuration = try await musicAsset.load(.duration)
        guard CMTimeGetSeconds(musicDuration) > 0 else {
          throw MasterFehler.export("Die Musikdatei hat keine gültige Dauer.")
        }
        var musicCursor = CMTime.zero
        while CMTimeCompare(musicCursor, cursor) < 0 {
          let remaining = CMTimeSubtract(cursor, musicCursor)
          let chunk = min(remaining, musicDuration)
          try destination.insertTimeRange(
            CMTimeRange(start: .zero, duration: chunk), of: source, at: musicCursor)
          musicCursor = CMTimeAdd(musicCursor, chunk)
        }
        let p = AVMutableAudioMixInputParameters(track: destination)
        p.setVolume(0.12, at: .zero)
        mixParameters.append(p)
      }
    }

    let audioMix = AVMutableAudioMix()
    audioMix.inputParameters = mixParameters
    guard let exporter = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality) else {
      throw MasterFehler.exportNichtVerfuegbar
    }
    guard exporter.supportedFileTypes.contains(.mp4) else { throw MasterFehler.mp4NichtUnterstuetzt }
    exporter.outputURL = ziel
    exporter.outputFileType = .mp4
    exporter.shouldOptimizeForNetworkUse = true
    exporter.videoComposition = videoComposition
    exporter.audioMix = audioMix
    await withCheckedContinuation { continuation in
      exporter.exportAsynchronously { continuation.resume() }
    }
    switch exporter.status {
    case .completed:
      guard FileManager.default.fileExists(atPath: ziel.path) else {
        throw MasterFehler.export("Die Exportdatei fehlt nach Abschluss.")
      }
      return ziel
    case .failed, .cancelled:
      throw MasterFehler.export(exporter.error?.localizedDescription ?? "Unbekannter Exportfehler")
    default:
      throw MasterFehler.export(exporter.error?.localizedDescription ?? "Export wurde nicht abgeschlossen")
    }
  }

  private func makeVideoComposition(
    compositionVideo: AVCompositionTrack,
    segments: [(source: AVAssetTrack, range: CMTimeRange, start: CMTime, outputDuration: CMTime)],
    renderSize: CGSize,
    totalDuration: CMTime,
    optionen: Optionen
  ) async throws -> AVMutableVideoComposition {
    let result = AVMutableVideoComposition()
    result.renderSize = renderSize
    result.frameDuration = CMTime(value: 1, timescale: 30)

    var instructions: [AVVideoCompositionInstructionProtocol] = []
    for segment in segments {
      let instruction = AVMutableVideoCompositionInstruction()
      instruction.timeRange = CMTimeRange(start: segment.start, duration: segment.outputDuration)
      let layer = AVMutableVideoCompositionLayerInstruction(assetTrack: compositionVideo)
      let naturalSize = try await segment.source.load(.naturalSize)
      let preferred = try await segment.source.load(.preferredTransform)
      let transformedRect = CGRect(origin: .zero, size: naturalSize).applying(preferred)
      let oriented = CGSize(width: abs(transformedRect.width), height: abs(transformedRect.height))
      guard oriented.width > 0, oriented.height > 0 else {
        throw MasterFehler.export("Ein Clip meldet eine ungültige Bildgröße.")
      }
      let scale = max(renderSize.width / oriented.width, renderSize.height / oriented.height)
      let scaled = CGSize(width: oriented.width * scale, height: oriented.height * scale)
      let x = (renderSize.width - scaled.width) / 2
      let y = (renderSize.height - scaled.height) / 2
      var transform = preferred
      transform = transform.concatenating(
        CGAffineTransform(translationX: -transformedRect.minX, y: -transformedRect.minY))
      transform = transform.concatenating(CGAffineTransform(scaleX: scale, y: scale))
      transform = transform.concatenating(CGAffineTransform(translationX: x, y: y))
      layer.setTransform(transform, at: segment.start)
      instruction.layerInstructions = [layer]
      instructions.append(instruction)
    }
    result.instructions = instructions

    guard optionen.captions || optionen.watermark != nil else { return result }
    let parent = CALayer()
    parent.frame = CGRect(origin: .zero, size: renderSize)
    parent.isGeometryFlipped = false
    let videoLayer = CALayer()
    videoLayer.frame = parent.bounds
    parent.addSublayer(videoLayer)

    if optionen.captions, !optionen.szenen.isEmpty {
      addCaptions(optionen.szenen, totalDuration: totalDuration, renderSize: renderSize, to: parent)
    }
    if let watermark = optionen.watermark,
      let image = NSImage(contentsOf: watermark),
      let cg = image.cgImage(forProposedRect: nil, context: nil, hints: nil)
    {
      let w: CGFloat = optionen.format == .short ? 150 : 120
      let layer = CALayer()
      layer.contents = cg
      layer.contentsGravity = .resizeAspect
      layer.opacity = 0.82
      layer.frame = CGRect(x: renderSize.width - w - 44, y: 42, width: w, height: w * 0.72)
      parent.addSublayer(layer)
    }
    result.animationTool = AVVideoCompositionCoreAnimationTool(
      postProcessingAsVideoLayer: videoLayer, in: parent)
    return result
  }

  private func addCaptions(
    _ scenes: [ProduktionsSzene], totalDuration: CMTime, renderSize: CGSize, to parent: CALayer
  ) {
    let total = max(0.1, CMTimeGetSeconds(totalDuration))
    var sceneStart: Double = 0
    for scene in scenes {
      let sceneDuration = min(max(0.6, scene.dauerSekunden), max(0.6, total - sceneStart))
      guard sceneStart < total, sceneDuration > 0 else { break }
      let chunks = captionChunks(scene.narration)
      guard !chunks.isEmpty else {
        sceneStart += sceneDuration
        continue
      }
      let chunkDuration = sceneDuration / Double(chunks.count)
      for (index, text) in chunks.enumerated() {
        let start = sceneStart + Double(index) * chunkDuration
        let end = min(total, start + chunkDuration)
        guard end > start else { continue }

        let container = CALayer()
        let isVertical = renderSize.height > renderSize.width
        let maxWidth = renderSize.width - (isVertical ? 120 : 260)
        let height: CGFloat = isVertical ? 180 : 120
        container.frame = CGRect(
          x: (renderSize.width - maxWidth) / 2,
          y: isVertical ? 175 : 90,
          width: maxWidth, height: height)
        container.backgroundColor = NSColor.black.withAlphaComponent(0.46).cgColor
        container.cornerRadius = isVertical ? 24 : 18
        container.opacity = 0

        let layer = CATextLayer()
        layer.contentsScale = 2
        layer.alignmentMode = .center
        layer.isWrapped = true
        layer.foregroundColor = NSColor.white.cgColor
        layer.shadowColor = NSColor.black.cgColor
        layer.shadowOpacity = 0.95
        layer.shadowRadius = 5
        layer.shadowOffset = CGSize(width: 0, height: -1)
        layer.fontSize = isVertical ? 54 : 40
        layer.font = NSFont.systemFont(ofSize: layer.fontSize, weight: .heavy)
        layer.string = text
        layer.frame = CGRect(x: 24, y: 20, width: maxWidth - 48, height: height - 40)
        container.addSublayer(layer)

        let animation = CAKeyframeAnimation(keyPath: "opacity")
        animation.calculationMode = .linear
        let startN = max(0, min(1, start / total))
        let endN = max(startN, min(1, end / total))
        let fade = min(0.012, max(0.002, (endN - startN) * 0.16))
        animation.values = [0, 0, 1, 1, 0, 0]
        animation.keyTimes = [
          0, NSNumber(value: max(0, startN - fade)), NSNumber(value: startN),
          NSNumber(value: max(startN, endN - fade)), NSNumber(value: endN), 1,
        ]
        animation.beginTime = AVCoreAnimationBeginTimeAtZero
        animation.duration = total
        animation.isRemovedOnCompletion = false
        animation.fillMode = .forwards
        container.add(animation, forKey: "blackstock.caption.\(scene.id).\(index)")
        parent.addSublayer(container)
      }
      sceneStart += sceneDuration
    }
  }

  private func captionChunks(_ narration: String) -> [String] {
    let clean = narration.replacingOccurrences(of: "\n", with: " ")
      .split(whereSeparator: { $0.isWhitespace }).map(String.init)
    guard !clean.isEmpty else { return [] }
    var result: [String] = []
    var current: [String] = []
    for word in clean {
      current.append(word)
      let joined = current.joined(separator: " ")
      let endsPhrase = word.last.map { ".,!?;:".contains($0) } ?? false
      if current.count >= 6 || joined.count >= 42 || (current.count >= 3 && endsPhrase) {
        result.append(joined)
        current.removeAll(keepingCapacity: true)
      }
    }
    if !current.isEmpty { result.append(current.joined(separator: " ")) }
    return result
  }

}
