import AVFoundation
import Foundation

actor LocalMusicService {
  static let shared = LocalMusicService()

  enum MusikFehler: LocalizedError {
    case format
    case buffer

    var errorDescription: String? {
      switch self {
      case .format: return "Die lokale Musik-Engine konnte kein Audioformat erzeugen."
      case .buffer: return "Die lokale Musik-Engine konnte keinen Audiopuffer erzeugen."
      }
    }
  }

  func generieren(produktion: Produktion, kanal: Kanal, ziel: URL) throws -> URL {
    let sampleRate = 44_100.0
    let duration = 24.0
    guard let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 2) else {
      throw MusikFehler.format
    }
    let capacity = AVAudioFrameCount(sampleRate * duration)
    guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: capacity) else {
      throw MusikFehler.buffer
    }
    buffer.frameLength = capacity
    guard let channels = buffer.floatChannelData else { throw MusikFehler.buffer }

    let text = "\(produktion.arbeitstitel) \(produktion.chanceSnapshot?.thema ?? "")".lowercased()
    let serious = ["politik", "wahl", "regierung", "news", "krieg", "krise", "unfall"].contains {
      text.contains($0)
    }
    let gaming = ["gaming", "game", "gta", "playstation", "xbox", "nintendo", "steam"].contains {
      text.contains($0)
    }
    let base: Double = gaming ? 98.0 : (serious ? 82.41 : 110.0)
    let chord = [base, base * 1.2599, base * 1.4983]
    let master: Float = serious ? 0.018 : (gaming ? 0.035 : 0.026)

    for frame in 0..<Int(capacity) {
      let t = Double(frame) / sampleRate
      let phase = (sin(t * .pi / 8.0) + 1.0) * 0.5
      let pulse = serious ? 0.75 : (0.75 + 0.25 * max(0, sin(t * .pi)))
      var value = 0.0
      for (i, f) in chord.enumerated() {
        value += sin(2 * .pi * f * t + Double(i) * 0.7) / Double(chord.count)
      }
      value += 0.18 * sin(2 * .pi * (base / 2) * t)
      let sample = Float(value * Double(master) * (0.7 + 0.3 * phase) * pulse)
      channels[0][frame] = sample
      channels[1][frame] = sample * 0.96
    }

    try FileManager.default.createDirectory(
      at: ziel.deletingLastPathComponent(), withIntermediateDirectories: true)
    try? FileManager.default.removeItem(at: ziel)
    let file = try AVAudioFile(forWriting: ziel, settings: format.settings)
    try file.write(from: buffer)
    return ziel
  }
}
