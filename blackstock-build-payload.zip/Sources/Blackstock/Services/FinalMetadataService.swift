import Foundation

struct FinalMetadata: Hashable {
  var title: String
  var description: String
  var tags: [String]
  var hashtags: [String]
  var chapters: [String]
  var thumbnailText: String
  var disclosure: String?
}

final class FinalMetadataService {
  func make(
    trendTitle: String,
    profile: ChannelContentProfile,
    sources: [SourceAsset],
    timeline: RemixTimeline,
    fallbackTitle: String
  ) -> FinalMetadata {
    let usedIDs = Set(timeline.segments.map(\.sourceAssetID))
    let used = sources.filter { usedIDs.contains($0.id) }
    let transcript = used.compactMap(\.transcript).joined(separator: " ")
      .trimmingCharacters(in: .whitespacesAndNewlines)
    let sourceTitles = used.map(\.title)
    let factualAnchor = sourceTitles.first ?? trendTitle
    let titleBase = trendTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? fallbackTitle : trendTitle
    let title = String(titleBase.prefix(96))

    var descriptionParts: [String] = []
    if !factualAnchor.isEmpty {
      descriptionParts.append("Dieses Video ordnet \(factualAnchor) anhand der tatsächlich verwendeten, freigegebenen Quellen ein.")
    }
    if !sourceTitles.isEmpty {
      descriptionParts.append("Verwendete Quellen: " + sourceTitles.prefix(5).joined(separator: ", ") + ".")
    }
    if !transcript.isEmpty {
      let excerpt = transcript.split(separator: " ").prefix(34).joined(separator: " ")
      descriptionParts.append("Im Video behandelt: \(excerpt).")
    }
    let attribution = used.filter { $0.allowedUses.contains(.attributionRequired) }
      .compactMap { source -> String? in
        guard let creator = source.creator else { return nil }
        return "\(source.title) — \(creator)"
      }
    if !attribution.isEmpty {
      descriptionParts.append("Attribution: " + attribution.joined(separator: "; "))
    }

    let uniqueTags = Array(Set(profile.effectiveSearchTerms + used.flatMap(\.topicTags))).sorted()
    let tags = Array(uniqueTags.prefix(20))
    let hashtags = Array(tags.prefix(4)).map { "#" + $0.replacingOccurrences(of: " ", with: "") }
    let chapters: [String]
    if timeline.format == .longform || timeline.format == .serie {
      var cursor: Double = 0
      chapters = timeline.segments.enumerated().map { index, segment in
        let seconds = Int(cursor)
        defer { cursor += segment.duration }
        let source = used.first(where: { $0.id == segment.sourceAssetID })?.title ?? "Kapitel \(index + 1)"
        return String(format: "%02d:%02d %@", seconds / 60, seconds % 60, source)
      }
    } else {
      chapters = []
    }
    return FinalMetadata(
      title: title,
      description: descriptionParts.joined(separator: "\n\n"),
      tags: tags,
      hashtags: hashtags,
      chapters: chapters,
      thumbnailText: String(title.prefix(42)),
      disclosure: nil
    )
  }
}
