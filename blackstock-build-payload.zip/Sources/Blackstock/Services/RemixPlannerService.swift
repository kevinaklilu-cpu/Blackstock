import Foundation

final class RemixPlannerService {
  enum PlannerError: LocalizedError {
    case noUsableSources
    case noSegments

    var errorDescription: String? {
      switch self {
      case .noUsableSources: "Es wurden keine rights-cleared Schnittquellen gefunden."
      case .noSegments: "Aus den verfügbaren Quellen konnten keine sinnvollen Segmente geplant werden."
      }
    }
  }

  private let analyzer = ClipAnalysisService()

  func plan(
    sources: [SourceAsset],
    mode: ProductionModeV11,
    requestedFormat: VideoFormat
  ) throws -> RemixTimeline {
    let usable = sources.filter(RightsService.canEnterAutomaticRender)
    guard !usable.isEmpty else { throw PlannerError.noUsableSources }
    let format: VideoFormat
    switch mode {
    case .short: format = .short
    case .longform: format = .longform
    case .live: format = .livestream
    case .automatic, .singleSource, .remix: format = requestedFormat
    }
    let targetDuration: Double
    switch format {
    case .short: targetDuration = 55
    case .longform: targetDuration = 8 * 60
    case .serie: targetDuration = 4 * 60
    case .livestream: targetDuration = usable.compactMap(\.duration).reduce(0, +)
    }

    let analyses = Dictionary(uniqueKeysWithValues: usable.map { source in
      (source.id, analyzer.analyze(source, targetFormat: format))
    })
    var candidates = usable.flatMap { analyses[$0.id] ?? [] }
    if mode == .singleSource,
      let bestSource = usable.max(by: { lhs, rhs in
        (analyses[lhs.id]?.first?.score ?? 0) < (analyses[rhs.id]?.first?.score ?? 0)
      })
    {
      candidates = analyses[bestSource.id] ?? []
    }

    var selected: [ClipCandidate] = []
    var duration: Double = 0
    var perSource = [UUID: Int]()
    for candidate in candidates.sorted(by: { $0.score > $1.score }) {
      guard duration < targetDuration else { break }
      guard candidate.duration > 0.5 else { continue }
      let overlaps = selected.contains { other in
        guard other.sourceAssetID == candidate.sourceAssetID else { return false }
        return max(other.start, candidate.start) < min(other.end, candidate.end)
      }
      guard !overlaps else { continue }
      if mode != .singleSource && mode != .live, perSource[candidate.sourceAssetID, default: 0] >= 3 { continue }
      let remaining = targetDuration - duration
      if remaining <= 0 { break }
      if candidate.duration > remaining && remaining >= 1.5 {
        var clipped = candidate
        clipped.end = min(candidate.end, candidate.start + remaining)
        selected.append(clipped)
        duration += clipped.duration
      } else {
        selected.append(candidate)
        duration += candidate.duration
      }
      perSource[candidate.sourceAssetID, default: 0] += 1
    }

    if format == .livestream {
      selected = usable.enumerated().compactMap { index, source in
        guard let d = source.duration, d > 0 else { return nil }
        return ClipCandidate(sourceAssetID: source.id, start: 0, end: d, score: 100, reason: "Live-Playlist", transcriptExcerpt: nil)
      }
      duration = selected.reduce(0) { $0 + $1.duration }
    }
    guard !selected.isEmpty else { throw PlannerError.noSegments }

    // Editorial order: strong hook first, then alternate sources to avoid random repetition.
    let ordered: [ClipCandidate]
    if format == .short {
      ordered = selected.sorted { lhs, rhs in
        if lhs.score == rhs.score { return lhs.start < rhs.start }
        return lhs.score > rhs.score
      }
    } else {
      ordered = selected.sorted { lhs, rhs in
        if lhs.sourceAssetID == rhs.sourceAssetID { return lhs.start < rhs.start }
        return lhs.score > rhs.score
      }
    }

    let segments = ordered.enumerated().map { index, c in
      RemixSegment(
        sourceAssetID: c.sourceAssetID,
        startTime: c.start,
        endTime: c.end,
        cropMode: format == .short ? .smartReframe : .fill,
        speed: 1,
        audioMode: .original,
        captionMode: format == .short ? .burnedIn : .auto,
        order: index
      )
    }
    let actual = segments.reduce(0) { $0 + $1.duration }
    return RemixTimeline(
      format: format,
      duration: actual,
      segments: segments,
      transitions: format == .short ? ["cut"] : ["cut", "crossfade"],
      captions: true
    )
  }
}
