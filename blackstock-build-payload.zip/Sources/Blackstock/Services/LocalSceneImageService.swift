import CoreGraphics
import Foundation
import ImageIO
import UniformTypeIdentifiers

actor LocalSceneImageService {
  static let shared = LocalSceneImageService()

  enum Fehler: LocalizedError {
    case render
    case speichern

    var errorDescription: String? {
      switch self {
      case .render: return "Lokales Szenenbild konnte nicht gerendert werden."
      case .speichern: return "Lokales Szenenbild konnte nicht gespeichert werden."
      }
    }
  }

  func generieren(
    scene: ProduktionsSzene, produktion: Produktion, kanal: Kanal, branding: KanalBranding,
    index: Int, ziel: URL
  ) throws -> URL {
    let vertical = produktion.format == .short
    let width = vertical ? 1080 : 1920
    let height = vertical ? 1920 : 1080
    let colorSpace = CGColorSpaceCreateDeviceRGB()
    guard
      let context = CGContext(
        data: nil, width: width, height: height, bitsPerComponent: 8, bytesPerRow: 0,
        space: colorSpace, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
    else { throw Fehler.render }

    let canvas = CGRect(x: 0, y: 0, width: width, height: height)
    let accent = color(hex: branding.akzentHex)
    let seed = stableSeed(
      "\(produktion.arbeitstitel)|\(scene.titel)|\(scene.visualDirection)|\(kanal.thema)|\(index)")
    let secondary = derivedColor(seed: seed, offset: 37)
    let tertiary = derivedColor(seed: seed, offset: 83)

    context.setFillColor(CGColor(gray: 0.018, alpha: 1))
    context.fill(canvas)

    if let gradient = CGGradient(
      colorsSpace: colorSpace,
      colors: [
        accent.copy(alpha: 0.78) ?? accent,
        secondary.copy(alpha: 0.56) ?? secondary,
        CGColor(gray: 0.015, alpha: 1),
      ] as CFArray,
      locations: [0, 0.45, 1])
    {
      context.drawLinearGradient(
        gradient,
        start: CGPoint(x: CGFloat(width) * 0.08, y: CGFloat(height) * 0.92),
        end: CGPoint(x: CGFloat(width) * 0.92, y: CGFloat(height) * 0.08), options: [])
    }

    // Große, weiche Formen erzeugen pro Szene eine eigenständige, aber markenkonsistente Bildsprache.
    for i in 0..<6 {
      let n = CGFloat((seed + UInt64(i * 19)) % 1000) / 1000
      let m = CGFloat((seed + UInt64(i * 53 + 11)) % 1000) / 1000
      let radius = CGFloat(min(width, height)) * (0.12 + CGFloat(i % 3) * 0.055)
      let rect = CGRect(
        x: CGFloat(width) * (0.04 + n * 0.78) - radius,
        y: CGFloat(height) * (0.06 + m * 0.78) - radius,
        width: radius * 2, height: radius * 2)
      context.setFillColor(
        (i.isMultiple(of: 2) ? secondary : tertiary).copy(alpha: 0.10 + Double(i) * 0.018)
          ?? tertiary)
      context.fillEllipse(in: rect)
    }

    context.setStrokeColor(CGColor(gray: 1, alpha: 0.10))
    context.setLineWidth(max(1, CGFloat(width) / 1200))
    let spacing = CGFloat(max(90, width / 12))
    var x = -CGFloat(height)
    let canvasWidth = CGFloat(width)
    let canvasHeight = CGFloat(height)
    while x < canvasWidth + canvasHeight {
      context.move(to: CGPoint(x: x, y: 0))
      context.addLine(to: CGPoint(x: x + canvasHeight, y: canvasHeight))
      x += spacing
    }
    context.strokePath()

    // Motiv-Fokusfläche: abstrakt, damit kein fremdes Material oder Markenrecht benötigt wird.
    let focusW = CGFloat(width) * (vertical ? 0.76 : 0.48)
    let focusH = CGFloat(height) * (vertical ? 0.34 : 0.58)
    let focus = CGRect(
      x: CGFloat(width) * (vertical ? 0.12 : 0.46),
      y: CGFloat(height) * (vertical ? 0.32 : 0.22), width: focusW, height: focusH)
    context.setFillColor(CGColor(gray: 0, alpha: 0.18))
    context.addPath(
      CGPath(
        roundedRect: focus, cornerWidth: CGFloat(width) * 0.028,
        cornerHeight: CGFloat(width) * 0.028, transform: nil))
    context.fillPath()
    context.setStrokeColor(CGColor(gray: 1, alpha: 0.14))
    context.setLineWidth(max(2, CGFloat(width) / 700))
    context.addPath(
      CGPath(
        roundedRect: focus, cornerWidth: CGFloat(width) * 0.028,
        cornerHeight: CGFloat(width) * 0.028, transform: nil))
    context.strokePath()

    guard let image = context.makeImage() else { throw Fehler.render }
    try FileManager.default.createDirectory(
      at: ziel.deletingLastPathComponent(), withIntermediateDirectories: true)
    try? FileManager.default.removeItem(at: ziel)
    guard
      let destination = CGImageDestinationCreateWithURL(
        ziel as CFURL, UTType.png.identifier as CFString, 1, nil)
    else { throw Fehler.speichern }
    CGImageDestinationAddImage(destination, image, nil)
    guard CGImageDestinationFinalize(destination) else { throw Fehler.speichern }
    return ziel
  }

  private func stableSeed(_ text: String) -> UInt64 {
    text.utf8.reduce(UInt64(1_469_598_103_934_665_603)) { hash, byte in
      (hash ^ UInt64(byte)) &* 1_099_511_628_211
    }
  }

  private func derivedColor(seed: UInt64, offset: UInt64) -> CGColor {
    let hue = Double((seed &+ offset * 7919) % 360) / 360
    return hsv(h: hue, s: 0.62, v: 0.82)
  }

  private func hsv(h: Double, s: Double, v: Double) -> CGColor {
    let i = Int(h * 6)
    let f = h * 6 - Double(i)
    let p = v * (1 - s)
    let q = v * (1 - f * s)
    let t = v * (1 - (1 - f) * s)
    let rgb: (Double, Double, Double)
    switch i % 6 {
    case 0: rgb = (v, t, p)
    case 1: rgb = (q, v, p)
    case 2: rgb = (p, v, t)
    case 3: rgb = (p, q, v)
    case 4: rgb = (t, p, v)
    default: rgb = (v, p, q)
    }
    return CGColor(red: rgb.0, green: rgb.1, blue: rgb.2, alpha: 1)
  }

  private func color(hex: String) -> CGColor {
    var value = hex.trimmingCharacters(in: .whitespacesAndNewlines)
    if value.hasPrefix("#") { value.removeFirst() }
    guard value.count == 6, let rgb = Int(value, radix: 16) else {
      return CGColor(red: 1, green: 0.08, blue: 0.12, alpha: 1)
    }
    return CGColor(
      red: CGFloat((rgb >> 16) & 255) / 255,
      green: CGFloat((rgb >> 8) & 255) / 255,
      blue: CGFloat(rgb & 255) / 255,
      alpha: 1)
  }
}
