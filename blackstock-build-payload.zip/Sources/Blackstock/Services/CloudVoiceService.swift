import AVFoundation
import Foundation

#if canImport(FoundationNetworking)
  import FoundationNetworking
#endif

final class CloudVoiceService {
  static let shared = CloudVoiceService()

  enum CloudVoiceFehler: LocalizedError {
    case nichtKonfiguriert
    case ungueltigeURL
    case leeresSkript
    case http(Int, String)
    case export

    var errorDescription: String? {
      switch self {
      case .nichtKonfiguriert: "Premium-Voice-Engine ist nicht vollständig konfiguriert."
      case .ungueltigeURL: "Die Voice-Engine-URL ist ungültig."
      case .leeresSkript: "Für die Voice-Engine fehlt ein Skript."
      case .http(let code, let body): "Voice-Engine antwortet mit HTTP \(code): \(body)"
      case .export: "Die erzeugten Voice-Segmente konnten nicht zusammengeführt werden."
      }
    }
  }

  private struct SpeechRequest: Encodable {
    let model: String
    let input: String
    let voice: String
    let responseFormat: String
    let instructions: String?

    enum CodingKeys: String, CodingKey {
      case model, input, voice, instructions
      case responseFormat = "response_format"
    }
  }

  func generieren(
    text: String,
    provider: ProviderVerbindung,
    apiKey: String,
    ziel: URL
  ) async throws -> URL {
    let sauber = text.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !sauber.isEmpty else { throw CloudVoiceFehler.leeresSkript }
    guard let base = provider.basisURL?.trimmingCharacters(in: .whitespacesAndNewlines),
      let model = provider.modell?.trimmingCharacters(in: .whitespacesAndNewlines),
      !base.isEmpty, !model.isEmpty, !apiKey.isEmpty
    else { throw CloudVoiceFehler.nichtKonfiguriert }

    let adapter = provider.optionen?["adapter"] ?? "openai"
    let chunks = split(sauber, max: adapter == "elevenlabs" ? 2800 : 3900)
    let temp = FileManager.default.temporaryDirectory
      .appendingPathComponent("blackstock-voice-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: temp, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: temp) }

    var urls: [URL] = []
    for (index, chunk) in chunks.enumerated() {
      let data: Data
      if adapter == "elevenlabs" {
        let voiceID =
          provider.optionen?["voice"]?.trimmingCharacters(in: .whitespacesAndNewlines).nonEmpty
          ?? "JBFqnCBsd6RMkjVDRZzb"
        let endpointString =
          base.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
          + "/text-to-speech/\(voiceID)?output_format=mp3_44100_128"
        guard let endpoint = URL(string: endpointString) else {
          throw CloudVoiceFehler.ungueltigeURL
        }
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 150
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(apiKey, forHTTPHeaderField: "xi-api-key")
        let body: [String: Any] = [
          "text": chunk,
          "model_id": model,
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (responseData, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
          let code = (response as? HTTPURLResponse)?.statusCode ?? -1
          let body = String(data: responseData, encoding: .utf8) ?? "Unbekannter Fehler"
          throw CloudVoiceFehler.http(code, String(body.prefix(600)))
        }
        data = responseData
      } else {
        let endpointString =
          base.hasSuffix("/audio/speech")
          ? base : base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/audio/speech"
        guard let endpoint = URL(string: endpointString) else {
          throw CloudVoiceFehler.ungueltigeURL
        }
        let requestBody = SpeechRequest(
          model: model,
          input: chunk,
          voice: provider.optionen?["voice"]?.trimmingCharacters(in: .whitespacesAndNewlines)
            .nonEmpty ?? "marin",
          responseFormat: "mp3",
          instructions: provider.optionen?["instructions"]?.trimmingCharacters(
            in: .whitespacesAndNewlines
          ).nonEmpty)
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 120
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONEncoder().encode(requestBody)
        let (responseData, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
          let code = (response as? HTTPURLResponse)?.statusCode ?? -1
          let body = String(data: responseData, encoding: .utf8) ?? "Unbekannter Fehler"
          throw CloudVoiceFehler.http(code, String(body.prefix(600)))
        }
        data = responseData
      }
      let file = temp.appendingPathComponent("segment-\(index).mp3")
      try data.write(to: file, options: .atomic)
      urls.append(file)
    }

    try FileManager.default.createDirectory(
      at: ziel.deletingLastPathComponent(), withIntermediateDirectories: true)
    try? FileManager.default.removeItem(at: ziel)
    return try await combine(urls, target: ziel)
  }

  private func combine(_ urls: [URL], target: URL) async throws -> URL {
    let composition = AVMutableComposition()
    guard
      let track = composition.addMutableTrack(
        withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
    else { throw CloudVoiceFehler.export }
    var cursor = CMTime.zero
    for url in urls {
      let asset = AVURLAsset(url: url)
      guard let source = try await asset.loadTracks(withMediaType: .audio).first else { continue }
      let duration = try await asset.load(.duration)
      try track.insertTimeRange(
        CMTimeRange(start: .zero, duration: duration), of: source, at: cursor)
      cursor = CMTimeAdd(cursor, duration)
    }
    guard CMTimeGetSeconds(cursor) > 0,
      let exporter = AVAssetExportSession(
        asset: composition, presetName: AVAssetExportPresetAppleM4A)
    else { throw CloudVoiceFehler.export }
    exporter.outputURL = target
    exporter.outputFileType = .m4a
    await withCheckedContinuation { continuation in
      exporter.exportAsynchronously { continuation.resume() }
    }
    guard exporter.status == .completed, FileManager.default.fileExists(atPath: target.path) else {
      throw CloudVoiceFehler.export
    }
    return target
  }

  private func split(_ text: String, max limit: Int) -> [String] {
    guard text.count > limit else { return [text] }
    var result: [String] = []
    var current = ""
    for sentence in text.split(whereSeparator: { ".!?\n".contains($0) }) {
      let part = sentence.trimmingCharacters(in: .whitespacesAndNewlines) + "."
      if current.count + part.count + 1 > limit, !current.isEmpty {
        result.append(current)
        current = part
      } else {
        current += (current.isEmpty ? "" : " ") + part
      }
    }
    if !current.isEmpty { result.append(current) }
    if result.isEmpty {
      var index = text.startIndex
      while index < text.endIndex {
        let end = text.index(index, offsetBy: limit, limitedBy: text.endIndex) ?? text.endIndex
        result.append(String(text[index..<end]))
        index = end
      }
    }
    return result
  }
}

extension String {
  fileprivate var nonEmpty: String? { isEmpty ? nil : self }
}
