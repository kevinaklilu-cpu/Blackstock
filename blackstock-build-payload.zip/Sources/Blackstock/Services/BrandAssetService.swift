import AppKit
import Foundation

final class BrandAssetService {
  static let shared = BrandAssetService()

  struct Ergebnis {
    let logo: URL
    let banner: URL
  }

  enum BrandFehler: LocalizedError {
    case bildExport
    var errorDescription: String? { "Branding-Dateien konnten nicht als PNG exportiert werden." }
  }

  func generieren(kanal: Kanal, branding: KanalBranding) throws -> Ergebnis {
    let support =
      FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
      ?? FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent(
        "Library/Application Support", isDirectory: true)
    let base = support.appendingPathComponent(
      "Blackstock/Branding/\(kanal.id.uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
    let logoURL = base.appendingPathComponent("channel-logo.png")
    let bannerURL = base.appendingPathComponent("channel-banner.png")

    let accent =
      NSColor(hex: branding.akzentHex)
      ?? NSColor(calibratedRed: 1.0, green: 0.105, blue: 0.125, alpha: 1)
    let logo = makeLogo(size: NSSize(width: 1024, height: 1024), accent: accent)
    let banner = makeBanner(
      size: NSSize(width: 2560, height: 1440), accent: accent, kanal: kanal, branding: branding)
    try writePNG(logo, to: logoURL)
    try writePNG(banner, to: bannerURL)
    return Ergebnis(logo: logoURL, banner: bannerURL)
  }

  private func makeLogo(size: NSSize, accent: NSColor) -> NSImage {
    let image = NSImage(size: size)
    image.lockFocus()
    NSColor(calibratedWhite: 0.055, alpha: 1).setFill()
    NSBezierPath(rect: NSRect(origin: .zero, size: size)).fill()

    let tile = NSRect(x: 92, y: 300, width: 840, height: 424)
    accent.setFill()
    NSBezierPath(roundedRect: tile, xRadius: 122, yRadius: 122).fill()

    NSColor.white.setFill()
    let triangle = NSBezierPath()
    triangle.move(to: NSPoint(x: 284, y: 404))
    triangle.line(to: NSPoint(x: 284, y: 620))
    triangle.line(to: NSPoint(x: 456, y: 512))
    triangle.close()
    triangle.fill()

    let attrs: [NSAttributedString.Key: Any] = [
      .font: NSFont.systemFont(ofSize: 310, weight: .black),
      .foregroundColor: NSColor.white,
    ]
    NSAttributedString(string: "B", attributes: attrs).draw(at: NSPoint(x: 490, y: 350))
    image.unlockFocus()
    return image
  }

  private func makeBanner(size: NSSize, accent: NSColor, kanal: Kanal, branding: KanalBranding)
    -> NSImage
  {
    let image = NSImage(size: size)
    image.lockFocus()
    if let gradient = NSGradient(colors: [
      NSColor(calibratedWhite: 0.045, alpha: 1), accent.withAlphaComponent(0.75),
      NSColor(calibratedWhite: 0.07, alpha: 1),
    ]) {
      gradient.draw(in: NSRect(origin: .zero, size: size), angle: 0)
    } else {
      NSColor(calibratedWhite: 0.055, alpha: 1).setFill()
      NSBezierPath(rect: NSRect(origin: .zero, size: size)).fill()
    }

    let mark = makeLogo(size: NSSize(width: 420, height: 420), accent: accent)
    mark.draw(
      in: NSRect(x: 300, y: 510, width: 420, height: 420), from: .zero, operation: .sourceOver,
      fraction: 1)

    let titleAttrs: [NSAttributedString.Key: Any] = [
      .font: NSFont.systemFont(ofSize: 118, weight: .black), .foregroundColor: NSColor.white,
    ]
    let subAttrs: [NSAttributedString.Key: Any] = [
      .font: NSFont.systemFont(ofSize: 42, weight: .medium),
      .foregroundColor: NSColor.white.withAlphaComponent(0.76),
    ]
    NSAttributedString(string: kanal.name, attributes: titleAttrs).draw(at: NSPoint(x: 780, y: 720))
    NSAttributedString(string: kanal.thema + "  ·  " + branding.thumbnailStil, attributes: subAttrs)
      .draw(at: NSPoint(x: 790, y: 635))
    image.unlockFocus()
    return image
  }

  private func writePNG(_ image: NSImage, to url: URL) throws {
    guard let tiff = image.tiffRepresentation,
      let bitmap = NSBitmapImageRep(data: tiff),
      let data = bitmap.representation(using: .png, properties: [:])
    else { throw BrandFehler.bildExport }
    try data.write(to: url, options: .atomic)
  }
}

extension NSColor {
  fileprivate convenience init?(hex: String) {
    var value = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    if value.hasPrefix("#") { value.removeFirst() }
    guard value.count == 6, let int = Int(value, radix: 16) else { return nil }
    self.init(
      calibratedRed: CGFloat((int >> 16) & 0xFF) / 255,
      green: CGFloat((int >> 8) & 0xFF) / 255,
      blue: CGFloat(int & 0xFF) / 255,
      alpha: 1
    )
  }
}
