import Foundation

#if canImport(FoundationModels) && arch(arm64)
  import FoundationModels
#endif

enum AppleIntelligenceCreatorService {
  enum Fehler: LocalizedError {
    case nichtVerfuegbar
    case leereAntwort
    case ungueltigesJSON

    var errorDescription: String? {
      switch self {
      case .nichtVerfuegbar:
        return "Apple Intelligence ist auf diesem Mac nicht verfügbar oder noch nicht bereit."
      case .leereAntwort:
        return "Apple Intelligence hat keine verwertbare Antwort geliefert."
      case .ungueltigesJSON:
        return "Apple Intelligence konnte kein gültiges Blackstock-Produktionspaket erzeugen."
      }
    }
  }

  private struct PaketDTO: Decodable {
    struct SzeneDTO: Decodable {
      let titel: String
      let narration: String
      let visualDirection: String
      let dauerSekunden: Double
    }
    let titel: String
    let hook: String
    let skript: String
    let beschreibung: String
    let tags: [String]
    let thumbnailText: String
    let szenen: [SzeneDTO]
  }

  static var verfuegbar: Bool {
    #if canImport(FoundationModels) && arch(arm64)
      if #available(macOS 26.0, *) {
        return SystemLanguageModel.default.isAvailable
      }
    #endif
    return false
  }

  static func produktionsPaket(
    chance: Chance, kanal: Kanal, format: VideoFormat, modus: Produktionsmodus
  ) async throws -> ProduktionsPaket {
    #if canImport(FoundationModels) && arch(arm64)
      if #available(macOS 26.0, *) {
        guard SystemLanguageModel.default.isAvailable else { throw Fehler.nichtVerfuegbar }

        let formatText: String = {
          switch format {
          case .short: return "9:16 Short, 35–60 Sekunden, 6–8 kompakte Szenen"
          case .longform: return "16:9 Langvideo, klare Kapitel, 8–14 Szenen"
          case .serie: return "eigenständige Serienfolge mit Anschluss an weitere Episoden"
          case .livestream: return "Livestream mit Segmenten, Moderation und Interaktion"
          }
        }()

        let instructions = """
          Du bist die lokale redaktionelle Blackstock-Engine. Schreibe auf Deutsch wie eine professionelle YouTube-Redaktion. Bleibe strikt beim gelieferten Thema. Erfinde keine Fakten, Zahlen, Zitate oder Quellen. Wenn eine konkrete Tatsachenbehauptung aus den gelieferten Informationen nicht ableitbar ist, formuliere sie als offene Einordnung oder markiere sie im Skript mit [VERIFY]. Vermeide generische KI-Floskeln. Titel, Hook, Skript, Beschreibung, Thumbnail-Text und jede Szene müssen inhaltlich dieselbe Kernstory erzählen. Antworte ausschließlich als valides JSON, ohne Markdown.
          """
        let session = LanguageModelSession(instructions: instructions)
        let prompt = """
          KANAL: \(kanal.name)
          KANALTHEMA: \(kanal.thema)
          VIDEO-THEMA: \(chance.thema)
          MARKTSIGNAL/TITEL: \(chance.titel)
          SIGNAL-KONTEXT: \(chance.begruendung)
          FORMAT: \(formatText)
          QUALITÄTSMODUS: \(modus.rawValue)

          Erzeuge exakt dieses JSON-Schema:
          {
            "titel":"...",
            "hook":"...",
            "skript":"...",
            "beschreibung":"...",
            "tags":["..."],
            "thumbnailText":"...",
            "szenen":[
              {"titel":"...","narration":"...","visualDirection":"...","dauerSekunden":6}
            ]
          }

          Regeln:
          - Die Beschreibung muss konkret erklären, was der Zuschauer in genau diesem Video bekommt; keine Platzhalter und kein generischer Blackstock-Werbetext.
          - Das Skript muss die Szenen in derselben Reihenfolge abbilden.
          - Jede visualDirection beschreibt ein Motiv, das sichtbar zur jeweiligen Narration passt.
          - News/Politik: bestätigte Information, Kontext und offene Punkte klar trennen; neutral formulieren.
          - Gaming: konkrete Mechanik, Spielmoment, Vergleich oder beobachtbares Feature in den Mittelpunkt stellen.
          - Keine fremden Formulierungen oder urheberrechtlich geschützten Figuren imitieren.
          """

        let response = try await session.respond(to: prompt)
        let raw = response.content.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { throw Fehler.leereAntwort }
        let json = jsonObjekt(aus: raw)
        guard let data = json.data(using: .utf8),
          let dto = try? JSONDecoder().decode(PaketDTO.self, from: data)
        else { throw Fehler.ungueltigesJSON }
        return try normalisieren(dto, chance: chance, format: format)
      }
    #endif
    throw Fehler.nichtVerfuegbar
  }

  private static func normalisieren(
    _ dto: PaketDTO, chance: Chance, format: VideoFormat
  ) throws -> ProduktionsPaket {
    let title = String(dto.titel.trimmingCharacters(in: .whitespacesAndNewlines).prefix(100))
    let hook = dto.hook.trimmingCharacters(in: .whitespacesAndNewlines)
    let desc = dto.beschreibung.trimmingCharacters(in: .whitespacesAndNewlines)
    let scenes = dto.szenen.filter {
      !$0.titel.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        && !$0.narration.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        && !$0.visualDirection.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        && $0.dauerSekunden > 0
    }
    guard !title.isEmpty, hook.count >= 12, desc.count >= 50, !scenes.isEmpty else {
      throw Fehler.ungueltigesJSON
    }

    let anchors = relevanteWoerter("\(chance.titel) \(chance.thema)")
    let combined = "\(title) \(hook) \(dto.skript) \(desc)".lowercased()
    let hits = anchors.filter { combined.contains($0) }.count
    guard anchors.isEmpty || hits >= min(2, anchors.count) else { throw Fehler.ungueltigesJSON }

    let mapped = scenes.map {
      ProduktionsSzene(
        titel: String($0.titel.prefix(80)),
        narration: $0.narration.trimmingCharacters(in: .whitespacesAndNewlines),
        visualDirection: $0.visualDirection.trimmingCharacters(in: .whitespacesAndNewlines),
        dauerSekunden: max(2.5, min($0.dauerSekunden, format == .short ? 12 : 45)))
    }
    let script = dto.skript.trimmingCharacters(in: .whitespacesAndNewlines)
    let normalizedScript =
      script.count >= (format == .short ? 120 : 320)
      ? script
      : ([hook] + mapped.map(\.narration)).joined(separator: "\n\n")

    var tags: [String] = []
    for raw in dto.tags + [chance.thema] {
      let t = String(raw.trimmingCharacters(in: .whitespacesAndNewlines).prefix(30))
      if !t.isEmpty && !tags.contains(where: { $0.caseInsensitiveCompare(t) == .orderedSame }) {
        tags.append(t)
      }
      if tags.count >= 12 { break }
    }

    return ProduktionsPaket(
      titel: title,
      hook: hook,
      skript: normalizedScript,
      beschreibung: desc,
      tags: tags,
      thumbnailText: String(
        dto.thumbnailText.trimmingCharacters(in: .whitespacesAndNewlines).prefix(60)),
      szenen: mapped)
  }

  private static func relevanteWoerter(_ text: String) -> [String] {
    let stop = Set([
      "dieser", "diese", "dieses", "warum", "jetzt", "neue", "neuer", "neues", "über", "oder",
      "eine", "einer", "eines", "the", "und", "mit",
    ])
    return text.lowercased().split { !$0.isLetter && !$0.isNumber }
      .map(String.init).filter { $0.count >= 4 && !stop.contains($0) }
  }

  private static func jsonObjekt(aus text: String) -> String {
    var cleaned = text.trimmingCharacters(in: .whitespacesAndNewlines)
    if cleaned.hasPrefix("```json") {
      cleaned.removeFirst(7)
    } else if cleaned.hasPrefix("```") {
      cleaned.removeFirst(3)
    }
    if cleaned.hasSuffix("```") { cleaned.removeLast(3) }
    if let first = cleaned.firstIndex(of: "{"), let last = cleaned.lastIndex(of: "}"), first <= last
    {
      return String(cleaned[first...last])
    }
    return cleaned
  }
}
