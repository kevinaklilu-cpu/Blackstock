#if canImport(CryptoKit)
import CryptoKit
#endif
import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

actor RemoteMediaCacheService {
  static let shared = RemoteMediaCacheService()

  enum CacheError: LocalizedError {
    case invalidSource
    case rightsBlocked(String)
    case insufficientDiskSpace
    case invalidServerResponse(Int)
    case rangeNotSupported
    case cancelled
    case unsafePath

    var errorDescription: String? {
      switch self {
      case .invalidSource: return "Die Remote-Quelle besitzt keine gültige HTTPS-Mediendatei."
      case .rightsBlocked(let detail): return "Quelle blockiert: \(detail)"
      case .insufficientDiskSpace: return "Für die Remote-Mediendatei steht nicht genügend freier Speicher zur Verfügung."
      case .invalidServerResponse(let code): return "Remote-Mediendownload fehlgeschlagen (HTTP \(code))."
      case .rangeNotSupported: return "Der Server unterstützt keinen sicheren fortsetzbaren Download."
      case .cancelled: return "Download wurde abgebrochen."
      case .unsafePath: return "Unsicherer Cache-Pfad wurde blockiert."
      }
    }
  }

  struct Progress: Sendable, Hashable {
    var received: Int64
    var expected: Int64?
    var fraction: Double? {
      guard let expected, expected > 0 else { return nil }
      return min(1, Double(received) / Double(expected))
    }
  }

  private let fm = FileManager.default
  private let chunkSize: Int64 = 8 * 1024 * 1024
  private var cancelledAssets = Set<UUID>()
  private var activePartialPaths = Set<String>()

  private func root() throws -> URL {
    let base = fm.urls(for: .cachesDirectory, in: .userDomainMask).first
      ?? fm.homeDirectoryForCurrentUser.appendingPathComponent("Library/Caches", isDirectory: true)
    let folder = base.appendingPathComponent("Blackstock/RemoteMedia", isDirectory: true)
    try fm.createDirectory(at: folder, withIntermediateDirectories: true)
    return folder.standardizedFileURL
  }

  func cancel(assetID: UUID) { cancelledAssets.insert(assetID) }

  func cachedURL(for asset: SourceAsset) throws -> URL? {
    if let expiresAt = asset.expiresAt, expiresAt <= Date() { return nil }
    guard let checksum = asset.checksumSHA256, !checksum.isEmpty else { return nil }
    let candidate = try root().appendingPathComponent(checksum).appendingPathExtension("media")
    try assertManaged(candidate, root: try root())
    return fm.fileExists(atPath: candidate.path) ? candidate : nil
  }

  func fetch(
    asset: SourceAsset,
    connector: any SourceConnectorProtocol,
    progress: (@Sendable (Progress) -> Void)? = nil
  ) async throws -> (url: URL, checksum: String) {
    if let reason = RightsService.blockingReason(asset) { throw CacheError.rightsBlocked(reason) }
    if let cached = try cachedURL(for: asset), let checksum = asset.checksumSHA256 {
      return (cached, checksum)
    }
    let remote = try await connector.downloadURL(for: asset)
    guard remote.scheme?.lowercased() == "https" else { throw CacheError.invalidSource }

    cancelledAssets.remove(asset.id)
    let cacheRoot = try root()
    let partial = cacheRoot.appendingPathComponent(asset.id.uuidString + ".part")
    try assertManaged(partial, root: cacheRoot)
    activePartialPaths.insert(partial.standardizedFileURL.path)
    defer { activePartialPaths.remove(partial.standardizedFileURL.path) }
    if !fm.fileExists(atPath: partial.path) {
      _ = fm.createFile(atPath: partial.path, contents: nil)
    }
    let existing = ((try? fm.attributesOfItem(atPath: partial.path)[.size]) as? NSNumber)?.int64Value ?? 0

    let expected = try await remoteSize(remote)
    if let expected {
      try ensureDiskSpace(requiredAdditionalBytes: max(0, expected - existing), at: cacheRoot)
      if existing > expected { try fm.removeItem(at: partial); _ = fm.createFile(atPath: partial.path, contents: nil) }
    }

    var offset = min(existing, expected ?? existing)
    let handle = try FileHandle(forWritingTo: partial)
    defer { try? handle.close() }
    try handle.seek(toOffset: UInt64(offset))
    progress?(Progress(received: offset, expected: expected))

    if let expected {
      while offset < expected {
        if cancelledAssets.contains(asset.id) { throw CacheError.cancelled }
        let end = min(expected - 1, offset + chunkSize - 1)
        var request = URLRequest(url: remote)
        request.setValue("bytes=\(offset)-\(end)", forHTTPHeaderField: "Range")
        request.timeoutInterval = 60
        let (temporary, response) = try await URLSession.shared.download(for: request)
        guard let http = response as? HTTPURLResponse else { throw CacheError.invalidServerResponse(-1) }
        if http.statusCode == 200 && offset == 0 {
          // Server ignored Range. URLSession downloaded to a temporary file, so even a large
          // media object was never materialized as one Data value in RAM.
          try? handle.close()
          let actual = ((try? fm.attributesOfItem(atPath: temporary.path)[.size]) as? NSNumber)?.int64Value ?? -1
          guard actual == expected else { throw CacheError.rangeNotSupported }
          if fm.fileExists(atPath: partial.path) { try fm.removeItem(at: partial) }
          try fm.moveItem(at: temporary, to: partial)
          offset = expected
          progress?(Progress(received: offset, expected: expected))
          break
        }
        guard http.statusCode == 206 else { throw CacheError.invalidServerResponse(http.statusCode) }
        guard let confirmedRange = Self.contentRange(http), confirmedRange.start == offset else {
          throw CacheError.rangeNotSupported
        }
        let actual = ((try? fm.attributesOfItem(atPath: temporary.path)[.size]) as? NSNumber)?.int64Value ?? -1
        guard confirmedRange.end >= confirmedRange.start,
          actual == confirmedRange.end - confirmedRange.start + 1
        else { throw CacheError.rangeNotSupported }
        let chunk = try FileHandle(forReadingFrom: temporary)
        defer { try? chunk.close() }
        while let data = try chunk.read(upToCount: 4 * 1024 * 1024), !data.isEmpty {
          try handle.write(contentsOf: data)
        }
        try? fm.removeItem(at: temporary)
        offset = confirmedRange.end + 1
        progress?(Progress(received: offset, expected: expected))
      }
    } else {
      // Unknown size: use one streamed URLSession download to avoid holding an unbounded file in RAM.
      try? handle.close()
      let (temporary, response) = try await URLSession.shared.download(from: remote)
      guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
        throw CacheError.invalidServerResponse((response as? HTTPURLResponse)?.statusCode ?? -1)
      }
      if fm.fileExists(atPath: partial.path) { try fm.removeItem(at: partial) }
      try fm.moveItem(at: temporary, to: partial)
    }

    let checksum = try sha256(of: partial)
    let final = cacheRoot.appendingPathComponent(checksum).appendingPathExtension("media")
    try assertManaged(final, root: cacheRoot)
    if fm.fileExists(atPath: final.path) {
      try? fm.removeItem(at: partial)
    } else {
      try fm.moveItem(at: partial, to: final)
    }
    cancelledAssets.remove(asset.id)
    return (final, checksum)
  }

  func cleanup(maxBytes: Int64, preserving preservedPaths: Set<String> = []) throws {
    let cacheRoot = try root()
    let urls = try fm.contentsOfDirectory(
      at: cacheRoot,
      includingPropertiesForKeys: [.contentModificationDateKey, .fileSizeKey, .isRegularFileKey],
      options: [.skipsHiddenFiles])
    var entries: [(URL, Date, Int64)] = []
    for url in urls {
      try assertManaged(url, root: cacheRoot)
      let standardized = url.standardizedFileURL.path
      guard !preservedPaths.contains(standardized), !activePartialPaths.contains(standardized) else { continue }
      let values = try url.resourceValues(forKeys: [.contentModificationDateKey, .fileSizeKey, .isRegularFileKey])
      guard values.isRegularFile == true else { continue }
      entries.append((url, values.contentModificationDate ?? .distantPast, Int64(values.fileSize ?? 0)))
    }
    var total = entries.reduce(0) { $0 + $1.2 }
    guard total > maxBytes else {
      // Still remove stale partials older than 24 hours.
      for (url, date, _) in entries where url.pathExtension == "part" && Date().timeIntervalSince(date) > 86_400 {
        try? fm.removeItem(at: url)
      }
      return
    }
    for (url, _, size) in entries.sorted(by: { $0.1 < $1.1 }) {
      guard total > maxBytes else { break }
      try fm.removeItem(at: url)
      total -= size
    }
  }

  private func remoteSize(_ url: URL) async throws -> Int64? {
    var request = URLRequest(url: url)
    request.httpMethod = "HEAD"
    request.timeoutInterval = 20
    let (_, response) = try await URLSession.shared.data(for: request)
    guard let http = response as? HTTPURLResponse else { return nil }
    if http.statusCode == 405 || http.statusCode == 403 { return nil }
    guard (200..<400).contains(http.statusCode) else { throw CacheError.invalidServerResponse(http.statusCode) }
    return http.value(forHTTPHeaderField: "Content-Length").flatMap(Int64.init)
  }

  private static func contentRange(_ response: HTTPURLResponse) -> (start: Int64, end: Int64, total: Int64?)? {
    guard let raw = response.value(forHTTPHeaderField: "Content-Range") else { return nil }
    // Expected: bytes START-END/TOTAL (TOTAL may be *).
    let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
    guard value.lowercased().hasPrefix("bytes ") else { return nil }
    let payload = value.dropFirst(6)
    let parts = payload.split(separator: "/", maxSplits: 1).map(String.init)
    guard parts.count == 2 else { return nil }
    let rangeParts = parts[0].split(separator: "-", maxSplits: 1).compactMap { Int64($0) }
    guard rangeParts.count == 2 else { return nil }
    let total = parts[1] == "*" ? nil : Int64(parts[1])
    return (rangeParts[0], rangeParts[1], total)
  }

  private func ensureDiskSpace(requiredAdditionalBytes: Int64, at url: URL) throws {
    guard requiredAdditionalBytes > 0 else { return }
    let attributes = try fm.attributesOfFileSystem(forPath: url.path)
    guard let free = (attributes[.systemFreeSize] as? NSNumber)?.int64Value else { return }
    let safetyReserve: Int64 = 512 * 1024 * 1024
    if free < requiredAdditionalBytes + safetyReserve {
      throw CacheError.insufficientDiskSpace
    }
  }

  private func sha256(of url: URL) throws -> String {
#if canImport(CryptoKit)
    let handle = try FileHandle(forReadingFrom: url)
    defer { try? handle.close() }
    var hasher = SHA256()
    while autoreleasepool(invoking: {
      let data = try? handle.read(upToCount: 4 * 1024 * 1024)
      guard let data, !data.isEmpty else { return false }
      hasher.update(data: data)
      return true
    }) {}
    return hasher.finalize().map { String(format: "%02x", $0) }.joined()
#else
    // Blackstock ships as a macOS app where CryptoKit is available. Keeping the
    // unsupported-platform branch explicit lets the portable CI type-check the
    // complete cache service instead of silently excluding it.
    throw CacheError.invalidSource
#endif
  }

  private func assertManaged(_ url: URL, root: URL) throws {
    let candidate = url.standardizedFileURL.resolvingSymlinksInPath().path
    let managed = root.standardizedFileURL.resolvingSymlinksInPath().path
    guard candidate == managed || candidate.hasPrefix(managed + "/") else { throw CacheError.unsafePath }
  }
}
