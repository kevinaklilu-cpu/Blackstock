import Foundation

final class PersistenceService {
  static let shared = PersistenceService()

  enum PersistenceError: LocalizedError {
    case unsafeWorkingPath

    var errorDescription: String? {
      switch self {
      case .unsafeWorkingPath:
        return "Der angeforderte Arbeitsordner liegt außerhalb des Blackstock-Datenbereichs."
      }
    }
  }

  private let encoder: JSONEncoder = {
    let e = JSONEncoder()
    e.outputFormatting = [.prettyPrinted, .sortedKeys]
    e.dateEncodingStrategy = .iso8601
    return e
  }()

  private let decoder: JSONDecoder = {
    let d = JSONDecoder()
    d.dateDecodingStrategy = .iso8601
    return d
  }()

  private var appFolder: URL {
    let base =
      FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
      ?? FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent(
        "Library/Application Support", isDirectory: true)
    return base.appendingPathComponent("Blackstock", isDirectory: true)
  }

  func arbeitsordner(_ name: String) throws -> URL {
    guard !name.isEmpty, !name.hasPrefix("/") else { throw PersistenceError.unsafeWorkingPath }
    let root = appFolder.standardizedFileURL
    let folder = root.appendingPathComponent(name, isDirectory: true).standardizedFileURL
    let rootPath = root.path.hasSuffix("/") ? root.path : root.path + "/"
    guard folder.path.hasPrefix(rootPath), !name.split(separator: "/").contains("..") else {
      throw PersistenceError.unsafeWorkingPath
    }
    try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
    let resolvedRoot = root.resolvingSymlinksInPath().path
    let resolvedFolder = folder.resolvingSymlinksInPath().path
    let resolvedPrefix = resolvedRoot.hasSuffix("/") ? resolvedRoot : resolvedRoot + "/"
    guard resolvedFolder == resolvedRoot || resolvedFolder.hasPrefix(resolvedPrefix) else {
      throw PersistenceError.unsafeWorkingPath
    }
    return folder
  }

  private var stateURL: URL { appFolder.appendingPathComponent("state.json") }
  private var backupURL: URL { appFolder.appendingPathComponent("state.backup.json") }
  private var corruptURL: URL { appFolder.appendingPathComponent("state.corrupt.json") }
  private var migrationBackupURL: URL { appFolder.appendingPathComponent("state.v10.pre-v11.json") }

  func laden() -> AppZustand? {
    guard FileManager.default.fileExists(atPath: stateURL.path) else {
      guard let backup = ladeBackup() else { return nil }
      _ = speichern(backup)
      return backup
    }
    do {
      let data = try Data(contentsOf: stateURL)
      let decoded = try decoder.decode(AppZustand.self, from: data)
      if decoded.v11 == nil && !FileManager.default.fileExists(atPath: migrationBackupURL.path) {
        // One immutable pre-v11 snapshot before AppStore normalizes/migrates the state.
        try? FileManager.default.copyItem(at: stateURL, to: migrationBackupURL)
      }
      return decoded
    } catch {
      print("Blackstock: Zustand konnte nicht geladen werden: \(error)")
      sichereBeschaedigtenZustand()
      if let backup = ladeBackup() {
        try? FileManager.default.removeItem(at: stateURL)
        _ = speichern(backup)
        print("Blackstock: Backup-Zustand wurde wiederhergestellt.")
        return backup
      }
      return nil
    }
  }

  private func ladeBackup() -> AppZustand? {
    guard FileManager.default.fileExists(atPath: backupURL.path) else { return nil }
    do {
      let data = try Data(contentsOf: backupURL)
      return try decoder.decode(AppZustand.self, from: data)
    } catch {
      print("Blackstock: Backup konnte nicht geladen werden: \(error)")
      return nil
    }
  }

  @discardableResult
  func speichern(_ state: AppZustand) -> Bool {
    do {
      try FileManager.default.createDirectory(at: appFolder, withIntermediateDirectories: true)
      let data = try encoder.encode(state)

      if FileManager.default.fileExists(atPath: stateURL.path) {
        try? FileManager.default.removeItem(at: backupURL)
        try? FileManager.default.copyItem(at: stateURL, to: backupURL)
      }

      try data.write(to: stateURL, options: [.atomic])
      return true
    } catch {
      print("Blackstock: Zustand konnte nicht gespeichert werden: \(error)")
      return false
    }
  }

  func zuruecksetzen() {
    try? FileManager.default.removeItem(at: stateURL)
    try? FileManager.default.removeItem(at: backupURL)
    try? FileManager.default.removeItem(at: corruptURL)
    try? FileManager.default.removeItem(at: migrationBackupURL)
  }

  private func sichereBeschaedigtenZustand() {
    guard FileManager.default.fileExists(atPath: stateURL.path) else { return }
    try? FileManager.default.removeItem(at: corruptURL)
    try? FileManager.default.copyItem(at: stateURL, to: corruptURL)
  }
}
