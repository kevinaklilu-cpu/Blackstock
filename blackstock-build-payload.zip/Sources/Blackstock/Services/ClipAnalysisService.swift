import Foundation

struct ClipCandidate: Identifiable, Hashable {
  var id = UUID()
  var sourceAssetID: UUID
  var start: Double
  var end: Double
  var score: Double
  var reason: String
  var transcriptExcerpt: String?
  var duration: Double { max(0, end - start) }
}

final class ClipAnalysisService {
  func analyze(_ asset: SourceAsset, targetFormat: VideoFormat) -> [ClipCandidate] {
    guard let duration = asset.duration, duration > 1 else { return [] }
    let transcript = asset.transcript?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    let target: Double = targetFormat == .short ? min(55, duration) : min(150, duration)
    let window: Double = targetFormat == .short ? min(18, max(6, duration / 4)) : min(45, max(15, duration / 5))
    let step = max(3, window * 0.65)

    let sentences = transcript
      .split(whereSeparator: { ".!?\n".contains($0) })
      .map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }
      .filter { !$0.isEmpty }
    let hookWords = ["warum", "jetzt", "neu", "erstmals", "wichtig", "entscheidend", "aber", "überrasch", "zeigt", "problem", "ergebnis", "breaking"]

    var candidates: [ClipCandidate] = []
    var start: Double = 0
    var index = 0
    while start < duration && candidates.count < 24 {
      let end = min(duration, start + window)
      let sentence = sentences.isEmpty ? nil : sentences[index % sentences.count]
      let lower = sentence?.lowercased() ?? ""
      let keywordHits = hookWords.filter(lower.contains).count
      let positionBonus = start < duration * 0.18 ? 12.0 : 0
      let transcriptBonus = min(25, Double(keywordHits) * 7 + (sentence == nil ? 0 : 5))
      let durationFit = max(0, 20 - abs((end - start) - min(window, target / 3)))
      let score = min(100, 45 + positionBonus + transcriptBonus + durationFit)
      candidates.append(
        ClipCandidate(
          sourceAssetID: asset.id,
          start: start,
          end: end,
          score: score,
          reason: keywordHits > 0 ? "Relevante Aussage/Hook im Transkript" : "Gute Dauer- und Positionspassung",
          transcriptExcerpt: sentence
        ))
      start += step
      index += 1
    }
    return candidates.sorted { $0.score > $1.score }
  }
}
