import Foundation

#if canImport(FoundationNetworking)
  import FoundationNetworking
#endif

final class CreatorAIService {
  static let shared = CreatorAIService()

  enum AIServiceFehler: LocalizedError {
    case nichtKonfiguriert
    case ungueltigeURL
    case http(Int, String)
    case ungueltigeAntwort(String)

    var errorDescription: String? {
      switch self {
      case .nichtKonfiguriert:
        "Recherche-/Text-Engine ist noch nicht eingerichtet. Öffne Einstellungen → Creator Engines."
      case .ungueltigeURL: "Die konfigurierte AI-Base-URL ist ungültig."
      case .http(let code, let text): "AI-Engine antwortet mit HTTP \(code): \(text)"
      case .ungueltigeAntwort(let detail):
        "Die AI-Engine hat kein gültiges Produktionspaket geliefert: \(detail)"
      }
    }
  }

  private struct ChatMessage: Encodable {
    let role: String
    let content: String
  }

  private struct ChatRequest: Encodable {
    struct ResponseFormat: Encodable { let type: String }
    let model: String
    let messages: [ChatMessage]
    let responseFormat: ResponseFormat

    enum CodingKeys: String, CodingKey {
      case model, messages
      case responseFormat = "response_format"
    }
  }

  private struct ChatResponse: Decodable {
    struct Choice: Decodable {
      struct Message: Decodable { let content: String? }
      let message: Message
    }
    let choices: [Choice]
  }

  private struct PaketDTO: Decodable {
    struct SzeneDTO: Decodable {
      let titel: String
      let narration: String
      let visualDirection: String
      let dauerSekunden: Double
    }
    let titel: String
    let hook: String
    let skript: String
    let beschreibung: String
    let tags: [String]
    let thumbnailText: String
    let szenen: [SzeneDTO]
  }

  func produktionsPaket(
    chance: Chance,
    kanal: Kanal,
    format: VideoFormat,
    modus: Produktionsmodus,
    provider: ProviderVerbindung,
    apiKey: String
  ) async throws -> ProduktionsPaket {
    guard let basis = provider.basisURL?.trimmingCharacters(in: .whitespacesAndNewlines),
      let modell = provider.modell?.trimmingCharacters(in: .whitespacesAndNewlines),
      !basis.isEmpty, !modell.isEmpty, !apiKey.isEmpty
    else { throw AIServiceFehler.nichtKonfiguriert }

    let formatHinweis: String =
      switch format {
      case .short: "9:16 Short, 30–60 Sekunden, sofortige Hook, hohe Informationsdichte"
      case .longform: "16:9 Langvideo, klare Kapitel, Belege und Spannungsbogen"
      case .serie:
        "Serienfolge mit eigenständigem Payoff und Anschlussfähigkeit an weitere Episoden"
      case .livestream: "Livestream-Konzept mit Segmenten, Moderationspunkten und Interaktion"
      }

    let system = """
      Du bist die redaktionelle Engine von Blackstock. Ziel ist eine hochwertige, eigenständige YouTube-Produktion – kein generischer AI-Massencontent. Bleibe strikt beim gelieferten VIDEO-THEMA und der konkreten Kernstory. Titel, Hook, Skript, Beschreibung, Thumbnail-Text und jede einzelne Szene müssen dieselbe Story erzählen. Nutze Marktsignale ausschließlich als Themenhinweis, niemals als Faktenbeleg. Unsichere Tatsachenbehauptungen müssen im Skript mit [VERIFY] markiert werden. Schreibe natürlich, präzise, abwechslungsreich und mit konkretem Payoff. Vermeide erfundene Quellen, leere Superlative, künstliche AI-Floskeln, Wiederholungen und Clickbait ohne Einlösung. Die Beschreibung muss genau dieses Video zusammenfassen und darf kein generischer Kanaltext sein. Jede Szene braucht eine visuelle Funktion, die direkt zur gesprochenen Narration passt. Für News und Politik neutral formulieren und bestätigte Information, Einordnung und offene Punkte klar trennen.
      """

    let user = """
      KANAL
      Name: \(kanal.name)
      Thema: \(kanal.thema)
      Handle: \(kanal.handle)

      VIDEO-THEMA / CHANCE
      Titel: \(chance.titel)
      Thema: \(chance.thema)
      Trend Score: \(Int(chance.trendScore))
      Vertrauen: \(Int(chance.konfidenz * 100))%
      Risiko: \(chance.risiko.rawValue)
      Begründung: \(chance.begruendung)

      PRODUKTION
      Format: \(formatHinweis)
      Qualitätsmodus: \(modus.rawValue) – \(modus.beschreibung)

      Qualitätsregeln:
      - Die Beschreibung besteht aus 2 kurzen, konkreten Absätzen und sagt, was Zuschauer in genau diesem Video erfahren.
      - Jede Szene zahlt sichtbar auf VIDEO-THEMA und Kernstory ein; keine austauschbaren Standard-Szenen.
      - Das Skript spiegelt die Szenen in derselben Reihenfolge.
      - visualDirection beschreibt genau das Motiv, das zur narration passt.
      - News/Politik: neutral, bestätigte Fakten von Interpretation und offenen Punkten trennen.
      - Gaming: Mechanik, Gameplay, Update, Vergleich oder beobachtbares Feature konkretisieren.
      - Keine erfundenen Fakten. Unsicheres mit [VERIFY] markieren.
      """

    let adapter = provider.optionen?["adapter"] ?? "openai-chat"
    let rawContent: String
    if adapter == "openai-responses" {
      rawContent = try await openAIResponses(
        basis: basis, modell: modell, system: system, user: user, apiKey: apiKey)
    } else {
      rawContent = try await chatCompletions(
        basis: basis, modell: modell, system: system, user: user, apiKey: apiKey)
    }

    return try validierenUndBauen(
      rawContent: rawContent, chance: chance, format: format)
  }

  private func openAIResponses(
    basis: String, modell: String, system: String, user: String, apiKey: String
  ) async throws -> String {
    let base = basis.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    guard let endpoint = URL(string: base.hasSuffix("/responses") ? base : base + "/responses")
    else { throw AIServiceFehler.ungueltigeURL }

    let schema: [String: Any] = [
      "type": "object",
      "properties": [
        "titel": ["type": "string"],
        "hook": ["type": "string"],
        "skript": ["type": "string"],
        "beschreibung": ["type": "string"],
        "tags": ["type": "array", "items": ["type": "string"]],
        "thumbnailText": ["type": "string"],
        "szenen": [
          "type": "array",
          "items": [
            "type": "object",
            "properties": [
              "titel": ["type": "string"],
              "narration": ["type": "string"],
              "visualDirection": ["type": "string"],
              "dauerSekunden": ["type": "number"],
            ],
            "required": ["titel", "narration", "visualDirection", "dauerSekunden"],
            "additionalProperties": false,
          ],
        ],
      ],
      "required": [
        "titel", "hook", "skript", "beschreibung", "tags", "thumbnailText", "szenen",
      ],
      "additionalProperties": false,
    ]

    let payload: [String: Any] = [
      "model": modell,
      "instructions": system,
      "input": user,
      "store": false,
      "text": [
        "format": [
          "type": "json_schema",
          "name": "blackstock_production_package",
          "strict": true,
          "schema": schema,
        ]
      ],
    ]

    var request = URLRequest(url: endpoint)
    request.httpMethod = "POST"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
    request.httpBody = try JSONSerialization.data(withJSONObject: payload)
    request.timeoutInterval = 120

    let (data, response) = try await URLSession.shared.data(for: request)
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
      let code = (response as? HTTPURLResponse)?.statusCode ?? -1
      let body = String(data: data, encoding: .utf8) ?? "Unbekannter Fehler"
      throw AIServiceFehler.http(code, String(body.prefix(1000)))
    }
    guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
      throw AIServiceFehler.ungueltigeAntwort("Responses-Antwort konnte nicht gelesen werden")
    }
    if let direct = object["output_text"] as? String,
      !direct.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    {
      return direct
    }
    if let output = object["output"] as? [[String: Any]] {
      for item in output {
        guard let content = item["content"] as? [[String: Any]] else { continue }
        for part in content where (part["type"] as? String) == "output_text" {
          if let text = part["text"] as? String,
            !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
          {
            return text
          }
        }
      }
    }
    throw AIServiceFehler.ungueltigeAntwort("Responses API lieferte keinen Text")
  }

  private func chatCompletions(
    basis: String, modell: String, system: String, user: String, apiKey: String
  ) async throws -> String {
    let endpointString =
      basis.hasSuffix("/chat/completions")
      ? basis : basis.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/chat/completions"
    guard let endpoint = URL(string: endpointString) else { throw AIServiceFehler.ungueltigeURL }
    let payload = ChatRequest(
      model: modell,
      messages: [
        ChatMessage(role: "system", content: system), ChatMessage(role: "user", content: user),
      ],
      responseFormat: .init(type: "json_object"))
    var request = URLRequest(url: endpoint)
    request.httpMethod = "POST"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
    request.httpBody = try JSONEncoder().encode(payload)
    request.timeoutInterval = 90
    let (data, response) = try await URLSession.shared.data(for: request)
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
      let code = (response as? HTTPURLResponse)?.statusCode ?? -1
      let body = String(data: data, encoding: .utf8) ?? "Unbekannter Fehler"
      throw AIServiceFehler.http(code, String(body.prefix(800)))
    }
    let chat = try JSONDecoder().decode(ChatResponse.self, from: data)
    guard let text = chat.choices.first?.message.content,
      !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    else { throw AIServiceFehler.ungueltigeAntwort("Antwort war leer") }
    return text
  }

  private func validierenUndBauen(
    rawContent: String, chance: Chance, format: VideoFormat
  ) throws -> ProduktionsPaket {
    let content = extrahiereJSONObject(aus: rawContent)
    guard let jsonData = content.data(using: .utf8) else {
      throw AIServiceFehler.ungueltigeAntwort("Antwort konnte nicht als UTF-8 gelesen werden")
    }
    let dto: PaketDTO
    do { dto = try JSONDecoder().decode(PaketDTO.self, from: jsonData) } catch {
      throw AIServiceFehler.ungueltigeAntwort(
        "JSON-Struktur stimmt nicht mit dem Blackstock-Produktionsschema überein")
    }

    let titel = String(dto.titel.trimmingCharacters(in: .whitespacesAndNewlines).prefix(100))
    let hook = dto.hook.trimmingCharacters(in: .whitespacesAndNewlines)
    let skript = dto.skript.trimmingCharacters(in: .whitespacesAndNewlines)
    let beschreibung = dto.beschreibung.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !titel.isEmpty else { throw AIServiceFehler.ungueltigeAntwort("Titel fehlt") }
    guard hook.count >= 12 else {
      throw AIServiceFehler.ungueltigeAntwort("Hook ist zu kurz oder fehlt")
    }
    let minSkriptZeichen = format == .short ? 120 : 350
    guard skript.count >= minSkriptZeichen else {
      throw AIServiceFehler.ungueltigeAntwort("Skript ist für das gewählte Format zu kurz")
    }
    guard beschreibung.count >= 60 else {
      throw AIServiceFehler.ungueltigeAntwort("Beschreibung ist zu kurz oder zu generisch")
    }

    let valideSzenen = dto.szenen.filter {
      !$0.titel.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        && !$0.narration.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        && !$0.visualDirection.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        && $0.dauerSekunden > 0
    }
    guard !valideSzenen.isEmpty else {
      throw AIServiceFehler.ungueltigeAntwort(
        "Szenenplan fehlt oder enthält keine verwendbaren Szenen")
    }

    let anchors = relevanteWoerter("\(chance.titel) \(chance.thema)")
    let textCombined = "\(titel) \(hook) \(skript) \(beschreibung)".lowercased()
    let mainHits = anchors.filter { textCombined.contains($0) }.count
    guard anchors.isEmpty || mainHits >= min(2, anchors.count) else {
      throw AIServiceFehler.ungueltigeAntwort("Text weicht zu stark vom gewählten Thema ab")
    }
    let alignedScenes = valideSzenen.filter { scene in
      let sceneText = "\(scene.titel) \(scene.narration) \(scene.visualDirection)".lowercased()
      return anchors.isEmpty || anchors.contains(where: { sceneText.contains($0) })
    }
    let requiredAligned = min(
      valideSzenen.count, max(1, Int(ceil(Double(valideSzenen.count) * 0.6))))
    guard alignedScenes.count >= requiredAligned else {
      throw AIServiceFehler.ungueltigeAntwort("Zu viele Szenen weichen vom gewählten Thema ab")
    }

    var tagBudget = 0
    var tags: [String] = []
    for raw in dto.tags {
      let tag = String(raw.trimmingCharacters(in: .whitespacesAndNewlines).prefix(30))
      guard !tag.isEmpty else { continue }
      if tagBudget + tag.count > 420 { break }
      if !tags.contains(where: { $0.caseInsensitiveCompare(tag) == .orderedSame }) {
        tags.append(tag)
        tagBudget += tag.count
      }
    }

    return ProduktionsPaket(
      titel: titel,
      hook: hook,
      skript: skript,
      beschreibung: beschreibung,
      tags: tags,
      thumbnailText: String(
        dto.thumbnailText.trimmingCharacters(in: .whitespacesAndNewlines).prefix(80)),
      szenen: valideSzenen.map {
        ProduktionsSzene(
          titel: $0.titel, narration: $0.narration, visualDirection: $0.visualDirection,
          dauerSekunden: $0.dauerSekunden)
      })
  }

  private func relevanteWoerter(_ text: String) -> [String] {
    let stop = Set([
      "dieser", "diese", "dieses", "warum", "jetzt", "neue", "neuer", "neues", "über", "oder",
      "eine", "einer", "eines", "the", "und", "mit",
    ])
    return text.lowercased().split { !$0.isLetter && !$0.isNumber }
      .map(String.init).filter { $0.count >= 4 && !stop.contains($0) }
  }

  private func extrahiereJSONObject(aus text: String) -> String {
    var cleaned = text.trimmingCharacters(in: .whitespacesAndNewlines)
    if cleaned.hasPrefix("```json") {
      cleaned.removeFirst(7)
    } else if cleaned.hasPrefix("```") {
      cleaned.removeFirst(3)
    }
    if cleaned.hasSuffix("```") { cleaned.removeLast(3) }
    cleaned = cleaned.trimmingCharacters(in: .whitespacesAndNewlines)
    if let first = cleaned.firstIndex(of: "{"), let last = cleaned.lastIndex(of: "}"), first <= last
    {
      return String(cleaned[first...last])
    }
    return cleaned
  }
}
