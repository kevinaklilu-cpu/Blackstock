import AVFoundation
import Foundation

final class MediaProbeService {
  static let shared = MediaProbeService()

  enum ProbeError: LocalizedError {
    case missingFile
    case invalidDuration
    case noVideoTrack

    var errorDescription: String? {
      switch self {
      case .missingFile: "Die Mediendatei existiert nicht mehr."
      case .invalidDuration: "Die Mediendatei besitzt keine gültige Videodauer."
      case .noVideoTrack: "Die Mediendatei besitzt keine Videospur."
      }
    }
  }

  func duration(of url: URL) async throws -> Double {
    try await inspect(url).duration
  }

  func inspect(_ url: URL) async throws -> RenderValidation {
    guard FileManager.default.fileExists(atPath: url.path) else { throw ProbeError.missingFile }
    let asset = AVURLAsset(url: url)
    let duration = try await asset.load(.duration)
    let seconds = CMTimeGetSeconds(duration)
    guard seconds.isFinite, seconds > 0 else { throw ProbeError.invalidDuration }

    guard let video = try await asset.loadTracks(withMediaType: .video).first else {
      throw ProbeError.noVideoTrack
    }
    let natural = try await video.load(.naturalSize)
    let preferred = try await video.load(.preferredTransform)
    let rect = CGRect(origin: .zero, size: natural).applying(preferred)
    let width = Int(abs(rect.width).rounded())
    let height = Int(abs(rect.height).rounded())
    let hasAudio = !(try await asset.loadTracks(withMediaType: .audio)).isEmpty
    let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
    let fileSize = (attributes[.size] as? NSNumber)?.int64Value ?? 0

    return RenderValidation(
      duration: seconds,
      width: width,
      height: height,
      hasVideo: true,
      hasAudio: hasAudio,
      fileSize: fileSize,
      validatedAt: Date())
  }
}
