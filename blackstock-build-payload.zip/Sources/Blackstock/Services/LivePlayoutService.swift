import Foundation

@MainActor
final class LivePlayoutService {
  static let shared = LivePlayoutService()

  enum PlayoutError: LocalizedError {
    case ffmpegMissing
    case noMedia
    case invalidRTMPTarget
    case launchFailed(String)
    case ingestNotConfirmed

    var errorDescription: String? {
      switch self {
      case .ffmpegMissing:
        return "Live Playout benötigt eine lokal installierte FFmpeg-Version (Homebrew: brew install ffmpeg). Blackstock verteilt FFmpeg nicht mit."
      case .noMedia: return "Für das Live Playout fehlt eine rights-cleared Medienplaylist."
      case .invalidRTMPTarget: return "Das YouTube-RTMP-Ziel ist ungültig."
      case .launchFailed(let detail): return "FFmpeg-Live-Playout konnte nicht gestartet werden: \(detail)"
      case .ingestNotConfirmed: return "FFmpeg hat innerhalb des Startfensters keine tatsächlich gesendeten Frames bestätigt."
      }
    }
  }

  private struct Session {
    var process: Process
    var playlistURL: URL
    var progressURL: URL
    var stopRequested: Bool
  }

  private var sessions: [UUID: Session] = [:]

  var ffmpegURL: URL? {
    let candidates = [
      "/opt/homebrew/bin/ffmpeg",
      "/usr/local/bin/ffmpeg",
      "/opt/local/bin/ffmpeg",
      "/usr/bin/ffmpeg",
    ]
    return candidates.map(URL.init(fileURLWithPath:)).first {
      FileManager.default.isExecutableFile(atPath: $0.path)
    }
  }

  var isAvailable: Bool { ffmpegURL != nil }

  func isRunning(productionID: UUID) -> Bool {
    sessions[productionID]?.process.isRunning == true
  }

  func start(
    productionID: UUID,
    mediaURLs: [URL],
    rtmpTarget: String,
    loop: Bool,
    onTermination: @escaping @Sendable (_ exitCode: Int32, _ requested: Bool) -> Void
  ) async throws {
    guard sessions[productionID]?.process.isRunning != true else { return }
    guard let executable = ffmpegURL else { throw PlayoutError.ffmpegMissing }
    let existing = mediaURLs.filter { FileManager.default.fileExists(atPath: $0.path) }
    guard !existing.isEmpty else { throw PlayoutError.noMedia }
    guard let target = URL(string: rtmpTarget), ["rtmp", "rtmps"].contains(target.scheme?.lowercased() ?? "") else {
      throw PlayoutError.invalidRTMPTarget
    }

    let folder = try PersistenceService.shared.arbeitsordner("Live/\(productionID.uuidString)")
    let playlist = folder.appendingPathComponent("playlist.ffconcat")
    let progress = folder.appendingPathComponent("ffmpeg-progress.txt")
    try? FileManager.default.removeItem(at: progress)

    var text = "ffconcat version 1.0\n"
    for url in existing {
      // Cached Blackstock paths are generated internally and contain no user-controlled shell syntax.
      let escaped = url.path.replacingOccurrences(of: "'", with: "\\'")
      text += "file '\(escaped)'\n"
    }
    try text.data(using: .utf8)?.write(to: playlist, options: .atomic)

    let process = Process()
    process.executableURL = executable
    var arguments = ["-hide_banner", "-nostdin", "-loglevel", "warning", "-re"]
    if loop { arguments += ["-stream_loop", "-1"] }
    arguments += [
      "-f", "concat", "-safe", "0", "-i", playlist.path,
      "-map", "0:v:0", "-map", "0:a:0?",
      "-c:v", "libx264", "-preset", "veryfast", "-tune", "zerolatency",
      "-pix_fmt", "yuv420p", "-r", "30", "-g", "60",
      "-c:a", "aac", "-b:a", "160k", "-ar", "44100",
      "-f", "flv",
      "-progress", progress.path, "-nostats",
      rtmpTarget,
    ]
    process.arguments = arguments
    process.standardOutput = FileHandle.nullDevice
    process.standardError = FileHandle.nullDevice

    process.terminationHandler = { [weak self] finished in
      Task { @MainActor in
        guard let self else { return }
        let requested = self.sessions[productionID]?.stopRequested ?? false
        self.sessions.removeValue(forKey: productionID)
        try? FileManager.default.removeItem(at: progress)
        onTermination(finished.terminationStatus, requested)
      }
    }

    do { try process.run() }
    catch { throw PlayoutError.launchFailed(error.localizedDescription) }
    sessions[productionID] = Session(
      process: process, playlistURL: playlist, progressURL: progress, stopRequested: false)

    // Do not claim "Live" until ffmpeg reports at least one processed frame while
    // the RTMP process remains alive. Connection failures normally terminate before this.
    let deadline = Date().addingTimeInterval(15)
    while Date() < deadline {
      try Task.checkCancellation()
      guard process.isRunning else {
        throw PlayoutError.launchFailed("Der Encoder wurde beendet, bevor YouTube-Ingest bestätigt werden konnte.")
      }
      if let data = try? Data(contentsOf: progress),
        let raw = String(data: data, encoding: .utf8),
        raw.split(separator: "\n").contains(where: { line in
          guard line.hasPrefix("frame=") else { return false }
          return Int(line.dropFirst("frame=".count)) ?? 0 > 0
        })
      {
        return
      }
      try await Task.sleep(nanoseconds: 250_000_000)
    }

    stop(productionID: productionID)
    throw PlayoutError.ingestNotConfirmed
  }

  func stop(productionID: UUID) {
    guard var session = sessions[productionID] else { return }
    session.stopRequested = true
    sessions[productionID] = session
    if session.process.isRunning { session.process.terminate() }
  }
}
