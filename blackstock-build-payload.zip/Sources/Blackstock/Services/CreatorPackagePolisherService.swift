import Foundation

enum CreatorPackagePolisherService {
  static func normalisieren(
    _ paket: ProduktionsPaket,
    chance: Chance,
    kanal: Kanal,
    format: VideoFormat
  ) -> ProduktionsPaket {
    let topic = chance.thema.trimmingCharacters(in: .whitespacesAndNewlines)
    let subject = chance.titel.trimmingCharacters(in: .whitespacesAndNewlines)
    let anchors = relevanteWoerter("\(subject) \(topic)")

    var title = String(paket.titel.trimmingCharacters(in: .whitespacesAndNewlines).prefix(100))
    if title.isEmpty { title = String((subject.isEmpty ? topic : subject).prefix(100)) }

    var hook = paket.hook.trimmingCharacters(in: .whitespacesAndNewlines)
    if hook.count < 12 {
      hook =
        "Warum \(subject.isEmpty ? topic : subject) gerade relevant ist – und was wirklich dahintersteckt."
    }

    var script = paket.skript.trimmingCharacters(in: .whitespacesAndNewlines)
    if !enthaeltAnker(script, anchors: anchors), !subject.isEmpty {
      script = "In diesem Video geht es konkret um \(subject).\n\n" + script
    }

    let description: String = {
      let original = paket.beschreibung.trimmingCharacters(in: .whitespacesAndNewlines)
      let genericMarkers = [
        "auf diesem kanal", "blackstock", "willkommen", "in diesem spannenden video",
        "vergiss nicht zu abonnieren", "like und abonnieren",
      ]
      let isGeneric = genericMarkers.contains { original.lowercased().contains($0) }
      let aligned = enthaeltAnker(original, anchors: anchors)
      if original.count >= 90 && aligned && !isGeneric { return original }

      let focus = subject.isEmpty ? topic : subject
      let first =
        "In diesem Video geht es konkret um \(focus). Wir erklären die wichtigsten Zusammenhänge, zeigen den relevanten Kontext und trennen belegbare Informationen klar von offenen Punkten."
      let second: String
      switch format {
      case .short:
        second =
          "Du bekommst die Kernaussage kompakt und ohne Umwege – passend zum Thema \(topic.isEmpty ? focus : topic)."
      case .longform, .serie:
        second =
          "Wir gehen Schritt für Schritt durch die entscheidenden Aspekte rund um \(topic.isEmpty ? focus : topic), damit du Ursache, Bedeutung und mögliche Folgen nachvollziehen kannst."
      case .livestream:
        second =
          "Der Stream ordnet neue Entwicklungen rund um \(topic.isEmpty ? focus : topic) laufend ein und kennzeichnet unbestätigte Punkte ausdrücklich als offen."
      }
      return "\(first)\n\n\(second)"
    }()

    let thumbnail = thumbnailText(
      paket.thumbnailText.trimmingCharacters(in: .whitespacesAndNewlines),
      fallback: subject.isEmpty ? title : subject)

    let tags = tagsNormalisieren(
      paket.tags,
      zusaetzlich: [topic, kanal.thema, format.rawValue] + anchors)

    let scenes = paket.szenen.enumerated().map { index, scene in
      var narration = scene.narration.trimmingCharacters(in: .whitespacesAndNewlines)
      if narration.isEmpty {
        narration = "Wir ordnen den nächsten Punkt zu \(subject.isEmpty ? topic : subject) ein."
      }
      var visual = scene.visualDirection.trimmingCharacters(in: .whitespacesAndNewlines)
      if visual.isEmpty {
        visual =
          "Editoriale Szene passend zu \(subject.isEmpty ? topic : subject), ohne Text oder fremde Logos."
      } else if !enthaeltAnker(visual, anchors: anchors), !topic.isEmpty {
        visual = "Zum Thema \(topic): \(visual)"
      }
      let sceneTitle =
        scene.titel.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        ? "Szene \(index + 1)" : scene.titel
      return ProduktionsSzene(
        titel: sceneTitle,
        narration: narration,
        visualDirection: visual,
        dauerSekunden: max(1.5, scene.dauerSekunden))
    }

    return ProduktionsPaket(
      titel: title,
      hook: hook,
      skript: script,
      beschreibung: description,
      tags: tags,
      thumbnailText: thumbnail,
      szenen: scenes)
  }

  private static func thumbnailText(_ value: String, fallback: String) -> String {
    let source = value.isEmpty ? fallback : value
    let words =
      source
      .replacingOccurrences(of: "·", with: " ")
      .split { !$0.isLetter && !$0.isNumber }
      .map(String.init)
      .filter { !$0.isEmpty }
    let selected = Array(words.prefix(4))
    let result = selected.joined(separator: " ")
    return String((result.isEmpty ? "JETZT WICHTIG" : result).uppercased().prefix(42))
  }

  private static func tagsNormalisieren(_ source: [String], zusaetzlich: [String]) -> [String] {
    var result: [String] = []
    var budget = 0
    for raw in source + zusaetzlich {
      let cleaned = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        .replacingOccurrences(of: "#", with: "")
      guard !cleaned.isEmpty else { continue }
      let tag = String(cleaned.prefix(30))
      guard !result.contains(where: { $0.caseInsensitiveCompare(tag) == .orderedSame }) else {
        continue
      }
      if budget + tag.count > 420 { break }
      result.append(tag)
      budget += tag.count
    }
    return Array(result.prefix(18))
  }

  private static func enthaeltAnker(_ text: String, anchors: [String]) -> Bool {
    if anchors.isEmpty { return true }
    let lower = text.lowercased()
    return anchors.contains { lower.contains($0) }
  }

  private static func relevanteWoerter(_ text: String) -> [String] {
    let stop = Set([
      "dieser", "diese", "dieses", "warum", "jetzt", "neue", "neuer", "neues", "über", "oder",
      "eine", "einer", "eines", "the", "und", "mit", "für", "von", "aus", "wird", "werden",
    ])
    return text.lowercased().split { !$0.isLetter && !$0.isNumber }
      .map(String.init)
      .filter { $0.count >= 4 && !stop.contains($0) }
  }
}
