import Foundation
import Network

final class OAuthLoopbackServer {
  enum ServerFehler: LocalizedError {
    case konnteNichtStarten(String)
    case keineAntwort
    case abgebrochen(String)

    var errorDescription: String? {
      switch self {
      case .konnteNichtStarten(let detail):
        return "Lokale OAuth-Rückgabe konnte nicht gestartet werden: \(detail)"
      case .keineAntwort:
        return "Google hat keine verwertbare OAuth-Antwort an Blackstock zurückgegeben."
      case .abgebrochen(let detail): return "Google-Anmeldung wurde nicht abgeschlossen: \(detail)"
      }
    }
  }

  private let queue = DispatchQueue(label: "de.blackstock.oauth.loopback", qos: .userInitiated)
  private var listener: NWListener?
  private var resultContinuation: CheckedContinuation<String, Error>?
  private var pendingResult: Result<String, Error>?
  private var readyContinuation: CheckedContinuation<UInt16, Error>?
  private var hasFinished = false
  private var expectedState: String?
  private var timeoutWorkItem: DispatchWorkItem?

  func start(expectedState: String) async throws -> UInt16 {
    self.expectedState = expectedState
    let listener = try NWListener(using: .tcp, on: .any)
    self.listener = listener

    listener.newConnectionHandler = { [weak self] connection in
      self?.handle(connection: connection)
    }

    return try await withCheckedThrowingContinuation { continuation in
      self.readyContinuation = continuation
      listener.stateUpdateHandler = { [weak self] state in
        guard let self else { return }
        switch state {
        case .ready:
          if let port = listener.port?.rawValue, let continuation = self.readyContinuation {
            self.readyContinuation = nil
            continuation.resume(returning: port)
          }
        case .failed(let error):
          if let continuation = self.readyContinuation {
            self.readyContinuation = nil
            continuation.resume(
              throwing: ServerFehler.konnteNichtStarten(error.localizedDescription))
          } else {
            self.finish(.failure(ServerFehler.konnteNichtStarten(error.localizedDescription)))
          }
        case .cancelled:
          if let continuation = self.readyContinuation {
            self.readyContinuation = nil
            continuation.resume(
              throwing: ServerFehler.konnteNichtStarten("Listener wurde beendet."))
          }
        default:
          break
        }
      }
      listener.start(queue: queue)
    }
  }

  func waitForCode(timeout: TimeInterval = 180) async throws -> String {
    if let pendingResult {
      self.pendingResult = nil
      return try pendingResult.get()
    }
    return try await withCheckedThrowingContinuation { continuation in
      self.resultContinuation = continuation
      let work = DispatchWorkItem { [weak self] in
        self?.finish(
          .failure(
            ServerFehler.abgebrochen("Zeitlimit überschritten. Starte die Google-Anmeldung erneut.")
          ))
      }
      self.timeoutWorkItem = work
      self.queue.asyncAfter(deadline: .now() + timeout, execute: work)
    }
  }

  func stop() {
    listener?.cancel()
    listener = nil
  }

  private func handle(connection: NWConnection) {
    connection.start(queue: queue)
    connection.receive(minimumIncompleteLength: 1, maximumLength: 32_768) {
      [weak self] data, _, _, error in
      guard let self else { return }
      if let error {
        self.finish(.failure(ServerFehler.konnteNichtStarten(error.localizedDescription)))
        connection.cancel()
        return
      }
      guard let data,
        let request = String(data: data, encoding: .utf8),
        let firstLine = request.components(separatedBy: "\r\n").first
      else {
        self.finish(.failure(ServerFehler.keineAntwort))
        connection.cancel()
        return
      }

      let parts = firstLine.split(separator: " ")
      guard parts.count >= 2 else {
        self.finish(.failure(ServerFehler.keineAntwort))
        connection.cancel()
        return
      }

      let target = String(parts[1])
      let comps = URLComponents(string: "http://127.0.0.1\(target)")
      let code = comps?.queryItems?.first(where: { $0.name == "code" })?.value
      let returnedState = comps?.queryItems?.first(where: { $0.name == "state" })?.value
      let oauthError = comps?.queryItems?.first(where: { $0.name == "error" })?.value
      let description = comps?.queryItems?.first(where: { $0.name == "error_description" })?.value

      if let expectedState = self.expectedState, returnedState != expectedState {
        let body =
          "<html><body style='font-family:-apple-system;background:#111;color:#fff;padding:40px'><h2>Ungültige OAuth-Antwort.</h2><p>Bitte starte die Verbindung erneut aus Blackstock.</p></body></html>"
        let response =
          "HTTP/1.1 400 Bad Request\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: \(body.utf8.count)\r\nConnection: close\r\n\r\n\(body)"
        connection.send(
          content: response.data(using: .utf8),
          completion: .contentProcessed { _ in connection.cancel() })
        self.finish(.failure(ServerFehler.abgebrochen("OAuth-State stimmt nicht überein.")))
        return
      }

      let success = code != nil
      let body =
        success
        ? """
        <html><head><meta charset='utf-8'><title>Blackstock</title></head>
        <body style='margin:0;background:#080a0c;color:#f3f4ef;font-family:-apple-system;padding:56px'>
        <div style='max-width:560px;margin:auto'>
        <div style='font-size:13px;letter-spacing:1.4px;color:#97db63;font-weight:700'>BLACKSTOCK</div>
        <h1 style='font-size:28px;margin:12px 0'>Verbindung hergestellt.</h1>
        <p style='color:#9ba0a5;line-height:1.6'>Du kannst dieses Fenster schließen. Blackstock übernimmt ab hier.</p>
        </div></body></html>
        """
        : """
        <html><head><meta charset='utf-8'><title>Blackstock</title></head>
        <body style='margin:0;background:#080a0c;color:#f3f4ef;font-family:-apple-system;padding:56px'>
        <div style='max-width:560px;margin:auto'>
        <div style='font-size:13px;letter-spacing:1.4px;color:#efaa4a;font-weight:700'>BLACKSTOCK</div>
        <h1 style='font-size:28px;margin:12px 0'>Verbindung nicht abgeschlossen.</h1>
        <p style='color:#9ba0a5;line-height:1.6'>Kehre zu Blackstock zurück. Dort siehst du den nächsten Schritt.</p>
        </div></body></html>
        """
      let response =
        "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: \(body.utf8.count)\r\nConnection: close\r\n\r\n\(body)"
      connection.send(
        content: response.data(using: .utf8),
        completion: .contentProcessed { _ in
          connection.cancel()
        })

      if let code {
        self.finish(.success(code))
      } else {
        self.finish(
          .failure(ServerFehler.abgebrochen(description ?? oauthError ?? "Login abgebrochen")))
      }
    }
  }

  private func finish(_ result: Result<String, Error>) {
    guard !hasFinished else { return }
    hasFinished = true
    timeoutWorkItem?.cancel()
    timeoutWorkItem = nil
    listener?.cancel()
    if let continuation = resultContinuation {
      resultContinuation = nil
      continuation.resume(with: result)
    } else {
      pendingResult = result
    }
  }
}
