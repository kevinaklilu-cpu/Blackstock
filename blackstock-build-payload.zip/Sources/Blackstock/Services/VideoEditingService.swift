import AVFoundation
import CoreGraphics
import Foundation

final class VideoEditingService {
  static let shared = VideoEditingService()

  enum RenderFehler: LocalizedError {
    case keineClips
    case dateiFehlt(String)
    case keineVideospur(String)
    case exportNichtVerfuegbar
    case mp4NichtUnterstuetzt
    case exportFehlgeschlagen(String)

    var errorDescription: String? {
      switch self {
      case .keineClips: "Wähle mindestens einen echten Video-Clip für den Rohschnitt aus."
      case .dateiFehlt(let name):
        "Der Clip „\(name)“ wurde verschoben oder gelöscht. Importiere ihn erneut."
      case .keineVideospur(let name): "\(name) enthält keine Videospur."
      case .exportNichtVerfuegbar: "Der lokale Videoexport konnte nicht gestartet werden."
      case .mp4NichtUnterstuetzt:
        "Der gewählte Quellmix kann auf diesem Mac nicht direkt als MP4 exportiert werden. Konvertiere problematische Clips zuerst in H.264/H.265."
      case .exportFehlgeschlagen(let text): "Lokaler Render fehlgeschlagen: \(text)"
      }
    }
  }

  func rohSchnitt(clips: [URL], format: VideoFormat, ziel: URL) async throws -> URL {
    guard !clips.isEmpty else { throw RenderFehler.keineClips }
    for clip in clips where !FileManager.default.fileExists(atPath: clip.path) {
      throw RenderFehler.dateiFehlt(clip.lastPathComponent)
    }

    try FileManager.default.createDirectory(
      at: ziel.deletingLastPathComponent(), withIntermediateDirectories: true)
    let composition = AVMutableComposition()
    guard
      let compositionVideo = composition.addMutableTrack(
        withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid)
    else {
      throw RenderFehler.exportNichtVerfuegbar
    }
    let compositionAudio = composition.addMutableTrack(
      withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)

    var cursor = CMTime.zero
    var segments: [(track: AVAssetTrack, range: CMTimeRange, start: CMTime)] = []

    for clip in clips {
      let asset = AVURLAsset(url: clip)
      let duration = try await asset.load(.duration)
      let sekunden = CMTimeGetSeconds(duration)
      guard duration.isValid, sekunden.isFinite, sekunden > 0 else {
        throw RenderFehler.exportFehlgeschlagen(
          "\(clip.lastPathComponent) hat keine gültige Dauer.")
      }
      guard let videoTrack = try await asset.loadTracks(withMediaType: .video).first else {
        throw RenderFehler.keineVideospur(clip.lastPathComponent)
      }

      let range = CMTimeRange(start: .zero, duration: duration)
      try compositionVideo.insertTimeRange(range, of: videoTrack, at: cursor)
      if let audioTrack = try await asset.loadTracks(withMediaType: .audio).first {
        let audioDuration = try await asset.load(.duration)
        let audioRange = CMTimeRange(start: .zero, duration: min(duration, audioDuration))
        try compositionAudio?.insertTimeRange(audioRange, of: audioTrack, at: cursor)
      }
      segments.append((videoTrack, range, cursor))
      cursor = CMTimeAdd(cursor, duration)
    }

    let renderSize: CGSize
    switch format {
    case .short:
      renderSize = CGSize(width: 1080, height: 1920)
    case .longform, .serie, .livestream:
      renderSize = CGSize(width: 1920, height: 1080)
    }

    let videoComposition = AVMutableVideoComposition()
    videoComposition.renderSize = renderSize
    videoComposition.frameDuration = CMTime(value: 1, timescale: 30)

    var instructions: [AVVideoCompositionInstructionProtocol] = []
    for segment in segments {
      let instruction = AVMutableVideoCompositionInstruction()
      instruction.timeRange = CMTimeRange(start: segment.start, duration: segment.range.duration)
      let layer = AVMutableVideoCompositionLayerInstruction(assetTrack: compositionVideo)

      let naturalSize = try await segment.track.load(.naturalSize)
      let preferred = try await segment.track.load(.preferredTransform)
      let transformedRect = CGRect(origin: .zero, size: naturalSize).applying(preferred)
      let orientedSize = CGSize(
        width: abs(transformedRect.width), height: abs(transformedRect.height))
      guard orientedSize.width > 0, orientedSize.height > 0 else {
        throw RenderFehler.exportFehlgeschlagen("Ein Clip meldet eine ungültige Bildgröße.")
      }

      let scale = max(
        renderSize.width / orientedSize.width, renderSize.height / orientedSize.height)
      let scaledSize = CGSize(
        width: orientedSize.width * scale, height: orientedSize.height * scale)
      let centerX = (renderSize.width - scaledSize.width) / 2
      let centerY = (renderSize.height - scaledSize.height) / 2

      var transform = preferred
      transform = transform.concatenating(
        CGAffineTransform(translationX: -transformedRect.minX, y: -transformedRect.minY))
      transform = transform.concatenating(CGAffineTransform(scaleX: scale, y: scale))
      transform = transform.concatenating(CGAffineTransform(translationX: centerX, y: centerY))
      layer.setTransform(transform, at: segment.start)
      instruction.layerInstructions = [layer]
      instructions.append(instruction)
    }
    videoComposition.instructions = instructions

    try? FileManager.default.removeItem(at: ziel)
    guard
      let exporter = AVAssetExportSession(
        asset: composition, presetName: AVAssetExportPresetHighestQuality)
    else {
      throw RenderFehler.exportNichtVerfuegbar
    }
    guard exporter.supportedFileTypes.contains(.mp4) else {
      throw RenderFehler.mp4NichtUnterstuetzt
    }

    exporter.outputURL = ziel
    exporter.outputFileType = .mp4
    exporter.shouldOptimizeForNetworkUse = true
    exporter.videoComposition = videoComposition

    await withCheckedContinuation { continuation in
      exporter.exportAsynchronously { continuation.resume() }
    }

    switch exporter.status {
    case .completed:
      guard FileManager.default.fileExists(atPath: ziel.path) else {
        throw RenderFehler.exportFehlgeschlagen("Export wurde beendet, aber die Zieldatei fehlt.")
      }
      return ziel
    case .failed, .cancelled:
      throw RenderFehler.exportFehlgeschlagen(
        exporter.error?.localizedDescription ?? "Unbekannter Exportfehler")
    default:
      throw RenderFehler.exportFehlgeschlagen(
        exporter.error?.localizedDescription ?? "Export wurde nicht abgeschlossen")
    }
  }
}
