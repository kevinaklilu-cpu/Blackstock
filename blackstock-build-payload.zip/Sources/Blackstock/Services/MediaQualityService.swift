import AVFoundation
import AppKit
import Foundation

struct MedienPruefung {
  var score: Double
  var videoScore: Double
  var audioScore: Double
  var status: String
  var details: [String]
}

final class MediaQualityService {
  static let shared = MediaQualityService()

  func videoPruefen(url: URL, erwartetesFormat: VideoFormat? = nil) async -> MedienPruefung {
    guard FileManager.default.fileExists(atPath: url.path) else {
      return MedienPruefung(
        score: 0, videoScore: 0, audioScore: 0, status: "Fehler",
        details: ["Datei wurde nicht gefunden"])
    }

    let asset = AVURLAsset(url: url)
    var details: [String] = []
    var videoPoints = 100.0
    var audioPoints = 94.0

    do {
      let duration = try await asset.load(.duration)
      let videoTracks = try await asset.loadTracks(withMediaType: .video)
      let audioTracks = try await asset.loadTracks(withMediaType: .audio)
      guard let video = videoTracks.first else {
        return MedienPruefung(
          score: 0, videoScore: 0, audioScore: audioTracks.isEmpty ? 0 : 100, status: "Blockiert",
          details: ["Keine Videospur gefunden"])
      }

      let naturalSize = try await video.load(.naturalSize)
      let transform = try await video.load(.preferredTransform)
      let transformedRect = CGRect(origin: .zero, size: naturalSize).applying(transform)
      let width = abs(transformedRect.width)
      let height = abs(transformedRect.height)
      let fps = Double(try await video.load(.nominalFrameRate))
      let seconds = CMTimeGetSeconds(duration)
      let ratio = width / max(height, 1)

      details.append("Auflösung: \(Int(width)) × \(Int(height))")
      details.append("Bildrate: \(String(format: "%.1f", fps)) fps")
      details.append("Dauer: \(seconds.isFinite ? String(format: "%.1f", seconds) : "unbekannt") s")
      details.append(audioTracks.isEmpty ? "Keine Audiospur" : "Audiospur vorhanden")

      if width < 720 || height < 720 {
        videoPoints -= 35
        details.append("Auflösung ist deutlich zu niedrig")
      } else if max(width, height) < 1080 {
        videoPoints -= 20
        details.append("Auflösung liegt unter dem Blackstock-Studiostandard")
      }

      if fps > 0 && fps < 23.5 {
        videoPoints -= 15
        details.append("Bildrate liegt unter 24 fps")
      }

      if !seconds.isFinite || seconds <= 0 {
        videoPoints -= 50
        details.append("Videodauer ist ungültig")
      }

      if let erwartetesFormat {
        switch erwartetesFormat {
        case .short:
          let target = 9.0 / 16.0
          if abs(ratio - target) > 0.05 {
            videoPoints -= 22
            details.append("Short erwartet 9:16 – aktuelles Verhältnis weicht ab")
          }
          if seconds.isFinite && seconds > 180 {
            videoPoints -= 12
            details.append("Short ist länger als 180 Sekunden")
          }
        case .longform, .serie, .livestream:
          let target = 16.0 / 9.0
          if abs(ratio - target) > 0.08 {
            videoPoints -= 12
            details.append("16:9-Ausgabe empfohlen – aktuelles Verhältnis weicht ab")
          }
        }
      }

      if audioTracks.isEmpty {
        audioPoints = 0
        details.append("Audio-Gate offen: keine Audiospur")
      } else if let audio = audioTracks.first {
        let formatDescriptions = try await audio.load(.formatDescriptions)
        let bitRate = Double(try await audio.load(.estimatedDataRate))
        details.append("Audio-Datenrate: \(Int(bitRate / 1000)) kbit/s")
        if formatDescriptions.isEmpty {
          audioPoints -= 8
          details.append("Audioformat konnte nicht vollständig geprüft werden")
        }
        if bitRate > 0 && bitRate < 64_000 {
          audioPoints -= 25
          details.append("Audio-Datenrate ist für hochwertige Sprach-/Musikwiedergabe sehr niedrig")
        } else if bitRate > 0 && bitRate < 96_000 {
          audioPoints -= 14
          details.append("Audio-Datenrate liegt unter dem Studiostandard")
        } else if bitRate > 0 && bitRate < 128_000 {
          audioPoints -= 6
          details.append("Audio-Datenrate ist brauchbar, aber nicht optimal")
        }
        if audioTracks.count > 1 { details.append("Mehrere Audiospuren erkannt") }
      }
    } catch {
      return MedienPruefung(
        score: 0, videoScore: 0, audioScore: 0, status: "Fehler",
        details: [error.localizedDescription])
    }

    videoPoints = max(0, min(100, videoPoints))
    audioPoints = max(0, min(100, audioPoints))
    let overall = audioPoints > 0 ? (videoPoints * 0.72 + audioPoints * 0.28) : videoPoints * 0.75
    let status: String
    if overall >= 90 && videoPoints >= 90 && audioPoints >= 85 {
      status = "Bestanden"
    } else if overall >= 75 {
      status = "Prüfen"
    } else {
      status = "Blockiert"
    }

    return MedienPruefung(
      score: max(0, min(100, overall)), videoScore: videoPoints, audioScore: audioPoints,
      status: status, details: details)
  }

  func thumbnailPruefen(url: URL) -> MedienPruefung {
    guard FileManager.default.fileExists(atPath: url.path), let image = NSImage(contentsOf: url)
    else {
      return MedienPruefung(
        score: 0, videoScore: 0, audioScore: 0, status: "Fehler",
        details: ["Bild konnte nicht geöffnet werden"])
    }

    let pixelSize: NSSize = {
      if let rep = image.representations.compactMap({ $0 as? NSBitmapImageRep }).first {
        return NSSize(width: rep.pixelsWide, height: rep.pixelsHigh)
      }
      if let tiff = image.tiffRepresentation, let rep = NSBitmapImageRep(data: tiff) {
        return NSSize(width: rep.pixelsWide, height: rep.pixelsHigh)
      }
      return image.size
    }()

    let width = Double(pixelSize.width)
    let height = Double(pixelSize.height)
    let ratio = width / max(height, 1)
    var points = 100.0
    var details = ["Pixelgröße: \(Int(width)) × \(Int(height))"]

    if width < 1280 || height < 720 {
      points -= 25
      details.append("Thumbnail liegt unter 1280 × 720 Pixel")
    }
    if abs(ratio - (16.0 / 9.0)) > 0.08 {
      points -= 15
      details.append("Seitenverhältnis weicht deutlich von 16:9 ab")
    }
    if width > 8_000 || height > 8_000 {
      points -= 5
      details.append("Sehr große Quelldatei – vor Upload optimieren")
    }

    points = max(0, min(100, points))
    return MedienPruefung(
      score: points, videoScore: points, audioScore: 100,
      status: points >= 90 ? "Bestanden" : (points >= 75 ? "Prüfen" : "Blockiert"), details: details
    )
  }
}
