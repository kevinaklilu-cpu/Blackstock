import Foundation

#if canImport(FoundationNetworking)
  import FoundationNetworking
#endif

actor CloudImageService {
  static let shared = CloudImageService()

  enum ImageFehler: LocalizedError {
    case nichtKonfiguriert
    case ungueltigeURL
    case http(Int, String)
    case antwort

    var errorDescription: String? {
      switch self {
      case .nichtKonfiguriert: "Premium-Bildengine ist nicht vollständig eingerichtet."
      case .ungueltigeURL: "Die Bildengine-URL ist ungültig."
      case .http(let code, let text): "Bildengine antwortet mit HTTP \(code): \(text)"
      case .antwort: "Die Bildengine hat kein verwendbares Bild geliefert."
      }
    }
  }

  private struct OpenAIRequest: Encodable {
    let model: String
    let prompt: String
    let size: String
    let quality: String
    let n: Int
  }

  private struct OpenAIResponse: Decodable {
    struct Item: Decodable {
      let b64JSON: String?
      let url: String?

      enum CodingKeys: String, CodingKey {
        case b64JSON = "b64_json"
        case url
      }
    }
    let data: [Item]
  }

  func generieren(
    prompt: String, provider: ProviderVerbindung, apiKey: String, ziel: URL
  ) async throws -> URL {
    guard let basis = provider.basisURL, let model = provider.modell, !apiKey.isEmpty else {
      throw ImageFehler.nichtKonfiguriert
    }
    guard
      let endpoint = URL(
        string: basis.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
          + "/images/generations")
    else { throw ImageFehler.ungueltigeURL }

    var request = URLRequest(url: endpoint)
    request.httpMethod = "POST"
    request.timeoutInterval = 180
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
    request.httpBody = try JSONEncoder().encode(
      OpenAIRequest(
        model: model,
        prompt: String(prompt.trimmingCharacters(in: .whitespacesAndNewlines).prefix(30_000)),
        size: "1536x1024", quality: "high", n: 1))

    let (data, response) = try await URLSession.shared.data(for: request)
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
      let code = (response as? HTTPURLResponse)?.statusCode ?? -1
      let text = String(data: data, encoding: .utf8) ?? "Unbekannter Fehler"
      throw ImageFehler.http(code, String(text.prefix(700)))
    }
    let decoded = try JSONDecoder().decode(OpenAIResponse.self, from: data)
    guard let item = decoded.data.first else { throw ImageFehler.antwort }
    let bytes: Data
    if let b64 = item.b64JSON, let decodedData = Data(base64Encoded: b64) {
      bytes = decodedData
    } else if let rawURL = item.url, let remote = URL(string: rawURL) {
      let (downloaded, downloadResponse) = try await URLSession.shared.data(from: remote)
      guard let dHTTP = downloadResponse as? HTTPURLResponse, (200..<300).contains(dHTTP.statusCode)
      else {
        throw ImageFehler.antwort
      }
      bytes = downloaded
    } else {
      throw ImageFehler.antwort
    }
    guard !bytes.isEmpty else { throw ImageFehler.antwort }
    try FileManager.default.createDirectory(
      at: ziel.deletingLastPathComponent(), withIntermediateDirectories: true)
    try bytes.write(to: ziel, options: .atomic)
    return ziel
  }
}
