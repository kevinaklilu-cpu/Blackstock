import Foundation

enum LocalCreatorService {
  private enum ThemenArt {
    case gaming, politikNews, techAI, finanzen, business, sport, creator, wissen, wissenschaft
    case gesundheit, mobilitaet, lifestyle, entertainment, allgemein
  }

  static func produktionsPaket(
    chance: Chance, kanal: Kanal, format: VideoFormat, modus: Produktionsmodus
  ) -> ProduktionsPaket {
    let thema = chance.thema.trimmingCharacters(in: .whitespacesAndNewlines)
    let kern = chance.titel.trimmingCharacters(in: .whitespacesAndNewlines)
    let topic = thema.isEmpty ? (kern.isEmpty ? kanal.thema : kern) : thema
    let art = kategorisieren("\(topic) \(kern) \(kanal.thema)")
    let hook = hookFuer(art: art, kern: kern.isEmpty ? topic : kern, thema: topic)
    let sceneCount: Int = format == .short ? 7 : (format == .livestream ? 9 : 11)
    let seconds: Double = format == .short ? 6.5 : (format == .livestream ? 45 : 22)

    let blueprints = szenenBlueprints(art: art, kern: kern.isEmpty ? topic : kern, thema: topic)
    let scenes = (0..<sceneCount).map { index -> ProduktionsSzene in
      let b = blueprints[index % blueprints.count]
      return ProduktionsSzene(
        titel: b.0,
        narration: b.1,
        visualDirection: b.2,
        dauerSekunden: seconds)
    }

    let body = scenes.map(\.narration).joined(separator: "\n\n")
    let conclusion: String = {
      switch art {
      case .politikNews:
        return
          "Fazit: Entscheidend ist, bestätigte Informationen von Interpretation zu trennen und neue Entwicklungen erst nach Verifikation einzuordnen."
      case .gaming:
        return
          "Fazit: Entscheidend ist nicht der Hype, sondern ob sich der beobachtbare Spielmoment, die Mechanik oder das Update im echten Gameplay bestätigt."
      default:
        return
          "Fazit: Entscheidend ist, was sich aus dem Thema konkret ableiten lässt und welche Punkte vor Veröffentlichung noch verifiziert werden müssen."
      }
    }()

    let title = String((kern.isEmpty ? "\(topic): Das steckt dahinter" : kern).prefix(100))
    let description = beschreibungFuer(art: art, titel: title, thema: topic, kanal: kanal)
    let tags = relevanteTags(art: art, thema: topic, kanal: kanal, format: format)

    return ProduktionsPaket(
      titel: title,
      hook: hook,
      skript: "\(hook)\n\n\(body)\n\n\(conclusion)",
      beschreibung: description,
      tags: tags,
      thumbnailText: thumbnailTextFuer(art: art, thema: topic, kern: kern),
      szenen: scenes)
  }

  private static func kategorisieren(_ text: String) -> ThemenArt {
    let t = text.lowercased()
    func has(_ words: [String]) -> Bool { words.contains { t.contains($0) } }
    if has([
      "gaming", "game", "spiel", "gta", "fortnite", "minecraft", "playstation", "xbox", "nintendo",
      "steam", "esport",
    ]) {
      return .gaming
    }
    if has([
      "politik", "wahl", "bundestag", "regierung", "partei", "minister", "präsident", "kanzler",
      "news", "breaking", "meldung", "nato", "eu ",
    ]) {
      return .politikNews
    }
    if has([
      "ki", " ai ", "apple", "google", "openai", "chip", "software", "hardware", "tech",
      "smartphone", "computer",
    ]) {
      return .techAI
    }
    if has([
      "aktie", "börse", "finanz", "geld", "bitcoin", "krypto", "etf", "wirtschaft",
    ]) {
      return .finanzen
    }
    if has(["business", "startup", "unternehmen", "gründer", "e-commerce", "marketing", "sales"]) {
      return .business
    }
    if has([
      "sport", "fußball", "fussball", "nba", "nfl", "tennis", "formel 1", "bundesliga",
      "champions league",
    ]) {
      return .sport
    }
    if has([
      "youtube", "creator", "thumbnail", "shorts", "tiktok", "instagram", "podcast", "content",
    ]) {
      return .creator
    }
    if has(["wissenschaft", "forschung", "physik", "biologie", "weltraum", "studie"]) {
      return .wissenschaft
    }
    if has(["gesundheit", "fitness", "training", "ernährung", "wellness", "sportmedizin"]) {
      return .gesundheit
    }
    if has(["auto", "elektroauto", "mobilität", "fahrzeug", "tesla", "bmw", "mercedes", "porsche"])
    {
      return .mobilitaet
    }
    if has([
      "reise", "urlaub", "hotel", "flug", "food", "essen", "kochen", "rezept", "restaurant",
      "lifestyle",
    ]) {
      return .lifestyle
    }
    if has(["wissen", "geschichte", "erklärt", "erklaert", "doku", "fakten"]) {
      return .wissen
    }
    if has(["film", "serie", "musik", "promi", "celebrity", "kino", "streaming"]) {
      return .entertainment
    }
    return .allgemein
  }

  private static func hookFuer(art: ThemenArt, kern: String, thema: String) -> String {
    switch art {
    case .gaming:
      return
        "\(kern) sorgt gerade für Aufmerksamkeit – aber was davon ist im Spiel wirklich sichtbar und warum ist das für Spieler relevant?"
    case .politikNews:
      return
        "\(kern): Was ist daran bestätigt, was ist Einordnung und welche Punkte sind für das Verständnis wirklich wichtig?"
    case .techAI:
      return
        "\(kern) klingt nach dem nächsten großen Tech-Thema – entscheidend ist aber, was sich technisch tatsächlich verändert."
    case .finanzen:
      return
        "Bei \(kern) zählt nicht die Schlagzeile, sondern welche Mechanik dahintersteht und welche Risiken man verstehen muss."
    case .business:
      return
        "\(kern) klingt nach einer Business-Story – entscheidend ist, welches Problem gelöst wird, wie das Modell funktioniert und wo die echte Substanz liegt."
    case .sport:
      return
        "\(kern) ist das Signal – spannend wird es dort, wo Leistung, Kontext und die nächste Entwicklung zusammenkommen."
    case .creator:
      return
        "\(kern) wird gerade viel diskutiert – wir schauen darauf, was davon für echte Creator-Performance wirklich relevant ist."
    case .wissen:
      return
        "\(kern) wirkt auf den ersten Blick einfach – der interessante Teil steckt im Zusammenhang dahinter."
    case .wissenschaft:
      return
        "Bei \(kern) zählt nicht die spektakulärste Überschrift, sondern was untersucht wurde, was das Ergebnis wirklich zeigt und wo die Grenzen liegen."
    case .gesundheit:
      return
        "\(kern) betrifft Gesundheit oder Fitness – wir trennen praktische Orientierung von unbelegten Versprechen und ordnen den konkreten Nutzen ein."
    case .mobilitaet:
      return
        "\(kern) ist mehr als ein neues Fahrzeug-Thema – wichtig sind Technik, Alltag, Kosten und der Unterschied zur bisherigen Lösung."
    case .lifestyle:
      return
        "\(kern) ist das Thema – wir machen daraus einen konkreten, visuellen Guide mit klaren Entscheidungen statt allgemeiner Tipps."
    case .entertainment:
      return
        "\(kern) zieht Aufmerksamkeit – wir ordnen ein, was daran tatsächlich neu oder bemerkenswert ist."
    case .allgemein:
      return
        "\(kern) ist gerade relevant – wir ordnen ein, was dahintersteckt, was sicher ist und was noch offen bleibt."
    }
  }

  private static func szenenBlueprints(art: ThemenArt, kern: String, thema: String)
    -> [(String, String, String)]
  {
    let base: [(String, String, String)] = [
      (
        "Hook & Kernfrage",
        "Im Mittelpunkt steht \(kern). Wir klären, worum es bei \(thema) konkret geht und welche Frage dieses Video beantworten soll.",
        "Starker thematischer Opener zu \(thema), klare Schlagzeile, passendes Symbol oder abstraktes Motiv, keine fremden Logos als Hauptmotiv."
      ),
      (
        "Ausgangslage",
        "Der Ausgangspunkt ist ein aktuelles Signal rund um \(kern). Dieses Signal zeigt Aufmerksamkeit für das Thema, ersetzt aber keine unabhängige Faktenprüfung.",
        "Editoriale Einordnung mit Timeline, neutraler Grafik oder klar beschriftetem Kontext-Panel zu \(thema)."
      ),
      (
        "Was daran wichtig ist",
        "Relevant wird \(thema) dort, wo sich für Zuschauer ein konkreter Zusammenhang, eine beobachtbare Veränderung oder eine nachvollziehbare Konsequenz ergibt.",
        "Detailansicht oder erklärende Grafik, die exakt den im Satz beschriebenen Zusammenhang visualisiert."
      ),
      (
        "Kontext statt Hype",
        "Eine einzelne Schlagzeile reicht nicht für ein Urteil. Deshalb trennen wir bei \(kern) zwischen dem sichtbaren Signal, dem Hintergrund und Punkten, die noch verifiziert werden müssen.",
        "Dreiteilige Grafik: Signal, Kontext, offene Punkte; ruhige Motion, keine dramatisierende Fake-News-Optik."
      ),
      (
        "Was Zuschauer mitnehmen",
        "Der praktische Nutzen liegt darin, \(thema) schneller einordnen zu können: Was ist relevant, worauf sollte man achten und welche Behauptung braucht noch einen Beleg?",
        "Checkliste mit drei klaren Punkten, thematisch passende Icons und saubere Blackstock-Branding-Flächen."
      ),
      (
        "Gegencheck",
        "Bevor aus \(kern) eine endgültige Aussage wird, müssen Gegenpositionen, zeitliche Einordnung und mögliche Missverständnisse mitgedacht werden.",
        "Vergleichsansicht mit zwei Perspektiven und einem neutralen Prüfhinweis."
      ),
      (
        "Payoff",
        "Damit ist die Kernstory zu \(thema) klar: Das Thema ist relevant, aber gute Einordnung entsteht erst durch nachvollziehbare Belege und einen direkten Bezug zur eigentlichen Frage.",
        "Klares Abschlussmotiv mit der Kernfrage und einem prägnanten visuellen Payoff."
      ),
    ]

    switch art {
    case .gaming:
      return [
        base[0],
        (
          "Gameplay-Signal",
          "Bei \(kern) ist entscheidend, welcher Spielmoment, welches Update oder welche Mechanik tatsächlich beobachtbar ist – nicht nur die Reaktion darauf.",
          "Gameplay-nahe Visualisierung: HUD-freie Spielsituation, Controller-/Map-Metapher oder mechanische Ablaufgrafik passend zu \(thema)."
        ),
        (
          "Mechanik & Wirkung",
          "Wir betrachten, wie die beobachtete Mechanik das Spielgefühl, die Strategie oder den Ablauf verändert und für wen dieser Unterschied relevant ist.",
          "Vorher/Nachher- oder Mechanik-Diagramm, das den beschriebenen Unterschied sichtbar macht."
        ),
        base[3], base[4], base[5], base[6],
      ]
    case .politikNews:
      return [
        base[0],
        (
          "Was bestätigt ist",
          "Bei \(kern) müssen bestätigte Informationen klar von Kommentaren, Prognosen und noch offenen Punkten getrennt werden.",
          "Neutrale Nachrichten-Grafik mit Bereichen 'bestätigt' und 'offen'; keine parteiliche Bildsprache."
        ),
        (
          "Hintergrund",
          "Für die Einordnung von \(thema) ist der zeitliche und institutionelle Kontext wichtig. Aussagen außerhalb des vorhandenen Signals werden vor Veröffentlichung als [VERIFY] behandelt.",
          "Sachliche Timeline oder institutionelle Kontextgrafik, neutral und ohne politische Werbung."
        ),
        (
          "Warum es relevant ist",
          "Die Bedeutung des Themas hängt davon ab, welche konkrete Entscheidung, Zuständigkeit oder Folge tatsächlich betroffen ist – nicht von der Lautstärke der Debatte.",
          "Nüchterne Ursache-Wirkung-Grafik mit klaren Pfeilen und neutralen Symbolen."
        ),
        base[4], base[5], base[6],
      ]
    case .techAI:
      return [
        base[0],
        (
          "Technische Veränderung",
          "Bei \(kern) interessiert vor allem, was sich technisch gegenüber dem bisherigen Stand verändert und welche Fähigkeit dadurch real hinzukommt.",
          "Technische Schema-Grafik oder abstrakte Hardware/Software-Darstellung passend zu \(thema)."
        ),
        (
          "Praxisbezug",
          "Der Unterschied zählt erst dann, wenn er einen nachvollziehbaren Effekt auf Nutzung, Geschwindigkeit, Qualität oder Kosten hat.",
          "Praktischer Vorher/Nachher-Vergleich oder Workflow-Grafik."
        ),
        base[3], base[4], base[5], base[6],
      ]
    case .finanzen:
      return [
        base[0],
        (
          "Treiber",
          "Bei \(kern) schauen wir auf den Mechanismus hinter der Bewegung: Nachfrage, Erwartungen, Risiko und zeitlicher Kontext müssen getrennt betrachtet werden.",
          "Sachliche Finanzgrafik ohne Kaufaufforderung; Trendlinie, Faktoren und Risikohinweis."
        ),
        (
          "Risiko",
          "Eine einzelne Kurs- oder Nachrichtenbewegung ist keine Anlageempfehlung. Entscheidend ist, welche Annahmen bestätigt sind und welche Unsicherheit bleibt.",
          "Risiko-/Szenario-Grafik mit neutralen Wahrscheinlichkeitsflächen."
        ), base[3], base[4], base[5], base[6],
      ]
    case .business:
      return [
        base[0],
        (
          "Problem & Zielgruppe",
          "Bei \(kern) ist zuerst wichtig, welches konkrete Problem gelöst wird und für welche Zielgruppe \(thema) tatsächlich relevant ist.",
          "Klare Problem-Lösung-Grafik mit Zielgruppe, Ausgangssituation und messbarem Nutzen."
        ),
        (
          "Modell & Substanz",
          "Danach prüfen wir, wie das Angebot oder Geschäftsmodell funktioniert, welche Abhängigkeiten bestehen und woran sich echte Substanz erkennen lässt.",
          "Sachliches Business-Canvas mit Produkt, Nutzer, Erlöslogik und kritischen Abhängigkeiten."
        ), base[3], base[4], base[5], base[6],
      ]
    case .sport:
      return [
        base[0],
        (
          "Leistungssignal",
          "Bei \(kern) zählt, welche Leistung oder Veränderung tatsächlich beobachtet wurde und wie sie in den bisherigen Verlauf passt.",
          "Sportliche Performance-Grafik, Spielfeld-/Streckenmetapher oder neutrale Statistikdarstellung."
        ),
        (
          "Kontext",
          "Ein einzelner Moment erklärt selten die ganze Entwicklung. Form, Gegner, Bedingungen und Zeitpunkt gehören zur Einordnung.",
          "Kontextvergleich mit mehreren Einflussfaktoren."
        ), base[3], base[4], base[5], base[6],
      ]
    case .creator:
      return [
        base[0],
        (
          "Performance-Hebel",
          "Bei \(kern) ist entscheidend, welcher konkrete Hebel auf Klickrate, Retention oder Produktionsqualität wirkt.",
          "YouTube-artige, aber markenfreie Analytics-Grafik mit Hook, CTR und Retention als abstrahierten Elementen."
        ),
        (
          "Praxis",
          "Der sinnvollste Test ist eine klar messbare Änderung statt zehn gleichzeitiger Anpassungen.",
          "A/B-Test-Visualisierung mit zwei Varianten und einem klaren Messwert."
        ), base[3], base[4], base[5], base[6],
      ]
    case .wissenschaft:
      return [
        base[0],
        (
          "Was wurde untersucht?",
          "Bei \(kern) muss klar sein, welche Beobachtung oder Untersuchung hinter der Aussage steht und was daraus tatsächlich folgt.",
          "Forschungsnahe Grafik mit Frage, Methode und Ergebnis; keine erfundenen Messwerte."
        ),
        (
          "Ergebnis & Grenzen",
          "Ein Ergebnis ist nur so stark wie sein Kontext. Deshalb trennen wir bei \(thema) Befund, Interpretation und offene Grenzen.",
          "Dreiteilige Visualisierung: Befund, Einordnung, Grenzen."
        ), base[3], base[4], base[5], base[6],
      ]
    case .gesundheit:
      return [
        base[0],
        (
          "Praktischer Nutzen",
          "Bei \(kern) interessiert, welcher praktische Effekt plausibel ist und für wen der Ansatz überhaupt relevant sein kann.",
          "Ruhige Health-/Fitness-Grafik mit Alltagssituation, Ablauf und neutraler Nutzen-Einordnung."
        ),
        (
          "Grenzen & Sicherheit",
          "Gesundheitsbezogene Aussagen brauchen besonders saubere Grenzen. Unbelegte Wirkversprechen werden nicht als Tatsache dargestellt.",
          "Neutrale Checkliste mit Nutzen, Grenzen und Hinweis auf individuelle Unterschiede."
        ), base[3], base[4], base[5], base[6],
      ]
    case .mobilitaet:
      return [
        base[0],
        (
          "Technik & Alltag",
          "Bei \(kern) vergleichen wir die relevante Technik mit dem Alltag: Reichweite, Bedienung, Infrastruktur oder Effizienz müssen zum konkreten Thema passen.",
          "Technik-/Alltagsvergleich mit Fahrzeug-Silhouette, Route oder Energiefluss ohne fremde Markenlogos."
        ),
        (
          "Trade-offs",
          "Der Nutzen von \(thema) hängt von klaren Kompromissen ab. Deshalb zeigen wir Vorteile und Nachteile im selben Kontext.",
          "Zweiseitige Vergleichsgrafik mit Nutzen und Trade-offs."
        ), base[3], base[4], base[5], base[6],
      ]
    case .lifestyle:
      return [
        base[0],
        (
          "Konkrete Auswahl",
          "Bei \(kern) wird aus einem allgemeinen Thema erst dann ein gutes Video, wenn konkrete Optionen, Kriterien oder Schritte sichtbar werden.",
          "Visueller Guide mit drei klaren Optionen oder Stationen passend zu \(thema)."
        ),
        (
          "Praxis & Entscheidung",
          "Wir zeigen, welche Entscheidung in welcher Situation sinnvoll sein kann und welche Details Zuschauer vorher prüfen sollten.",
          "Praktische Checkliste oder Route mit Entscheidungspunkten und realistischen Alltagsszenen."
        ), base[3], base[4], base[5], base[6],
      ]
    case .wissen, .entertainment, .allgemein:
      return base
    }
  }

  private static func beschreibungFuer(art: ThemenArt, titel: String, thema: String, kanal: Kanal)
    -> String
  {
    let lead: String
    switch art {
    case .politikNews:
      lead =
        "In diesem Video ordnen wir \(titel) sachlich ein. Wir trennen bestätigte Informationen, Hintergrund und offene Fragen und zeigen, warum \(thema) gerade relevant ist."
    case .gaming:
      lead =
        "In diesem Video geht es konkret um \(titel). Wir schauen auf den beobachtbaren Spielmoment, die relevante Mechanik und darauf, was \(thema) für Spieler tatsächlich verändert."
    case .techAI:
      lead =
        "Dieses Video erklärt \(titel) mit Fokus auf die technische Veränderung, den praktischen Nutzen und die Punkte, die bei \(thema) oft zu kurz kommen."
    case .finanzen:
      lead =
        "Dieses Video ordnet \(titel) ein und erklärt die wichtigsten Treiber, Risiken und offenen Annahmen rund um \(thema). Keine Anlageberatung."
    case .business:
      lead =
        "Dieses Video analysiert \(titel) als Business-Thema und zeigt Problem, Zielgruppe, Modell, Nutzen und die wichtigsten offenen Annahmen rund um \(thema)."
    case .sport:
      lead =
        "Dieses Video analysiert \(titel) im sportlichen Kontext und zeigt, welche Leistungssignale und Rahmenbedingungen für \(thema) entscheidend sind."
    case .wissenschaft:
      lead =
        "Dieses Video ordnet \(titel) wissenschaftlich ein: Was wurde untersucht, was zeigt das Ergebnis tatsächlich und welche Grenzen sind bei \(thema) wichtig?"
    case .gesundheit:
      lead =
        "Dieses Video ordnet \(titel) mit Fokus auf praktischen Nutzen, Grenzen und belastbare Aussagen rund um \(thema) ein. Unbelegte Gesundheitsversprechen werden nicht als Fakten dargestellt."
    case .mobilitaet:
      lead =
        "Dieses Video erklärt \(titel) mit Fokus auf Technik, Alltag, Kosten und die entscheidenden Trade-offs bei \(thema)."
    case .lifestyle:
      lead =
        "Dieses Video macht \(titel) konkret: Optionen, Kriterien, praktische Schritte und die wichtigsten Entscheidungen rund um \(thema) stehen im Mittelpunkt."
    default:
      lead =
        "Dieses Video erklärt \(titel) und ordnet die wichtigsten Zusammenhänge rund um \(thema) verständlich und ohne unnötigen Hype ein."
    }
    return
      "\(lead)\n\nAuf \(kanal.name) stehen klare Einordnung, nachvollziehbare Aussagen und ein direkter Bezug zum eigentlichen Thema im Mittelpunkt. Aussagen, die noch nicht unabhängig bestätigt sind, werden vor Veröffentlichung überprüft."
  }

  private static func relevanteTags(
    art: ThemenArt, thema: String, kanal: Kanal, format: VideoFormat
  ) -> [String] {
    var values = [thema, kanal.thema, format.rawValue]
    switch art {
    case .gaming: values += ["Gaming", "Games"]
    case .politikNews: values += ["News", "Politik", "Einordnung"]
    case .techAI: values += ["Technologie", "KI"]
    case .finanzen: values += ["Finanzen", "Wirtschaft"]
    case .business: values += ["Business", "Startups"]
    case .sport: values += ["Sport", "Analyse"]
    case .creator: values += ["YouTube", "Creator"]
    case .wissen: values += ["Wissen", "Erklärung"]
    case .wissenschaft: values += ["Wissenschaft", "Forschung"]
    case .gesundheit: values += ["Gesundheit", "Fitness"]
    case .mobilitaet: values += ["Auto", "Mobilität"]
    case .lifestyle: values += ["Lifestyle", "Guide"]
    case .entertainment: values += ["Entertainment"]
    case .allgemein: values += ["Erklärung"]
    }
    var result: [String] = []
    for raw in values {
      let t = String(raw.trimmingCharacters(in: .whitespacesAndNewlines).prefix(30))
      if !t.isEmpty && !result.contains(where: { $0.caseInsensitiveCompare(t) == .orderedSame }) {
        result.append(t)
      }
    }
    return Array(result.prefix(12))
  }

  private static func thumbnailTextFuer(art: ThemenArt, thema: String, kern: String) -> String {
    let base = kern.isEmpty ? thema : kern
    let cleaned = base.replacingOccurrences(of: "|", with: " ")
    return String(cleaned.uppercased().prefix(46))
  }
}
