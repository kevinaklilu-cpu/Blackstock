# Blackstock 11.1.0 – Release Notes

**Build:** 1110

## 11.0.6 Build-Hotfix – Swift 6 Collection Overload

- `ChancenView.discoveryTerms` materialisiert deduplizierte Suchbegriffe jetzt explizit als `[String]`, bevor `prefix(24)` angewendet wird.
- Behebt den nativen Swift-Compilerfehler `ambiguous use of prefix` bei `Array(Set(terms)).prefix(24)`.
- Release-Audit blockiert das mehrdeutige `Array(Set(...)).prefix(...)`-Muster künftig vor dem eigentlichen App-Build.
- Auf macOS typprüft der Release-Audit jetzt zusätzlich die komplette App (alle Swift-Dateien), nicht nur Syntax und portable Services.

## 11.0.5 Build-Hotfix – YouTube Analytics

- Behebt einen Swift-Compilerfehler in `YouTubeService.swift` beim 403-Fallback der YouTube Analytics API.
- Der veraltete Aufruf `AnalyticsResponse(columnHeaders: nil, rows: nil)` wurde an das aktuelle Datenmodell `AnalyticsResponse(rows:)` angepasst.
- Der Revenue-403-Fallback bleibt semantisch unverändert: Blackstock markiert den Revenue-Zugriff als verboten und lädt die Tages-Analytics anschließend ohne Umsatzmetrik erneut.


## 11.0.4 Toolchain-/macOS-26-Hotfix

- Korrigiert alle expliziten Apple-Swift-Targets auf die kanonische Darwin-Form `arm64-apple-macosx13.0` bzw. `x86_64-apple-macosx13.0`.
- Installer, Release-Audit, Core-Tests, Release-Prüfung und nativer Build verwenden nun exakt dieselbe Target-Strategie.
- Fügt vor Release-Audit und Direkt-Build einen minimalen Foundation-Typecheck als Toolchain-Probe ein. Inkompatible oder veraltete Xcode/Command-Line-Tools werden dadurch mit konkreter Diagnose erkannt.
- Behebt den Installationspfad für Systeme, auf denen Swift sonst automatisch das Host-Target `arm64-apple-macosx26.0` wählt und dabei die Standardbibliothek nicht laden kann.
- Release-Version auf `11.0.4 / 1104` angehoben.

## 11.0.3 Hotfix

- Release-Preflight auf macOS SDK-aware Typechecking umgestellt.
- Swift-Compiler, aktives SDK und Deployment Target werden über `xcrun` ermittelt und explizit an `swiftc` übergeben.
- Verhindert den Preflight-Fehler `unable to load standard library for target arm64-apple-macosx26.0` auf neueren macOS-Versionen.
- Core-Tests, Release-Audit und nativer Build verwenden jetzt dieselbe Toolchain-/Target-Strategie.
- Installationsprotokoll enthält künftig Swift-Version, Developer Directory, SDK-Pfad und Preflight-Target.

## 11.0.2 Hotfix

- Behebt den nativen macOS-Compilerfehler in `RemoteMediaCacheService.cleanup`: `preserving` war nur das externe Argument-Label und wurde fälschlich als lokale Variable verwendet. Der lokale Parameter heißt jetzt explizit `preservedPaths`.
- `RemoteMediaCacheService` wird jetzt auch in der portablen Service-Typecheck-Grenze geprüft. Dafür ist `CryptoKit` auf unterstützten macOS-Systemen unverändert aktiv; nicht unterstützte Plattformen können die Datei trotzdem semantisch kompilieren.
- Die Speicherplatzprüfung verwendet eine portable Dateisystem-Abfrage; aktive Partial-Downloads und explizit erhaltene Cache-Dateien bleiben vom Cleanup ausgenommen.
- Der Ein-Klick-Installer führt vor dem Universal-Build einen semantischen Release-Preflight aus.
- Release-Version auf `11.0.2 / 1102` angehoben.

### 11.0.1 Hotfix

- Behebt den macOS-Compilerfehler beim Aufbau von `ChannelContentProfile` in `AppStore.swift`. Das Profil wird nun schrittweise initialisiert, sodass Änderungen der Property-Reihenfolge keinen Memberwise-Initializer-Buildfehler mehr auslösen.


Blackstock 11 ist ein grundlegender Produktumbau zum nativen YouTube Creator & Media Operations Center.

## Wichtigste Änderungen

- Existing-Media-First statt AI-first-Produktion.
- Strikte Trennung von YouTube `TrendReference` und tatsächlich nutzbarem `SourceAsset`.
- Rights-aware Source Pipeline mit Owned/Licensed/Public-Domain/CC/Unknown/Restricted und Auto-Publish-Blockern.
- Remote Media Cache mit Resume, Partial Files, Prüfsummen, Deduplizierung, Cancellation und sicherem Cleanup.
- Transkript-/Metadaten-basierte Clip-Analyse und Remix-Planung für Short, Longform und Single/Multi-Source.
- AVFoundation-Rendering aus einer validierten `RemixTimeline`.
- Finale Titel/Beschreibung/Tags/Kapitel erst nach feststehender Timeline.
- Thumbnail-Workflow auf Basis des tatsächlichen fertigen Videos; AI nur optionaler Fallback.
- Neue Production State Machine mit Checkpoints, Recovery und Bereit-Check statt abstrakten Quality-Scores.
- Multi-Google-Account/Multi-YouTube-Channel-Modell und kanalbezogene Content-DNA.
- Tagesbasierte Analytics mit klarer Zeitraumtrennung; Revenue nur bei vorhandenem monetären Zugriff.
- Resumable YouTube Upload mit persistierter Session/Offset/Video-ID und Doppelupload-Schutz.
- Review- und Auto-Publish-Modi mit kanalbezogenen Defaults.
- YouTube Live Vorbereitung plus echtes lokales RTMP-Playout ohne Fake-Live-Status.
- Hauptnavigation auf Übersicht, Trends, Produktionen, Inhalte, Analytics, Kanäle und Einstellungen reduziert.
- Einstellungen konsolidiert; AI Provider nur noch als optionaler Fallback unter Erweitert.
- v10→v11 Migration mit Pre-Migration-Snapshot.
- Gemeinsame lokale/CI-Testmatrix, Release Audit und zentrale Version `11.0.6 / 1106`.

## Bewusste Grenzen

- YouTube-Trendvideos werden nicht heruntergeladen oder gerippt.
- Exakter YPP-Bewerbungs-/Freigabestatus wird nicht erfunden, wenn die YouTube APIs ihn nicht liefern.
- Lizensierte Stock-/Media-Provider benötigen einen realen API-Adapter; die Abstraktion existiert, nicht vorhandene Provider werden nicht vorgetäuscht.
- FFmpeg wird für Live-Playout nicht gebündelt.
- Ein vollständiger Universal-Binary-/Codesign-/Launch-/Notarisierungs-Test benötigt macOS/Xcode.

## 11.1.0 — Standard-macOS-App-Verteilung

- Endnutzer-Installation ist jetzt DMG-first: `Blackstock.app` nach `Programme` ziehen; kein lokaler Swift-Build und keine `.command`-Installation mehr.
- Lokale Endnutzer-Installer (`Blackstock installieren.command`, `Blackstock reparieren.command`) wurden aus dem Release-Quellpaket entfernt.
- Developer-Buildskripte liegen ausschließlich unter `Build/` und tragen keine `.command`-Endung mehr.
- CI läuft auf dem offiziellen GitHub `macos-26`-Runner und erzeugt immer eine Universal-`Blackstock.app`, App-ZIP und Drag-and-Drop-DMG.
- Developer-ID-Signierung und Apple-Notarisierung werden automatisch aktiviert, sobald die vorgesehenen Repository-Secrets vorhanden sind.
- Getaggte, signierte Builds können direkt als GitHub Release mit DMG und Prüfsummen veröffentlicht werden.
