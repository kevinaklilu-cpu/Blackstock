# Blackstock 11.1.0 — CI-Status

Stand: 2026-09-14

- Endnutzer-Installation: DMG -> Blackstock.app -> Programme
- Kein Endnutzer-Build und kein `.command`-Installer
- GitHub Actions Runner: `macos-26`
- Portable Regression Suite: bestanden
- Swift-Parse aller 55 Quelldateien: bestanden
- Workflow-Secret-Bedingungen: GitHub-konform über `env` statt direkter `secrets`-Abfrage
- DMG- und App-ZIP-Artefakte werden auch ohne Apple-Developer-Secrets erzeugt
- Developer-ID-Signierung und Apple-Notarisierung werden automatisch aktiviert, wenn die Release-Secrets vorhanden sind

Der eigentliche AppKit/SwiftUI-Link-Build und die DMG-Erzeugung müssen auf macOS ausgeführt werden und sind Aufgabe des CI-Workflows.
