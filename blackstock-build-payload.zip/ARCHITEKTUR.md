# Blackstock v11 – Architektur

## Ziel

Blackstock ist eine native SwiftUI/AppKit/AVFoundation-Anwendung. Die v11-Architektur optimiert auf Stabilität, korrekte Daten, einen einfachen Workflow, Rights/Security und danach Automatisierung.

## Feature-Mapping

| Feature | Model | Store/State | Service | View | Persistenz | Tests |
|---|---|---|---|---|---|---|
| Accounts/Kanäle | `GoogleAccount`, `YouTubeChannelConnection`, `ChannelContentProfile` | `V11State` | `YouTubeService` | `KanalStudioView` | App state + Keychain | V11 Core/Release |
| Trends | `TrendReference`, `TopicTaxonomy` | `V11State` + Chancen | YouTube trend/search path | `ChancenView` | App state | V11 Core |
| Quellen/Rechte | `SourceAsset`, `RightsStatus` | production source IDs | `SourceConnectorProtocol`, `RightsService` | `ProduktionsDetailView` | v11 state + cache metadata | V11 Core/Release |
| Remix | `RemixSegment`, `RemixTimeline` | `ProductionV11State` | `ClipAnalysisService`, `RemixPlannerService` | Production Detail | v11 state | V11 Core/Release |
| Render | `RemixTimeline` | production checkpoint | `MasterVideoService` | Production Detail | managed files | Media/V11 tests |
| Publishing | `UploadRecord`, readiness | production state | YouTube resumable upload | Production Detail | v11 state | V11 Release |
| Analytics | `AnalyticsDailyPoint`, video performance | v11 analytics | YouTube Analytics | Dashboard/`WachstumView` | v11 state | V11 Core |
| Live | live IDs + production state | production state | YouTube Live + `LivePlayoutService` | Production Detail | state + stream key in Keychain | recovery checks |

## State Machine

`draft → discoveringSources → analyzingSources → planning → fetchingMedia → editing → rendering → review → ready → uploading → scheduled/published`

`failed` ist recoverable, sofern der fehlgeschlagene Schritt wiederholt werden kann. Persistierte Checkpoints verhindern Zombie-Jobs. Nach einem App-Neustart werden zuvor laufende lokale Jobs nicht fälschlich als weiterhin aktiv dargestellt.

## Rechtearchitektur

`TrendReference` ist Discovery/Metadata. `SourceAsset` ist Render-Material. Automatische Nutzung setzt einen erlaubten Rechtezustand voraus. Für lizenzierte/CC-Quellen werden Lizenzangabe, Edit/Publish und für Auto-Publishing kommerzielle Nutzung verlangt; Ablaufdatum und Attribution werden berücksichtigt. `unknown` und `restricted` blockieren.

## Remote Media

`RemoteMediaCacheService` arbeitet in Blackstocks verwaltetem Arbeitsbereich, nutzt Partial-Dateien, Range/Resume, Prüfsummen, Deduplizierung, Disk-Space-Prüfung, Cancellation und sicheren Cleanup. Cleanup verlässt das verwaltete Verzeichnis nicht und folgt keinen beliebigen Nutzerpfaden.

## YouTube

Google-Login und YouTube-Kanal sind getrennte Entitäten. Ein Login kann mehrere Kanäle liefern. Scopes werden featurebezogen erweitert: Basis-Lesen/Analytics zuerst, Upload, monetäre Analytics und Live nur bei Bedarf. Revenue bleibt unbekannt, wenn kein monetärer Analytics-Zugriff vorhanden ist.

Uploads verwenden resumable Sessions. Session-URL, Offset und YouTube Video ID werden persistiert, um Wiederaufnahme zu ermöglichen und Doppeluploads zu vermeiden.

## Live

YouTube Broadcast/Stream werden über die Live API vorbereitet. Tatsächliches RTMP-Playout wird nur über einen lokal vorhandenen Encoder gestartet. Blackstock setzt den Live-Zustand erst, wenn der Encoder gesendete Frames meldet. Fehlt der Encoder oder scheitert Ingest, gibt es keinen Fake-Live-Status.

## Sicherheit

- OAuth-Tokens, Provider-Secrets und Live Stream Keys: Keychain.
- Keine Secrets in App-State-JSON oder Logs.
- Keine YouTube-Downloads/Rips als Source-Mechanismus.
- Destruktiver Cleanup nur für Blackstock-Working-Files.
- Importierte/eigene Originalmedien werden beim Löschen eines Projekts nicht automatisch entfernt.
- Automatisches Publishing nur nach technischem und Rights-Bereit-Check.

## Plattformgrenze

Portable Swift-Regressionen und Syntax-/Release-Audits können plattformunabhängig laufen. SwiftUI/AppKit/AVFoundation-Linking, Universal Binary, Codesigning, Launch-Smoke-Test und Notarisierung müssen auf macOS geprüft werden. Die Build-/CI-Skripte führen diese Prüfungen dort aus.
