# Blackstock 11.1.0 installieren

Blackstock wird als normale macOS-Anwendung ausgeliefert. Auf dem Ziel-Mac wird **kein Quellcode kompiliert** und es muss **kein Terminal- oder `.command`-Skript** ausgeführt werden.

## Installation

1. `Blackstock-11.1.0-universal.dmg` öffnen.
2. `Blackstock.app` in den Ordner **Programme** ziehen.
3. DMG auswerfen.
4. Blackstock aus **Programme**, Spotlight oder Launchpad starten.

## Sicherheit

Der öffentliche Release soll mit einer Apple **Developer ID Application** signiert und über Apples Notary Service notarisiert werden. Dann verhält sich Blackstock wie eine regulär außerhalb des Mac App Store verteilte Mac-App.

Ein interner CI-Testbuild kann auch ad-hoc signiert werden. Dieser ist nur zum Testen gedacht und kann beim ersten Öffnen eine macOS-Sicherheitswarnung auslösen.

## Für Entwickler

Die Build-/Release-Skripte liegen ausschließlich unter `Build/`. Endnutzer führen diese Dateien nicht aus. Der macOS-Release wird auf einem macOS-26-CI-Runner gebaut und als fertige `.app`/`.dmg` veröffentlicht.
